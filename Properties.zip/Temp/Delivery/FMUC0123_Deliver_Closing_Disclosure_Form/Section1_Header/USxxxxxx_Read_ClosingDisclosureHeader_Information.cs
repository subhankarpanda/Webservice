﻿using FASTSelenium.Common;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Web_Services_Regression.Delivery.FMUC0123_Deliver_Closing_Disclosure_Form.Section1
{
    [CodedUITest]
    public class USxxxxxx_Read_ClosingDisclosureHeader_Information : FASTHelpers
    {
        [TestMethod]
        [Description("Verify CD ClosingDisclosureHeader - ClosingInformation using GetCDDetails web service")]
        public void Scenario_1_Get_CD_Header_ClosingInformation() 
        {
            try
            {
                Reports.TestDescription = "Verify CD ClosingDisclosureHeader - ClosingInformation using GetCDDetails web service";
                
                FAST_Init_File(salesPrice: (decimal)6000000, loanAmt: (decimal)1000000, GABRole: AdditionalRoleType.NewLender);

                #region Navigate to Outside Title Company and add GAB details
                Reports.TestStep = "Navigate to Outside Title Company and add GAB details";
                FastDriver.OutsideEscrowCompanyDetail.Open();
                FastDriver.OutsideEscrowCompanyDetail.FindGAB("501");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to Outside Escrow Company and add GAB details
                Reports.TestStep = "Navigate to Outside Escrow Company and add GAB details";
                FastDriver.OTCDetail.Open();
                FastDriver.OTCDetail.FindGAB("488");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to Closing Disclosure [ Delivery Options ]
                Reports.TestStep = "Navigate to Closing Disclosure [ Delivery Options ]";
                FastDriver.ClosingDisclosure.Open();
                FastDriver.ClosingDisclosure.DeliveryOptions.Click();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.InitialCD);
                FastDriver.ClosingDisclosure.InitialCD.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.LenderIssueProvided.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.DateIssuedtxt);
                FastDriver.ClosingDisclosure.DateIssuedtxt.FASetText(DateTime.Today.ToDateString());
                FastDriver.ClosingDisclosure.ClosingDatetxt.FASetText(DateTime.Today.AddDays(7).ToDateString());
                FastDriver.ClosingDisclosure.DisbursementDatetxt.FASetText(DateTime.Today.AddDays(28).ToDateString());
                FastDriver.ClosingDisclosure.DeliveryMethod.FASelectItem("Imagedoc");
                FastDriver.ClosingDisclosure.DeliveryButton.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Image Doc", true, 15);
                Keyboard.SendKeys("%I");
                FastDriver.WebDriver.WaitForWindowAndSwitch("Message", true, 15);
                Keyboard.SendKeys("{TAB}{ENTER}");
                FastDriver.WebDriver.WaitForDeliveryWindow("Imagedoc");
                #endregion

                #region Verify CD ClosingDisclosureHeader - ClosingInformation with GetCDDetails()
                Reports.TestStep = "Verify CD ClosingDisclosureHeader - ClosingInformation with GetCDDetails()";
                FastDriver.ClosingDisclosure.Open();
                var request = CDRequestFactory.GetCDRequest(File.FileID, FASTWCFHelpers.FastClosingDisclosureService.eCDFilterSection.HeaderInformation);
                var details = ClosingDisclosureService.GetCDDetails(request);
                Support.AreEqual("1", details.Status.ToString(), details.StatusDescription);
                Support.AreEqual(DateTime.Today.ToDateString(), ((DateTime)details.ClosingDisclosureHeader.IssuedDate).ToDateString(), ".ClosingDisclosureHeader.IssuedDate");
                Support.AreEqual(DateTime.Today.AddDays(7).ToDateString(), ((DateTime)details.ClosingDisclosureHeader.ClosingDate).ToDateString(), ".ClosingDisclosureHeader.ClosingDate");
                Support.AreEqual(DateTime.Today.AddDays(28).ToDateString(), ((DateTime)details.ClosingDisclosureHeader.DisbursementDate).ToDateString(), ".ClosingDisclosureHeader.DisbursementDate");
                Support.AreEqual("*QA Automation Office - DO NOT", details.ClosingDisclosureHeader.DisplaySettlementAgentName, "DisplaySettlementAgentName");
                Support.AreEqual("Santa Ana, CA", details.ClosingDisclosureHeader.DisplayPropertyCSZ, "DisplayPropertyCSZ");
                Support.AreEqual("$6,000,000", details.ClosingDisclosureHeader.PropertyValue, "DisplayPropertyValue");
                Support.IsTrue(details.ClosingDisclosureHeader.SettlementAgentColl.Count() > 2, "ClosingDisclosureHeader.SettlementAgentColl.Count() > 2");
                #endregion
            }
            catch(Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify CD ClosingDisclosureHeader - TransactionalInformation using GetCDDetails web service")]
        public void Scenario_2_Get_CD_Header_TransactionInformation()
        {
            try
            {
                Reports.TestDescription = "Verify CD ClosingDisclosureHeader - TransactionalInformation using GetCDDetails web service";

                FAST_Init_File(salesPrice: (decimal)6000000, loanAmt: (decimal)1000000, GABRole: AdditionalRoleType.NewLender);

                #region Add new Buyer in FAST
                Reports.TestStep = "Add new Buyer in FAST";
                FastDriver.BuyerSellerSetup.Open(isBuyer: true);
                FastDriver.BuyerSellerSetup.SetIndividual(new FASTSelenium.DataObjects.IIS.BuyerParameters
                {
                    First = "Homer",
                    Last = "Simpson",
                    SSN = "111111111",
                });
                FastDriver.BottomFrame.Done();
                #endregion

                #region Add new Seller in FAST
                Reports.TestStep = "Add new Seller in FAST";
                FastDriver.BuyerSellerSetup.Open(isBuyer: false);
                FastDriver.BuyerSellerSetup.SetIndividual(new FASTSelenium.DataObjects.IIS.BuyerParameters
                {
                    First = "Marsh",
                    Last = "Simpson",
                    SSN = "222222222",
                });
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify CD ClosingDisclosureHeader - TransactionalInformation with GetCDDetails()
                Reports.TestStep = "Verify CD ClosingDisclosureHeader - TransactionalInformation with GetCDDetails()";
                FastDriver.ClosingDisclosure.Open();
                var request = CDRequestFactory.GetCDRequest(File.FileID, FASTWCFHelpers.FastClosingDisclosureService.eCDFilterSection.HeaderInformation);
                var details = ClosingDisclosureService.GetCDDetails(request);
                Support.AreEqual("1", details.Status.ToString(), details.StatusDescription);
                Support.AreEqual("Homer Simpson", details.ClosingDisclosureHeader.BorrowerName, "ClosingDisclosureHeader.BorrowerName");
                Support.AreEqual("Marsh Simpson", details.ClosingDisclosureHeader.SellerName, "ClosingDisclosureHeader.SellerName");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify CD ClosingDisclosureHeader - LoanInformation using GetCDDetails web service")]
        public void Scenario_3_Get_CD_Header_LoanInformation()
        {
            try
            {
                Reports.TestDescription = "Verify CD ClosingDisclosureHeader - LoanInformation using GetCDDetails web service";

                FAST_Init_File(salesPrice: (decimal)6000000, loanAmt: (decimal)1000000, GABRole: AdditionalRoleType.NewLender);

                #region Modify CD header for Loan Information
                Reports.TestStep = "Modify CD header for Loan Information";
                FastDriver.ClosingDisclosure.Open();
                //
                FastDriver.ClosingDisclosure.LoanTermPlus.FAClick();
                FastDriver.ClosingDisclosure.LoanTermYearMonthRdobtn.FAClick();
                FastDriver.ClosingDisclosure.LoanTermYearTextbox.FASetText("5");
                FastDriver.ClosingDisclosure.LoanTermMonthTextbox.FASetText("0");
                FastDriver.ClosingDisclosure.LoanTermDone.FAClick();
                //
                FastDriver.ClosingDisclosure.imgLoanProduct.FAClick();
                FastDriver.ClosingDisclosure.LoanProductTypeCDID.FASelectItem("Step Rate");
                FastDriver.ClosingDisclosure.btnLoanProductDone.FAClick();
                FastDriver.WebDriver.WaitForAlertToExist(timeoutSeconds: 5);
                Support.AreEqual("Index + Margin values in AIR Table will be removed. Continue?", FastDriver.WebDriver.SwitchTo().Alert().Text);
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: true, clickAcceptButton: true);
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                //
                FastDriver.ClosingDisclosure.LoanTypeOthers.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.LoanType.FASelectItem("Mortgage");
                FastDriver.ClosingDisclosure.LoantypeDone.FAClick();
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                //
                FastDriver.ClosingDisclosure.LoanIDValue.FASetText("12344321", continueOnFailure: true);
                FastDriver.ClosingDisclosure.MICValue.FASetText("43211234", continueOnFailure: true);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify CD ClosingDisclosureHeader - LoanInformation with GetCDDetails()
                Reports.TestStep = "Verify CD ClosingDisclosureHeader - LoanInformation with GetCDDetails()";
                FastDriver.ClosingDisclosure.Open();
                var request = CDRequestFactory.GetCDRequest(File.FileID, FASTWCFHelpers.FastClosingDisclosureService.eCDFilterSection.HeaderInformation);
                var details = ClosingDisclosureService.GetCDDetails(request);
                Support.AreEqual("1", details.Status.ToString(), details.StatusDescription);
                Support.AreEqual("5 years", details.ClosingDisclosureHeader.DisplayLoanTerm, "DisplayLoanTerm");
                Support.AreEqual("Purchase", details.ClosingDisclosureHeader.DisplayLoanPurpose, "DisplayLoanPurpose");
                Support.AreEqual("Step Rate", details.ClosingDisclosureHeader.DisplayLoanProduct1, "DisplayLoanProduct1");
                Support.AreEqual("Other - Mortgage", details.ClosingDisclosureHeader.DisplayLoanType, "DisplayLoanType");
                Support.AreEqual("12344321", details.ClosingDisclosureHeader.DisplayLoanID, "DisplayLoanID");
                Support.AreEqual("43211234", details.ClosingDisclosureHeader.DisplayMICNum, "DisplayMICNum");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
