﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.Delivery.FMUC0123_Deliver_Closing_Disclosure_Form.Section1
{
    [CodedUITest]
    public class USxxxxxx_Update_ClosingDisclosureHeader_Information : FASTHelpers
    {
        [TestMethod]
        [Description("Verify update CD ClosingDisclosureHeader - ClosingInformation - Settlement Agent using UpdateCDDetails web service")]
        public void Scenario_1_Update_CD_Header_ClosingInformation()
        {
            try
            {
                Reports.TestDescription = "Verify update CD ClosingDisclosureHeader - ClosingInformation - Settlement Agent using UpdateCDDetails web service";

                FAST_Init_File(salesPrice: (decimal)6000000, loanAmt: (decimal)1000000, GABRole: AdditionalRoleType.NewLender);

                #region Navigate to Outside Title Company and add GAB details
                Reports.TestStep = "Navigate to Outside Title Company and add GAB details";
                FastDriver.OutsideEscrowCompanyDetail.Open();
                FastDriver.OutsideEscrowCompanyDetail.FindGAB("501");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to Outside Escrow Company and add GAB details
                Reports.TestStep = "Navigate to Outside Escrow Company and add GAB details";
                FastDriver.OTCDetail.Open();
                FastDriver.OTCDetail.FindGAB("488");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Update CD Closing Information - Settlement Agent with UpdateCDDetails()
                Reports.TestStep = "Update CD Closing Information - Settlement Agent with UpdateCDDetails()";
                var request = CDRequestFactory.GetCDRequest(File.FileID, FASTWCFHelpers.FastClosingDisclosureService.eCDFilterSection.HeaderInformation);
                var details = ClosingDisclosureService.GetCDDetails(request);
                Support.AreEqual("1", details.Status.ToString(), details.StatusDescription);
                var updateReq = CDRequestFactory.GetUpdateCDDetailsRequest(File.FileID);
                updateReq.ClosingDisclosure.ClosingDisclosureHeader = new FASTWCFHelpers.FastClosingDisclosureService.ClosingDisclosureHeader()
                {
                    SettlementAgentID = details.ClosingDisclosureHeader.SettlementAgentColl[1].FileBusinessPartyID,
                };
                var response = ClosingDisclosureService.UpdateCDDetails(updateReq);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Verify CD Closing Information - Settlement Agent changed in FAST
                Reports.TestStep = "Verify CD Closing Information - Settlement Agent changed in FAST";
                FastDriver.ClosingDisclosure.Open();
                Support.IsTrue(FastDriver.ClosingDisclosure.SettlementAgentValue.FAGetText().Contains("Principal Residential"), "SettlementAgentValue contains 'Principal Residential'");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify update CD ClosingDisclosureHeader - TransactionInformation using UpdateCDDetails web service")]
        public void Scenario_2_Update_CD_Header_TransactionInformation()
        {
            try 
            {
                Reports.TestDescription = "Verify update CD ClosingDisclosureHeader - TransactionInformation using UpdateCDDetails web service";
                
                FAST_Init_File();

                #region Add new Buyer in FAST
                Reports.TestStep = "Add new Buyer in FAST";
                FastDriver.BuyerSellerSetup.Open(isBuyer: true);
                FastDriver.BuyerSellerSetup.SetIndividual(new FASTSelenium.DataObjects.IIS.BuyerParameters
                {
                    First = "Homer",
                    Last = "Simpson",
                    SSN = "111111111",
                });
                FastDriver.BottomFrame.Done();
                FastDriver.BuyerSellerSummary.Open(true);
                FastDriver.BuyerSellerSummary.btnNew.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.SetIndividual(new FASTSelenium.DataObjects.IIS.BuyerParameters
                {
                    First = "Bart",
                    Last = "Simpson",
                    SSN = "",
                });
                FastDriver.BottomFrame.Done();
                #endregion

                #region Add new Seller in FAST
                Reports.TestStep = "Add new Seller in FAST";
                FastDriver.BuyerSellerSetup.Open(isBuyer: false);
                FastDriver.BuyerSellerSetup.SetIndividual(new FASTSelenium.DataObjects.IIS.BuyerParameters
                {
                    First = "Marsh",
                    Last = "Simpson",
                    SSN = "222222222",
                });
                FastDriver.BottomFrame.Done();
                FastDriver.BuyerSellerSummary.Open(false);
                FastDriver.BuyerSellerSummary.btnNew.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.SetIndividual(new FASTSelenium.DataObjects.IIS.BuyerParameters
                {
                    First = "Lisa",
                    Last = "Simpson",
                    SSN = "",
                });
                FastDriver.BottomFrame.Done();
                #endregion

                #region Update CD ClosingDisclosureHeader - TransactionInformation with UpdateCDDetails()
                Reports.TestStep = "Update CD ClosingDisclosureHeader - TransactionInformation with UpdateCDDetails()";
                var request = CDRequestFactory.GetCDRequest(File.FileID, FASTWCFHelpers.FastClosingDisclosureService.eCDFilterSection.HeaderInformation);
                var details = ClosingDisclosureService.GetCDDetails(request);
                Support.AreEqual("1", details.Status.ToString(), details.StatusDescription);
                var updateReq = CDRequestFactory.GetUpdateCDDetailsRequest(File.FileID);
                updateReq.ClosingDisclosure.ClosingDisclosureHeader = new FASTWCFHelpers.FastClosingDisclosureService.ClosingDisclosureHeader()
                {
                    BorrowerColl = details.ClosingDisclosureHeader.BorrowerColl,
                    SellerColl = details.ClosingDisclosureHeader.SellerColl,
                };
                updateReq.ClosingDisclosure.ClosingDisclosureHeader.BorrowerColl[0].IsLoanApplicant = 0;
                updateReq.ClosingDisclosure.ClosingDisclosureHeader.BorrowerColl[1].PrimaryPhyAddrTypeCdID = 120;
                updateReq.ClosingDisclosure.ClosingDisclosureHeader.SellerColl[0].PrimaryPhyAddrTypeCdID = 120;
                var response = ClosingDisclosureService.UpdateCDDetails(updateReq);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Verify CD Transaction Information - Borrower and Seller details changed in FAST
                Reports.TestStep = "Verify CD Transaction Information - Borrower and Seller details changed in FAST";
                FastDriver.ClosingDisclosure.Open();
                Support.AreEqual("Bart Simpson", FastDriver.ClosingDisclosure.BorrowerName.FAGetText(), "Borrower");
                Support.AreEqual("Santa Ana, CA", FastDriver.ClosingDisclosure.lblBorrowerCSZ.FAGetText(), "Borrower Address");
                Support.AreEqual("*Marsh Simpson", FastDriver.ClosingDisclosure.SellerName.FAGetText(), "Seller");
                Support.AreEqual("", FastDriver.ClosingDisclosure.lblSellerCSZ.FAGetText(), "Seller Address");
                #endregion
            }
            catch(Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify update CD ClosingDisclosureHeader - LoanInformation using UpdateCDDetails web service")]
        public void Scenario_3_Update_CD_Header_LoanInformation()
        {
            try
            {
                Reports.TestDescription = "Verify update CD ClosingDisclosureHeader - LoanInformation using UpdateCDDetails web service";

                FAST_Init_File(GABRole:AdditionalRoleType.NewLender);

                #region Update CD ClosingDisclosureHeader - TransactionInformation with UpdateCDDetails()
                Reports.TestStep = "Update CD ClosingDisclosureHeader - TransactionInformation with UpdateCDDetails()";
                var request = CDRequestFactory.GetCDRequest(File.FileID, FASTWCFHelpers.FastClosingDisclosureService.eCDFilterSection.HeaderInformation);
                var details = ClosingDisclosureService.GetCDDetails(request);
                Support.AreEqual("1", details.Status.ToString(), details.StatusDescription);
                var updateReq = CDRequestFactory.GetUpdateCDDetailsRequest(File.FileID);
                updateReq.ClosingDisclosure.ClosingDisclosureHeader = new FASTWCFHelpers.FastClosingDisclosureService.ClosingDisclosureHeader()
                {
                    LoanTermYear = 5,
                    LoanTermMonth = 6,
                    LoanProductTypeCDID = 2570,
                    LoanPurposeTypeCDID = 2573,
                    LoanType = "Mortgage",
                    LoanTypeOthers = true,
                    LoanID = "12344321",
                    MIC = "43211234",
                    NewLoanTypeCDID = 980,
                };
                var response = ClosingDisclosureService.UpdateCDDetails(updateReq);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Verify CD Loan Informtion details is updated in FAST
                Reports.TestStep = "Verify CD Loan Informtion details is updated in FAST";
                FastDriver.ClosingDisclosure.Open();
                Support.AreEqual("5 yr. 6 mo.", FastDriver.ClosingDisclosure.LoanTermValue.FAGetText(), "LoanTermValue");
                Support.AreEqual("Construction", FastDriver.ClosingDisclosure.LoanPurpose.FAGetText(), "LoanPurpose");
                Support.AreEqual("Fixed Rate", FastDriver.ClosingDisclosure.LoanInfo_Product1_lbl.FAGetText(), "LoanProduct");
                Support.AreEqual("Other - Mortgage", FastDriver.ClosingDisclosure.LoanTypeOthersValue.FAGetText(), "LoanTypeOthersValue");
                Support.AreEqual("12344321", FastDriver.ClosingDisclosure.lblLoanId.FAGetText(), "LoanID");
                Support.AreEqual("43211234", FastDriver.ClosingDisclosure.MICValue1.FAGetText(), "MIC");
                #endregion
            }
            catch(Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
