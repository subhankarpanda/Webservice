﻿using FASTSelenium.Common;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.Delivery.FMUC0123_Deliver_Closing_Disclosure_Form.LoanCalculations
{
    [CodedUITest]
    public class US290276_Update_CD_Loan_Calculations_Details : FASTHelpers
    {
        [TestMethod]
        [Description("Verify update Closing Disclosure - Loan Calculations information using UpdateCDDetails web service")]
        public void Scenario_1_Update_CD_Loan_Calculations_Details()
        {
            try
            {
                Reports.TestDescription = "Verify update Closing Disclosure - Loan Calculations information using UpdateCDDetails web service";

                FAST_Init_File(GABRole: AdditionalRoleType.NewLender, loanAmt: 1500000, salesPrice: 1350000);

                #region Update CD Loan Calculations information using UpdateCDDetails()
                Reports.TestStep = "Update CD Loan Calculations information using UpdateCDDetails()";
                var request = CDRequestFactory.GetCDLoanCalculationsRequest(File.FileID ?? 0);
                request.ClosingDisclosure.LoanCalculations.AmountFinanced = 1200000;
                request.ClosingDisclosure.LoanCalculations.AnnualPercentageRate = 9;
                request.ClosingDisclosure.LoanCalculations.FinanceCharge = 30000;
                request.ClosingDisclosure.LoanCalculations.TotalInterestPercentage = (decimal)12.75;
                request.ClosingDisclosure.LoanCalculations.TotalOfPayments = 1400000;
                var response = ClosingDisclosureService.UpdateCDDetails(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Verify CD Loan Calculations information using UpdateCDDetails()
                Reports.TestStep = "Verify CD Loan Calculations information using UpdateCDDetails()";
                FastDriver.ClosingDisclosure.Open();
                FastDriver.ClosingDisclosure.Loan_Calculations.Click();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.Loan_Calculations_table);
                Support.AreEqual("$1,400,000.00", FastDriver.ClosingDisclosure.TotalofPayments.Text, "TotalofPayments");
                Support.AreEqual("$30,000.00", FastDriver.ClosingDisclosure.FinanceCharge.Text, "FinanceCharge");
                Support.AreEqual("$1,200,000.00", FastDriver.ClosingDisclosure.AmountFinanced.Text, "AmountFinanced");
                Support.AreEqual("9%", FastDriver.ClosingDisclosure.AnnualPercentageRate.Text, "AnnualPercentageRate");
                Support.AreEqual("12.75%", FastDriver.ClosingDisclosure.TotalInterestPercentage.Text, "TotalInterestPercentage");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
