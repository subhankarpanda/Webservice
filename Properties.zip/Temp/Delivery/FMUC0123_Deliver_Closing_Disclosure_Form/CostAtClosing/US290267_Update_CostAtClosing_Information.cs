﻿using FASTSelenium.Common;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.Delivery.FMUC0123_Deliver_Closing_Disclosure_Form.CostAtClosing
{
    [CodedUITest]
    public class US290267_Update_CostAtClosing_Information : FASTHelpers
    {
        [TestMethod]
        [Description("Verify update Closing Disclosure - Costs At Closing information using UpdateCDDetails web service")]
        public void Scenario_1_Update_CostsAtClosing_Details()
        {
            try
            {
                Reports.TestDescription = "Verify update Closing Disclosure - Costs At Closing information using UpdateCDDetails web service";

                FAST_Init_File();

                #region Update Closing Disclosure - Costs At Closing with UpdateCDDetails()
                Reports.TestStep = "Update Closing Disclosure - Costs At Closing with UpdateCDDetails()";
                var updateReq = CDRequestFactory.GetUpdateCDDetailsRequest(File.FileID);
                updateReq.ClosingDisclosure.CostAtClosing = new FASTWCFHelpers.FastClosingDisclosureService.ClosingDisclosureCostAtClosingSection()
                {
                    CashToClose = "this is an statement.",
                    ClosingCostDisplayText1 = "BorrowerCostAtClosing",
                    ClosingCostDisplayText2 = "SectionIBorrowerPaidAmt",
                    ClosingCostDisplayText3 = "BorrowerLenderCredits",
                    ClosingCostDisplayText4 = "and more...",

                };
                var response = ClosingDisclosureService.UpdateCDDetails(updateReq);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Verify updates to Closing Disclosure - Cost At Closing statements
                Reports.TestStep = "Verify updates to Closing Disclosure - Cost At Closing statements";
                FastDriver.ClosingDisclosure.Open();
                FastDriver.ClosingDisclosure.Costs_at_Closing.FAClick();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.Section4_CostsatClosing_ClosingCostsAmount);
                Support.AreEqual("BorrowerCostAtClosing $0 SectionIBorrowerPaidAmt $0 BorrowerLenderCredits $0 and more...", FastDriver.ClosingDisclosure.Section4_CostsatClosing_ClosingCostsStatementCell.FAGetText(), "Section4_CostsatClosing_ClosingCostsStatementCell");
                Support.AreEqual("this is an statement.", FastDriver.ClosingDisclosure.CashtoCloseStatement.FAGetText(), "CashtoCloseStatement");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
