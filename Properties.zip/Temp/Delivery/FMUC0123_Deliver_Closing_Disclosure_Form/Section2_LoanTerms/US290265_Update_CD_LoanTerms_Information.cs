﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.Delivery.FMUC0123_Deliver_Closing_Disclosure_Form.LoanTerms
{
    [CodedUITest]
    public class US290265_Update_CD_LoanTerms_Information : FASTHelpers
    {
        [TestMethod]
        [Description("Verify update Closing Disclosure - Loan Terms information using UpdateCDDetails web service")]
        public void Scenario_1_Update_LoanTerms_Details()
        {
            try
            {
                Reports.TestDescription = "Verify update Closing Disclosure - Loan Terms information using UpdateCDDetails web service";

                FAST_Init_File(LenderID: "415", loanAmt: (decimal)1000000);

                #region Update Closing Disclosure - Loan Terms details with UpdateCDDetails()
                Reports.TestStep = "Update Closing Disclosure - Loan Terms details with UpdateCDDetails()";
                var updateReq = CDRequestFactory.GetUpdateCDDetailsRequest(File.FileID);
                updateReq.ClosingDisclosure.ClosingDisclosureLoanTerm = new FASTWCFHelpers.FastClosingDisclosureService.ClosingDisclosureLoanTerm()
                {
                    BalloonLoanMaturityPeriodCount = "5",
                    BallonPaymentCanIncrease = FASTWCFHelpers.FastClosingDisclosureService.LoanTermAmountIncrease.Yes,
                    BalloonPaymentAmount = "50000.00",
                    BalloonPaymentLoanTermClauseID = 0,
                    BalloonPaymentClauses = "<ul><li id=\"25881\">You will have to pay <strong>$50,000.00</strong> at the end of year</li></ul>",
                    CanInterestRateIncrease = FASTWCFHelpers.FastClosingDisclosureService.LoanTermAmountIncrease.Yes,
                    CanLoanAmountIncrease = FASTWCFHelpers.FastClosingDisclosureService.LoanTermAmountIncrease.Yes,
                    CeilingRatePercentEarliestEffectiveYearsCount = "5",
                    FirstPrincipalAndInterestPaymentChangeYearsCount = "1",
                    InterestRate = 14,
                    InterestRateAdjustEveryYear = "1",
                    InterestRateCanIncrease = "2585",
                    InterestRateCeilingRatePercent = "19",
                    InterestRateFirstRateChangeYearsCount = "1",
                    InterestRateLoanTermClauseID = 0,
                    InterestRateClauses = "<ul><li id=\"25851\">Adjusts <strong>every 1 year(s) </strong>starting in year 1</li><li id=\"25852\">Can go <strong>as high as </strong><strong>19%</strong> in year 5</li></ul>",
                    IsAPTableForPrincipleInterest = false,
                    IsAirTableForInterestRate = false,
                    IsRequiredSectionSave = false,
                    LoanAmount = (decimal)1000000.00,
                    LoanAmountCanGoAsHighAsIndicator = 1,
                    LoanAmountCanIncrease = "2584",
                    LoanAmountCanIncreaseAsHighAsIndicator = 1,
                    LoanAmountGoesAsHighAsIndicator = 0,
                    LoanAmountIncreasesAsHighAsIndicator = 0,
                    LoanAmountLoanTermClauseID = 0,
                    LoanAmountClauses = "<ul><li id=\"25841\">Can go&nbsp;<strong>as high as</strong>&nbsp;<strong>$2,000,000.00</strong></li><li id=\"25842\"><strong>Can increase</strong>&nbsp;until year&nbsp;5</li></ul>",
                    LoanTermsInterestTypeCDID = 2649,
                    LoanWithBalloonPaymentFeature = "2588",
                    LoanWithPrepaymentPenaltyFeature = "2587",
                    MonthlyPrincipalInterest = (decimal)100000.00,
                    NegativeAmortizationLimitYearsCount = "5",
                    NegativeAmortizationMaximumLoadBalanceAmount = "2000000.00",
                    PerChangePrincipalInterestPaymentAdjustFrequencyYearsCount = "1",
                    PredefinedClauseIDsBalloonPayment = "25881|",
                    PredefinedClauseIDsInterestRate = "25851|25852|",
                    PredefinedClauseIDsLoanAmount = "25841|25842",
                    PredefinedClauseIDsPrepaymentPenalty = "25871|",
                    PredefinedClauseIDsPrincipalandInterest = "25861|25862|",
                    PrePaymentPenaltyCanIncrease = FASTWCFHelpers.FastClosingDisclosureService.LoanTermAmountIncrease.Yes,
                    PrepaymentPenaltyExpirationYearsCount = "2",
                    PrepaymentPenaltyLoanTermClauseID = 0,
                    PrepaymentPenaltyClauses = "<ul><li id=\"25871\"><strong>As high as $110,000.00</strong> if you pay off the loan during the first 2 year(s)</li></ul>",
                    PrepaymentPenaltyMaximumLifeOfLoanAmount = "110000.00",
                    PrincipalAndInterestCanIncrease = FASTWCFHelpers.FastClosingDisclosureService.LoanTermAmountIncrease.Yes,
                    PrincipalAndInterestPaymentMaximumAmount = "150000.00",
                    PrincipalAndInterestPaymentMaximumAmountEarliestEffectiveYearsCount = "5",
                    PrincipalInterestCanIncrease = "2586",
                    PrincipalInterestTerm = 0,
                    PrincipalandInterestLoanTermClauseID = 0,
                    PrincipalandInterestClauses = "<ul><li id=\"25861\">Adjusts <strong>every 1 year(s) </strong>starting in year 1</li><li id=\"25862\">Can go <strong>as high as </strong><strong>$150,000.00</strong> in year 5</li></ul>"
                };
                var response = ClosingDisclosureService.UpdateCDDetails(updateReq);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion
                
                #region Verify Closing Disclosure - Loan Terms updates in FAST
                Reports.TestStep = "Verify Closing Disclosure - Loan Terms updates in FAST";
                FastDriver.ClosingDisclosure.Open();
                FastDriver.ClosingDisclosure.Section2_LoanTerms.Click();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.Section2_LoanTerms_LoanAmountValue);
                //  Loan Amount
                Support.AreEqual("$1,000,000", FastDriver.ClosingDisclosure.Section2_LoanTerms_LoanAmountValue.Text, "Section2_LoanTerms_LoanAmountValue");
                Support.AreEqual("YES", FastDriver.ClosingDisclosure.Section2_LoanTerms_LoanAmountDropdown.FAGetSelectedItem(), "Section2_LoanTerms_LoanAmountDropdown");
                Support.Match("Can go as high as \\$2,000,000\\.00", FastDriver.ClosingDisclosure.CustomClauseSpan.FAGetText(), "Loan Amount Clause text1");
                Support.Match("Can increase until year 5", FastDriver.ClosingDisclosure.CustomClauseSpan.FAGetText(), "Loan Amount Clause text2");
                //  Interest Rate
                Support.AreEqual("14%", FastDriver.ClosingDisclosure.Section2_LoanTerms_InterestRateValue.FAGetText(), "Section2_LoanTerms_InterestRateValue");
                Support.AreEqual("YES", FastDriver.ClosingDisclosure.Section2_LoanTerms_InterestRateDropdown.FAGetSelectedItem(), "Section2_LoanTerms_InterestRateDropdown");
                Support.Match("Adjusts every 1 year\\(s\\) starting in year 1", FastDriver.ClosingDisclosure.LoanTerms_InterestRateClause.FAGetText(), "Interest Rate Clause text1");
                Support.Match("Can go as high as 19% in year 5", FastDriver.ClosingDisclosure.LoanTerms_InterestRateClause.FAGetText(), "Interest Rate Clause text2 ");
                //  Principal & Interest
                FastDriver.ClosingDisclosure.Section2_LoanTerms_MonthlyPlusIcon.Click();
                Support.AreEqual("At Maturity", FastDriver.ClosingDisclosure.Section2_LoanTerms_MonthlyDropDown.FAGetSelectedItem(), "Section2_LoanTerms_MonthlyDropDown");
                FastDriver.ClosingDisclosure.Section2_LoanTerms_MonthlyPopupDone.Click();
                Support.AreEqual("$100,000.00", FastDriver.ClosingDisclosure.Section2_LoanTerms_MonthlyPrincipalValue.FAGetText(), "Section2_LoanTerms_MonthlyPrincipalValue");
                Support.AreEqual("YES", FastDriver.ClosingDisclosure.Section2_LoanTerms_MonthlyPrincipalDropdown.FAGetSelectedItem(), "Section2_LoanTerms_MonthlyPrincipalDropdown");
                Support.Match("Adjusts every 1 year\\(s\\) starting in year 1", FastDriver.ClosingDisclosure.LoanTerms_PrincipalAndInterestClause.FAGetText(), "Principal & Interest Clause text1");
                Support.Match("Can go as high as \\$150,000\\.00 in year 5", FastDriver.ClosingDisclosure.LoanTerms_PrincipalAndInterestClause.FAGetText(), "Principal & Interest Clause text2");
                //  Prepayment Penalty
                Support.AreEqual("YES", FastDriver.ClosingDisclosure.Section2_LoanTerms_PrepaymentPenaltyDropdown.FAGetSelectedItem(), "Section2_LoanTerms_PrepaymentPenaltyDropdown");
                Support.Match("As high as \\$110,000\\.00 if you pay off the loan during the first 2 year\\(s\\)", FastDriver.ClosingDisclosure.LoanTerms_PrepaymentPenaltyClause.FAGetText(), "Prepayment Penalty Clause text1");
                //  Balloon Payment
                Support.AreEqual("YES", FastDriver.ClosingDisclosure.Section2_LoanTerms_BalloonPaymentDropdown.FAGetSelectedItem(), "Section2_LoanTerms_BalloonPaymentDropdown");
                Support.Match("You will have to pay \\$?50,?000\\.00 at the end of year", FastDriver.ClosingDisclosure.LoanTerms_BalloonPaymentClauses.FAGetText(), "Balloon Payment Clause text1");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
