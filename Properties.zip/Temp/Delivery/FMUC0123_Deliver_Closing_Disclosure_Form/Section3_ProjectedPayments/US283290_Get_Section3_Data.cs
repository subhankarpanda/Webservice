﻿using FASTSelenium.Common;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.Delivery.FMUC0123_Deliver_Closing_Disclosure_Form.ProjectedPayments
{
    [CodedUITest]
    public class US283290_Get_Section3_Data : FASTHelpers
    {
        [TestMethod]
        [Description("Verify Closing Disclosure - Projected Payments information using GetCDDetails web service")]
        public void Scenario_1_Get_ProjectedPayments_Details()
        {
            try
            {
                Reports.TestDescription = "Verify Closing Disclosure - Projected Payments information using GetCDDetails web service";

                FAST_Init_File(LenderID: "415", loanAmt: (decimal)1000000);

                #region Navigate to Closing Disclosure and complete Projected Payments information
                Reports.TestStep = "Navigate to Closing Disclosure and complete Projected Payments information";
                FastDriver.ClosingDisclosure.Open();
                FastDriver.ClosingDisclosure.Projected_Payments.FAClick();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.Section3_ProjectedPaymentPlusIcon);
                FastDriver.ClosingDisclosure.Section3_ProjectedPaymentPlusIcon.Click();
                FastDriver.ClosingDisclosure.ProjectedPayment_PaymentCalculation_YearRange.FASelectItem("3");
                FastDriver.ClosingDisclosure.YearRangeDone.FAClick();
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                //  Year 1
                FastDriver.ClosingDisclosure.ProjectedPayment_ddlYearRanges1.FASelectItemByIndex(1);
                FastDriver.ClosingDisclosure.ProjectedPayment_txtStartYear1.FASetText("1");
                FastDriver.ClosingDisclosure.ProjectedPayment_PrincInterest1Plus.FAClick();
                FastDriver.ClosingDisclosure.ProjectedPayment_rdoMinimumMaximum.FAClick();
                FastDriver.ClosingDisclosure.Section3_txtMinimum.FASetText("333333");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.ClosingDisclosure.Section3_txtMaximum.FASetText("400000");
                FastDriver.ClosingDisclosure.Section3_btnPrincipalInterestDone.FAClick();
                FastDriver.ClosingDisclosure.Section3_MortgageInsurance.FASetText("15000");
                FastDriver.ClosingDisclosure.Section3_EstimatedEscrow.FASetText("5000");
                //  Year 2
                FastDriver.ClosingDisclosure.ProjectedPayment_ddlYearRanges2.FASelectItemByIndex(1);
                FastDriver.ClosingDisclosure.ProjectedPayment_txtStartYear2.FASetText("2");
                FastDriver.ClosingDisclosure.ProjectedPayment_PrincInterest2Plus.FAClick();
                FastDriver.ClosingDisclosure.ProjectedPayment_rdoMinimumMaximum.FAClick();
                FastDriver.ClosingDisclosure.Section3_txtMinimum.FASetText("333333");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.ClosingDisclosure.Section3_txtMaximum.FASetText("400000");
                FastDriver.ClosingDisclosure.Section3_btnPrincipalInterestDone.FAClick();
                FastDriver.ClosingDisclosure.ProjectedPayment_txtMortInsAmt1.FASetText("7500");
                FastDriver.ClosingDisclosure.ProjectedPayment_txtEstEscAmt1.FASetText("2500");
                //  Final Year
                FastDriver.ClosingDisclosure.ProjectedPayment_PrincInterest3Plus.FAClick();
                FastDriver.ClosingDisclosure.ProjectedPayment_rdoPrincipalInterest.FAClick();
                FastDriver.ClosingDisclosure.ProjectedPayment_txtPrincipalInterest.FASetText("333333");
                FastDriver.ClosingDisclosure.Section3_btnPrincipalInterestDone.FAClick();
                FastDriver.ClosingDisclosure.ProjectedPayment_txtMortInsAmt2.FASetText("3750");
                FastDriver.ClosingDisclosure.ProjectedPayment_txtEstEscAmt2.FASetText("1250");
                //  Estimates
                FastDriver.ClosingDisclosure.ProjectedPayment_Estimated_TI_Amount.FASetText("800");
                FastDriver.ClosingDisclosure.Section3_PropertyTax.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.Section3_PropertyTaxInEscrow.FASelectItem("SOME");
                FastDriver.ClosingDisclosure.Section3_HomeownersInsurance.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.Section3_HomeownersInsuranceInEscrow.FASelectItem("SOME");
                FastDriver.ClosingDisclosure.Section3_OthersInEscrowPlus.FAClick();
                FastDriver.ClosingDisclosure.Section3_EstimateIncludesID_2992.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.Section3_InEscrowID_2992.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.txtPOPupEstimateOther.FASetText("test-value");
                FastDriver.ClosingDisclosure.Section3_OtherpopupDone.FAClick();
                //
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify Closing Disclosure - Projected Payments details with GetCDDetails()
                Reports.TestStep = "Verify Closing Disclosure - Projected Payments details with GetCDDetails()";
                var request = CDRequestFactory.GetCDRequest(File.FileID, FASTWCFHelpers.FastClosingDisclosureService.eCDFilterSection.ProjectedPayments);
                var details = ClosingDisclosureService.GetCDDetails(request);
                Support.AreEqual("1", details.Status.ToString(), details.StatusDescription);
                var projectedPayments = details.ClosingDisclosureProjectedPayment;
                Support.AreEqual("SOME", projectedPayments.DisplayHomeOwnerInsuranceInEscrow, "DisplayHomeOwnerInsuranceInEscrow");
                Support.AreEqual("YES", projectedPayments.DisplayPPEstimateIncludesOtherInEscrow, "DisplayPPEstimateIncludesOtherInEscrow");
                Support.AreEqual("Monthly", projectedPayments.DisplayPrincipalInterestTypeDescription, "DisplayPrincipalInterestTypeDescription");
                Support.AreEqual("Other", projectedPayments.DisplayProjectedPaymentEstimateOtherInEscrow, "DisplayProjectedPaymentEstimateOtherInEscrow");
                Support.AreEqual("SOME", details.ClosingDisclosureProjectedPayment.DisplayPropertyTaxInEscrow, "DisplayPropertyTaxInEscrow");
                Support.AreEqual("$800.00", projectedPayments.EstimatedTaxInsuranceAssesment, "EstimatedTaxInsuranceAssesment");
                Support.AreEqual("3145", projectedPayments.HomeOwnerInsuranceInEscrowID != null ? projectedPayments.HomeOwnerInsuranceInEscrowID.ToString() : "null", "HomeOwnerInsuranceInEscrowID");
                Support.AreEqual("1", projectedPayments.IsHomeOwnerInsurance != null ? projectedPayments.IsHomeOwnerInsurance.ToString() : "null", "IsHomeOwnerInsurance");
                Support.AreEqual("1", projectedPayments.IsProjectedPaymentEstimateOther != null ? projectedPayments.IsProjectedPaymentEstimateOther.ToString() : "null", "IsProjectedPaymentEstimateOther");
                Support.AreEqual("1", projectedPayments.IsPropertyTax != null ? projectedPayments.IsPropertyTax.ToString() : "null", "IsPropertyTax");
                Support.AreEqual("2992", projectedPayments.PPAdditionalEstimatedPropertyCosts[0].EstimateIncludeID, "PPAdditionalEstimatedPropertyCosts[0].EstimateIncludeID");
                Support.AreEqual("True", projectedPayments.PPAdditionalEstimatedPropertyCosts[0].InEscrow.ToString(), "PPAdditionalEstimatedPropertyCosts[0].InEscrow");
                Support.AreEqual("True", projectedPayments.PPAdditionalEstimatedPropertyCosts[0].ShowOnForm.ToString(), "PPAdditionalEstimatedPropertyCosts[0].ShowOnForm");
                Support.AreEqual("3094", projectedPayments.PPEstimateIncludesOtherInEscrowID != null ? projectedPayments.PPEstimateIncludesOtherInEscrowID.ToString():"null", "PPEstimateIncludesOtherInEscrowID");
                Support.AreEqual("test-value", projectedPayments.ProjectedPaymentEstimateOther, "ProjectedPaymentEstimateOther");
                //  Year 1
                var paymentAtYear1 = projectedPayments.ProjectedPaymentRanges[0];
                Support.AreEqual("$353,333 - $420,000", paymentAtYear1.DisplayEstimatedTotalMonthlyPayment, "paymentAtYear1.DisplayEstimatedTotalMonthlyPayment");
                Support.AreEqual("$333,333 min", paymentAtYear1.DisplayPrincipalInterestLine1, "paymentAtYear1.DisplayPrincipalInterestLine1");
                Support.AreEqual("$400,000 max", paymentAtYear1.DisplayPrincipalInterestLine2, "paymentAtYear1.DisplayPrincipalInterestLine2");
                Support.AreEqual("Year 1", paymentAtYear1.DisplayYearRange, "paymentAtYear1.DisplayYearRange");
                Support.AreEqual("1", paymentAtYear1.EndRange != null ? paymentAtYear1.EndRange.ToString() : "null", "paymentAtYear1.EndRange");
                Support.AreEqual("5,000", paymentAtYear1.EstimatedEscrow, "paymentAtYear1.EstimatedEscrow");
                Support.AreEqual("0", paymentAtYear1.Interest != null ? paymentAtYear1.Interest.ToString() : "null", "paymentAtYear1.Interest");
                Support.AreEqual("0", paymentAtYear1.IsInterestOnly != null ? paymentAtYear1.IsInterestOnly.ToString() : "null", "paymentAtYear1.IsInterestOnly");
                Support.AreEqual("420000", paymentAtYear1.MaxEstimatedTotalMonthlyPayment != null ? paymentAtYear1.MaxEstimatedTotalMonthlyPayment.ToString() : "null", "paymentAtYear1.MaxEstimatedTotalMonthlyPayment");
                Support.AreEqual("400000", paymentAtYear1.MaxPrincipal != null ? paymentAtYear1.MaxPrincipal.ToString() : "null", "paymentAtYear1.MaxPrincipal");
                Support.AreEqual("353333", paymentAtYear1.MinEstimatedTotalMonthlyPayment != null ? paymentAtYear1.MinEstimatedTotalMonthlyPayment.ToString() : "null", "paymentAtYear1.MinEstimatedTotalMonthlyPayment");
                Support.AreEqual("333333", paymentAtYear1.MinPrincipal != null ? paymentAtYear1.MinPrincipal.ToString() : "null", "paymentAtYear1.MinPrincipal");
                Support.AreEqual("15,000", paymentAtYear1.MortgageInsurance != null ? paymentAtYear1.MortgageInsurance.ToString() : "null", "paymentAtYear1.MortgageInsurance");
                Support.AreEqual("0", paymentAtYear1.PrincipalInterest != null ? paymentAtYear1.PrincipalInterest.ToString() : "null", "paymentAtYear1.PrincipalInterest");
                Support.AreEqual("1", paymentAtYear1.StartRange != null ? paymentAtYear1.StartRange.ToString() : "null", "paymentAtYear1.StartRange");
                //  Year 2
                var paymentAtYear2 = projectedPayments.ProjectedPaymentRanges[1];
                Support.AreEqual("$343,333 - $410,000", paymentAtYear2.DisplayEstimatedTotalMonthlyPayment, "paymentAtYear2.DisplayEstimatedTotalMonthlyPayment");
                Support.AreEqual("$333,333 min", paymentAtYear2.DisplayPrincipalInterestLine1, "paymentAtYear2.DisplayPrincipalInterestLine1");
                Support.AreEqual("$400,000 max", paymentAtYear2.DisplayPrincipalInterestLine2, "paymentAtYear2.DisplayPrincipalInterestLine2");
                Support.AreEqual("Year 2", paymentAtYear2.DisplayYearRange, "paymentAtYear2.DisplayYearRange");
                Support.AreEqual("2", paymentAtYear2.EndRange != null ? paymentAtYear2.EndRange.ToString() : "null", "paymentAtYear2.EndRange");
                Support.AreEqual("2,500", paymentAtYear2.EstimatedEscrow, "paymentAtYear2.EstimatedEscrow");
                Support.AreEqual("0", paymentAtYear2.Interest != null ? paymentAtYear2.Interest.ToString() : "null", "paymentAtYear2.Interest");
                Support.AreEqual("0", paymentAtYear2.IsInterestOnly != null ? paymentAtYear2.IsInterestOnly.ToString() : "null", "paymentAtYear2.IsInterestOnly");
                Support.AreEqual("410000", paymentAtYear2.MaxEstimatedTotalMonthlyPayment != null ? paymentAtYear2.MaxEstimatedTotalMonthlyPayment.ToString() : "null", "paymentAtYear2.MaxEstimatedTotalMonthlyPayment");
                Support.AreEqual("400000", paymentAtYear2.MaxPrincipal != null ? paymentAtYear2.MaxPrincipal.ToString() : "null", "paymentAtYear2.MaxPrincipal");
                Support.AreEqual("343333", paymentAtYear2.MinEstimatedTotalMonthlyPayment != null ? paymentAtYear2.MinEstimatedTotalMonthlyPayment.ToString() : "null", "paymentAtYear2.MinEstimatedTotalMonthlyPayment");
                Support.AreEqual("333333", paymentAtYear2.MinPrincipal != null ? paymentAtYear2.MinPrincipal.ToString() : "null", "paymentAtYear2.MinPrincipal");
                Support.AreEqual("7,500", paymentAtYear2.MortgageInsurance != null ? paymentAtYear2.MortgageInsurance.ToString() : "null", "paymentAtYear2.MortgageInsurance");
                Support.AreEqual("0", paymentAtYear2.PrincipalInterest != null ? paymentAtYear2.PrincipalInterest.ToString() : "null", "paymentAtYear2.PrincipalInterest");
                Support.AreEqual("2", paymentAtYear2.StartRange != null ? paymentAtYear2.StartRange.ToString() : "null", "paymentAtYear2.StartRange");
                //  Final Year
                var paymentAtYear3 = projectedPayments.ProjectedPaymentRanges[2];
                Support.AreEqual("$338,333.00", paymentAtYear3.DisplayEstimatedTotalMonthlyPayment, "paymentAtYear3.DisplayEstimatedTotalMonthlyPayment");
                Support.AreEqual("$333,333.00", paymentAtYear3.DisplayPrincipalInterestLine1, "paymentAtYear3.DisplayPrincipalInterestLine1");
                Support.AreEqual("$0 max", paymentAtYear3.DisplayPrincipalInterestLine2, "paymentAtYear3.DisplayPrincipalInterestLine2");
                Support.AreEqual("Years 3 - 0", paymentAtYear3.DisplayYearRange, "paymentAtYear3.DisplayYearRange");
                Support.AreEqual("0", paymentAtYear3.EndRange != null ? paymentAtYear3.EndRange.ToString() : "null", "paymentAtYear3.EndRange");
                Support.AreEqual("1,250.00", paymentAtYear3.EstimatedEscrow, "paymentAtYear3.EstimatedEscrow");
                Support.AreEqual("0", paymentAtYear3.Interest != null ? paymentAtYear3.Interest.ToString() : "null", "paymentAtYear3.Interest");
                Support.AreEqual("2", paymentAtYear3.IsInterestOnly != null ? paymentAtYear3.IsInterestOnly.ToString() : "null", "paymentAtYear3.IsInterestOnly");
                Support.AreEqual("null", paymentAtYear3.MaxEstimatedTotalMonthlyPayment != null ? paymentAtYear3.MaxEstimatedTotalMonthlyPayment.ToString() : "null", "paymentAtYear3.MaxEstimatedTotalMonthlyPayment");
                Support.AreEqual("0", paymentAtYear3.MaxPrincipal != null ? paymentAtYear3.MaxPrincipal.ToString() : "null", "paymentAtYear3.MaxPrincipal");
                Support.AreEqual("null", paymentAtYear3.MinEstimatedTotalMonthlyPayment != null ? paymentAtYear3.MinEstimatedTotalMonthlyPayment.ToString() : "null", "paymentAtYear3.MinEstimatedTotalMonthlyPayment");
                Support.AreEqual("0", paymentAtYear3.MinPrincipal != null ? paymentAtYear3.MinPrincipal.ToString() : "null", "paymentAtYear3.MinPrincipal");
                Support.AreEqual("3,750.00", paymentAtYear3.MortgageInsurance != null ? paymentAtYear3.MortgageInsurance.ToString() : "null", "paymentAtYear3.MortgageInsurance");
                Support.AreEqual("333333", paymentAtYear3.PrincipalInterest != null ? paymentAtYear3.PrincipalInterest.ToString() : "null", "paymentAtYear3.PrincipalInterest");
                Support.AreEqual("3", paymentAtYear3.StartRange != null ? paymentAtYear3.StartRange.ToString() : "null", "paymentAtYear3.StartRange");
                //
                Support.AreEqual("2623", projectedPayments.PropertyTaxInEscrowID != null ? projectedPayments.PropertyTaxInEscrowID.ToString() : "null", "projectedPayments.PropertyTaxInEscrowID");
                Support.AreEqual("3", projectedPayments.YearRange.ToString(), "projectedPayments.YearRange");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
