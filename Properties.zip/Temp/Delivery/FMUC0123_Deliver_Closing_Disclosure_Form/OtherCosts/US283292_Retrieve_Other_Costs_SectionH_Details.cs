﻿using FASTSelenium.Common;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.Delivery.FMUC0123_Deliver_Closing_Disclosure_Form.OtherCosts
{
    [CodedUITest]
    public class US283292_Retrieve_Other_Costs_SectionH_Details : FASTHelpers
    {
        [TestMethod]
        [Description("Verify Closing Disclosure - Other Costs Section H information with GetCDDetails web service")]
        public void Scenario_1_Retrieve_Other_Costs_SectionH_Details()
        {
            try
            {
                Reports.TestDescription = "Verify Closing Disclosure - Other Costs Section H information with GetCDDetails web service";

                FAST_Init_File(LenderID: "415", loanAmt: 2000000);

                #region Navigate to Outside Title Company and create a new instance with charges for Section H
                Reports.TestStep = "Navigate to Outside Title Company and create a new instance with charges for Section H";
                FastDriver.OTCDetail.Open();
                FastDriver.OTCDetail.FindGAB("415");
                FastDriver.OTCDetail.ChargesRetained.FASetText("1300000");
                FastDriver.OTCDetail.Type.FASelectItemBySendingKeys("Attorney");
                FastDriver.OTCDetail.OTCTitleServicesPaymentDetails.Click();
                var paymentDetails = new FASTSelenium.DataObjects.IIS.PDD()
                {
                    BuyerAtClosing = (double)100000,
                    BuyerBeforeClosing = (double)50000,
                    BuyerPaidbyOther = (double)350000,
                    BuyerPaidbyOtherPaymentMethod = "POC",
                    SellerPaidAtClosing = (double)100000,
                    SellerPaidBeforeClosing = (double)50000,
                    SellerPaidbyOthers = (double)350000,
                    SellerPaidbyOtherPaymentMthd = "POC",
                    LoanEstimateUnrounded = (double)999999.99,
                    SectionHOtherCosts = true,
                };
                FAST_UpdatePDD(paymentDetails);
                FastDriver.OTCDetail.SwitchToContentFrame();
                if (FastDriver.OTCDetail.DisplayAggregateOnCD.Exists())
                    FastDriver.OTCDetail.DisplayAggregateOnCD.FASetCheckbox(true);
                else
                    Support.IsTrue(true, "DisplayAggregateOnCD does not exist");
                FastDriver.OTCDetail.OTCLenderPolicyEndorsementPaymentDetails.Click();
                FAST_UpdatePDD(paymentDetails);
                FastDriver.OTCDetail.SwitchToContentFrame();
                FastDriver.OTCDetail.OTCOwnerPolicyEndorsementPaymentDetails.Click();
                FAST_UpdatePDD(paymentDetails);
                FastDriver.BottomFrame.Done();
                FastDriver.OTCDetail.WaitForScreenToLoad();
                #endregion

                #region Verify CD Section H Charges with GetCDDetails web service
                Reports.TestStep = "Verify CD Section H Charges with GetCDDetails web service";
                var request = CDRequestFactory.GetCDDetailsRequest();
                request.FileID = File.FileID ?? 0;
                request.CDFilter = FASTWCFHelpers.FastClosingDisclosureService.eCDFilterSection.OtherCosts;
                var details = ClosingDisclosureService.GetCDDetails(request);
                Support.AreEqual("1", details.Status.ToString(), details.StatusDescription);
                Support.IsTrue(details.OtherCosts.SectionHCharges.Charges.Length >= 3, "Charges.Length >= 3");
                Support.AreEqual("$450,000.00", details.OtherCosts.SectionHCharges.DisplayTotal ?? "", "DisplayTotal");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }
        
        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
