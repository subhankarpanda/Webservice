﻿using FASTSelenium.Common;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.Delivery.FMUC0123_Deliver_Closing_Disclosure_Form.LoanDisclosures
{
    [CodedUITest]
    public class US290273_Update_CD_AP_Table_Details : FASTHelpers
    {
        [TestMethod]
        [Description("Verify update Closing Disclosure - AP Table information using UpdateCDDetails")]
        public void Scenario_1_Update_CD_AP_Table_Details()
        {
            try
            {
                Reports.TestStep = "Verify update Closing Disclosure - AP Table information using UpdateCDDetails";

                FAST_Init_File();

                #region Update CD AP Table details using UpdateCDDetails()
                Reports.TestStep = "Update CD AP Table details using UpdateCDDetails()";
                var updateReq = CDRequestFactory.GetCDApAirRequest(File.FileID ?? 0, withAP:true);
                var response = ClosingDisclosureService.UpdateCDDetails(updateReq);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Navigate to Closing Disclosure and verify AP Table
                Reports.TestStep = "Navigate to Closing Disclosure and verify AP Table";
                FastDriver.ClosingDisclosure.Open();
                FastDriver.ClosingDisclosure.AP_AIR.Click();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.Sec9_APnAIRtable_APTableChkBox);
                Support.AreEqual("true", FastDriver.ClosingDisclosure.Sec9_APnAIRtable_APTableChkBox.GetAttribute("status").ToLowerInvariant(), "Include Adjustable Payment (AP) Table");
                //  InterestOnly Payment
                Support.AreEqual("1", FastDriver.ClosingDisclosure.Sec9_APnAIRtable_APInterestOnlyDrpDwn.FAGetValue(), "InterestOnlyOption");
                Support.AreEqual("test-value1", FastDriver.ClosingDisclosure.Sec9_APnAIRtable_APspnIntPayment.Text ?? "", "InterestOnlyDescription");
                //  Optional Payment
                Support.AreEqual("1", FastDriver.ClosingDisclosure.Sec9_APnAIRtable_APOptionalPaymentsDrpDwn.FAGetValue(), "OptionalOption");
                Support.AreEqual("test-value1", FastDriver.ClosingDisclosure.Sec9_APnAIRtable_APspnOptPayments.Text ?? "", "OptionalDescription");
                //  Step Payment
                Support.AreEqual("1", FastDriver.ClosingDisclosure.Sec9_APnAIRtable_APStepPaymentsDrpDwn.FAGetValue(), "StepOption");
                Support.AreEqual("test-value1", FastDriver.ClosingDisclosure.Sec9_APnAIRtable_APspnStepPayments.Text ?? "", "StepDescription");
                //  Seasonal Payment
                Support.AreEqual("1", FastDriver.ClosingDisclosure.Sec9_APnAIRtable_APSeasonalPaymentsDrpDwn.FAGetValue(), "SeasonalOption");
                Support.AreEqual("test-value1", FastDriver.ClosingDisclosure.Sec9_APnAIRtable_APspnSeasonalPayments.Text ?? "", "SeasonalDescription");
                //  First Change/Amount
                Support.AreEqual("$1,500 at 12th payment", FastDriver.ClosingDisclosure.Sec9_APnAIRtable_APFirstChangeValue.Text, "First Change/Amount schedule");
                //  Subsequent Changes
                Support.AreEqual("Every year", FastDriver.ClosingDisclosure.Sec9_APnAIRtable_APSubsequentChangesValue.Text, "Subsequent Changes schedule");
                //  Maximum Payment
                Support.AreEqual("$150 starting at 50th payment", FastDriver.ClosingDisclosure.Sec9_APnAIRtable_APMaximumPaymentValue.Text, "Maximum Payment schedule");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
