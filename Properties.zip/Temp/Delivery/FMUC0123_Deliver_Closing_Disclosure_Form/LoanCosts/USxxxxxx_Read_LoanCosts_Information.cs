﻿using FASTSelenium.Common;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.Delivery.FMUC0123_Deliver_Closing_Disclosure_Form
{
    [CodedUITest]
    public class USxxxxxx_Read_LoanCosts_Information : FASTHelpers
    {
        protected void AddChargesForSectionA()
        {
            #region Navigate to New Loan - Loan Charges and complete Credit/Charge Points details
            Reports.TestStep = "Navigate to New Loan - Loan Charges and complete Credit/Charge Points details";
            FastDriver.NewLoan.Open();
            FastDriver.NewLoan.ClickChargesTab();
            FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FASetText("50");
            FastDriver.NewLoan.CreditChargePointsPercentageIRSPoints.FASetText("5.0");
            FastDriver.NewLoan.CreditCharge_Points_PaymentDetails.FAClick();
            FAST_UpdatePDD(new FASTSelenium.DataObjects.IIS.PDD
            {
                LoanEstimateUnrounded = (double)1249999.99,
                BuyerAtClosing = (double)500000,
                BuyerBeforeClosing = (double)250000,
                BuyerPaidbyOther = (double)250000,
                BuyerPaidbyOtherPaymentMethod = OtherPaymentMethods.POC.ToString(),
                SellerPaidAtClosing = (double)150000,
                SellerPaidBeforeClosing = (double)50000,
                SellerPaidbyOthers = (double)50000,
                SellerPaidbyOtherPaymentMthd = OtherPaymentMethods.POC.ToString(),
            });
            FastDriver.BottomFrame.Done();
            #endregion
        }

        protected void AddChargesForSectionB()
        {
            #region Navigate to Outside Title Company and complete a charge's details for section B
            Reports.TestStep = "Navigate to Outside Title Company and complete a charge's details for section B";
            FastDriver.OTCDetail.Open();
            FastDriver.OTCDetail.FindGAB("415");
            FastDriver.OTCDetail.OTCLenderPolicyEndorsementDescription.FASetText("test-charge");
            FastDriver.OTCDetail.OTCLenderPolicyEndorsementPaymentDetails.FAClick();
            FAST_UpdatePDD(new FASTSelenium.DataObjects.IIS.PDD
            {
                LoanEstimateUnrounded = (double)1249999.99,
                BuyerAtClosing = (double)500000,
                BuyerBeforeClosing = (double)250000,
                BuyerPaidbyOther = (double)250000,
                BuyerPaidbyOtherPaymentMethod = OtherPaymentMethods.POC.ToString(),
                SellerPaidAtClosing = (double)150000,
                SellerPaidBeforeClosing = (double)50000,
                SellerPaidbyOthers = (double)50000,
                SellerPaidbyOtherPaymentMthd = OtherPaymentMethods.POC.ToString(),
                SectionBdidnotShopFor = true,
            });
            FastDriver.BottomFrame.Done();
            #endregion
        }

        protected void AddChargesForSectionC()
        {
            #region Navigate to Outside Escrow Company and complete a charge's details for section C
            Reports.TestStep = "Navigate to OTC and complete a charge's details for section C";
            FastDriver.OutsideEscrowCompanyDetail.Open();
            FastDriver.OutsideEscrowCompanyDetail.FindGAB("415");
            FastDriver.OutsideEscrowCompanyDetail.ChargeDescription.FASetText("test-charge");
            FastDriver.OutsideEscrowCompanyDetail.PaymentDetails.FAClick();
            FAST_UpdatePDD(new FASTSelenium.DataObjects.IIS.PDD
            {
                LoanEstimateUnrounded = (double)1249999.99,
                BuyerAtClosing = (double)500000,
                BuyerBeforeClosing = (double)250000,
                BuyerPaidbyOther = (double)250000,
                BuyerPaidbyOtherPaymentMethod = OtherPaymentMethods.POC.ToString(),
                SellerPaidAtClosing = (double)150000,
                SellerPaidBeforeClosing = (double)50000,
                SellerPaidbyOthers = (double)50000,
                SellerPaidbyOtherPaymentMthd = OtherPaymentMethods.POC.ToString(),
                SectionCDidShopFor = true,
            });
            FastDriver.BottomFrame.Done();
            #endregion   
        }

        [TestMethod]
        [Description("Verify Closing Disclosure - Loan Costs Section A information using GetCDDetails web service")]
        public void Scenario_1_Get_SectionA_Details()
        {
            try 
            {
                Reports.TestDescription = "Verify Closing Disclosure - Loan Costs Section A information using GetCDDetails web service";

                FAST_Init_File(LenderID: "415", loanAmt: (decimal)2500000);

                AddChargesForSectionA();
                
                #region Verify Closing Disclosure - Loan Costs Section A details in FAST
                Reports.TestStep = "Verify Closing Disclosure - Loan Costs Section A details in FAST";
                FastDriver.ClosingDisclosure.Open();
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.TableLoanCostSectionA);
                //  TableLoanCostSectionA
                var sectionDetails = FastDriver.ClosingDisclosure.TableLoanCostSectionA;
                Support.AreEqual("A. Origination Charges", sectionDetails.PerformTableAction(1, 1, TableAction.GetText).Message, "Column Name");
                Support.AreEqual("$750,000.00", sectionDetails.PerformTableAction(1, 2, TableAction.GetText).Message, "Borrower Total");
                Support.AreEqual("01. 50 % of Loan Amount (Points)", sectionDetails.PerformTableAction(2, 1, TableAction.GetText).Message, "Description");
                Support.AreEqual("$500,000.00", sectionDetails.PerformTableAction(2, 2, TableAction.GetText).Message, "Borrower At Closing");
                Support.AreEqual("$250,000.00", sectionDetails.PerformTableAction(2, 3, TableAction.GetText).Message, "Borrower Before Closing");
                Support.AreEqual("$150,000.00", sectionDetails.PerformTableAction(2, 4, TableAction.GetText).Message, "Seller At Closing");
                Support.AreEqual("$50,000.00", sectionDetails.PerformTableAction(2, 5, TableAction.GetText).Message, "Seller Before Closing");
                Support.AreEqual("$250,000.00", sectionDetails.PerformTableAction(2, 6, TableAction.GetText).Message, "Paid By Others");
                Support.AreEqual("$1,249,999.99", sectionDetails.PerformTableAction(2, 7, TableAction.GetText).Message, "Loan Estimate Unrounded");
                Support.AreEqual("$1,250,000.00 ", sectionDetails.PerformTableAction(2, 8, TableAction.GetText).Message, "Loan Estimate Rounded");
                #endregion

                #region Verify Closing Disclosure - Loan Costs Section B details with GetCDDetails()
                Reports.TestStep = "Verify Closing Disclosure - Loan Costs Section B details with GetCDDetails()";
                var request = CDRequestFactory.GetCDRequest(File.FileID, FASTWCFHelpers.FastClosingDisclosureService.eCDFilterSection.LoanCosts);
                var details = ClosingDisclosureService.GetCDDetails(request);
                Support.AreEqual("1", details.Status.ToString(), details.StatusDescription);
                //  
                var sectionCharge = details.LoanCosts.SectionACharges.Charges.First(x => x.PayeeRoleType == "NewLoan1Lender");
                Support.AreEqual("1,000,000.00", sectionCharge.DisplayBuyerChargeAmount, "DisplayBuyerChargeAmount");
                Support.AreEqual("$1,249,999.99", sectionCharge.DisplayLEAmount, "DisplayLEAmount");
                Support.AreEqual("$500,000.00", sectionCharge.DisplayPaidByBuyerAtClosing, "DisplayPaidByBuyerAtClosing");
                Support.AreEqual("$250,000.00", sectionCharge.DisplayPaidByBuyerBeforeClosing, "DisplayPaidByBuyerBeforeClosing");
                Support.AreEqual("$250,000.00", sectionCharge.DisplayPaidByOthersForBuyer, "DisplayPaidByOthersForBuyer");
                Support.AreEqual("$50,000.00", sectionCharge.DisplayPaidByOthersForSeller, "DisplayPaidByOthersForSeller");
                Support.AreEqual("$150,000.00", sectionCharge.DisplayPaidBySellerAtClosing, "DisplayPaidBySellerAtClosing");
                Support.AreEqual("$50,000.00", sectionCharge.DisplayPaidBySellerBeforeClosing, "DisplayPaidBySellerBeforeClosing");
                Support.AreEqual("Continental Mortgage Corporation", sectionCharge.PayeeName, "DisplayPayeeName");
                #endregion
            }
            catch(Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify Closing Disclosure - Loan Costs Section B information using GetCDDetails web service")]
        public void Scenario_2_Get_SectionB_Details()
        {
            try
            {
                Reports.TestDescription = "Verify Closing Disclosure - Loan Costs Section B information using GetCDDetails web service";

                FAST_Init_File();

                AddChargesForSectionB();
                
                #region Verify Closing Disclosure - Loan Costs Section B details in FAST
                Reports.TestStep = "Verify Closing Disclosure - Loan Costs Section B details in FAST";
                FastDriver.ClosingDisclosure.Open();
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.TableLoanCostSectionB);
                //  TableLoanCostSectionB
                var sectionDetails = FastDriver.ClosingDisclosure.TableLoanCostSectionB;
                Support.AreEqual("B. Services Borrower Did Not Shop For", sectionDetails.PerformTableAction(1, 1, TableAction.GetText).Message, "Column Name");
                Support.AreEqual("$750,000.00", sectionDetails.PerformTableAction(1, 2, TableAction.GetText).Message, "Borrower Total");
                Support.AreEqual("01. test-charge to Continental Mortgage", sectionDetails.PerformTableAction(2, 1, TableAction.GetText).Message, "Description");
                Support.AreEqual("$500,000.00", sectionDetails.PerformTableAction(2, 2, TableAction.GetText).Message, "Borrower At Closing");
                Support.AreEqual("$250,000.00", sectionDetails.PerformTableAction(2, 3, TableAction.GetText).Message, "Borrower Before Closing");
                Support.AreEqual("$150,000.00", sectionDetails.PerformTableAction(2, 4, TableAction.GetText).Message, "Seller At Closing");
                Support.AreEqual("$50,000.00", sectionDetails.PerformTableAction(2, 5, TableAction.GetText).Message, "Seller Before Closing");
                Support.AreEqual("(L)$250,000.00", sectionDetails.PerformTableAction(2, 6, TableAction.GetText).Message, "Paid By Others");
                Support.AreEqual("$1,249,999.99", sectionDetails.PerformTableAction(2, 7, TableAction.GetText).Message, "Loan Estimate Unrounded");
                Support.AreEqual("$1,250,000.00 ", sectionDetails.PerformTableAction(2, 8, TableAction.GetText).Message, "Loan Estimate Rounded");
                #endregion

                #region Verify Closing Disclosure - Loan Costs Section B details with GetCDDetails()
                Reports.TestStep = "Verify Closing Disclosure - Loan Costs Section B details with GetCDDetails()";
                var request = CDRequestFactory.GetCDRequest(File.FileID, FASTWCFHelpers.FastClosingDisclosureService.eCDFilterSection.LoanCosts);
                var details = ClosingDisclosureService.GetCDDetails(request);
                Support.AreEqual("1", details.Status.ToString(), details.StatusDescription);
                //  
                var sectionCharge = details.LoanCosts.SectionBCharges.Charges.First(x => x.PayeeRoleType.Contains("OutsideTitleCompany") && x.PayeeName.Contains("Continental"));
                Support.AreEqual("1,000,000.00", sectionCharge.DisplayBuyerChargeAmount, "DisplayBuyerChargeAmount");
                Support.AreEqual("$1,249,999.99", sectionCharge.DisplayLEAmount, "DisplayLEAmount");
                Support.AreEqual("$500,000.00", sectionCharge.DisplayPaidByBuyerAtClosing, "DisplayPaidByBuyerAtClosing");
                Support.AreEqual("$250,000.00", sectionCharge.DisplayPaidByBuyerBeforeClosing, "DisplayPaidByBuyerBeforeClosing");
                Support.AreEqual("(L)$250,000.00", sectionCharge.DisplayPaidByOthersForBuyer, "DisplayPaidByOthersForBuyer");
                Support.AreEqual("$50,000.00", sectionCharge.DisplayPaidByOthersForSeller, "DisplayPaidByOthersForSeller");
                Support.AreEqual("$150,000.00", sectionCharge.DisplayPaidBySellerAtClosing, "DisplayPaidBySellerAtClosing");
                Support.AreEqual("$50,000.00", sectionCharge.DisplayPaidBySellerBeforeClosing, "DisplayPaidBySellerBeforeClosing");
                Support.AreEqual("Continental Mortgage", sectionCharge.DisplayPayeeName, "DisplayPayeeName");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify Closing Disclosure - Loan Costs Section C information using GetCDDetails web service")]
        public void Scenario_3_Get_SectionC_Details()
        {
            try
            {
                Reports.TestDescription = "Verify Closing Disclosure - Loan Costs Section C information using GetCDDetails web service";

                FAST_Init_File();

                AddChargesForSectionC();

                #region Verify Closing Disclosure - Loan Costs Section C details in FAST
                Reports.TestStep = "Verify Closing Disclosure - Loan Costs Section C details in FAST";
                FastDriver.ClosingDisclosure.Open();
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.TableLoanCostSectionC);
                //  TableLoanCostSectionB
                var sectionDetails = FastDriver.ClosingDisclosure.TableLoanCostSectionC;
                Support.AreEqual("C. Services Borrower Did Shop For", sectionDetails.PerformTableAction(1, 1, TableAction.GetText).Message, "Column Name");
                Support.AreEqual("$750,000.00", sectionDetails.PerformTableAction(1, 2, TableAction.GetText).Message, "Borrower Total");
                Support.AreEqual("01. test-charge to Continental Mortgage", sectionDetails.PerformTableAction(2, 1, TableAction.GetText).Message, "Description");
                Support.AreEqual("$500,000.00", sectionDetails.PerformTableAction(2, 2, TableAction.GetText).Message, "Borrower At Closing");
                Support.AreEqual("$250,000.00", sectionDetails.PerformTableAction(2, 3, TableAction.GetText).Message, "Borrower Before Closing");
                Support.AreEqual("$150,000.00", sectionDetails.PerformTableAction(2, 4, TableAction.GetText).Message, "Seller At Closing");
                Support.AreEqual("$50,000.00", sectionDetails.PerformTableAction(2, 5, TableAction.GetText).Message, "Seller Before Closing");
                Support.AreEqual("(L)$250,000.00", sectionDetails.PerformTableAction(2, 6, TableAction.GetText).Message, "Paid By Others");
                Support.AreEqual("$1,249,999.99", sectionDetails.PerformTableAction(2, 7, TableAction.GetText).Message, "Loan Estimate Unrounded");
                Support.AreEqual("$1,250,000.00 ", sectionDetails.PerformTableAction(2, 8, TableAction.GetText).Message, "Loan Estimate Rounded");
                #endregion

                #region Verify Closing Disclosure - Loan Costs Section D details with GetCDDetails()
                Reports.TestStep = "Verify Closing Disclosure - Loan Costs Section D details with GetCDDetails()";
                var request = CDRequestFactory.GetCDRequest(File.FileID, FASTWCFHelpers.FastClosingDisclosureService.eCDFilterSection.LoanCosts);
                var details = ClosingDisclosureService.GetCDDetails(request);
                Support.AreEqual("1", details.Status.ToString(), details.StatusDescription);
                //  
                var sectionCharge = details.LoanCosts.SectionCCharges.Charges.First(x => x.PayeeRoleType == "OutsideEscrow");
                Support.AreEqual("1,000,000.00", sectionCharge.DisplayBuyerChargeAmount, "DisplayBuyerChargeAmount");
                Support.AreEqual("$1,249,999.99", sectionCharge.DisplayLEAmount, "DisplayLEAmount");
                Support.AreEqual("$500,000.00", sectionCharge.DisplayPaidByBuyerAtClosing, "DisplayPaidByBuyerAtClosing");
                Support.AreEqual("$250,000.00", sectionCharge.DisplayPaidByBuyerBeforeClosing, "DisplayPaidByBuyerBeforeClosing");
                Support.AreEqual("(L)$250,000.00", sectionCharge.DisplayPaidByOthersForBuyer, "DisplayPaidByOthersForBuyer");
                Support.AreEqual("$50,000.00", sectionCharge.DisplayPaidByOthersForSeller, "DisplayPaidByOthersForSeller");
                Support.AreEqual("$150,000.00", sectionCharge.DisplayPaidBySellerAtClosing, "DisplayPaidBySellerAtClosing");
                Support.AreEqual("$50,000.00", sectionCharge.DisplayPaidBySellerBeforeClosing, "DisplayPaidBySellerBeforeClosing");
                Support.AreEqual("Continental Mortgage", sectionCharge.DisplayPayeeName, "DisplayPayeeName");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify Closing Disclosure - Loan Costs Section D information using GetCDDetails web service")]
        public void Scenario_4_Get_SectionD_Details()
        {
            try
            {
                Reports.TestDescription = "Verify Closing Disclosure - Loan Costs Section D information using GetCDDetails web service";

                FAST_Init_File(LenderID: "415", loanAmt: (decimal)2500000);

                AddChargesForSectionA();
                AddChargesForSectionB();
                AddChargesForSectionC();
                
                #region Verify Closing Disclosure - Loan Costs Section D details in FAST
                Reports.TestStep = "Verify Closing Disclosure - Loan Costs Section D details in FAST";
                FastDriver.ClosingDisclosure.Open();
                FastDriver.ClosingDisclosure.LoanCosts.FAClick();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.TableLoanCostSectionD);
                //  TableLoanCostSectionB
                var sectionDetails = FastDriver.ClosingDisclosure.TableLoanCostSectionD;
                Support.AreEqual("D. TOTAL LOAN COSTS (Borrower-Paid)", sectionDetails.PerformTableAction(1, 1, TableAction.GetText).Message, "Column Name");
                Support.AreEqual("$2,250,000.00", sectionDetails.PerformTableAction(1, 2, TableAction.GetText).Message, "Borrower Total");
                Support.AreEqual("Loan Costs Subtotals (A + B + C)", sectionDetails.PerformTableAction(2, 1, TableAction.GetText).Message, "Description");
                Support.AreEqual("$1,500,000.00", sectionDetails.PerformTableAction(2, 2, TableAction.GetText).Message, "Borrower At Closing");
                Support.AreEqual("$750,000.00", sectionDetails.PerformTableAction(2, 3, TableAction.GetText).Message, "Borrower Before Closing");
                Support.AreEqual("", sectionDetails.PerformTableAction(2, 4, TableAction.GetText).Message, "Seller At Closing");
                Support.AreEqual("", sectionDetails.PerformTableAction(2, 5, TableAction.GetText).Message, "Seller Before Closing");
                Support.AreEqual("", sectionDetails.PerformTableAction(2, 6, TableAction.GetText).Message, "Paid By Others");
                Support.AreEqual("", sectionDetails.PerformTableAction(2, 7, TableAction.GetText).Message, "Loan Estimate Unrounded");
                Support.AreEqual("", sectionDetails.PerformTableAction(2, 8, TableAction.GetText).Message, "Loan Estimate Rounded");
                #endregion

                #region Verify Closing Disclosure - Loan Costs Section D details with GetCDDetails()
                Reports.TestStep = "Verify Closing Disclosure - Loan Costs Section D details with GetCDDetails()";
                var request = CDRequestFactory.GetCDRequest(File.FileID, FASTWCFHelpers.FastClosingDisclosureService.eCDFilterSection.LoanCosts);
                var details = ClosingDisclosureService.GetCDDetails(request);
                Support.AreEqual("1", details.Status.ToString(), details.StatusDescription);
                //  
                Support.AreEqual("$2,250,000.00", details.LoanCosts.SectionDCharges.DisplayTotal, "DisplayTotal");
                var sectionCharge = details.LoanCosts.SectionDCharges.Charges.First();
                Support.AreEqual("$1,500,000.00", sectionCharge.DisplayPaidByBuyerAtClosing, "DisplayPaidByBuyerAtClosing");
                Support.AreEqual("$750,000.00", sectionCharge.DisplayPaidByBuyerBeforeClosing, "DisplayPaidByBuyerBeforeClosing");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
