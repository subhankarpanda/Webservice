﻿using FASTSelenium.Common;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.Delivery.FMUC0123_Deliver_Closing_Disclosure_Form.CalculatingCashToClose
{
    [CodedUITest]
    public class US290270_Update_CD_Cash_To_Close_Details : FASTHelpers
    {
        [TestMethod]
        [Description("Verify update Closing Disclosure - Calculate Cash to Close information using UpdateCDDetails web service")]
        public void Scenario_1_Update_CD_Cash_To_Close_Details()
        {
            try
            {
                Reports.TestDescription = "Verify update Closing Disclosure - Calculate Cash to Close information using UpdateCDDetails web service";

                FAST_Init_File(GABRole: AdditionalRoleType.NewLender, loanAmt: 1999999);

                #region Update CD Calculate Cash to Close information using UpdateCDDetails
                Reports.TestStep = "Update CD Calculate Cash to Close information using UpdateCDDetails";
                var detailsReq = CDRequestFactory.GetCDDetailsRequest();
                detailsReq.FileID = File.FileID ?? 0;
                detailsReq.CDFilter = FASTWCFHelpers.FastClosingDisclosureService.eCDFilterSection.CalculatingCashToClose;
                var cdDetails = ClosingDisclosureService.GetCDDetails(detailsReq);
                var updateReq = CDRequestFactory.GetUpdateCDDetailsRequest(File.FileID ?? 0);
                updateReq.ClosingDisclosure.CalculateCashToClose = cdDetails.CalculateCashToClose;
                //  Total Closing Costs(J)
                updateReq.ClosingDisclosure.CalculateCashToClose.TotalClosingCostsOfSectionJ.IsModified = true;
                updateReq.ClosingDisclosure.CalculateCashToClose.TotalClosingCostsOfSectionJ.OverrideLoanEstimate = (decimal)2000000;
                updateReq.ClosingDisclosure.CalculateCashToClose.TotalClosingCostsOfSectionJ.CashToCloseComments = "testing-comment";
                updateReq.ClosingDisclosure.CalculateCashToClose.TotalClosingCostsOfSectionJ.OverrideUnroundedLoanEstimate = (decimal)1999999.99;
                updateReq.ClosingDisclosure.CalculateCashToClose.TotalClosingCostsOfSectionJ.LoanEstimateRefreshFlag = 1;
                //  Closing Costs before Closing
                updateReq.ClosingDisclosure.CalculateCashToClose.ClosingCostsPaidBeforeClosing.IsModified = true;
                updateReq.ClosingDisclosure.CalculateCashToClose.ClosingCostsPaidBeforeClosing.LoanEstimate = (decimal)100000;
                updateReq.ClosingDisclosure.CalculateCashToClose.ClosingCostsPaidBeforeClosing.UnRoundedLoanEstimate = (decimal)99999.99;
                updateReq.ClosingDisclosure.CalculateCashToClose.ClosingCostsPaidBeforeClosing.LoanEstimateRefreshFlag = 1;
                //  Closing Costs Financed
                updateReq.ClosingDisclosure.CalculateCashToClose.ClosingCostsFinanced.IsModified = true;
                updateReq.ClosingDisclosure.CalculateCashToClose.ClosingCostsFinanced.LoanEstimate = (decimal)100000;
                updateReq.ClosingDisclosure.CalculateCashToClose.ClosingCostsFinanced.UnRoundedLoanEstimate = (decimal)99999.99;
                updateReq.ClosingDisclosure.CalculateCashToClose.ClosingCostsFinanced.LoanEstimateRefreshFlag = 1;
                //  Down Payment/Funds from Borrower
                updateReq.ClosingDisclosure.CalculateCashToClose.DownPaymentOrFundsfromBorrower.IsModified = true;
                updateReq.ClosingDisclosure.CalculateCashToClose.DownPaymentOrFundsfromBorrower.LoanEstimate = (decimal)100000;
                updateReq.ClosingDisclosure.CalculateCashToClose.DownPaymentOrFundsfromBorrower.CommentsTypeCdId = 2961;
                updateReq.ClosingDisclosure.CalculateCashToClose.DownPaymentOrFundsfromBorrower.UnRoundedLoanEstimate = (decimal)99999.99;
                updateReq.ClosingDisclosure.CalculateCashToClose.DownPaymentOrFundsfromBorrower.LoanEstimateRefreshFlag = 1;
                //  Deposit
                updateReq.ClosingDisclosure.CalculateCashToClose.Deposit.IsModified = true;
                updateReq.ClosingDisclosure.CalculateCashToClose.Deposit.LoanEstimate = (decimal)100000;
                updateReq.ClosingDisclosure.CalculateCashToClose.Deposit.UnRoundedLoanEstimate = (decimal)99999.99;
                updateReq.ClosingDisclosure.CalculateCashToClose.Deposit.LoanEstimateRefreshFlag = 1;
                //  Funds for Borrower
                updateReq.ClosingDisclosure.CalculateCashToClose.FundsForBorrower.IsModified = true;
                updateReq.ClosingDisclosure.CalculateCashToClose.FundsForBorrower.LoanEstimate = (decimal)100000;
                updateReq.ClosingDisclosure.CalculateCashToClose.FundsForBorrower.UnRoundedLoanEstimate = (decimal)99999.99;
                updateReq.ClosingDisclosure.CalculateCashToClose.FundsForBorrower.LoanEstimateRefreshFlag = 1;
                //  Seller Credits
                updateReq.ClosingDisclosure.CalculateCashToClose.SellerCredits.IsModified = true;
                updateReq.ClosingDisclosure.CalculateCashToClose.SellerCredits.LoanEstimate = (decimal)100000;
                updateReq.ClosingDisclosure.CalculateCashToClose.SellerCredits.UnRoundedLoanEstimate = (decimal)99999.99;
                updateReq.ClosingDisclosure.CalculateCashToClose.SellerCredits.LoanEstimateRefreshFlag = 1;
                //  Adjustments and Other Credits
                updateReq.ClosingDisclosure.CalculateCashToClose.AdjustmentsAndOtherCredits.IsModified = true;
                updateReq.ClosingDisclosure.CalculateCashToClose.AdjustmentsAndOtherCredits.LoanEstimate = (decimal)100000;
                updateReq.ClosingDisclosure.CalculateCashToClose.AdjustmentsAndOtherCredits.UnRoundedLoanEstimate = (decimal)99999.99;
                updateReq.ClosingDisclosure.CalculateCashToClose.AdjustmentsAndOtherCredits.LoanEstimateRefreshFlag = 1;
                //
                var response = ClosingDisclosureService.UpdateCDDetails(updateReq);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Navigate to Closing Disclosure and verify Calculate Cash to Close table
                Reports.TestStep = "Navigate to Closing Disclosure and verify Calculate Cash to Close table";
                FastDriver.ClosingDisclosure.Open();
                FastDriver.ClosingDisclosure.Calculating_Cash_to_Close.Click();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.CCTotalClosingCostsJ_ImgPlus);
                //  Total Closing Costs(J)
                Support.AreEqual("$2,000,000.00", FastDriver.ClosingDisclosure.CCC_TotalClosingCostsJ_txt.Text, "Total Closing Costs(J) | LE amount");
                Support.AreEqual("testing-comment", FastDriver.ClosingDisclosure.CCC_spnTCCComments.Text, "Total Closing Costs(J) | change text");
                Support.AreEqual("$1,999,999.99", FastDriver.ClosingDisclosure.CCC_spnTCCULEAmount.Text, "Total Closing Costs(J) | LE Unrounded amount");
                //  Closing Costs before Closing
                Support.AreEqual("$0", FastDriver.ClosingDisclosure.CCC_spnCCPLEAmount.Text, "Closing Costs before Closing | LE amount");
                Support.AreEqual("", FastDriver.ClosingDisclosure.CCC_spnCCPComments.Text, "Closing Costs before Closing | change text");
                Support.AreEqual("$0", FastDriver.ClosingDisclosure.CCC_spnCCPULEAmount.Text, "Closing Costs before Closing | LE Unrounded amount");
                //  Closing Costs Financed
                Support.AreEqual("-$100,000.00", FastDriver.ClosingDisclosure.CCFLoanEstimateAmount.Text, "Closing Costs Financed | LE amount");
                Support.AreEqual("You Included the Closing Costs in the Loan Amount, which increased the Loan Amount", FastDriver.ClosingDisclosure.CCC_spnCCFComments.Text, "Closing Costs Financed | change text");
                Support.AreEqual("-$99,999.99", FastDriver.ClosingDisclosure.CCC_spnCCFULEAmount.Text, "Closing Costs Financed | LE Unrounded amount");
                //  Down Payment/Funds from Borrower
                Support.AreEqual("$100,000.00", FastDriver.ClosingDisclosure.CCC_spnDPLEAmount.Text, "Down Payment/Funds from Borrower | LE amount");
                Support.AreEqual("This payment changed. See details in Section K and L.", FastDriver.ClosingDisclosure.CCC_spnDPComments.Text, "Down Payment/Funds from Borrower | change text");
                Support.AreEqual("$99,999.99", FastDriver.ClosingDisclosure.CCC_spnDPULEAmount.Text, "Down Payment/Funds from Borrower | LE Unrounded amount");
                //  Deposit
                Support.AreEqual("-$100,000.00", FastDriver.ClosingDisclosure.CCC_spnDLEAmount.Text, "Deposit | LE amount");
                Support.AreEqual("See Deposit in Section L. You decreased this payment.", FastDriver.ClosingDisclosure.CCC_spnDComments.Text, "Deposit | change text");
                Support.AreEqual("-$99,999.99", FastDriver.ClosingDisclosure.CCC_spnDULEAmount.Text, "Deposit | LE Unrounded amount");
                //  Funds for Borrower
                Support.AreEqual("$100,000.00", FastDriver.ClosingDisclosure.CCC_spnFBLEAmount.Text, "Funds for Borrower | LE amount");
                Support.AreEqual("This amount decreased.", FastDriver.ClosingDisclosure.CCC_spnFBComments.Text, "Funds for Borrower | change text");
                Support.AreEqual("$99,999.99", FastDriver.ClosingDisclosure.CCC_spnFBULEAmount.Text, "Funds for Borrower | LE Unrounded amount");
                //  Seller Credits
                Support.AreEqual("-$100,000.00", FastDriver.ClosingDisclosure.CCC_spnSCLEAmount.Text, "Seller Credits | LE amount");
                Support.AreEqual("See Seller Credits in Section L.", FastDriver.ClosingDisclosure.CCC_spnSCComments.Text, "Seller Credits | change text");
                Support.AreEqual("-$99,999.99", FastDriver.ClosingDisclosure.CCC_spnSCULEAmount.Text, "Seller Credits | LE Unrounded amount");
                //  Adjustments and Other Credits
                Support.AreEqual("$100,000.00", FastDriver.ClosingDisclosure.CCC_spnAOCLEAmount.Text, "Adjustments and Other Credits | LE amount");
                Support.AreEqual("See details in Sections K and L.", FastDriver.ClosingDisclosure.CCC_spnAOCComments.Text, "Adjustments and Other Credits | change text");
                Support.AreEqual("$99,999.99", FastDriver.ClosingDisclosure.CCC_spnAOCULEAmount.Text, "Adjustments and Other Credits | LE Unrounded amount");
                //  Cash to Close
                Support.AreEqual("$1,999,999.99", FastDriver.ClosingDisclosure.CashtoCloseLoanEstimate.Text, "Cash to Close | LE amount");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
