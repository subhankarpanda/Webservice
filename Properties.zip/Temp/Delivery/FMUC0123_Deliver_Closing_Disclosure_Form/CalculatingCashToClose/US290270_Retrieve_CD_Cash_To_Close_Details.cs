﻿using FASTSelenium.Common;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.Delivery.FMUC0123_Deliver_Closing_Disclosure_Form.CalculatingCashToClose
{
    [CodedUITest]
    public class US290270_Retrieve_CD_Cash_To_Close_Details : FASTHelpers
    {
        [TestMethod]
        [Description("Verify Closing Disclosure - Calculate Cash to Close information using GetCDDetails web service")]
        public void Scenario_1_Retrieve_CD_Cash_To_Close_Details()
        {
            try
            {
                Reports.TestDescription = "Verify Closing Disclosure - Calculate Cash to Close information using GetCDDetails web service";

                FAST_Init_File(GABRole: AdditionalRoleType.NewLender, loanAmt: 1999999);

                #region Navigate to New Loan and add charges impacting CD Cash to Close table
                Reports.TestStep = "Navigate to New Loan and add charges impacting CD Cash to Close table";
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.ClickChargesTab();
                //  Principal Balance
                FastDriver.NewLoan.LoanChargesPrincipalBalanceChargesPaymentDetails.Click();
                var paymentDetails = new FASTSelenium.DataObjects.IIS.PDD()
                {
                    BuyerCredit = (double)1000000,
                    LoanEstimateUnrounded = (double)1000000.99
                };
                FAST_UpdatePDD(paymentDetails);
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                //  Interest Calculation
                FastDriver.NewLoan.LoanChargesInterestCalculationInterestType.FASelectItemBySendingKeys("Fixed Rate");
                FastDriver.NewLoan.LoanChargesInterestCalculationPercentage.Click();
                FastDriver.NewLoan.LoanChargesInterestCalculationPercentageRate.FASetText("10");
                FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FASetText(DateTime.Today.ToDateString());
                FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FASetText(DateTime.Today.AddDays(28).ToDateString());
                FastDriver.NewLoan.LoanChargesInterestCalculationPaymentDetails.Click();
                paymentDetails = new FASTSelenium.DataObjects.IIS.PDD()
                {
                    LoanEstimateUnrounded = (double)9999.99
                };
                FAST_UpdatePDD(paymentDetails);
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                //  Credit/Charge Points
                FastDriver.NewLoan.CreditChargePointsPercentageLoanAmount.FASetText("10");
                FastDriver.NewLoan.CreditCharge_Points_PaymentDetails.Click();
                paymentDetails = new FASTSelenium.DataObjects.IIS.PDD()
                {
                    LoanEstimateUnrounded = (double)101000.99
                };
                FAST_UpdatePDD(paymentDetails);
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                //  Origination Charges
                FastDriver.NewLoan.LoanChargesOriginationChargePaymentDetails.Click();
                paymentDetails = new FASTSelenium.DataObjects.IIS.PDD()
                {
                    BuyerBeforeClosing = (double)50000,
                    LoanEstimateUnrounded = (double)50000.99
                };
                FAST_UpdatePDD(paymentDetails);
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                //  New Loan Charges
                FastDriver.NewLoan.NewLoanChargesPaymentDetails.Click();
                paymentDetails = new FASTSelenium.DataObjects.IIS.PDD()
                {
                    BuyerBeforeClosing = (double)50000,
                    LoanEstimateUnrounded = (double)50000.99,
                    SectionHOtherCosts = true,
                };
                FAST_UpdatePDD(paymentDetails);
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                //  
                FastDriver.BottomFrame.Done();
                #endregion

                #region Add a Deposit Outside Escrow impacting CD Cash to Close table
                Reports.TestStep = "Add a Deposit Outside Escrow impacting CD Cash to Close table";
                FastDriver.DepositOutsideEscrow.SetDeposit(new FASTSelenium.PageObjects.IIS.DepositOutsideEscrow.OEDeposit[]
                {
                    new FASTSelenium.PageObjects.IIS.DepositOutsideEscrow.OEDeposit()
                    { 
                         HeldBy = FASTSelenium.PageObjects.IIS.DepositOutsideEscrow.HeldBy.BuyersBroker,
                         Amount = (decimal)99000,
                         Comment = "FASTQA07"
                    }
                });
                #endregion

                #region Navigate to Closing Disclosure and update Calculate Cash to Close table
                Reports.TestStep = "Navigate to Closing Disclosure and update Calculate Cash to Close table";
                FastDriver.ClosingDisclosure.Open();
                FastDriver.ClosingDisclosure.Calculating_Cash_to_Close.Click();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.CCTotalClosingCostsJ_ImgPlus);
                FastDriver.ClosingDisclosure.CCTotalClosingCostsJ_ImgPlus.Click();
                FastDriver.ClosingDisclosure.CCTotalClosingCostsJ_OverrideCheck.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.CCTotalClosingCostsJ_newLEUnroundedAmt.FASetText("249999.99");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.ClosingDisclosure.CCTotalClosingCostsJ_btnOverrideDone.FAClick();
                FindVisibleElement(ByLocator.Id, "optCCC2973").Click(); //FastDriver.ClosingDisclosure.selectOtherRadioButton
                FastDriver.ClosingDisclosure.OtherComment.FASetText("test-other-reason-for-change");
                FindVisibleElement(ByLocator.Id, "btnCalculateCashToCloseDone").Click(); //FastDriver.ClosingDisclosure.btnCalculateCashToCloseDone
                FastDriver.ClosingDisclosure.CCFLoanEstimateAmount.FASetText("110000");
                FastDriver.ClosingDisclosure.CCC_spnDPLEAmount.FASetText("19999.99");
                FastDriver.ClosingDisclosure.CCC_spnDLEAmount.FASetText("19999.99");
                FastDriver.ClosingDisclosure.CCC_spnFBLEAmount.FASetText("19999.99");
                FastDriver.ClosingDisclosure.CCC_spnSCLEAmount.FASetText("19999.99");
                FastDriver.ClosingDisclosure.CCC_spnAOCLEAmount.FASetText("19999.99");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify CD Calculate Cash to Close information using GetCDDetails()
                Reports.TestStep = "Verify CD Calculate Cash to Close information using GetCDDetails()";
                var request = CDRequestFactory.GetCDDetailsRequest();
                request.CDFilter = FASTWCFHelpers.FastClosingDisclosureService.eCDFilterSection.CalculatingCashToClose;
                request.FileID = File.FileID ?? 0;
                var details = ClosingDisclosureService.GetCDDetails(request);
                Support.AreEqual("1", details.Status.ToString(), details.StatusDescription);
                //  AdjustmentsAndOtherCredits
                Support.AreEqual("$19,999.99", details.CalculateCashToClose.AdjustmentsAndOtherCredits.DisplayLoanEstimate, "AdjustmentsAndOtherCredits.DisplayLoanEstimate");
                Support.AreEqual("$0", details.CalculateCashToClose.AdjustmentsAndOtherCredits.DisplayFinalAmount, "AdjustmentsAndOtherCredits.DisplayFinalAmount");
                Support.AreEqual("NO", details.CalculateCashToClose.AdjustmentsAndOtherCredits.DisplayDidThisChange, "AdjustmentsAndOtherCredits.DisplayDidThisChange");
                //  CashToClose
                Support.AreEqual("-$991,328.77", details.CalculateCashToClose.CashToClose.DisplayFinalAmount, "CashToClose.DisplayFinalAmount");
                Support.AreEqual("$120,000.01", details.CalculateCashToClose.CashToClose.DisplayLoanEstimate, "CashToClose.DisplayLoanEstimate");
                Support.AreEqual("YES", details.CalculateCashToClose.CashToClose.DisplayDidThisChange, "CashToClose.DisplayDidThisChange");
                //  ClosingCostsFinanced
                Support.AreEqual("-$107,671.23", details.CalculateCashToClose.ClosingCostsFinanced.DisplayFinalAmount, "ClosingCostsFinanced.DisplayFinalAmount");
                Support.AreEqual("-$110,000.00", details.CalculateCashToClose.ClosingCostsFinanced.DisplayLoanEstimate, "ClosingCostsFinanced.DisplayLoanEstimate");
                Support.AreEqual("YES", details.CalculateCashToClose.ClosingCostsFinanced.DisplayDidThisChange, "ClosingCostsFinanced.DisplayDidThisChange");
                //  ClosingCostsPaidBeforeClosing
                Support.AreEqual("-$100,000.00", details.CalculateCashToClose.ClosingCostsPaidBeforeClosing.DisplayFinalAmount, "ClosingCostsPaidBeforeClosing.DisplayFinalAmount");
                Support.AreEqual("$0", details.CalculateCashToClose.ClosingCostsPaidBeforeClosing.DisplayLoanEstimate, "ClosingCostsPaidBeforeClosing.DisplayLoanEstimate");
                Support.AreEqual("YES", details.CalculateCashToClose.ClosingCostsPaidBeforeClosing.DisplayDidThisChange, "ClosingCostsPaidBeforeClosing.DisplayDidThisChange");
                //  Deposit
                Support.AreEqual("-$99,000.00", details.CalculateCashToClose.Deposit.DisplayFinalAmount, "Deposit.DisplayFinalAmount");
                Support.AreEqual("-$19,999.99", details.CalculateCashToClose.Deposit.DisplayLoanEstimate, "Deposit.DisplayLoanEstimate");
                Support.AreEqual("YES", details.CalculateCashToClose.Deposit.DisplayDidThisChange, "Deposit.DisplayDidThisChange");
                //  DownPaymentOrFundsfromBorrower
                Support.AreEqual("$0", details.CalculateCashToClose.DownPaymentOrFundsfromBorrower.DisplayFinalAmount, "DownPaymentOrFundsfromBorrower.DisplayFinalAmount");
                Support.AreEqual("$19,999.99", details.CalculateCashToClose.DownPaymentOrFundsfromBorrower.DisplayLoanEstimate, "DownPaymentOrFundsfromBorrower.DisplayLoanEstimate");
                Support.AreEqual("NO", details.CalculateCashToClose.DownPaymentOrFundsfromBorrower.DisplayDidThisChange, "DownPaymentOrFundsfromBorrower.DisplayDidThisChange");
                //  FundsForBorrower
                Support.AreEqual("-$892,328.77", details.CalculateCashToClose.FundsForBorrower.DisplayFinalAmount, "FundsForBorrower.DisplayFinalAmount");
                Support.AreEqual("-$19,999.99", details.CalculateCashToClose.FundsForBorrower.DisplayLoanEstimate, "FundsForBorrower.DisplayLoanEstimate");
                Support.AreEqual("YES", details.CalculateCashToClose.FundsForBorrower.DisplayDidThisChange, "FundsForBorrower.DisplayDidThisChange");
                //  SellerCredits
                Support.AreEqual("$0", details.CalculateCashToClose.SellerCredits.DisplayFinalAmount, "SellerCredits.DisplayFinalAmount");
                Support.AreEqual("-$19,999.99", details.CalculateCashToClose.SellerCredits.DisplayLoanEstimate, "SellerCredits.DisplayLoanEstimate");
                Support.AreEqual("NO", details.CalculateCashToClose.SellerCredits.DisplayDidThisChange, "SellerCredits.DisplayDidThisChange");
                //  TotalClosingCostsOfSectionJ
                Support.AreEqual("$207,671.23", details.CalculateCashToClose.TotalClosingCostsOfSectionJ.DisplayFinalAmount, "TotalClosingCostsOfSectionJ.DisplayFinalAmount");
                Support.AreEqual("$250,000.00", details.CalculateCashToClose.TotalClosingCostsOfSectionJ.DisplayLoanEstimate, "TotalClosingCostsOfSectionJ.DisplayLoanEstimate");
                Support.AreEqual("YES", details.CalculateCashToClose.TotalClosingCostsOfSectionJ.DisplayDidThisChange, "TotalClosingCostsOfSectionJ.DisplayDidThisChange");
                Support.AreEqual("test-other-reason-for-change", details.CalculateCashToClose.TotalClosingCostsOfSectionJ.CashToCloseComments, "TotalClosingCostsOfSectionJ.CashToCloseComments");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
