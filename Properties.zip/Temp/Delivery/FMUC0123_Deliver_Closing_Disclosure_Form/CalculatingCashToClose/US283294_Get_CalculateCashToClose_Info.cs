﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.Delivery.FMUC0123_Deliver_Closing_Disclosure_Form.CalculatingCashToClose
{
    [CodedUITest]
    public class US283294_Get_CalculateCashToClose_Info : FASTHelpers
    {
        protected void AddChargesForSectionH()
        {
            #region Navigate to Outside Escrow Company and complete charge for section H
            Reports.TestStep = "Navigate to Outside Escrow Company and complete charge for section H";
            FastDriver.OutsideEscrowCompanyDetail.Open();
            FastDriver.OutsideEscrowCompanyDetail.FindGAB("415");
            FastDriver.OutsideEscrowCompanyDetail.ChargeDescription.FASetText("test-charge");
            FastDriver.OutsideEscrowCompanyDetail.PaymentDetails.FAClick();
            FAST_UpdatePDD(new FASTSelenium.DataObjects.IIS.PDD
            {
                LoanEstimateUnrounded = (double)1249999.99,
                BuyerAtClosing = (double)500000,
                BuyerBeforeClosing = (double)250000,
                BuyerPaidbyOther = (double)250000,
                BuyerPaidbyOtherPaymentMethod = OtherPaymentMethods.POC.ToString(),
                SellerPaidAtClosing = (double)150000,
                SellerPaidBeforeClosing = (double)50000,
                SellerPaidbyOthers = (double)50000,
                SellerPaidbyOtherPaymentMthd = OtherPaymentMethods.POC.ToString(),
                SectionHOtherCosts = true,
            });
            FastDriver.BottomFrame.Done();
            #endregion
        }

        [TestMethod]
        [Description("Verify Closing Disclosure - Calculate Cash to Close information using GetCDDetails web service")]
        public void Scenario_1_Get_Section_Details()
        {
            try
            {
                Reports.TestDescription = "Verify Closing Disclosure - Calculate Cash to Close information using GetCDDetails web service";

                FAST_Init_File(LenderID: "415", loanAmt: (decimal)2500000);

                AddChargesForSectionH();

                #region Navigate to Closing Disclosure and complete Calculate Cash to Close section details
                Reports.TestStep = "Navigate to Closing Disclosure and complete Calculate Cash to Close section details";
                FastDriver.ClosingDisclosure.Open();
                FastDriver.ClosingDisclosure.CalculateCashToClose.FAClick();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.CalculatingCashtoCloseTable);
                FastDriver.ClosingDisclosure.CCC_spnCCFULEAmount.FASetText("199,999.99" + FAKeys.Tab);
                FastDriver.ClosingDisclosure.CCC_spnDPULEAmount.FASetText("199,999.99" + FAKeys.Tab);
                FastDriver.ClosingDisclosure.CCC_spnDULEAmount.FASetText("199,999.99" + FAKeys.Tab);
                FastDriver.ClosingDisclosure.CCC_spnFBULEAmount.FASetText("199,999.99" + FAKeys.Tab);
                FastDriver.ClosingDisclosure.CCC_spnSCULEAmount.FASetText("199,999.99" + FAKeys.Tab);
                FastDriver.ClosingDisclosure.CCC_spnAOCULEAmount.FASetText("199,999.99" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();
                #endregion
                
                #region Verify Closing Disclosure - Calculating Cash to Close table details with GetCDDetails()
                Reports.TestStep = "Verify Closing Disclosure - Calculating Cash to Close table details with GetCDDetails()";
                FastDriver.ClosingDisclosure.Open();
                FastDriver.ClosingDisclosure.CalculateCashToClose.FAClick();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.CalculatingCashtoCloseTable);
                var request = CDRequestFactory.GetCDRequest(File.FileID, FASTWCFHelpers.FastClosingDisclosureService.eCDFilterSection.CalculatingCashToClose);
                var details = ClosingDisclosureService.GetCDDetails(request);
                Support.AreEqual("1", details.Status.ToString(), details.StatusDescription);
                //
                //  TotalClosingCostsOfSectionJ
                Support.AreEqual("$1,250,000.00", details.CalculateCashToClose.TotalClosingCostsOfSectionJ.DisplayLoanEstimate, "TotalClosingCostsOfSectionJ.DisplayLoanEstimate");
                Support.AreEqual("$750,000.00", details.CalculateCashToClose.TotalClosingCostsOfSectionJ.DisplayFinalAmount, "TotalClosingCostsOfSectionJ.DisplayFinalAmount");
                Support.AreEqual("YES", details.CalculateCashToClose.TotalClosingCostsOfSectionJ.DisplayDidThisChange, "TotalClosingCostsOfSectionJ.DisplayDidThisChange");
                Support.AreEqual("<li>See <b>Total Other Costs (I)</b></li>", details.CalculateCashToClose.TotalClosingCostsOfSectionJ.CashToCloseComments, "TotalClosingCostsOfSectionJ.CashToCloseComments");
                Support.AreEqual("$1,249,999.99", details.CalculateCashToClose.TotalClosingCostsOfSectionJ.DisplayUnRoundedLoanEstimate, "TotalClosingCostsOfSectionJ.DisplayUnRoundedLoanEstimate");
                //  ClosingCostsPaidBeforeClosing
                Support.AreEqual("$0", details.CalculateCashToClose.ClosingCostsPaidBeforeClosing.DisplayLoanEstimate, "ClosingCostsPaidBeforeClosing.DisplayLoanEstimate");
                Support.AreEqual("-$250,000.00", details.CalculateCashToClose.ClosingCostsPaidBeforeClosing.DisplayFinalAmount, "ClosingCostsPaidBeforeClosing.DisplayFinalAmount");
                Support.AreEqual("YES", details.CalculateCashToClose.ClosingCostsPaidBeforeClosing.DisplayDidThisChange, "ClosingCostsPaidBeforeClosing.DisplayDidThisChange");
                Support.AreEqual("<li>You paid these Closing Costs <b>before closing.</b></li>", details.CalculateCashToClose.ClosingCostsPaidBeforeClosing.CashToCloseComments, "ClosingCostsPaidBeforeClosing.CashToCloseComments");
                Support.AreEqual("$0", details.CalculateCashToClose.ClosingCostsPaidBeforeClosing.DisplayUnRoundedLoanEstimate, "ClosingCostsPaidBeforeClosing.DisplayUnRoundedLoanEstimate");
                //  ClosingCostsFinanced
                Support.AreEqual("-$200,000.00", details.CalculateCashToClose.ClosingCostsFinanced.DisplayLoanEstimate, "ClosingCostsFinanced.DisplayLoanEstimate");
                Support.AreEqual("-$500,000.00", details.CalculateCashToClose.ClosingCostsFinanced.DisplayFinalAmount, "ClosingCostsFinanced.DisplayFinalAmount");
                Support.AreEqual("YES", details.CalculateCashToClose.ClosingCostsFinanced.DisplayDidThisChange, "ClosingCostsFinanced.DisplayDidThisChange");
                Support.AreEqual("<li>You <b>Included</b> the <b>Closing Costs</b> in the <b>Loan Amount</b>, which <b>increased the Loan Amount</b></li>", details.CalculateCashToClose.ClosingCostsFinanced.CashToCloseComments, "ClosingCostsFinanced.CashToCloseComments");
                Support.AreEqual("-$199,999.99", details.CalculateCashToClose.ClosingCostsFinanced.DisplayUnRoundedLoanEstimate, "ClosingCostsFinanced.DisplayUnRoundedLoanEstimate");
                //  DownPaymentOrFundsfromBorrower
                Support.AreEqual("$200,000.00", details.CalculateCashToClose.DownPaymentOrFundsfromBorrower.DisplayLoanEstimate, "DownPaymentOrFundsfromBorrower.DisplayLoanEstimate");
                Support.AreEqual("$0", details.CalculateCashToClose.DownPaymentOrFundsfromBorrower.DisplayFinalAmount, "DownPaymentOrFundsfromBorrower.DisplayFinalAmount");
                Support.AreEqual("YES", details.CalculateCashToClose.DownPaymentOrFundsfromBorrower.DisplayDidThisChange, "DownPaymentOrFundsfromBorrower.DisplayDidThisChange");
                Support.AreEqual("<li>This payment changed. See details in <b>Section K and L.</b></li>", details.CalculateCashToClose.DownPaymentOrFundsfromBorrower.CashToCloseComments, "DownPaymentOrFundsfromBorrower.CashToCloseComments");
                Support.AreEqual("$199,999.99", details.CalculateCashToClose.DownPaymentOrFundsfromBorrower.DisplayUnRoundedLoanEstimate, "DownPaymentOrFundsfromBorrower.DisplayUnRoundedLoanEstimate");
                //  Deposit
                Support.AreEqual("-$200,000.00", details.CalculateCashToClose.Deposit.DisplayLoanEstimate, "Deposit.DisplayLoanEstimate");
                Support.AreEqual("$0", details.CalculateCashToClose.Deposit.DisplayFinalAmount, "Deposit.DisplayFinalAmount");
                Support.AreEqual("YES", details.CalculateCashToClose.Deposit.DisplayDidThisChange, "Deposit.DisplayFinalAmount");
                Support.AreEqual("<li>See Deposit in <b>Section L.</b></li> <li>You <b>decreased</b> this payment.</li>", details.CalculateCashToClose.Deposit.CashToCloseComments, "Deposit.CashToCloseComments");
                Support.AreEqual("-$199,999.99", details.CalculateCashToClose.Deposit.DisplayUnRoundedLoanEstimate, "Deposit.DisplayUnRoundedLoanEstimate");
                //  FundsForBorrower
                Support.AreEqual("-$200,000.00", details.CalculateCashToClose.FundsForBorrower.DisplayLoanEstimate, "FundsForBorrower.DisplayLoanEstimate");
                Support.AreEqual("-$2,000,000.00", details.CalculateCashToClose.FundsForBorrower.DisplayFinalAmount, "FundsForBorrower.DisplayFinalAmount");
                Support.AreEqual("YES", details.CalculateCashToClose.FundsForBorrower.DisplayDidThisChange, "FundsForBorrower.DisplayFinalAmount");
                Support.AreEqual("<li>This amount <b>decreased.</b></li>", details.CalculateCashToClose.FundsForBorrower.CashToCloseComments, "FundsForBorrower.CashToCloseComments");
                Support.AreEqual("-$199,999.99", details.CalculateCashToClose.FundsForBorrower.DisplayUnRoundedLoanEstimate, "FundsForBorrower.DisplayUnRoundedLoanEstimate");
                //  SellerCredits
                Support.AreEqual("-$200,000.00", details.CalculateCashToClose.SellerCredits.DisplayLoanEstimate, "SellerCredits.DisplayLoanEstimate");
                Support.AreEqual("$0", details.CalculateCashToClose.SellerCredits.DisplayFinalAmount, "SellerCredits.DisplayFinalAmount");
                Support.AreEqual("YES", details.CalculateCashToClose.SellerCredits.DisplayDidThisChange, "SellerCredits.DisplayFinalAmount");
                Support.AreEqual("<li>See Seller Credits in <b>Section L.</b></li>", details.CalculateCashToClose.SellerCredits.CashToCloseComments, "SellerCredits.CashToCloseComments");
                Support.AreEqual("-$199,999.99", details.CalculateCashToClose.SellerCredits.DisplayUnRoundedLoanEstimate, "SellerCredits.DisplayUnRoundedLoanEstimate");
                //  AdjustmentsAndOtherCredits
                Support.AreEqual("$200,000.00", details.CalculateCashToClose.AdjustmentsAndOtherCredits.DisplayLoanEstimate, "AdjustmentsAndOtherCredits.DisplayLoanEstimate");
                Support.AreEqual("$0", details.CalculateCashToClose.AdjustmentsAndOtherCredits.DisplayFinalAmount, "AdjustmentsAndOtherCredits.DisplayFinalAmount");
                Support.AreEqual("YES", details.CalculateCashToClose.AdjustmentsAndOtherCredits.DisplayDidThisChange, "AdjustmentsAndOtherCredits.DisplayDidThisChange");
                Support.AreEqual("<li>See details in <b>Sections K and L.</b></li>", details.CalculateCashToClose.AdjustmentsAndOtherCredits.CashToCloseComments, "AdjustmentsAndOtherCredits.CashToCloseComments");
                Support.AreEqual("$199,999.99", details.CalculateCashToClose.AdjustmentsAndOtherCredits.DisplayUnRoundedLoanEstimate, "AdjustmentsAndOtherCredits.DisplayUnRoundedLoanEstimate");
                //  CashToClose
                Support.AreEqual("$850,000.00", details.CalculateCashToClose.CashToClose.DisplayLoanEstimate, "CashToClose.DisplayLoanEstimate");
                Support.AreEqual("-$2,000,000.00", details.CalculateCashToClose.CashToClose.DisplayFinalAmount, "CashToClose.DisplayFinalAmount");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
