﻿using FASTSelenium.Common;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.Escrow_Transactions.FMUC0028_Maintain_Escrow_Deposits
{
    [CodedUITest]
    public class US356774_Create_DepositInEscrow : FASTHelpers
    {
        [TestMethod]
        [Description("Verify create Deposit in Escrow using CreateDepositInEscrow web service")]
        public void Scenario_1_Create_Deposit()
        {
            try
            {
                Reports.TestDescription = "Verify create Deposit in Escrow using CreateDepositInEscrow web service";

                FAST_Init_File();

                #region Create Deposit in Escrow using CreateDepositInEscrow()
                Reports.TestStep = "Create Deposit in Escrow using CreateDepositInEscrow()";
                var request = EscrowRequestFactory.GetDepositInEscrowRequest(File.FileID);
                var response = EscrowService.CreateDepositInEscrow(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Navigate to Deposit/Receipt History and verify that deposit is created
                Reports.TestStep = "Navigate to Deposit/Receipt History and verify that deposit is created";
                FastDriver.DepositReceiptHistory.Open();
                Support.AreEqual("R  1020304  01-12-2016  5,000.00  test-payor  representing-other", FastDriver.DepositReceiptHistory.ReceiptsDepositActivityTable.FAGetText(), "Deposit #1");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
