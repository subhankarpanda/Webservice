﻿using FASTSelenium.Common;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.Escrow_Transactions.FMUC0028_Maintain_Escrow_Deposits
{
    [CodedUITest]
    public class US356794_Update_DepositInEscrow : FASTHelpers
    {
        [TestMethod]
        [Description("Verify update Deposit in Escrow using UpdateDepositInEscrow web service")]
        public void Scenario_1_Update_Deposit()
        {
            try
            {
                Reports.TestDescription = "Verify update Deposit in Escrow using UpdateDepositInEscrow web service";

                FAST_Init_File();

                #region Add Deposit In Escrow in FAST
                Reports.TestStep = "Add Deposit In Escrow in FAST";
                var depositReceiptNumber = FAST_DepositInEscrow("10000");
                FastDriver.DepositReceiptHistory.Open();
                FastDriver.DepositReceiptHistory.ReceiptsDepositActivityTable.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.DepositReceiptHistory.ViewDetails.FAClick();
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                Support.AreEqual("true", FastDriver.DepositInEscrow.CredittoBuyer.FAGetAttribute("status"), "CredittoBuyer selected");
                #endregion

                #region Update Deposit in Escrow using UpdateDepositInEscrow()
                Reports.TestStep = "Update Deposit in Escrow using UpdateDepositInEscrow()";
                var depositHistory = EscrowService.GetDepositHistorySummary(EscrowRequestFactory.GetServiceFileRequest(File.FileID));
                var request = EscrowRequestFactory.GetDepositInEscrowRequest(File.FileID);
                request.DepositInEscrow.DepositEscrow = new FASTWCFHelpers.FastEscrowService.DepositEscrow()
                {
                    CreditToTypeCdID = 329,
                    InEscrowID = depositHistory.DepositActivities[0].DepositID,
                    UpdatedEmployeeID = 1
                };
                var response = EscrowService.UpdateDepositInEscrow(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Navigate to Deposit/Receipt History and verify that deposit is updated
                Reports.TestStep = "Navigate to Deposit/Receipt History and verify that deposit is updated";
                FastDriver.DepositReceiptHistory.Open();
                FastDriver.DepositReceiptHistory.ReceiptsDepositActivityTable.PerformTableAction(1,1,TableAction.Click);
                FastDriver.DepositReceiptHistory.ViewDetails.FAClick();
                FastDriver.DepositInEscrow.WaitForScreenToLoad();
                Support.AreEqual("true", FastDriver.DepositInEscrow.CredittoOther.FAGetAttribute("status"), "CredittoOther selected");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
