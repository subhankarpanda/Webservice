﻿using FASTSelenium.Common;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.Escrow_Transactions.FMUC0120_ClosingDisclosureForm.OtherDisclosures
{
    [CodedUITest]
    public class US264124_Get_Data_From_Other_Disclosures : FASTHelpers
    {
        [TestMethod]
        [Description("Verify CD Section 11 Data Other Disclosures")]
        public void Scenario_1_Retrieve_CD_Other_Disclosure_Data()
        {
            try
            {
                Reports.TestDescription = "Verify CD Section 11 Data Other Disclosures";

                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FAST_Login_IIS();
                #endregion

                #region WCF Create File and open in FAST
                Reports.TestStep = @"Create a basic file with New Loan Lender (415) and Mortgage Broker (314)";
                FAST_WCF_File_IIS(GAB: "314", GABRole: AdditionalRoleType.MortgageBroker, isTO: true, isEO: true, SPAmt: (decimal)1000000, loanAmt: (decimal)1000, LenderID: "415");
                #endregion

                #region Verify CD Other Disclosures
                Reports.TestStep = "Verify CD Other Disclosures";
                FastDriver.ClosingDisclosure.Open();
                FastDriver.ClosingDisclosure.Other_Disclosures.Click();
                Support.IsTrue(FastDriver.ClosingDisclosure.ProtectedbyStateLaw.GetAttribute("status").ToString().ToLowerInvariant() == "false", "ClosingDisclosure.ProtectedbyStateLaw");
                Support.IsTrue(FastDriver.ClosingDisclosure.NotProtectedbyStateLaw.GetAttribute("status").ToString().ToLowerInvariant() == "false", "ClosingDisclosure.NotProtectedbyStateLaw");
                #endregion

                #region Modify CD Other Disclosures
                Reports.TestStep = "Modify CD Other Disclosures";
                FastDriver.ClosingDisclosure.ProtectedbyStateLaw.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify with GetCDDetails web service
                Reports.TestStep = "Verify with GetCDDetails web service";
                var request = CDRequestFactory.GetCDDetailsRequest();
                request.FileID = File.FileID ?? 0;
                request.CDFilter = FASTWCFHelpers.FastClosingDisclosureService.eCDFilterSection.OtherDisclosures;
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                var details = ClosingDisclosureService.GetCDDetails(request);
                Support.AreEqual(details.OtherDisclosures.ProtectedbyStateLaw.ToString(), "1");
                Support.AreEqual(details.OtherDisclosures.NotProtectedbyStateLaw.ToString(), "0");
                #endregion

                #region Modify CD Other Disclosures
                Reports.TestStep = "Modify CD Other Disclosures 2nd time";
                FastDriver.ClosingDisclosure.Other_Disclosures.Click();
                FastDriver.ClosingDisclosure.NotProtectedbyStateLaw.FASetCheckbox(true);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify with GetCDDetails web service
                Reports.TestStep = "Verify with GetCDDetails web service 2nd time";
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                details = ClosingDisclosureService.GetCDDetails(request);
                Support.AreEqual(details.OtherDisclosures.ProtectedbyStateLaw.ToString(), "0");
                Support.AreEqual(details.OtherDisclosures.NotProtectedbyStateLaw.ToString(), "1");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
