﻿using FASTSelenium.Common;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.Escrow_Transactions.FMUC0120_ClosingDisclosureForm.LoanDisclosure
{
    [CodedUITest]
    public class US264122_Get_Data_From_Loan_Disclosures_AIR_Table : FASTHelpers
    {
        [TestMethod]
        [Description("Verify the AIR Table by checking and unchecking the checkbox when product type is other than step rate")]
        public void Scenario_1_Verify_AIR_Table_product_Fixed_Rate()
        {
            try
            {
                Reports.TestDescription = "Verify the AIR Table by checking and unchecking the checkbox when product type is other than step rate";

                FAST_Init_File();

                #region Modify CD header for Loan Information
                Reports.TestStep = "Modify CD header for Loan Information";
                FastDriver.ClosingDisclosure.Open();
                FastDriver.ClosingDisclosure.imgLoanProduct.Click();
                FastDriver.ClosingDisclosure.LoanProductTypeCDID.FASelectItem("Fixed Rate");
                FastDriver.ClosingDisclosure.btnLoanProductDone.Click();
                FastDriver.ClosingDisclosure.Loan_Terms.Click();
                FastDriver.ClosingDisclosure.Section2_LoanTerms_InterestRateValue.Click();
                Keyboard.SendKeys("20" + "{TAB}");
                #endregion

                #region Verify CD Adjustable Interest Rate (AIR) Table
                Reports.TestStep = "Verify CD Adjustable Interest Rate (AIR) Table";
                FastDriver.ClosingDisclosure.AP_AIR.Click();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.Sec9_APnAIRtable_AIRTableChkBox, 5);
                Reports.TestStep = "Verify option 'Include Adjustable Interest Rate (AIR) Table' is unchecked";
                Support.AreEqual(FastDriver.ClosingDisclosure.Sec9_APnAIRtable_AIRTableChkBox.GetAttribute("status").ToString().ToLowerInvariant(), "false");
                Reports.TestStep = "Verify default values in AIR Table";
                Support.AreEqual(FastDriver.ClosingDisclosure.Sec9_AIRTable_DisplayIndexMargin.Text, "", "Sec9_AIRTable_DisplayIndexMargin");
                Support.AreEqual(FastDriver.ClosingDisclosure.Sec9_AIRTable_DisplayInitialIR.Text, "20%", "Sec9_AIRTable_DisplayInitialIR");
                Support.AreEqual(FastDriver.ClosingDisclosure.Sec9_AIRTable_DisplayMaxMinIR.Text, "", "Sec9_AIRTable_DisplayMaxMinIR");
                Support.AreEqual(FastDriver.ClosingDisclosure.Sec9_AIRTable_DisplayFreqFirstChange.Text, "", "Sec9_AIRTable_DisplayFreqFirstChange");
                Support.AreEqual(FastDriver.ClosingDisclosure.Sec9_AIRTable_DisplayFreqSubChange.Text, "", "Sec9_AIRTable_DisplayFreqSubChange");
                Support.AreEqual(FastDriver.ClosingDisclosure.Sec9_AIRTable_DisplayLimitsFirstChange.Text, "", "Sec9_AIRTable_DisplayLimitsFirstChange");
                Support.AreEqual(FastDriver.ClosingDisclosure.Sec9_AIRTable_DisplayLimitsSubChange.Text, "", "Sec9_AIRTable_DisplayLimitsSubChange");
                #endregion

                #region Modify CD AIR Table
                Reports.TestStep = "Modify CD AIR Table";
                FastDriver.ClosingDisclosure.Sec9_APnAIRtable_AIRTableChkBox.Click();
                FastDriver.ClosingDisclosure.Sec9_AIRTable_ImagePlus.Click();
                FastDriver.ClosingDisclosure.Sec9_AIRTable_IndexDescription.FASelectItemBySendingKeys("Other");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.ClosingDisclosure.Sec9_AIRTable_txtIndex.FASetText("1234567890".Repeat(5));
                FastDriver.ClosingDisclosure.Sec9_AIRTable_txtMargin.FASetText("5");
                FastDriver.ClosingDisclosure.Sec9_AIRTable_txtMinimumInterest.FASetText("2");
                FastDriver.ClosingDisclosure.Sec9_AIRTable_txtMaximumInterest.FASetText("29."+"9".Repeat(47));
                FastDriver.ClosingDisclosure.Sec9_AIRTable_txtFirstChange.FASetText("ABCD12$%");
                FastDriver.ClosingDisclosure.Sec9_AIRTable_txtEvery.FASetText("ABCD12$%");
                FastDriver.ClosingDisclosure.Sec9_AIRTable_LimitsFirstChange.FASetText("999." + "9".Repeat(10));
                FastDriver.ClosingDisclosure.Sec9_AIRTable_LimitsSubChange.FASetText("999." + "9".Repeat(10));
                FastDriver.ClosingDisclosure.Sec9_AIRTable_btnAIRPopUpDone.Click();
                FastDriver.BottomFrame.Done();
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                #endregion

                #region Verify with GetCDDetails web service
                Reports.TestStep = "Verify with GetCDDetails web service";
                var request = CDRequestFactory.GetCDDetailsRequest();
                request.FileID = File.FileID ?? 0;
                request.CDFilter = FASTWCFHelpers.FastClosingDisclosureService.eCDFilterSection.ApAir;
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                var details = ClosingDisclosureService.GetCDDetails(request);
                Support.IsTrue(details.ClosingDisclosureApAir.AdjustableIntrestRate.IncludeAdjustableInterestRateAIRTable, "ClosingDisclosureApAir.AdjustablePayment.IncludeAdjustablePaymentAPTable");
                Support.AreEqual(details.ClosingDisclosureApAir.AdjustableIntrestRate.IndexMarginPaymentInfo, "1234567890".Repeat(3) + " + 5%");
                Support.AreEqual(details.ClosingDisclosureApAir.AdjustableIntrestRate.InitialInterestRatePaymentInfo, "20%");
                Support.AreEqual(details.ClosingDisclosureApAir.AdjustableIntrestRate.MinMaxInterestRatePaymentInfo, "2% Min / 29." + "9".Repeat(4) + "% Max");
                Support.AreEqual(details.ClosingDisclosureApAir.AdjustableIntrestRate.DisplayFirstChange.AIRAmount, "Beginning of 12th month");
                Support.AreEqual(details.ClosingDisclosureApAir.AdjustableIntrestRate.DisplaySubsequentChanges.AIRAmount, "Every 12 months after first change");
                Support.AreEqual(details.ClosingDisclosureApAir.AdjustableIntrestRate.LimitFirstChange.AIRAmount, "999.9999");
                Support.AreEqual(details.ClosingDisclosureApAir.AdjustableIntrestRate.LimitSubsequentChanges.AIRAmount, "999.9999");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify the AIR Table by checking the checkbox when product type is step rate")]
        public void Scenario_2_Verify_AIR_Table_product_Step_Rate()
        {
            try
            {
                Reports.TestDescription = "Verify the AIR Table by checking the checkbox when product type is step rate";

                FAST_Init_File();

                #region Modify CD header for Loan Information
                Reports.TestStep = "Modify CD header for Loan Information";
                FastDriver.ClosingDisclosure.Open();
                FastDriver.ClosingDisclosure.imgLoanProduct.Click();
                FastDriver.ClosingDisclosure.LoanProductTypeCDID.FASelectItem("Step Rate");
                FastDriver.ClosingDisclosure.btnLoanProductDone.Click();
                FastDriver.WebDriver.WaitForAlertToExist(timeoutSeconds: 5);
                Support.AreEqual("Index + Margin values in AIR Table will be removed. Continue?", FastDriver.WebDriver.SwitchTo().Alert().Text);
                FastDriver.WebDriver.HandleDialogMessage(switchBackToFastWindow: true, clickAcceptButton: true);
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                FastDriver.ClosingDisclosure.Loan_Terms.Click();
                FastDriver.ClosingDisclosure.Section2_LoanTerms_InterestRateValue.Click();
                Keyboard.SendKeys("20" + "{TAB}");
                #endregion

                #region Verify CD Adjustable Interest Rate (AIR) Table
                Reports.TestStep = "Verify CD Adjustable Interest Rate (AIR) Table";
                FastDriver.ClosingDisclosure.AP_AIR.Click();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.Sec9_APnAIRtable_AIRTableChkBox, 5);
                Reports.TestStep = "Verify option 'Include Adjustable Interest Rate (AIR) Table' is unchecked";
                Support.AreEqual(FastDriver.ClosingDisclosure.Sec9_APnAIRtable_AIRTableChkBox.GetAttribute("status").ToString().ToLowerInvariant(), "false");
                Reports.TestStep = "Verify default values in AIR Table";
                Support.AreEqual(FastDriver.ClosingDisclosure.Sec9_AIRTable_DisplayInterestRateAdj.Text, "", "Sec9_AIRTable_DisplayInterestRateAdj");
                Support.AreEqual(FastDriver.ClosingDisclosure.Sec9_AIRTable_DisplayInitialIR.Text, "20%", "Sec9_AIRTable_DisplayInitialIR");
                Support.AreEqual(FastDriver.ClosingDisclosure.Sec9_AIRTable_DisplayMaxMinIR.Text, "", "Sec9_AIRTable_DisplayMaxMinIR");
                Support.AreEqual(FastDriver.ClosingDisclosure.Sec9_AIRTable_DisplayFreqFirstChange.Text, "", "Sec9_AIRTable_DisplayFreqFirstChange");
                Support.AreEqual(FastDriver.ClosingDisclosure.Sec9_AIRTable_DisplayFreqSubChange.Text, "", "Sec9_AIRTable_DisplayFreqSubChange");
                Support.AreEqual(FastDriver.ClosingDisclosure.Sec9_AIRTable_DisplayLimitsFirstChange.Text, "", "Sec9_AIRTable_DisplayLimitsFirstChange");
                Support.AreEqual(FastDriver.ClosingDisclosure.Sec9_AIRTable_DisplayLimitsSubChange.Text, "", "Sec9_AIRTable_DisplayLimitsSubChange");
                #endregion

                #region Modify CD AIR Table
                Reports.TestStep = "Modify CD AIR Table";
                FastDriver.ClosingDisclosure.Sec9_APnAIRtable_AIRTableChkBox.Click();
                FastDriver.ClosingDisclosure.Sec9_AIRTable_ImagePlus.Click();
                FastDriver.ClosingDisclosure.Sec9_AIRTable_txtIARFirst.FASetText("2." + "9".Repeat(48));
                FastDriver.ClosingDisclosure.Sec9_AIRTable_txtMinimumInterest.FASetText("2");
                FastDriver.ClosingDisclosure.Sec9_AIRTable_txtMaximumInterest.FASetText("29." + "9".Repeat(47));
                FastDriver.ClosingDisclosure.Sec9_AIRTable_txtFirstChange.FASetText("ABCD12$%");
                FastDriver.ClosingDisclosure.Sec9_AIRTable_txtEvery.FASetText("ABCD12$%");
                FastDriver.ClosingDisclosure.Sec9_AIRTable_LimitsFirstChange.FASetText("999."+"9".Repeat(10));
                FastDriver.ClosingDisclosure.Sec9_AIRTable_LimitsSubChange.FASetText("999." + "9".Repeat(10));
                FastDriver.ClosingDisclosure.Sec9_AIRTable_btnAIRPopUpDone.Click();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify with GetCDDetails web service
                Reports.TestStep = "Verify with GetCDDetails web service";
                var request = CDRequestFactory.GetCDDetailsRequest();
                request.FileID = File.FileID ?? 0;
                request.CDFilter = FASTWCFHelpers.FastClosingDisclosureService.eCDFilterSection.ApAir;
                FastDriver.ClosingDisclosure.WaitForScreenToLoad();
                var details = ClosingDisclosureService.GetCDDetails(request);
                Support.IsTrue(details.ClosingDisclosureApAir.AdjustableIntrestRate.IncludeAdjustableInterestRateAIRTable, "ClosingDisclosureApAir.AdjustablePayment.IncludeAdjustablePaymentAPTable");
                Support.AreEqual(details.ClosingDisclosureApAir.AdjustableIntrestRate.Index.AIRAmount, "2.999999999999999999");
                Support.AreEqual(details.ClosingDisclosureApAir.AdjustableIntrestRate.InitialInterestRatePaymentInfo, "20%");
                Support.AreEqual(details.ClosingDisclosureApAir.AdjustableIntrestRate.MinMaxInterestRatePaymentInfo, "2% Min / 29." + "9".Repeat(4) + "% Max");
                Support.AreEqual(details.ClosingDisclosureApAir.AdjustableIntrestRate.DisplayFirstChange.AIRAmount, "Beginning of 12th month");
                Support.AreEqual(details.ClosingDisclosureApAir.AdjustableIntrestRate.DisplaySubsequentChanges.AIRAmount, "Every 12 months after first change");
                Support.AreEqual(details.ClosingDisclosureApAir.AdjustableIntrestRate.LimitFirstChange.AIRAmount, "999.9999");
                Support.AreEqual(details.ClosingDisclosureApAir.AdjustableIntrestRate.LimitSubsequentChanges.AIRAmount, "999.9999");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
