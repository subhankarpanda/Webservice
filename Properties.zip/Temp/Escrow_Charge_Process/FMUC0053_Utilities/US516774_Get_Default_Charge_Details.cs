﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastEscrowService;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.Escrow_Charge_Process.FMUC0053_Utilities
{
    [CodedUITest]
    public class US516774_Get_Default_Charge_Details : FASTHelpers
    {
        #region Default Values
        protected PDD paymentDetails = new PDD()
        {
            ChargeDescription = "Utilities",
            PayTo = "",
            PayeeName = "",
            UseDefaultChecked = false,
            LoanEstimateUnrounded = (double)0,
            LoanEstimateRounded = (double)0,
            PartOfCheckbox = false,
            BuyerCharge = (double)0,
            BuyerAtClosing = (double)0,
            BuyerChargePaymentMethod = "CHK",
            BuyerBeforeClosing = (double)0,
            BuyerPaidbyOther = (double)0,
            BuyerPaidbyOtherPaymentMethod = "NONE",
            BuyerDoubleAsteriskChecked = false,
            SellerCharge = (double)0,
            SellerPaidAtClosing = (double)0,
            SellerChargePaymentMethod = "CHK",
            SellerPaidBeforeClosing = (double)0,
            SellerPaidbyOthers = (double)0,
            SellerPaidbyOtherPaymentMthd = "NONE",
            SectionHOtherCosts = true,
            TotalCharge = (double)0
        };

        protected FASTSelenium.PageObjects.IIS.UtilityProration prorationData = new FASTSelenium.PageObjects.IIS.UtilityProration()
        {
            CreditSeller = false,
            DayofClosePaidbySeller = false,
            ProrationAmount = (decimal)0,
            FromDate = "",
            fromInclusive = true,
            fromProrateDate = false,
            BasedOn = "365",
            Per = "MONTH",
            ToDate = "",
            toInclusive = false,
            toProrateDate = false,
            ProrationBuyerCharge = (decimal)0,
            ProrationBuyerCredit = (decimal)0,
            ProrationSellerCharge = (decimal)0,
            ProrationSellerCredit = (decimal)0,
            ProrationUtilityLE = (decimal)0,
        };
        #endregion

        protected void FAST_VerifyCDChargePaymentDetails(dynamic _pdd, PDD paymentDetails)
        {
            #region Verify Fee Payment Details
            var pdd = _pdd as FASTWCFHelpers.FastEscrowService.CDChargePaymentDetails;

            //  BuyerDetails
            Support.AreEqual(((Decimal)paymentDetails.BuyerCharge).ToString("C2"), ((Decimal)pdd.BuyerCharge).ToString("C2"), "BuyerCharge");
            Support.AreEqual(paymentDetails.BuyerLenderCheckbox.ToString().ToLowerInvariant(), pdd.DisplayLBuyer.ToString().ToLowerInvariant(), "DisplayLBuyer");
            Support.AreEqual(((Decimal)paymentDetails.BuyerAtClosing).ToString("C2"), ((Decimal)pdd.PBBuyerAtClosing).ToString("C2"), "PBBuyerAtClosing");
            Support.AreEqual(((Decimal)paymentDetails.BuyerBeforeClosing).ToString("C2"), ((Decimal)pdd.PBBuyerBeforeClosing).ToString("C2"), "PBBuyerBeforeClosing");
            Support.AreEqual(((Decimal)paymentDetails.BuyerPaidbyOther).ToString("C2"), ((Decimal)pdd.PBOthersForBuyer).ToString("C2"), "PBOthersForBuyer");
            Support.AreEqual(paymentDetails.BuyerPaidbyOtherPaymentMethod.ToLowerInvariant(), pdd.PBOthersForBuyerPMTypeCdID.ToString().ToLowerInvariant(), "PBOthersForBuyerPMTypeCdID");
            Support.AreEqual(paymentDetails.BuyerChargePaymentMethod.ToLowerInvariant(), pdd.AtClosingBuyerPaymentMethodTypeID.ToString().ToLowerInvariant(), "AtClosingBuyerPaymentMethodTypeID");
            //
            Support.AreEqual(paymentDetails.ChargeDescription, pdd.Description, "Description");
            Support.AreEqual(paymentDetails.BuyerDoubleAsteriskChecked.ToString().ToLowerInvariant(), pdd.DoubleAsteriskIndicator.ToString().ToLowerInvariant(), "DoubleAsteriskIndicator");
            //  Loan Estimate
            Support.AreEqual(((Decimal)paymentDetails.LoanEstimateUnrounded).ToString("N2"), ((Decimal)pdd.LEAmount).ToString("N2"), "LEAmount");
            Support.AreEqual(((Decimal)paymentDetails.LoanEstimateRounded).ToString("N2"), ((Decimal)pdd.RoundedLEAmount).ToString("N2"), "RoundedLEAmount");
            // 
            Support.AreEqual(paymentDetails.PartOfCheckbox.ToString().ToLowerInvariant(), pdd.PartOf.ToString().ToLowerInvariant(), "PartOf");
            Support.AreEqual(paymentDetails.PayTo ?? "", pdd.PayTo ?? "", "PayTo");
            Support.AreEqual(paymentDetails.PayeeName ?? "", pdd.PayeeNameOnCDOrSettlementStmt ?? "", "PayeeName");
            //  SectionShopDetails
            if (pdd.eSectionShop == FASTWCFHelpers.FastEscrowService.SectionsShoppedFor.SectionBdidNotShopFor)
                Support.IsTrue(paymentDetails.SectionBdidnotShopFor, "SectionBdidnotShopFor");
            else if (pdd.eSectionShop == FASTWCFHelpers.FastEscrowService.SectionsShoppedFor.SectionCdidShopFor)
                Support.IsTrue(paymentDetails.SectionCDidShopFor, "SectionCDidShopFor");
            else if (pdd.eSectionShop == FASTWCFHelpers.FastEscrowService.SectionsShoppedFor.SectionHotherCosts)
                Support.IsTrue(paymentDetails.SectionHOtherCosts, "SectionHOtherCosts");
            //  SellerDetails
            Support.AreEqual(((Decimal)paymentDetails.SellerCharge).ToString("C2"), ((Decimal)pdd.SellerCharge).ToString("C2"), "SellerCharge");
            Support.AreEqual(paymentDetails.SellerLenderCheckbox.ToString().ToLowerInvariant(), pdd.DisplayLSeller.ToString().ToLowerInvariant(), "DisplayLSeller");
            Support.AreEqual(((Decimal)paymentDetails.SellerPaidAtClosing).ToString("C2"), ((Decimal)pdd.PBSellerAtClosing).ToString("C2"), "PBSellerAtClosing");
            Support.AreEqual(((Decimal)paymentDetails.SellerPaidBeforeClosing).ToString("C2"), ((Decimal)pdd.PBSellerBeforeClosing).ToString("C2"), "PBSellerBeforeClosing");
            Support.AreEqual(((Decimal)paymentDetails.SellerPaidbyOthers).ToString("C2"), ((Decimal)pdd.PBOthersForSeller).ToString("C2"), "PBOthersForSeller");
            Support.AreEqual(paymentDetails.SellerPaidbyOtherPaymentMthd.ToLowerInvariant(), pdd.PBOthersForSellerPMTypeCdID.ToString().ToLowerInvariant(), "PBOthersForSellerPMTypeCdID");
            Support.AreEqual(paymentDetails.SellerChargePaymentMethod.ToLowerInvariant(), pdd.AtClosingSellerPaymentMethodTypeID.ToString().ToLowerInvariant(), "AtClosingSellerPaymentMethodTypeID");
            //
            Support.AreEqual(((Decimal)paymentDetails.TotalCharge).ToString("C2"), ((Decimal)pdd.TotalCharge).ToString("C2"), "TotalCharge");
            #endregion
        }

        protected void FAST_VerifyProrationDetails(dynamic _prorationDetails, FASTSelenium.PageObjects.IIS.UtilityProration pData)
        {
            var details = _prorationDetails as Proration;

            #region Verify Proration Details
            Support.AreEqual(((Decimal)pData.ProrationAmount).ToString("N2"), ((Decimal)details.Amount).ToString("N2"), "Proration.Amount");
            Support.AreEqual(pData.Per.ToLowerInvariant(), details.AmountPeriod.ToString().ToLowerInvariant(), "Proration.AmountPeriod");
            Support.AreEqual(pData.BasedOn, details.BasedOnDays.ToString(), "Proration.BasedOnDays");
            Support.AreEqual(((Decimal)pData.ProrationBuyerCharge).ToString("C2"), ((Decimal)details.BuyerCharge).ToString("C2"), "Proration.BuyerCharge");
            Support.AreEqual(((Decimal)pData.ProrationBuyerCredit).ToString("C2"), ((Decimal)details.BuyerCredit).ToString("C2"), "Proration.BuyerCredit");
            Support.AreEqual(pData.CreditSeller.ToString(), details.CreditSeller.ToString(), "Proration.CreditSeller");
            Support.AreEqual(pData.DayofClosePaidbySeller.ToString(), details.DayOfClosePaidbySeller.ToString(), "Proration.DayOfClosePaidbySeller");
            Support.AreEqual(pData.Description, details.Description, "Proration.Description");
            Support.AreEqual(pData.FromDate, details.FromDate != null ? ((DateTime)details.FromDate).ToDateString() : "", "Proration.FromDate");
            Support.AreEqual(pData.fromInclusive.ToString(), details.FromDateInclusive.ToString(), "Proration.FromDateInclusive");
            Support.AreEqual(pData.fromProrateDate.ToString(), details.FromDateIsProrateDate.ToString(), "Proration.FromDateIsProrateDate");
            Support.AreEqual(((Decimal)pData.ProrationUtilityLE).ToString("C2"), ((Decimal)details.LEAmount).ToString("C2"), "Proration.LEAmount");
            Support.AreEqual(pData.prorationType.ToLowerInvariant(), details.ProrationType.ToString().ToLowerInvariant(), "Proration.ProrationType");
            Support.AreEqual(((Decimal)pData.ProrationSellerCharge).ToString("C2"), ((Decimal)details.SellerCharge).ToString("C2"), "Proration.SellerCharge");
            Support.AreEqual(((Decimal)pData.ProrationSellerCredit).ToString("C2"), ((Decimal)details.SellerCredit).ToString("C2"), "Proration.SellerCredit");
            Support.AreEqual(pData.ToDate, details.ToDate != null ? ((DateTime)details.ToDate).ToDateString() : "", "Proration.ToDate");
            Support.AreEqual(pData.toInclusive.ToString(), details.ToDateInclusive.ToString(), "Proration.ToDateInclusive");
            Support.AreEqual(pData.toProrateDate.ToString(), details.ToDateIsProrateDate.ToString(), "Proration.ToDateIsProrateDate");
            #endregion
        }

        [TestMethod]
        [Description("Verify Utility default values using GetUtilityDetails web service")]
        public void Scenario_1_Get_Defaults()
        {
            try
            {
                Reports.TestDescription = "Verify Utility default values using GetUtilityDetails web service";

                FAST_Init_File();

                #region Verify Utility defaults with GetUtilityDetails()
                Reports.TestStep = "Verify Utility defaults with GetUtilityDetails()";
                FastDriver.UtilityDetail.Open();
                var details = EscrowService.GetUtilityDetails(EscrowRequestFactory.GetUtilityRequest(File.FileID, seqNum: 1));
                Support.AreEqual("1", details.Status.ToString(), details.StatusDescription);
                Support.IsTrue(details.DefaultUtilityDetails.Proration != null, "DefaultUtilityDetails.Proration != null");
                Support.IsTrue(details.DefaultUtilityDetails.UtilityCharges != null, "DefaultUtilityDetails.UtilityCharges != null");
                Support.IsTrue(details.DefaultUtilityDetails.UtilityCharges.UtilityCDChargesList.Count() > 0, "DefaultUtilityDetails.UtilityCharges.UtilityCDChargesList.Count() > 0");
                FAST_VerifyCDChargePaymentDetails(details.DefaultUtilityDetails.UtilityCharges.UtilityCDChargesList[0], paymentDetails);
                FAST_VerifyProrationDetails(details.DefaultUtilityDetails.Proration, prorationData);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
