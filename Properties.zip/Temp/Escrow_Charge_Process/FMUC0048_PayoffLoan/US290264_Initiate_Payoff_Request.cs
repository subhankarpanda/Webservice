﻿using FASTSelenium.Common;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.Escrow_Charge_Process.FMUC0048_PayoffLoan
{
    [CodedUITest]
    public class US290264_Initiate_Payoff_Request : FASTHelpers
    {
        private CreateFileRequest GetCreateFileRequest()
        {
            #region CreateFileRequest
            return new CreateFileRequest()
            {
                EmployeeObjectCD = "1",
                Source = "FAST",
                Target = "FAST",
                formType = ClosingDisclosureSupport.FormType,
                File = new File()
                {
                    TransactionTypeObjectCD = "SALE",
                    BusinessSegmentObjectCD = "RESIDENTAL",
                    ExternalFileNumber = "123456789",
                    AutoNumberIndicator = true,
                    BusinessParties = new FileBusinessParty[] 
                    {
                        new FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("1254", 189),
                            RoleTypeObjectCD = "BUSSOURCE",
                            AdditionalRole = new AdditionalRoleList()
                            {
                                eAddtionalRole = AdditionalRoleType.PayoffLender
                            },
                            CustomerReferenceNumber = "1234567890",
                        } 
                    },
                    Services = new Service[] 
                    { 
                        new Service() 
                        { 
                            OfficeInfo = new OfficeInfo() 
                            { 
                                RegionID = 189, 
                                BUID = 191, 
                            },
                        ServiceTypeObjectCD = "TO" 
                        },
                        new Service() 
                        {
                            OfficeInfo = new OfficeInfo() 
                            { 
                                RegionID = 189, 
                                BUID = 191, 
                            },
                            ServiceTypeObjectCD = "EO"
                        }
                    },
                    Properties = new Property[] 
                    { 
                        new Property() 
                        {
                            PropertyAddress = new FASTWCFHelpers.FastFileService.PhysicalAddress[] 
                            {
                                new FASTWCFHelpers.FastFileService.PhysicalAddress() 
                                { 
                                    AddrLine1 = "Main 876",
                                    State = "CA", 
                                    City = "Santa Ana", 
                                    County = "Orange", 
                                    Country = "USA",
                                    Zip = "92701"
                                } 
                            },
                            Taxes = new Taxes[]{
                                new Taxes(){
                                    APN = "024-150-06"
                                }
                            }
                        } 
                    },
                    Buyers = new BuyerSeller[] 
                    { 
                        new BuyerSeller() 
                        { 
                            FirstName = "BuyerName", 
                            LastName = "BuyerLastName", 
                            EntityTypeID = 48, 
                            Type = "Individual" 
                        }
                        
                    },
                    Sellers = new BuyerSeller[] 
                    {
                        new BuyerSeller() 
                        {
                            FirstName = "SellerName",
                            LastName = "SellerLastName",
                            EntityTypeID = 48,
                            Type = "Individual"
                        }
                        
                    }
                }
            };
            #endregion
        }
                        
        [TestMethod]
        [Description("Verify Payoff Loan is Initialized using InitiatePayoffRequest web service")]
        public void Scenario_1_Initiate_Payoff_Request()
        {
            try
            {
                Reports.TestDescription = "Verify Payoff Loan is Initialized using InitiatePayoffRequest web service";

                #region Create a file in QA Sandpoint Region
                Reports.TestStep = "Create a file in QA Sandpoint Region";
                var fileRequest = this.GetCreateFileRequest();
                var createFileResponse = FileService.CreateFile(fileRequest);
                var _File = FileService.GetOrderDetails(createFileResponse.FileID ?? 0);
                FAST_Login_IIS();
                FastDriver.SecuritySelectRegionOffice.SelectRegionOffice("191");
                FastDriver.TopFrame.SearchFileByFileNumber(_File.FileNumber);                
                #endregion

                #region Create PayoffLoan using CreatePayoffLoan web service
                Reports.TestStep = "Create PayoffLoan using CreatePayoffLoan web service";
                FastDriver.EventTrackingLog.Open();
                var request = RequestFactory.GetPayoffLoanRequest(_File.FileID ?? 0, 1254);
                var response = FileService.InitiatePayoffRequest(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Navigate to Payoff Loan and verify Payoff Loan initialization
                Reports.TestStep = "Navigate to Payoff Loan and verify Payoff Loan initialization ";
                FastDriver.PayoffLoanDetails.Open();
                Support.AreEqual("1254", FastDriver.PayoffLoanDetails.GABcodeLabel.Text ?? "", "GABcodeLabel.Text");
                Support.AreEqual("true", FastDriver.PayoffLoanDetails.RequestDemandStatement.GetAttribute("disabled") ?? "false", "RequestDemandStatement.Displayed");
                Support.AreEqual("false", FastDriver.PayoffLoanDetails.RestrictDemandUpdates.GetAttribute("status").ToLowerInvariant(), "RestrictDemandUpdates.Checked");
                #endregion

                #region Verify Event/Tracking Log for Payoff Loan initialization 
                Reports.TestStep = "Verify Event/Tracking Log for Payoff Loan initialization";
                FastDriver.EventTrackingLog.Open();
                if (FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, 1, TableAction.GetText).Message.Contains("Submitted"))
                {
                    Support.AreEqual("[Payoff Demand Request Submitted]", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, 1, TableAction.GetText).Message);
                    Support.AreEqual("[Payoff Demand Request Initiated]", FastDriver.EventTrackingLog.EventTable.PerformTableAction(2, 1, TableAction.GetText).Message);
                    Support.AreEqual("[Opened] ", FastDriver.EventTrackingLog.EventTable.PerformTableAction(3, 1, TableAction.GetText).Message);
                }
                else
                {
                    Support.AreEqual("[Payoff Demand Request Initiated]", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, 1, TableAction.GetText).Message);
                    Support.AreEqual("[Opened] ", FastDriver.EventTrackingLog.EventTable.PerformTableAction(2, 1, TableAction.GetText).Message);
                }
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
