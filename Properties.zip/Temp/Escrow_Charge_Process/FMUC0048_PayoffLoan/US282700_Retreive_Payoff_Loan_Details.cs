﻿using FASTSelenium.Common;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.Escrow_Charge_Process.FMUC0048_PayoffLoan
{
    [CodedUITest]
    public class US282700_Retreive_Payoff_Loan_Details : FASTHelpers
    {
        [TestMethod]
        [Description("Verify Payoff Loan details using GetOrderDetails web service")]
        public void Scenario_1_Retrieve_Payoff_Loan_Details()
        {
            try
            {
                Reports.TestDescription = "Verify Payoff Loan details using GetOrderDetails web service";

                FAST_Init_File();

                #region Navigate to Payoff Loan and create a new instance
                Reports.TestStep = "Navigate to Payoff Loan and create a new instance";
                FastDriver.PayoffLoanDetails.Open();
                FastDriver.PayoffLoanDetails.FindGABCode("415");
                FastDriver.PayoffLoanDetails.LenderLoanType.FASelectItemBySendingKeys("Private Party");
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.SwitchToContentFrame();
                FastDriver.PayoffLoanCharges.WaitCreation(FastDriver.PayoffLoanCharges.PaymentDetails);
                FastDriver.PayoffLoanCharges.PaymentDetails.Click();
                var paymentDetails = new FASTSelenium.DataObjects.IIS.PDD()
                {
                    BuyerAtClosing = (double)500000,
                    BuyerCredit = (double)1000000,
                    SellerPaidAtClosing = (double)500000,
                    SellerCredit = (double)1000000,
                    LoanEstimateUnrounded = (double)999999.99
                };
                FAST_UpdatePDD(paymentDetails);
                FastDriver.PayoffLoanCharges.SwitchToContentFrame();
                FastDriver.PayoffLoanCharges.WaitCreation(FastDriver.PayoffLoanCharges.InterestCalculationInterestType);
                FastDriver.PayoffLoanCharges.InterestCalculationInterestType.FASelectItemBySendingKeys("Fixed Rate");
                FastDriver.PayoffLoanCharges.InterestCalculationPercentRate.Click();
                FastDriver.PayoffLoanCharges.InterestCalculationProrPercentRateval.FASetText("2");
                FastDriver.PayoffLoanCharges.InterestCalculationProrFromDate.FASetText(DateTime.Today.ToDateString());
                FastDriver.PayoffLoanCharges.InterestCalculationProrToDate.FASetText(DateTime.Today.AddDays(28).ToDateString());
                FastDriver.PayoffLoanCharges.InterestCalculationPaymentDetails.Click();
                FAST_UpdatePDD(paymentDetails);
                FastDriver.PayoffLoanCharges.SwitchToContentFrame();
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.Click();
                FAST_UpdatePDD(paymentDetails);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify Payoff Loan Details using GetOrderDetails web service
                Reports.TestStep = "Verify Payoff Loan Details using GetOrderDetails web service";
                FastDriver.PayoffLoanDetails.Open();
                var details = FileService.GetOrderDetails(File.FileID ?? 0);
                Support.IsTrue(details.PayOffLoan != null && details.PayOffLoan.Count() > 0, "OrderDetails.PayOffLoan");
                Support.AreEqual("Continental Mortgage Corporation", details.PayOffLoan[0].BeneficiaryMortgagee ?? "", "BeneficiaryMortgagee");
                Support.AreEqual("415", details.PayOffLoan[0].FileBusinessParty.IDCode ?? "", "FileBusinessParty.IDCode");
                Support.AreEqual("668", details.PayOffLoan[0].LoanType.ToString(), "LoanType");
                Support.AreEqual("($1,000,000.00)", ((Decimal)details.PayOffLoan[0].PayOffLoanAmount).ToString("C2"), "PayOffLoanAmount");
                Support.AreEqual("$1,000,000.00", ((Decimal)details.PayOffLoan[0].PrincipalBalance).ToString("C2"), "PrincipalBalance");
                Support.AreEqual("($1,000,000.00)", ((Decimal)details.PayOffLoan[0].Recap.CheckAmount).ToString("C2"), "Recap.CheckAmount");
                Support.AreEqual("($2,000,000.00)", ((Decimal)details.PayOffLoan[0].Recap.TotalCharges).ToString("C2"), "Recap.TotalCharges");
                Support.AreEqual("Interest on Payoff Loan", details.PayOffLoan[0].CDInterestCalculationSummary[0].CDChargePaymentDetails.Description, "CDInterestCalculationSummary[0]...Description");
                Support.AreEqual("433", details.PayOffLoan[0].CDInterestCalculationSummary[0].InterestType.ToString(), "CDInterestCalculationSummary[0].InterestType");
                Support.IsTrue(true, "CDLoanCharges.Description= " + details.PayOffLoan[0].CDLoanCharges.Description);
                Support.IsTrue(true, "CDPayoffLoanCharges[0].Description= " + details.PayOffLoan[0].CDPayoffLoanCharges[0].Description);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
