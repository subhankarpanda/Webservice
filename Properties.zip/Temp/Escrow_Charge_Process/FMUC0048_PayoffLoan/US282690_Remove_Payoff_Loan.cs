﻿using FASTSelenium.Common;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.Escrow_Charge_Process.FMUC0048_PayoffLoan
{
    [CodedUITest]
    public class US282690_Remove_Payoff_Loan : FASTHelpers
    {
        [TestMethod]
        [Description("Verify Payoff Loan is removed using RemovePayOffLoan web service")]
        public void Scenario_1_Remove_Payoff_Loan()
        {
            try
            {
                Reports.TestDescription = "Verify Payoff Loan is removed using RemovePayOffLoan web service";

                FAST_Init_File();

                #region Navigate to Payoff Loan and create a new instance
                Reports.TestStep = "Navigate to Payoff Loan and create a new instance";
                FastDriver.PayoffLoanDetails.Open();
                FastDriver.PayoffLoanDetails.FindGABCode("415");
                FastDriver.PayoffLoanDetails.ClickChargesTab();
                FastDriver.PayoffLoanCharges.SwitchToContentFrame();
                FastDriver.PayoffLoanCharges.WaitCreation(FastDriver.PayoffLoanCharges.PaymentDetails, 10);
                FastDriver.PayoffLoanCharges.PaymentDetails.Click();
                var paymentDetails = new FASTSelenium.DataObjects.IIS.PDD()
                {
                    BuyerAtClosing = (double)500000,
                    BuyerCredit = (double)1000000,
                    SellerPaidAtClosing = (double)500000,
                    SellerCredit = (double)1000000,
                    LoanEstimateUnrounded = (double)999999.99
                };
                FAST_UpdatePDD(paymentDetails);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Remove Payoff Loan instance using RemovePayOffLoan web service
                Reports.TestStep = "Remove Payoff Loan instance using RemovePayOffLoan web service";
                var request = RequestFactory.GetPayOffLoanRequest(File.FileID, seqNum:1);
                var response = FileService.RemovePayOffLoan(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Navigate to Payoff Loan and verify instance was removed
                Reports.TestStep = "Navigate to Payoff Loan and verify instance was removed";
                FastDriver.PayoffLoanDetails.Open();
                Support.AreEqual("", FastDriver.PayoffLoanDetails.GABcodeLabel.Text ?? "", "PayoffLoanDetails.GABcodeLabel");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
