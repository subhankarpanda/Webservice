﻿using FASTSelenium.Common;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastEscrowService;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.Escrow_Charge_Process.FMUC0043_InspectionRepair
{
    [CodedUITest]
    public class USxxxxxx_Remove_Inspection_Repair_instance : FASTHelpers
    {
        [TestMethod]
        [Description("Verify Inspectton Repair Other is removed using RemoveInspectionRepairOther web service")]
        public void Scenario_1_US304192_Remove_OTHER_instance()
        {
            try
            {
                Reports.TestDescription = "Verify Inspectton Repair Other is removed using RemoveInspectionRepairOther web service";

                FAST_Init_File();

                #region Navigate to Inspection Repair Pest and create a new instance
                Reports.TestStep = "Navigate to Inspection Repair Pest and create a new instance";
                FastDriver.InspectionRepairOther.Open();
                FastDriver.InspectionRepairOther.FindGAB("415");
                FastDriver.InspectionRepairPest.FurnishedBy.FASelectItemBySendingKeys("Seller");
                FastDriver.InspectionRepairOther.WithinDays.FASetText("14");
                FastDriver.InspectionRepairOther.OrderDate.FASetText(DateTime.Today.ToDateString());
                FastDriver.InspectionRepairOther.DueDate.FASetText(DateTime.Today.AddDays(7).ToDateString());
                FastDriver.InspectionRepairOther.FollowUpDate.FASetText(DateTime.Today.AddDays(14).ToDateString());
                FastDriver.InspectionRepairOther.CompleteDate.FASetText(DateTime.Today.AddDays(28).ToDateString());
                FastDriver.InspectionRepairOther.ReportDate.FASetText(DateTime.Today.AddDays(35).ToDateString());
                FastDriver.InspectionRepairOther.BuyerCharge.FASetText("5,000.00");
                FastDriver.InspectionRepairOther.SellerCharge.FASetText("5,000.00");
                FastDriver.InspectionRepairOther.LEAmount.FASetText("9,999.99");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Remove created instance with RemoveInspectionRepairOther()
                Reports.TestStep = "Remove created instance with RemoveInspectionRepairOther()";
                var request = EscrowRequestFactory.GetIRORequest(File.FileID, seqNum: 1);
                var response = EscrowService.RemoveInspectionRepairOther(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Verify instance is removed in FAST
                Reports.TestStep = "Verify instance is removed in FAST";
                FastDriver.InspectionRepairOther.Open();
                Support.AreEqual("", FastDriver.InspectionRepairOther.GABcodeLabel.FAGetText().Trim(), "GABcodeLabel");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify Inspectton Repair Pest is removed using RemoveInspectionRepairPest web service")]
        public void Scenario_2_US355701_Remove_PEST_instance()
        {
            try
            {
                Reports.TestDescription = "Verify Inspectton Repair Pest is removed using RemoveInspectionRepairPest web service";

                FAST_Init_File();

                #region Navigate to Inspection Repair Pest and create a new instance
                Reports.TestStep = "Navigate to Inspection Repair Pest and create a new instance";
                FastDriver.InspectionRepairPest.Open();
                FastDriver.InspectionRepairPest.FindGAB("415");
                FastDriver.InspectionRepairPest.FurnishedBy.FASelectItemBySendingKeys("Seller");
                FastDriver.InspectionRepairPest.WithinDays.FASetText("14");
                FastDriver.InspectionRepairPest.OrderDate.FASetText(DateTime.Today.ToDateString());
                FastDriver.InspectionRepairPest.DueDate.FASetText(DateTime.Today.AddDays(7).ToDateString());
                FastDriver.InspectionRepairPest.FollowUpDate.FASetText(DateTime.Today.AddDays(14).ToDateString());
                FastDriver.InspectionRepairPest.CompleteDate.FASetText(DateTime.Today.AddDays(28).ToDateString());
                FastDriver.InspectionRepairPest.ReportDate.FASetText(DateTime.Today.AddDays(35).ToDateString());
                FastDriver.InspectionRepairPest.BuyerCharge.FASetText("5,000.00");
                FastDriver.InspectionRepairPest.SellerCharge.FASetText("5,000.00");
                FastDriver.InspectionRepairPest.LoanEstimate.FASetText("9,999.99");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Remove created instance with RemoveInspectionRepairPest()
                Reports.TestStep = "Remove created instance with RemoveInspectionRepairPest()";
                var request = EscrowRequestFactory.GetIRPRequest(File.FileID, seqNum: 1);
                var response = EscrowService.RemoveInspectionRepairPest(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Verify instance is removed in FAST
                Reports.TestStep = "Verify instance is removed in FAST";
                FastDriver.InspectionRepairPest.Open();
                Support.AreEqual("", FastDriver.InspectionRepairPest.LabelIDCode.FAGetText().Trim(), "LabelIDCode");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify Inspectton Repair Septic is removed using RemoveInspectionRepairSeptic web service")]
        public void Scenario_3_US355701_Remove_SEPTIC_instance()
        {
            try
            {
                Reports.TestDescription = "Verify Inspectton Repair Septic is removed using RemoveInspectionRepairSeptic web service";

                FAST_Init_File();

                #region Navigate to Inspection Repair Septic and create a new instance
                Reports.TestStep = "Navigate to Inspection Repair Septic and create a new instance";
                FastDriver.InspectionRepairSeptic.Open();
                FastDriver.InspectionRepairSeptic.FindGAB("415");
                FastDriver.InspectionRepairSeptic.FurnishedBy.FASelectItemBySendingKeys("Seller");
                FastDriver.InspectionRepairSeptic.WithinDays.FASetText("14");
                FastDriver.InspectionRepairSeptic.OrderDate.FASetText(DateTime.Today.ToDateString());
                FastDriver.InspectionRepairSeptic.DueDate.FASetText(DateTime.Today.AddDays(7).ToDateString());
                FastDriver.InspectionRepairSeptic.FollowUpDate.FASetText(DateTime.Today.AddDays(14).ToDateString());
                FastDriver.InspectionRepairSeptic.CompleteDate.FASetText(DateTime.Today.AddDays(28).ToDateString());
                FastDriver.InspectionRepairSeptic.ReportDate.FASetText(DateTime.Today.AddDays(35).ToDateString());
                FastDriver.InspectionRepairSeptic.BuyerCharge.FASetText("5,000.00");
                FastDriver.InspectionRepairSeptic.SellerCharge.FASetText("5,000.00");
                FastDriver.InspectionRepairSeptic.LEAmount.FASetText("9,999.99");
                FastDriver.BottomFrame.Done();
                #endregion


                #region Remove created instance with RemoveInspectionRepairSeptic()
                Reports.TestStep = "Remove created instance with RemoveInspectionRepairSeptic()";
                var request = EscrowRequestFactory.GetIRSRemoveRequest(File.FileID, seqNum: 1);
                var response = EscrowService.RemoveInspectionRepairSeptic(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Verify instance is removed in FAST
                Reports.TestStep = "Verify instance is removed in FAST";
                FastDriver.InspectionRepairSeptic.Open();
                Support.AreEqual("", FastDriver.InspectionRepairSeptic.GABcodeLabel.FAGetText().Trim(), "GABcodeLabel");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
