﻿using FASTSelenium.Common;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastEscrowService;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.Escrow_Charge_Process.FMUC0043_InspectionRepair
{
    [CodedUITest]
    public class USxxxxxx_Update_Inspection_Repair_Details : FASTHelpers
    {
        [TestMethod]
        [Description("Verify update Inspection Repair Other information using UpdateInspectionRepairOther web service")]
        public void Scenario_1_US283280_Update_OTHER_Instance()
        {
            try
            {
                Reports.TestDescription = "Verify update Inspection Repair Other information using UpdateInspectionRepairOther web service";

                FAST_Init_File();

                #region Navigate to Inspection Repair Other and create a new instance
                Reports.TestStep = "Navigate to Inspection Repair Other and create a new instance";
                FastDriver.InspectionRepairOther.Open();
                FastDriver.InspectionRepairOther.FindGAB("415");
                FastDriver.InspectionRepairOther.FurnishedBy.FASelectItemBySendingKeys("Seller");
                FastDriver.InspectionRepairOther.WithinDays.FASetText("14");
                FastDriver.InspectionRepairOther.OrderDate.FASetText(DateTime.Today.ToDateString());
                FastDriver.InspectionRepairOther.DueDate.FASetText(DateTime.Today.AddDays(7).ToDateString());
                FastDriver.InspectionRepairOther.FollowUpDate.FASetText(DateTime.Today.AddDays(14).ToDateString());
                FastDriver.InspectionRepairOther.CompleteDate.FASetText(DateTime.Today.AddDays(28).ToDateString());
                FastDriver.InspectionRepairOther.ReportDate.FASetText(DateTime.Today.AddDays(35).ToDateString());
                FastDriver.InspectionRepairOther.buyerCharge.FASetText("5,000.00");
                FastDriver.InspectionRepairOther.sellerCharge.FASetText("5,000.00");
                FastDriver.InspectionRepairOther.LEAmount.FASetText("9,999.99");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Update Inspection Repair Other datails with UpdateInspectionRepairOther()
                Reports.TestStep = "Update Inspection Repair Other datails with UpdateInspectionRepairOther()";
                var request = EscrowRequestFactory.GetIRORequest(File.FileID, seqNum: 1);
                request.oInspectionRepairDetails.CDChargeList[0].Description = "test-charge-description";
                var response = EscrowService.UpdateInspectionRepairOther(request);
                Assert.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Verify update Inspection Repair Other details in FAST
                Reports.TestStep = "Verify update Inspection Repair Other details in FAST";
                FastDriver.InspectionRepairOther.Open();
                Assert.AreEqual("501", FastDriver.InspectionRepairOther.GABcodeLabel.FAGetText() ?? "", "GABcodeLabel");
                Assert.AreEqual("Other", FastDriver.InspectionRepairOther.FurnishedBy.FAGetSelectedItem() ?? "", "FurnishedBy");
                Assert.AreEqual("28", FastDriver.InspectionRepairOther.WithinDays.FAGetValue() ?? "", "WithinDays");
                Assert.AreEqual(DateTime.Today.AddDays(70).ToDateString(), FastDriver.InspectionRepairOther.CompleteDate.FAGetValue() ?? "", "CompleteDate");
                Assert.AreEqual(DateTime.Today.AddDays(77).ToDateString(), FastDriver.InspectionRepairOther.ReportDate.FAGetValue() ?? "", "ReportDate");
                Assert.AreEqual("test-charge-description", FastDriver.InspectionRepairOther.description.FAGetValue() ?? "", "ChargeDescription");
                Assert.AreEqual("1,000,000.00", FastDriver.InspectionRepairOther.buyerCharge.FAGetValue() ?? "", "BuyerCharge");
                Assert.AreEqual("1,000,000.00", FastDriver.InspectionRepairOther.sellerCharge.FAGetValue() ?? "", "SellerCharge");
                Assert.AreEqual("999,999.99", FastDriver.InspectionRepairOther.LEAmount.FAGetValue() ?? "", "LEAmount");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify update Inspection Repair Pest information using UpdateInspectionRepairPest web service")]
        public void Scenario_2_US356206_Update_PEST_Intance()
        {
            try
            {
                Reports.TestDescription = "Verify update Inspection Repair Pest information using UpdateInspectionRepairPest web service";

                FAST_Init_File();

                #region Navigate to Inspection Repair Pest and create a new instance
                Reports.TestStep = "Navigate to Inspection Repair Pest and create a new instance";
                FastDriver.InspectionRepairPest.Open();
                FastDriver.InspectionRepairPest.FindGAB("415");
                FastDriver.InspectionRepairPest.FurnishedBy.FASelectItemBySendingKeys("Seller");
                FastDriver.InspectionRepairPest.WithinDays.FASetText("14");
                FastDriver.InspectionRepairPest.OrderDate.FASetText(DateTime.Today.ToDateString());
                FastDriver.InspectionRepairPest.DueDate.FASetText(DateTime.Today.AddDays(7).ToDateString());
                FastDriver.InspectionRepairPest.FollowUpDate.FASetText(DateTime.Today.AddDays(14).ToDateString());
                FastDriver.InspectionRepairPest.CompleteDate.FASetText(DateTime.Today.AddDays(28).ToDateString());
                FastDriver.InspectionRepairPest.ReportDate.FASetText(DateTime.Today.AddDays(35).ToDateString());
                FastDriver.InspectionRepairPest.BuyerCharge.FASetText("5,000.00");
                FastDriver.InspectionRepairPest.SellerCharge.FASetText("5,000.00");
                FastDriver.InspectionRepairPest.LoanEstimate.FASetText("9,999.99");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Update Inspection Repair Pest datails with UpdateInspectionRepairPest()
                Reports.TestStep = "Update Inspection Repair Pest datails with UpdateInspectionRepairPest()";
                var request = EscrowRequestFactory.GetIRPRequest(File.FileID, seqNum: 1);
                request.oInspectionRepairDetails.CDChargeList[0].Description = "test-charge-description";
                request.oInspectionRepairDetails.ReportInfo.FurnishedType = FurnishedType.Buyer;
                var response = EscrowService.UpdateInspectionRepairPest(request);
                Assert.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Verify update Inspection Repair Pest details in FAST
                Reports.TestStep = "Verify update Inspection Repair Pest details in FAST";
                FastDriver.InspectionRepairPest.Open();
                Assert.AreEqual("501", FastDriver.InspectionRepairPest.LabelIDCode.FAGetText() ?? "", "GABcodeLabel");
                Assert.AreEqual("Buyer", FastDriver.InspectionRepairPest.FurnishedBy.FAGetSelectedItem() ?? "", "FurnishedBy");
                Assert.AreEqual("28", FastDriver.InspectionRepairPest.WithinDays.FAGetValue() ?? "", "WithinDays");
                Assert.AreEqual(DateTime.Today.AddDays(70).ToDateString(), FastDriver.InspectionRepairPest.CompleteDate.FAGetValue() ?? "", "CompleteDate");
                Assert.AreEqual(DateTime.Today.AddDays(77).ToDateString(), FastDriver.InspectionRepairPest.ReportDate.FAGetValue() ?? "", "ReportDate");
                Assert.AreEqual("test-charge-description", FastDriver.InspectionRepairPest.description.FAGetValue() ?? "", "ChargeDescription");
                Assert.AreEqual("1,000,000.00", FastDriver.InspectionRepairPest.BuyerCharge.FAGetValue() ?? "", "BuyerCharge");
                Assert.AreEqual("1,000,000.00", FastDriver.InspectionRepairPest.SellerCharge.FAGetValue() ?? "", "SellerCharge");
                Assert.AreEqual("999,999.99", FastDriver.InspectionRepairPest.LoanEstimate.FAGetValue() ?? "", "LEAmount");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify update Inspection Repair Septic information using UpdateInspectionRepairSeptic web service")]
        public void Scenario_3_US356206_Update_SEPTIC_Instance()
        {
            try
            {
                Reports.TestDescription = "Verify update Inspection Repair Septic information using UpdateInspectionRepairSeptic web service";

                FAST_Init_File();

                #region Navigate to Inspection Repair Septic and create a new instance
                Reports.TestStep = "Navigate to Inspection Repair Septic and create a new instance";
                FastDriver.InspectionRepairSeptic.Open();
                FastDriver.InspectionRepairSeptic.FindGAB("415");
                FastDriver.InspectionRepairSeptic.FurnishedBy.FASelectItemBySendingKeys("Seller");
                FastDriver.InspectionRepairSeptic.WithinDays.FASetText("14");
                FastDriver.InspectionRepairSeptic.OrderDate.FASetText(DateTime.Today.ToDateString());
                FastDriver.InspectionRepairSeptic.DueDate.FASetText(DateTime.Today.AddDays(7).ToDateString());
                FastDriver.InspectionRepairSeptic.FollowUpDate.FASetText(DateTime.Today.AddDays(14).ToDateString());
                FastDriver.InspectionRepairSeptic.CompleteDate.FASetText(DateTime.Today.AddDays(28).ToDateString());
                FastDriver.InspectionRepairSeptic.ReportDate.FASetText(DateTime.Today.AddDays(35).ToDateString());
                FastDriver.InspectionRepairSeptic.BuyerCharge.FASetText("5,000.00");
                FastDriver.InspectionRepairSeptic.SellerCharge.FASetText("5,000.00");
                FastDriver.InspectionRepairSeptic.LEAmount.FASetText("9,999.99");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Update Inspection Repair Septic datails with UpdateInspectionRepairSeptic()
                Reports.TestStep = "Update Inspection Repair Septic datails with UpdateInspectionRepairSeptic()";
                var request = EscrowRequestFactory.GetIRSRequest(File.FileID, seqNum: 1);
                request.oInspectionRepairDetails.CDChargeList[0].Description = "test-charge-description";
                request.oInspectionRepairDetails.ReportInfo.FurnishedType = FurnishedType.Seller;
                var response = EscrowService.UpdateInspectionRepairSeptic(request);
                Assert.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Verify update Inspection Repair Septic details in FAST
                Reports.TestStep = "Verify update Inspection Repair Septic details in FAST";
                FastDriver.InspectionRepairSeptic.Open();
                Assert.AreEqual("501", FastDriver.InspectionRepairSeptic.GABcodeLabel.FAGetText() ?? "", "GABcodeLabel");
                Assert.AreEqual("Seller", FastDriver.InspectionRepairSeptic.FurnishedBy.FAGetSelectedItem() ?? "", "FurnishedBy");
                Assert.AreEqual("28", FastDriver.InspectionRepairSeptic.WithinDays.FAGetValue() ?? "", "WithinDays");
                Assert.AreEqual(DateTime.Today.AddDays(70).ToDateString(), FastDriver.InspectionRepairSeptic.CompleteDate.FAGetValue() ?? "", "CompleteDate");
                Assert.AreEqual(DateTime.Today.AddDays(77).ToDateString(), FastDriver.InspectionRepairSeptic.ReportDate.FAGetValue() ?? "", "ReportDate");
                Assert.AreEqual("test-charge-description", FastDriver.InspectionRepairSeptic.description.FAGetValue() ?? "", "ChargeDescription");
                Assert.AreEqual("1,000,000.00", FastDriver.InspectionRepairSeptic.BuyerCharge.FAGetValue() ?? "", "BuyerCharge");
                Assert.AreEqual("1,000,000.00", FastDriver.InspectionRepairSeptic.SellerCharge.FAGetValue() ?? "", "SellerCharge");
                Assert.AreEqual("999,999.99", FastDriver.InspectionRepairSeptic.LEAmount.FAGetValue() ?? "", "LEAmount");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
