﻿using FASTSelenium.Common;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.Escrow_Charge_Process.FMUC0051_PropertyTaxCheck
{
    [CodedUITest]
    public class US516431_Get_Default_Charge_Details : FASTHelpers
    {
        [TestMethod]
        [Description("Verify retrieve Property Tax Check default charge details using GetPropertyTaxCheckDetails web service")]
        public void Scenario_1_Get_Default_Charge_Details()
        {
            try
            {
                Reports.TestDescription = "Verify retrieve Property Tax Check default charge details using GetPropertyTaxCheckDetails web service";

                FAST_Init_File();

                #region Get default charge details with GetPropertyTaxCheckDetails()
                var details = EscrowService.GetPropertyTaxCheckDetails(File.FileID);
                Support.AreEqual("1", details.Status.ToString(), details.StatusDescription);
                Support.IsTrue(details.DefaultPropTaxCheckSummary.AdditionalChargesListForCD != null && details.DefaultPropTaxCheckSummary.AdditionalChargesListForCD.Count() > 0, "DefaultPropTaxCheckSummary.AdditionalChargesListForCD");
                Support.IsTrue(details.DefaultPropTaxCheckSummary.PropertyTaxesListForCD != null && details.DefaultPropTaxCheckSummary.PropertyTaxesListForCD.Count() > 0, "DefaultPropTaxCheckSummary.PropertyTaxesListForCD");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
