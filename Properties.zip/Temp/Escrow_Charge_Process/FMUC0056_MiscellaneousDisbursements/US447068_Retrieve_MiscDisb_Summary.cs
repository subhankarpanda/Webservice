﻿using FASTSelenium.Common;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;

namespace Web_Services_Regression.Escrow_Charge_Process.FMUC0056_MiscellaneousDisbursements
{
    [CodedUITest]
    public class US447068_Retrieve_MiscDisb_Summary : FASTHelpers
    {
        [TestMethod]
        [Description("Verify retrieve Miscellanoues Disbursement summary using GetMiscellaneousDisbursementSummary web service")]
        public void Scenario_1_Retrieve_MiscDisb_Summary()
        {
            try
            {
                Reports.TestDescription = "Verify retrieve Miscellanoues Disbursement summary using GetMiscellaneousDisbursementSummary web service";

                FAST_Init_File();

                #region Navigate to Miscellaneous Disbursement and create 1st instance
                Reports.TestStep = "Navigate to Miscellaneous Disbursement and create 1st instance";
                FastDriver.MiscDisbursementDetail.Open();
                FastDriver.MiscDisbursementDetail.FindGABcode("415");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to Miscellaneous Disbursement and create 2nd instance
                Reports.TestStep = "Navigate to Miscellaneous Disbursement and create 2nd instance";
                FastDriver.BottomFrame.New();
                FastDriver.MiscDisbursementDetail.WaitForScreenToLoad();
                FastDriver.MiscDisbursementDetail.FindGABcode("501");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify Miscellaneous Disbursement summary with GetMiscellaneousDisbursementSummary()
                Reports.TestStep = "Verify Miscellaneous Disbursement summary with GetMiscellaneousDisbursementSummary()";
                var details = FileService.GetMiscellaneousDisbursementSummary(RequestFactory.GetMiscDisbSummaryRequest(File.FileID));
                Support.AreEqual("1", details.Status.ToString(), details.StatusDescription);
                Support.AreEqual("Continental Mortgage Corporation", details.MiscDisbSummary[0].Name, "1st Business Party");
                Support.AreEqual("automation-user", details.MiscDisbSummary[0].BusOrgContact.ContactName, "1st Business Contact");
                Support.AreEqual("Principal Residential Mortgage, Inc.", details.MiscDisbSummary[1].Name, "2nd Business Party");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
