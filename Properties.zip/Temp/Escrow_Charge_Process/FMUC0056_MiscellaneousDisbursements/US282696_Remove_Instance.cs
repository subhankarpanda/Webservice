﻿using FASTSelenium.Common;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;

namespace Web_Services_Regression.Escrow_Charge_Process.FMUC0056_MiscellaneousDisbursements
{
    [CodedUITest]
    public class US282696_Remove_Instance : FASTHelpers
    {
        private void TestDeleteMiscDisb(FormType formType)
        {
            FAST_Login_IIS();

            FAST_WCF_File_IIS(formType: formType);

            #region Create Basic Miscallaneous Disbursement instance
            Reports.TestStep = "Create Basic Miscallaneous Disbursement instance";
            FastDriver.MiscDisbursementDetail.Open();
            FastDriver.MiscDisbursementDetail.FindGABcode("415");
            FastDriver.MiscDisbursementDetail.Description.FASetText("test-charge");
            FastDriver.BottomFrame.Done();
            #endregion

            #region Remove instance with DeleteMiscellaneousDisbursement()
            Reports.TestStep = "Remove instance with DeleteMiscellaneousDisbursement()";
            var request = RequestFactory.GetDeleteMiscDisbRequest(File.FileID, seqNum: 1);
            var response = FileService.DeleteMiscellaneousDisbursement(request);
            Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
            #endregion

            #region Verify Miscellaneous Disbursement is deleted in FAST
            Reports.TestStep = "Verify Miscellaneous Disbursement is deleted in FAST";
            FastDriver.MiscDisbursementDetail.Open();
            Support.AreEqual("", FastDriver.MiscDisbursementDetail.IDCode.FAGetText().Trim(), "IDCode");
            #endregion
        }

        [TestMethod]
        [Description("Verify deleting Miscellaneous Disbursement instance using DeleteMiscellaneousDisbursement web service when File is CD")]
        public void Scenario_1_CD_Remove_Instance()
        {
            try
            {
                Reports.TestDescription = "Verify deleting Miscellaneous Disbursement instance using DeleteMiscellaneousDisbursement web service when File is CD";

                TestDeleteMiscDisb(FormType.CD);
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify deleting Miscellaneous Disbursement instance using DeleteMiscellaneousDisbursement web service when File is HUD")]
        public void Scenario_2_HUD_Remove_Instance()
        {
            try
            {
                Reports.TestDescription = "Verify deleting Miscellaneous Disbursement instance using DeleteMiscellaneousDisbursement web service when File is HUD";

                TestDeleteMiscDisb(FormType.HUD);
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
