﻿using FASTSelenium.Common;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;


namespace Web_Services_Regression.Escrow_Charge_Process.FMUC0056_MiscellaneousDisbursements
{
    [CodedUITest]
    public class US282680_Get_Payment_Details : FASTHelpers
    {
        #region Tests Data
        private FASTSelenium.DataObjects.IIS.PDD paymentDetailsCD = new FASTSelenium.DataObjects.IIS.PDD()
        {
            LoanEstimateUnrounded = 14999.99,
            BuyerCharge = 10000,
            BuyerAtClosing = 3000,
            BuyerChargePaymentMethod = AtClosingPaymentMethods.CHK.ToString(),
            BuyerBeforeClosing = 2000,
            BuyerPaidbyOther = 5000,
            BuyerPaidbyOtherPaymentMethod = OtherPaymentMethods.POC.ToString(),
            SellerCharge = 5000,
            SellerPaidAtClosing = 3000,
            SellerChargePaymentMethod = AtClosingPaymentMethods.CHK.ToString(),
            SellerPaidBeforeClosing = 1000,
            SellerPaidbyOthers = 1000,
            SellerPaidbyOtherPaymentMthd = OtherPaymentMethods.POC.ToString(),
            TotalCharge = 15000,
            SectionHOtherCosts = true,
        };

        private FASTSelenium.DataObjects.IIS.hudPDD paymentDetailsHUD = new FASTSelenium.DataObjects.IIS.hudPDD() 
        { 
            BuyerCharge = 1000,
            BuyerPaymentMethod = AtClosingPaymentMethods.FEE.ToString(),
            SellerCharge = 1000,
            SellerPaymentMethod = AtClosingPaymentMethods.FEE.ToString(),
            GFE = "None",
        };
        #endregion

        private void TestGetMiscDisb(FormType ft)
        {
            FAST_Login_IIS();

            FAST_WCF_File_IIS(formType: ft);

            #region Add Miscellaneous Disbursement details in FAST
            Reports.TestStep = "Add Miscellaneous Disbursement details in FAST";
            FastDriver.MiscDisbursementDetail.Open();
            FastDriver.MiscDisbursementDetail.FindGABcode("415");
            FastDriver.MiscDisbursementDetail.Description.FASetText("test-charge");
            FastDriver.MiscDisbursementDetail.PaymentDetails.FAClick();
            if (ft == FormType.CD)
                FAST_UpdatePDD(paymentDetailsCD);
            else
                FAST_UpdatePDD(paymentDetailsHUD);
            FastDriver.BottomFrame.Done();
            #endregion

            #region Verify Miscellaneous Disbursement details with GetMiscellaneousDisbursement()
            Reports.TestStep = "Verify Miscellaneous Disbursement details with GetMiscellaneousDisbursement()";
            var details = FileService.GetMiscellaneousDisbursement(File.FileID ?? 0, seqNum: 1);
            Support.AreEqual("415", details.FileBusinessParty.IDCode, "IDCode");
            if (ft == FormType.CD)
                FAST_WCF_VerifyFilePDD(details.MiscDisbCDPaymentDetails[0], paymentDetailsCD);
            else
                FAST_WCF_VerifyFilePDD(details.MiscDisbPaymentDetails[0].MDPaymentDetails, paymentDetailsHUD);
            #endregion
        }

        [TestMethod]
        [Description("Verify retrieving Miscellaneous Disbursement details using GetMiscellaneousDisbursement web service when File is CD")]
        public void Scenario_1_CD_Get_MiscDisb_Details()
        {
            try
            {
                Reports.TestStep = "Verify retrieving Miscellaneous Disbursement details using GetMiscellaneousDisbursement web service when File is CD";

                TestGetMiscDisb(FormType.CD);
            }
            catch(Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify retrieving Miscellaneous Disbursement details using GetMiscellaneousDisbursement web service when File is HUD")]
        public void Scenario_2_HUD_Get_MiscDisb_Details()
        {
            try
            {
                Reports.TestStep = "Verify retrieving Miscellaneous Disbursement details using GetMiscellaneousDisbursement web service when File is HUD";

                TestGetMiscDisb(FormType.HUD);
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
