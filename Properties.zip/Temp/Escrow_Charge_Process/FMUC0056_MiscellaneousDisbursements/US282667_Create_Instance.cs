﻿using FASTSelenium.Common;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;


namespace Web_Services_Regression.Escrow_Charge_Process.FMUC0056_MiscellaneousDisbursements
{
    [CodedUITest]
    public class US282667_Create_Instance : FASTHelpers
    {
        [TestMethod]
        [Description("Verify creating new Miscellaneous Disbursement instance using CreateMiscellaneousDisbursement web service when File is CD")]
        public void Scenario_1_CD_Create_New_Instance()
        {
            try
            {
                Reports.TestDescription = "Verify creating new Miscellaneous Disbursement instance using CreateMiscellaneousDisbursement web service when File is CD";

                FAST_Login_IIS();

                FAST_WCF_File_IIS(formType: FormType.CD);

                #region Create new instance with CreateMiscellaneousDisbursement()
                Reports.TestStep = "Create new instance with CreateMiscellaneousDisbursement()";
                var request = RequestFactory.GetNewMiscDisbursementRequest(File.FileID);
                request.MiscDisbCDPaymentDetails = new CDChargePaymentDetails[]{
                    new CDChargePaymentDetails(){
                        Description = "test-charge",
                        BuyerCharge = 1000,
                        SellerCharge = 1000,
                        LEAmount = 1000,
                        SeqNum = 10,
                    }
                };
                var response = FileService.CreateMiscellaneousDisbursement(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Verify the new instance is showing in FAST
                Reports.TestStep = "Verify the new instance is showing in FAST";
                FastDriver.MiscDisbursementDetail.Open();
                Support.AreEqual("415", FastDriver.MiscDisbursementDetail.IDCode.FAGetText(), "IDCode");
                Support.AreEqual(request.MiscDisbCDPaymentDetails[0].Description, FastDriver.MiscDisbursementDetail.Description.FAGetValue(), "Charge Description");
                Support.AreEqual(request.MiscDisbCDPaymentDetails[0].BuyerCharge.ToString("N2"), FastDriver.MiscDisbursementDetail.BuyerCharge.FAGetValue(), "Buyer Charge");
                Support.AreEqual(request.MiscDisbCDPaymentDetails[0].SellerCharge.ToString("N2"), FastDriver.MiscDisbursementDetail.SellerCharge.FAGetValue(), "Seller Charge");
                Support.AreEqual(request.MiscDisbCDPaymentDetails[0].LEAmount.ToString("N2"), FastDriver.MiscDisbursementDetail.LoanEstimate.FAGetValue(), "Loan Estimate Unrounded");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify creating new Miscellaneous Disbursement instance using CreateMiscellaneousDisbursement web service when File is HUD")]
        public void Scenario_2_HUD_Create_New_Instance()
        {
            try
            {
                Reports.TestDescription = "Verify creating new Miscellaneous Disbursement instance using CreateMiscellaneousDisbursement web service when File is HUD";

                FAST_Login_IIS();

                FAST_WCF_File_IIS(formType: FormType.HUD);

                #region Create new instance with CreateMiscellaneousDisbursement()
                Reports.TestStep = "Create new instance with CreateMiscellaneousDisbursement()";
                var request = RequestFactory.GetNewMiscDisbursementRequest(File.FileID);
                request.MiscDisbPaymentDetails = new MiscDisbPaymentDetail[]{
                    new MiscDisbPaymentDetail(){
                        MDPaymentDetails = new PaymentDetailsWithGFE(){
                            Description = "test-charge",
                            BuyerPaymentMethodTypeID = 384,
                            BuyerCharge = 1000,
                            SellerPaymentMethodTypeID = 384,
                            SellerCharge = 1000,
                            SeqNum = 1,
                        },
                        GFEAmount = 1000,
                    }
                };
                var response = FileService.CreateMiscellaneousDisbursement(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Verify the new instance is showing in FAST
                Reports.TestStep = "Verify the new instance is showing in FAST";
                FastDriver.MiscDisbursementDetail.Open();
                Support.AreEqual("415", FastDriver.MiscDisbursementDetail.IDCode.FAGetText(), "IDCode");
                Support.AreEqual(request.MiscDisbPaymentDetails[0].MDPaymentDetails.Description, FastDriver.MiscDisbursementDetail.Description.FAGetValue(), "Charge Description");
                Support.AreEqual(request.MiscDisbPaymentDetails[0].MDPaymentDetails.BuyerCharge.ToString("N2"), FastDriver.MiscDisbursementDetail.BuyerCharge.FAGetValue(), "Buyer Charge");
                Support.AreEqual(request.MiscDisbPaymentDetails[0].MDPaymentDetails.SellerCharge.ToString("N2"), FastDriver.MiscDisbursementDetail.SellerCharge.FAGetValue(), "Seller Charge");
                Support.AreEqual(request.MiscDisbPaymentDetails[0].GFEAmount.ToString("N2"), FastDriver.MiscDisbursementDetail.LoanEstimate.FAGetValue(), "GFE Amount");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
