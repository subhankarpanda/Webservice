﻿using FASTSelenium.Common;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.Escrow_Charge_Process.FMUC0040_Attorney
{
    [CodedUITest]
    public class US282673_Retrieve_Buyer_Seller_Attorney_Information : FASTHelpers
    {
        private void CreateAttorneyInstance(bool isBuyer)
        {
            FastDriver.AttorneyDetail.Open(isBuyer: isBuyer);
            FastDriver.AttorneyDetail.FindGABcode("415");
            FastDriver.AttorneyDetail.PaymentDetails.Click();
            FAST_UpdatePDD(new FASTSelenium.DataObjects.IIS.PDD()
            {
                BuyerAtClosing = (double)1000000,
                SellerPaidAtClosing = (double)500000,
                LoanEstimateUnrounded = (double)999999.99
            });
            FastDriver.BottomFrame.Done();
        }

        [TestMethod]
        [Description("Verify Attorney Buyer information")]
        public void Scenario_1_Retrieve_Buyer_Attorney_Details()
        {
            try 
            {
                Reports.TestDescription = "Verify Attorney Buyer information";

                FAST_Init_File();

                #region Navigate to Attorney - Buyer and create a new instance
                Reports.TestStep = "Navigate to Attorney - Buyer and create a new instance";
                CreateAttorneyInstance(isBuyer: true);
                #endregion

                #region Verify Attorney - Buyer details using GetBuyerSellerAttorneyDetails web service
                Reports.TestStep = "Verify Attorney - Buyer details using GetBuyerSellerAttorneyDetails web service";
                var details = FileService.GetBuyerSellerAttorneyDetails(File.FileID ?? 0);
                Support.AreEqual("1", details.Status.ToString(), details.StatusDescription);
                Support.AreEqual("702", details.BuyerAttorneyDetails[0].AttorneyTypeObjectCD);
                Support.AreEqual("415", details.BuyerAttorneyDetails[0].AttorneyParty.IDCode ?? "");
                Support.AreEqual("1,000,000.00", ((Decimal)details.BuyerAttorneyDetails[0].CDChargeList[0].BuyerCharge).ToString("N2"));
                Support.AreEqual("500,000.00", ((Decimal)details.BuyerAttorneyDetails[0].CDChargeList[0].SellerCharge).ToString("N2"));
                Support.AreEqual("999,999.99", ((Decimal)details.BuyerAttorneyDetails[0].CDChargeList[0].LEAmount).ToString("N2"));
                Support.AreEqual("0.00", ((Decimal)details.BuyerAttorneyDetails[0].ChargeSummary.EarnestMoneyHeldByAttorney).ToString("N2"));
                Support.AreEqual("1,500,000.00", ((Decimal)details.BuyerAttorneyDetails[0].ChargeSummary.NetCheckAmount).ToString("N2"));
                Support.AreEqual("1,500,000.00", ((Decimal)details.BuyerAttorneyDetails[0].ChargeSummary.TotalCharges).ToString("N2"));
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify Attorney Seller information")]
        public void Scenario_2_Retrieve_Seller_Attorney_Details()
        {
            try
            {
                Reports.TestDescription = "Verify Attorney Seller information";

                FAST_Init_File();

                #region Navigate to Attorney - Seller and create a new instance
                Reports.TestStep = "Navigate to Attorney - Seller and create a new instance";
                CreateAttorneyInstance(isBuyer: false);
                #endregion

                #region Verify Attorney - Seller details using GetBuyerSellerAttorneyDetails web service
                Reports.TestStep = "Verify Attorney - Seller details using GetBuyerSellerAttorneyDetails web service";
                var details = FileService.GetBuyerSellerAttorneyDetails(File.FileID ?? 0);
                Support.AreEqual("1", details.Status.ToString(), details.StatusDescription);
                Support.AreEqual("702", details.SellerAttorneyDetails[0].AttorneyTypeObjectCD);
                Support.AreEqual("415", details.SellerAttorneyDetails[0].AttorneyParty.IDCode ?? "");
                Support.AreEqual("1,000,000.00", ((Decimal)details.SellerAttorneyDetails[0].CDChargeList[0].BuyerCharge).ToString("N2"));
                Support.AreEqual("500,000.00", ((Decimal)details.SellerAttorneyDetails[0].CDChargeList[0].SellerCharge).ToString("N2"));
                Support.AreEqual("999,999.99", ((Decimal)details.SellerAttorneyDetails[0].CDChargeList[0].LEAmount).ToString("N2"));
                Support.AreEqual("0.00", ((Decimal)details.SellerAttorneyDetails[0].ChargeSummary.EarnestMoneyHeldByAttorney).ToString("N2"));
                Support.AreEqual("1,500,000.00", ((Decimal)details.SellerAttorneyDetails[0].ChargeSummary.NetCheckAmount).ToString("N2"));
                Support.AreEqual("1,500,000.00", ((Decimal)details.SellerAttorneyDetails[0].ChargeSummary.TotalCharges).ToString("N2"));
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
