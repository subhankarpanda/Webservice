﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.Escrow_Charge_Process.FMUC0040_Attorney
{
    [CodedUITest]
    public class US332186_Create_Buyer_Seller_Attorney_Information : FASTHelpers
    {
        [TestMethod]
        [Description("Verify create Buyer Attorney information using CreateBuyerSellerAttorney web service")]
        public void Scenario_1_Create_Buyer_Attorney_Details()
        {
            try
            {
                Reports.TestDescription = "Verify create Buyer Attorney information using CreateBuyerSellerAttorney web service";

                FAST_Init_File();

                #region Add Buyer Attorney details using CreateBuyerSellerAttorney()
                Reports.TestStep = "Add Buyer Attorney details using CreateBuyerSellerAttorney()";
                var request = RequestFactory.GetCreateBuyerSellerAttorneyRequest(File.FileID ?? 0, seqNum: 1);
                request.AttorneyTypeObjectCD = "702";
                request.AttorneyParty = new FileBusinessParty() { 
                    AddrBookEntryID = AdminService.GetGABAddressBookEntryId("415"),
                    RoleTypeCdID = 322,
                    RoleTypeObjectCD = "BUYERATTY",
                };
                var response = FileService.CreateBuyerSellerAttorney(request);
                Support.AreEqual("1", response.OperationResponse.Status.ToString(), response.OperationResponse.StatusDescription);
                #endregion
                
                #region Verify Attorney - Buyer information in FAST
                Reports.TestStep = "Verify Attorney - Buyer information in FAST";
                FastDriver.AttorneyDetail.Open();
                FastDriver.AttorneyDetail.PaymentDetails.Click();
                Support.AreEqual("415", FastDriver.AttorneyDetail.GABcodeLabel.Text ?? "", "GABcodeLabel");
                Support.AreEqual("Attorney- Primary", FastDriver.AttorneyDetail.Type.FAGetSelectedItem(), "Type");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify create Seller Attorney information using CreateBuyerSellerAttorney web service")]
        public void Scenario_2_Create_Seller_Attorney_Details()
        {
            try
            {
                Reports.TestDescription = "Verify create Seller Attorney information using CreateBuyerSellerAttorney web service";

                FAST_Init_File();

                #region Add Seller Attorney details using CreateBuyerSellerAttorney()
                Reports.TestStep = "Add Seller Attorney details using CreateBuyerSellerAttorney()";
                var request = RequestFactory.GetCreateBuyerSellerAttorneyRequest(File.FileID ?? 0, seqNum: 1);
                request.AttorneyTypeObjectCD = "702";
                request.AttorneyParty = new FileBusinessParty()
                {
                    AddrBookEntryID = AdminService.GetGABAddressBookEntryId("415"),
                    RoleTypeCdID = 325,
                    RoleTypeObjectCD = "SELLATTY",
                };
                var response = FileService.CreateBuyerSellerAttorney(request);
                Support.AreEqual("1", response.OperationResponse.Status.ToString(), response.OperationResponse.StatusDescription);
                #endregion

                #region Verify Attorney - Seller information in FAST
                Reports.TestStep = "Verify Attorney - Seller information in FAST";
                FastDriver.AttorneyDetail.Open(isBuyer:false);
                FastDriver.AttorneyDetail.PaymentDetails.Click();
                Support.AreEqual("415", FastDriver.AttorneyDetail.GABcodeLabel.Text ?? "", "GABcodeLabel");
                Support.AreEqual("Attorney- Primary", FastDriver.AttorneyDetail.Type.FAGetSelectedItem(), "Type");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
