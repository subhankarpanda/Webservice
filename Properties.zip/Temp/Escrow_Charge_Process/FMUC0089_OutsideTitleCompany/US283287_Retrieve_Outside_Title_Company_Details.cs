﻿using FASTSelenium.Common;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.Escrow_Charge_Process.FMUC0089_OutsideTitleCompany
{
    [CodedUITest]
    public class US283287_Retrieve_Outside_Title_Company_Details : FASTHelpers
    {
        [TestMethod]
        [Description("Verify the Outside Title Company Details with service GetOutsideTitleCompanyDetails")]
        public void Scenario_1_Retrieve_OTC_Details()
        {
            try
            {
                Reports.TestStep = "Verify the Outside Title Company Details with service GetOutsideTitleCompanyDetails";

                FAST_Init_File();

                #region Navigate to Outside Title Company and create a new instance
                Reports.TestStep = "Navigate to Outside Title Company and create a new instance";
                FastDriver.OTCDetail.Open();
                FastDriver.OTCDetail.FindGAB("415");
                FastDriver.OTCDetail.ChargesRetained.FASetText("1300000");
                FastDriver.OTCDetail.Type.FASelectItemBySendingKeys("Attorney");
                FastDriver.OTCDetail.OTCTitleServicesPaymentDetails.Click();
                var paymentDetails = new FASTSelenium.DataObjects.IIS.PDD()
                {
                    BuyerAtClosing = (double)500000,
                    BuyerCredit = (double)1000000,
                    SellerPaidAtClosing = (double)500000,
                    SellerCredit = (double)1000000,
                    LoanEstimateUnrounded = (double)999999.99
                };
                FAST_UpdatePDD(paymentDetails);
                FastDriver.OTCDetail.SwitchToContentFrame();
                if (FastDriver.OTCDetail.DisplayAggregateOnCD.Exists())
                    FastDriver.OTCDetail.DisplayAggregateOnCD.FASetCheckbox(true);
                FastDriver.OTCDetail.OTCLenderPolicyEndorsementPaymentDetails.Click();
                FAST_UpdatePDD(paymentDetails);
                FastDriver.OTCDetail.SwitchToContentFrame();
                FastDriver.OTCDetail.OTCOwnerPolicyEndorsementPaymentDetails.Click();
                FAST_UpdatePDD(paymentDetails);
                FastDriver.OTCDetail.SwitchToContentFrame();
                FastDriver.OTCDetail.GRCLoanEstimateUnroundedAmount.FASetText("999999.99");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.OTCDetail.TTLoanEstimateUnroundedAmount.FASetText("999999.99");
                Keyboard.SendKeys(FAKeys.TabAway);
                FastDriver.BottomFrame.Done();
                FastDriver.OTCDetail.WaitForScreenToLoad();
                #endregion

                #region Verify OTC details using GetOutsideTitleCompanyDetails web service
                Reports.TestStep = "Verify OTC details using GetOutsideTitleCompanyDetails web service";
                var details = EscrowService.GetOutsideTitleCompanyDetails(EscrowRequestFactory.GetServiceFileRequest(File.FileID ?? 0));
                Support.AreEqual("1", details.Status.ToString(), details.StatusDescription);
                //  OTCInformations
                Support.AreEqual("1,300,000.00", ((Decimal)details.OTCInformations[0].OTCDetails.ChargesRetained).ToString("N2"), "OTCDetails.ChargesRetained");
                Support.AreEqual("Attorney", details.OTCInformations[0].OTCDetails.eOTCType.ToString(), "OTCDetails.eOTCType");
                Support.AreEqual("415", details.OTCInformations[0].OTCFileBusinessPartyInfo.FileBusinessParty.IDCode, "FileBusinessParty.IDCode");
                Support.AreEqual("1,700,000.00", ((Decimal)details.OTCInformations[0].OTCRecap.NetCheckAmount).ToString("N2"), "OTCRecap.NetCheckAmount");
                Support.AreEqual("3,000,000.00", ((Decimal)details.OTCInformations[0].OTCRecap.TotalCharges).ToString("N2"), "OTCRecap.TotalCharges");
                Support.AreEqual("1,000,000.00", ((Decimal)details.OTCInformations[0].OTCRecordingFeesAndTransferTaxesCD.OTCRecordingFeesLoanEstimateRounded).ToString("N2"), "OTCRecordingFeesLoanEstimateRounded");
                Support.AreEqual("999,999.99", ((Decimal)details.OTCInformations[0].OTCRecordingFeesAndTransferTaxesCD.OTCRecordingFeesLoanEstimateUnrounded).ToString("N2"), "OTCRecordingFeesLoanEstimateUnrounded");
                Support.AreEqual("0.00", ((Decimal)details.OTCInformations[0].OTCRecordingFeesAndTransferTaxesCD.OTCRecordingFeesSum).ToString("N2"), "OTCRecordingFeesSum");
                Support.AreEqual("1,000,000.00", ((Decimal)details.OTCInformations[0].OTCRecordingFeesAndTransferTaxesCD.OTCTransferTaxesLoanEstimateRounded).ToString("N2"), "OTCTransferTaxesLoanEstimateRounded");
                Support.AreEqual("999,999.99", ((Decimal)details.OTCInformations[0].OTCRecordingFeesAndTransferTaxesCD.OTCTransferTaxesLoanEstimateUnrounded).ToString("N2"), "OTCTransferTaxesLoanEstimateUnrounded");
                Support.AreEqual("0.00", ((Decimal)details.OTCInformations[0].OTCRecordingFeesAndTransferTaxesCD.OTCTransferTaxesSum).ToString("N2"), "OTCTransferTaxesSum");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
