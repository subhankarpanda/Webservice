﻿using FASTSelenium.Common;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.Escrow_Charge_Process.FMUC0089_OutsideTitleCompany
{
    [CodedUITest]
    public class US510232_Create_OTC_with_RecFees_and_TransferTaxes : FASTHelpers
    {
        [TestMethod]
        [Description("Verify create OTC with Recording Fees and Transfer Taxes using CreateOutsideTitleCompany web service")]
        public void Scenario_1_Create_OTC_instance()
        { 
            try
            {
                Reports.TestDescription = "Verify create OTC with Recording Fees and Transfer Taxes using CreateOutsideTitleCompany web service";

                FAST_Init_File();

                #region Create an OTC instance using CreateOutsideTitleCompany web service
                Reports.TestStep = "Create an OTC instance using CreateOutsideTitleCompany web service";
                var details = EscrowService.GetOutsideTitleCompanyDetails(EscrowRequestFactory.GetServiceFileRequest(File.FileID ?? 0));
                var request = RequestFactory.GetOTCRequest(File.FileID ?? 0);
                request.OTCRecordingFeesAndTransferTaxesCD = RequestFactory.GetOTCRecordingFeesAndTransferTaxesCD();
                request.OTCRecordingFeesAndTransferTaxesCD.OTCRecordingFeesAndTransferTaxesCDList[0].FeeID = details.DefaultOTCInformation.OTCRecordingFeesAndTransferTaxesCD.OTCRecordingFeesAndTransferTaxesCDList[0].FeeID;
                request.OTCRecordingFeesAndTransferTaxesCD.OTCRecordingFeesAndTransferTaxesCDList[0].ServiceFileFeeId = details.DefaultOTCInformation.OTCRecordingFeesAndTransferTaxesCD.OTCRecordingFeesAndTransferTaxesCDList[0].ServiceFileFeeId;
                var response = FileService.CreateOutsideTitleCompany(request);
                Support.AreEqual("1", response.OperationResponse.Status.ToString(), response.OperationResponse.StatusDescription);
                #endregion

                #region Verify OTC instance details in FAST
                Reports.TestStep = "Verify OTC instance details in FAST";
                FastDriver.OTCDetail.Open();
                // Summary Info
                Support.AreEqual("$ 8,000,000.00", FastDriver.OTCDetail.TotalChgs.Text, "Total Charges");
                Support.AreEqual("$ 1,300,000.00", FastDriver.OTCDetail.ChgsRetained.Text, "Funds Deposited with OTC");
                Support.AreEqual("$ 5,900,000.00", FastDriver.OTCDetail.NetCheckAmt.Text, "Net Check Amount");
                Support.AreEqual("CA, TEST04STTITLEINS", FastDriver.OTCDetail.BusOrg_LicenseID.Text ?? "", "BusOrg_LicenseID");
                Support.AreEqual("CA, TEST04STTITLEINS", FastDriver.OTCDetail.BusOrg_ContactLicenseID.Text ?? "", "BusOrg_ContactLicenseID");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

    }
}
