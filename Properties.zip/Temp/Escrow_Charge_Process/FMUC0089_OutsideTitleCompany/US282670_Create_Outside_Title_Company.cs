﻿using FASTSelenium.Common;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.Escrow_Charge_Process.FMUC0089_OutsideTitleCompany
{
    [CodedUITest]
    public class US282670_Create_Outside_Title_Company : FASTHelpers
    {
        [TestMethod]
        [Description("Verify OTC Information and Details")]
        public void Scenario_1_Create_OTC_Instance()
        {
            try 
            {
                Reports.TestDescription = "Verify OTC Information and Details";

                FAST_Init_File();

                #region Create an OTC instance using CreateOutsideTitleCompany web service
                Reports.TestStep = "Create an OTC instance using CreateOutsideTitleCompany web service";
                var request = RequestFactory.GetOTCRequest(File.FileID ?? 0);
                var response = FileService.CreateOutsideTitleCompany(request);
                Support.AreEqual("1", response.OperationResponse.Status.ToString(), response.OperationResponse.StatusDescription);
                #endregion

                #region Verify OTC instance details in FAST
                Reports.TestStep = "Verify OTC instance details in FAST";
                FastDriver.OTCDetail.Open();
                // Summary Info
                Support.AreEqual("$ 6,000,000.00", FastDriver.OTCDetail.TotalChgs.Text, "Total Charges");
                Support.AreEqual("$ 1,300,000.00", FastDriver.OTCDetail.ChgsRetained.Text, "Funds Deposited with OTC");
                Support.AreEqual("$ 4,100,000.00", FastDriver.OTCDetail.NetCheckAmt.Text, "Net Check Amount");
                Support.AreEqual("CA, TEST04STTITLEINS", FastDriver.OTCDetail.BusOrg_LicenseID.Text ?? "", "BusOrg_LicenseID");
                Support.AreEqual("CA, TEST04STTITLEINS", FastDriver.OTCDetail.BusOrg_ContactLicenseID.Text ?? "", "BusOrg_ContactLicenseID");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
