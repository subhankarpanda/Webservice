﻿using FASTSelenium.Common;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.Escrow_Charge_Process.FMUC0089_OutsideTitleCompany
{
    [CodedUITest]
    public class US439191_Update_OTC_Charge_PDD : FASTHelpers
    {
        #region paymentDetails
        protected FASTSelenium.DataObjects.IIS.PDD paymentDetails = new FASTSelenium.DataObjects.IIS.PDD()
        {
            AdditionalDescription = "test-description",
            UseDefaultChecked = true,
            BuyerCredit = (double)0.00,
            BuyerCreditPaymentMethod = CreditPaymentMethods.AtClosing.ToString(),
            LoanEstimateUnrounded = (double)999999.99,
            BuyerAtClosing = (double)900000.00,
            BuyerBeforeClosing = (double)99999.99,
            BuyerPaidbyOther = (double)0.01,
            BuyerPaidbyOtherPaymentMethod = OtherPaymentMethods.POC.ToString(),
            SellerCredit = (double)0.00,
            SellerCreditPaymentMethod = CreditPaymentMethods.AtClosing.ToString(),
            SellerPaidAtClosing = (double)900000.00,
            SellerPaidBeforeClosing = (double)99999.99,
            SellerPaidbyOthers = (double)0.01,
            SellerPaidbyOtherPaymentMthd = OtherPaymentMethods.POC.ToString(),
            PartOfCheckbox = false,
            //SectionsShoppedFor.None,
        };
        #endregion

        [TestMethod]
        [Description("Verify update OTC charge payment details using UpdateOutsideTitleCompanyDetails web service")]
        public void Scenario_1_Update_OTC_Charge_PDD()
        {
            try
            {
                Reports.TestDescription = "Verify update OTC charge payment details using UpdateOutsideTitleCompanyDetails web service";

                FAST_Init_File();

                #region Navigate to Outside Title Company and create a new instance
                Reports.TestStep = "Navigate to Outside Title Company and create a new instance";
                FastDriver.OTCDetail.Open();
                FastDriver.OTCDetail.FindGAB("415");
                FastDriver.OTCDetail.Type.FASelectItemBySendingKeys("Attorney");
                FastDriver.BottomFrame.Done();
                FastDriver.OTCDetail.WaitForScreenToLoad();
                #endregion

                #region Update OTC charge PDD using UpdateOutsideTitleCompanyDetails()
                Reports.TestStep = "Update OTC charge PDD using UpdateOutsideTitleCompanyDetails()";
                var request = EscrowRequestFactory.GetOTCRequest(File.FileID, seqNum: 1);
                request.OTCInformation.OTCLendersPolicyAndEndorsementChargesCD = new FASTWCFHelpers.FastEscrowService.OTCLendersPolicyAndEndorsementChargesCD() {
                    OTCLendersPolicyAndEndorsementChargesListCD = new FASTWCFHelpers.FastEscrowService.CDChargePaymentDetails[] { 
                        EscrowRequestFactory.GetCDChargePaymentDetails() 
                    }
                };
                var response = EscrowService.UpdateOutsideTitleCompanyDetails(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Verify OTC charge PDD in FAST
                Reports.TestStep = "Verify OTC charge PDD in FAST";
                FastDriver.OTCDetail.Open();
                FastDriver.OTCDetail.OTCLenderPolicyEndorsementPaymentDetails.Click();
                FAST_VerifyPDD(paymentDetails);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
