﻿using FASTSelenium.Common;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.Escrow_Charge_Process.FMUC0041_HomeownerAssociation
{
    [CodedUITest]
    public class US400910_Update_Homeowner_Association_Details : FASTHelpers
    {
        #region Payment Details
        protected FASTSelenium.DataObjects.IIS.PDD paymentDetails = new FASTSelenium.DataObjects.IIS.PDD()
        {
            UseDefaultChecked = true,
            LoanEstimateUnrounded = (double)999999.99,
            LoanEstimateRounded = (double)1000000.00,
            PartOfCheckbox = false,
            BuyerCharge = (double)1000000.00,
            BuyerAtClosing = (double)900000.00,
            BuyerChargePaymentMethod = "Check",
            BuyerBeforeClosing = (double)99999.99,
            BuyerPaidbyOther = (double)0.01,
            BuyerPaidbyOtherPaymentMethod = "POC",
            BuyerDoubleAsteriskChecked = false,
            SellerCharge = (double)1000000.00,
            SellerPaidAtClosing = (double)900000.00,
            SellerChargePaymentMethod = "Check",
            SellerPaidBeforeClosing = (double)99999.99,
            SellerPaidbyOthers = (double)0.01,
            SellerPaidbyOtherPaymentMthd = "POC",
            SectionHOtherCosts = true,
            TotalCharge = (double)2000000.00,
        };
        #endregion

        #region Proration Object
        public FASTSelenium.PageObjects.IIS.ProrationData prorationData = new FASTSelenium.PageObjects.IIS.ProrationData()
        {
            Description = "Association Dues",
            CreditSeller = true,
            DayofClosePaidbySeller = true,
            ProrationAmount = (decimal)50000.00,
            FromDate = DateTime.Today.ToDateString(),
            fromInclusive = true,
            fromProrateDate = false,
            BasedOn = "365",
            Per = "MONTH",
            ToDate = DateTime.Today.AddDays(28).ToDateString(),
            toInclusive = false,
            toProrateDate = false,
            ProrationBuyerCharge = (decimal)5000.00,
            ProrationBuyerCredit = (decimal)10000.00,
            ProrationSellerCharge = (decimal)5000.00,
            ProrationSellerCredit = (decimal)10000.00,
            ProrationUtilityLE = (decimal)9999.99,
        };
        #endregion

        [TestMethod]
        [Description("Verify update Homeowner Association information using UpdateHomeownerAssociation web service")]
        public void Scenario_1_Update_Instance()
        {
            try
            {
                Reports.TestDescription = "Verify update Homeowner Association information using UpdateHomeownerAssociation web service";

                FAST_Init_File();

                #region Navigate to Homeowner Association and create a new instance
                Reports.TestStep = "Navigate to Homeowner Association and create a new instance";
                FastDriver.HomeownerAssociation.Open();
                FastDriver.HomeownerAssociation.FindGABCode("501");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Update instance with UpdateHomeownerAssociation()
                Reports.TestStep = "Update instance with UpdateHomeownerAssociation()";
                var request = EscrowRequestFactory.GetHomeownerAssociationRequest(File.FileID, seqNum: 1);
                request.oHOADetails.HOAInformation = new FASTWCFHelpers.FastEscrowService.HomeownerAssociationInformation()
                {
                    HOAFileBusinessParty = new FASTWCFHelpers.FastEscrowService.FileBusinessParty() { AddrBookEntryID = AdminService.GetGABAddressBookEntryId("415") }
                };
                request.oHOADetails.AssocCharges = new FASTWCFHelpers.FastEscrowService.AssociationCharges()
                {
                    AssociationChargesListForCD = new FASTWCFHelpers.FastEscrowService.CDChargePaymentDetails[] { EscrowRequestFactory.GetCDChargePaymentDetails() }
                };
                request.oHOADetails.MgmtCompanyCharges = new FASTWCFHelpers.FastEscrowService.ManagementCompanyCharges()
                {
                    MgmtCompanyChargesListForCD = new FASTWCFHelpers.FastEscrowService.CDChargePaymentDetails[] { EscrowRequestFactory.GetCDChargePaymentDetails() }
                };
                request.oHOADetails.HOALienPayoff = new FASTWCFHelpers.FastEscrowService.LienPayoff()
                {
                    HOALienPayoffListForCD = new FASTWCFHelpers.FastEscrowService.CDChargePaymentDetails[] { EscrowRequestFactory.GetCDChargePaymentDetails() }
                };
                request.oHOADetails.Proration = EscrowRequestFactory.GetProration();
                var response = EscrowService.UpdateHomeownerAssociation(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Verify new instance in FAST
                Reports.TestStep = "Verify new instance in FAST";
                FastDriver.HomeownerAssociation.Open();
                Support.AreEqual("415", FastDriver.HomeownerAssociation.IDCodeText.FAGetText().Trim(), "IDCodeText");
                FastDriver.HomeownerAssociation.AssociationChargePaymentDetails.Click();
                FAST_VerifyPDD(paymentDetails);
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.ManagementCompanyPaymentDetails.Click();
                FAST_VerifyPDD(paymentDetails);
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.ProrationPaymentDetails.Click();
                paymentDetails.SectionHOtherCosts = false;
                FAST_VerifyPDD(paymentDetails);
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                FAST_VerifyHAProration(prorationData);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
