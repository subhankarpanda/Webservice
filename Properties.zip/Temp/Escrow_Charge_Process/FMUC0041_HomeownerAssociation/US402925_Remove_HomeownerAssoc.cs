﻿using FASTSelenium.Common;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.Escrow_Charge_Process.FMUC0041_HomeownerAssociation
{
    [CodedUITest]
    public class US402925_Remove_HomeownerAssoc : FASTHelpers
    {
        [TestMethod]
        [Description("Verify Homeowner Association is removed using RemoveHomeownerAssociation web service")]
        public void Scenario_1_Remove_instance()
        {
            try
            {
                Reports.TestDescription = "Verify Homeowner Association is removed using RemoveHomeownerAssociation web service";

                FAST_Init_File();

                #region Navigate to Homeowner Association and create a new instance
                Reports.TestStep = "Navigate to Homeowner Association and create a new instance";
                FastDriver.HomeownerAssociation.Open();
                FastDriver.HomeownerAssociation.FindGABCode("415");
                FastDriver.HomeownerAssociation.AssociationChargeBuyerCharge.FASetText("1,500.00");
                FastDriver.HomeownerAssociation.AssociationChargeSellerCharge.FASetText("1,500.00");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Remove Homeowner Association instance with RemoveHomeownerAssociation()
                Reports.TestStep = "Remove Homeowner Association instance with RemoveHomeownerAssociation()";
                var request = EscrowRequestFactory.GetHomeownerAssociationRequest(File.FileID, seqNum: 1);
                var response = EscrowService.RemoveHomeownerAssociation(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Verify Homeowner Association is removed in FAST
                Reports.TestStep = "Verify Homeowner Association is removed in FAST";
                FastDriver.HomeownerAssociation.Open();
                Support.AreEqual("", FastDriver.HomeownerAssociation.IDCodeText.FAGetText().Trim(), "IDCodeText");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
