﻿using FASTSelenium.Common;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.Escrow_Charge_Process.FMUC0054_OffsetAndMiscellaneousAdjustments
{
    [CodedUITest]
    public class USxxxxxx_Retrieve_Adjustments : FASTHelpers
    {
        [TestMethod]
        [Description("Verify retrieve Off-Set Adjustments information using GetAdjustmentDetails web service")]
        public void Scenario_1_Get_OffSet_Adjustments()
        {
            try
            {
                Reports.TestDescription = "Verify retrieve Off-Set Adjustments information using GetAdjustmentDetails web service";

                FAST_Init_File();

                #region Navigate to Off-Set Adjustments and fill in the charges
                Reports.TestStep = "Navigate to Off-Set Adjustments and fill in the charges";
                FastDriver.AdjustmentOffset.Open();
                //  Sale Price of Any Personal Property Included in Sale
                FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction(2, 3, TableAction.SetText, "15000.00");
                FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction(2, 6, TableAction.SetText, "15000.00");
                //  Assign Tenant Lease/Rent
                FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction(3, 3, TableAction.SetText, "15000.00");
                FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction(3, 4, TableAction.SetText, "15000.00");
                FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction(3, 5, TableAction.SetText, "15000.00");
                //  Assign Tenant Security Deposit
                FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction(4, 3, TableAction.SetText, "15000.00");
                FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction(4, 4, TableAction.SetText, "15000.00");
                FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction(4, 5, TableAction.SetText, "15000.00");
                //  Seller Credit
                FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction(5, 4, TableAction.SetText, "15000.00");
                FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction(5, 5, TableAction.SetText, "15000.00");
                //  Empty Space
                //
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify Off-Set Adjustments information with GetAdjustmentDetails()
                Reports.TestStep = "Verify Off-Set Adjustments information with GetAdjustmentDetails()";
                var request = EscrowRequestFactory.GetServiceFileRequest(File.FileID);
                var details = EscrowService.GetAdjustmentDetails(request);
                Support.AreEqual("1", details.Status.ToString(), details.StatusDescription);
                var chargeList = details.OffSet.CDChargeList;
                //  Sale Price of Any Personal Property Included in Sale
                Support.AreEqual("Sale Price of Any Personal Property Included in Sale", chargeList[0].Description, "chargeList[0].Description");
                Support.AreEqual("$15,000.00", ((Decimal)chargeList[0].BuyerCharge).ToString("C2"), "chargeList[0].BuyerCharge");
                Support.AreEqual("K", chargeList[0].BuyerChargeCDSection, "chargeList[0].BuyerChargeCDSection");
                Support.AreEqual("$15,000.00", ((Decimal)chargeList[0].SellerCredit).ToString("C2"), "chargeList[0].SellerCredit");
                Support.AreEqual("M", chargeList[0].SellerCreditCDSection, "chargeList[0].SellerCreditCDSection");
                //  Assign Tenant Lease/Rent
                Support.AreEqual("Assign Tenant Lease/Rent", chargeList[1].Description, "chargeList[1].Description");
                Support.AreEqual("$15,000.00", ((Decimal)chargeList[1].BuyerCharge).ToString("C2"), "chargeList[1].BuyerCharge");
                Support.AreEqual("K", chargeList[1].BuyerChargeCDSection, "chargeList[1].BuyerChargeCDSection");
                Support.AreEqual("$15,000.00", ((Decimal)chargeList[1].BuyerCredit).ToString("C2"), "chargeList[1].BuyerCredit");
                Support.AreEqual("L", chargeList[1].BuyerCreditCDSection, "chargeList[1].BuyerCreditCDSection");
                Support.AreEqual("$15,000.00", ((Decimal)chargeList[1].SellerCharge).ToString("C2"), "chargeList[1].SellerCharge");
                Support.AreEqual("N", chargeList[1].SellerChargeCDSection, "chargeList[1].SellerChargeCDSection");
                Support.AreEqual("$15,000.00", ((Decimal)chargeList[1].SellerCredit).ToString("C2"), "chargeList[1].SellerCredit");
                Support.AreEqual("M", chargeList[1].SellerCreditCDSection, "chargeList[1].SellerCreditCDSection");
                //  Assign Tenant Security Deposit
                Support.AreEqual("Assign Tenant Security Deposit", chargeList[2].Description, "chargeList[2].Description");
                Support.AreEqual("$15,000.00", ((Decimal)chargeList[2].BuyerCharge).ToString("C2"), "chargeList[2].BuyerCharge");
                Support.AreEqual("K", chargeList[2].BuyerChargeCDSection, "chargeList[2].BuyerChargeCDSection");
                Support.AreEqual("$15,000.00", ((Decimal)chargeList[2].BuyerCredit).ToString("C2"), "chargeList[2].BuyerCredit");
                Support.AreEqual("L", chargeList[2].BuyerCreditCDSection, "chargeList[2].BuyerCreditCDSection");
                Support.AreEqual("$15,000.00", ((Decimal)chargeList[2].SellerCharge).ToString("C2"), "chargeList[2].SellerCharge");
                Support.AreEqual("N", chargeList[2].SellerChargeCDSection, "chargeList[2].SellerChargeCDSection");
                Support.AreEqual("$15,000.00", ((Decimal)chargeList[2].SellerCredit).ToString("C2"), "chargeList[2].SellerCredit");
                Support.AreEqual("M", chargeList[2].SellerCreditCDSection, "chargeList[2].SellerCreditCDSection");
                //  Seller Credit
                Support.AreEqual("Seller Credit", chargeList[3].Description, "chargeList[3].Description");
                Support.AreEqual("$15,000.00", ((Decimal)chargeList[3].BuyerCredit).ToString("C2"), "chargeList[3].BuyerCredit");
                Support.AreEqual("L", chargeList[3].BuyerCreditCDSection, "chargeList[3].BuyerCreditCDSection");
                Support.AreEqual("$15,000.00", ((Decimal)chargeList[3].SellerCharge).ToString("C2"), "chargeList[3].SellerCharge");
                Support.AreEqual("N", chargeList[3].SellerChargeCDSection, "chargeList[3].SellerChargeCDSection");
                //  Empty Space
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify retrieve Miscellaneous Adjustments information using GetAdjustmentDetails web service")]
        public void Scenario_2_Get_Misc_Adjustments()
        {
            try
            {
                Reports.TestDescription = "Verify retrieve Miscellaneous Adjustments information using GetAdjustmentDetails web service";

                FAST_Init_File();

                #region Navigate to Miscellaneous Adjustments and fill in the charges
                Reports.TestStep = "Navigate to Miscellaneous Adjustments and fill in the charges";
                FastDriver.AdjustmentMisc.Open();
                //  Buyer Deposit Directly to Seller
                FastDriver.AdjustmentMisc.miscellaneousAdjustmentTable.PerformTableAction(2, 4, TableAction.SetText, "15000.00");
                FastDriver.AdjustmentMisc.miscellaneousAdjustmentTable.PerformTableAction(2, 5, TableAction.SetText, "15000.00");
                //  IBA Interest Paid
                FastDriver.AdjustmentMisc.miscellaneousAdjustmentTable.PerformTableAction(3, 4, TableAction.SetText, "15000.00");
                FastDriver.AdjustmentMisc.miscellaneousAdjustmentTable.PerformTableAction(3, 6, TableAction.SetText, "15000.00");
                //  Empty Space
                //
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify Miscellaneous Adjustments information with GetAdjustmentDetails()
                Reports.TestStep = "Verify Miscellaneous Adjustments information with GetAdjustmentDetails()";
                var request = EscrowRequestFactory.GetServiceFileRequest(File.FileID);
                var details = EscrowService.GetAdjustmentDetails(request);
                Support.AreEqual("1", details.Status.ToString(), details.StatusDescription);
                var chargeList = details.Misc.CDChargeList;
                //  Buyer Deposit Directly to Seller
                Support.AreEqual("Buyer Deposit Directly to Seller", chargeList[0].Description, "chargeList[0].Description");
                Support.AreEqual("$15,000.00", ((Decimal)chargeList[0].BuyerCredit).ToString("C2"), "chargeList[0].BuyerCredit");
                Support.AreEqual("L", chargeList[0].BuyerCreditCDSection, "chargeList[0].BuyerCreditCDSection");
                Support.AreEqual("$15,000.00", ((Decimal)chargeList[0].SellerCharge).ToString("C2"), "chargeList[0].SellerCharge");
                Support.AreEqual("N", chargeList[0].SellerChargeCDSection, "chargeList[0].SellerChargeCDSection");
                //  IBA Interest Paid
                Support.AreEqual("IBA Interest Paid", chargeList[1].Description, "chargeList[1].Description");
                Support.AreEqual("$15,000.00", ((Decimal)chargeList[1].BuyerCredit).ToString("C2"), "chargeList[1].BuyerCredit");
                Support.AreEqual("L", chargeList[1].BuyerCreditCDSection, "chargeList[1].BuyerCreditCDSection");
                Support.AreEqual("$15,000.00", ((Decimal)chargeList[1].SellerCredit).ToString("C2"), "chargeList[1].SellerCredit");
                Support.AreEqual("M", chargeList[1].SellerCreditCDSection, "chargeList[1].SellerCreditCDSection");
                //  Empty Space
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
