﻿using FASTSelenium.Common;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.Escrow_Charge_Process.FMUC0052_Survey
{
    [CodedUITest]
    public class USxxxxxx_Remove_Survey : FASTHelpers
    {
        #region paymentDetails
        protected FASTSelenium.DataObjects.IIS.PDD paymentDetails = new FASTSelenium.DataObjects.IIS.PDD()
        {
            AdditionalDescription = "test-description",
            UseDefaultChecked = true,
            BuyerCredit = (double)0.00,
            BuyerCreditPaymentMethod = CreditPaymentMethods.AtClosing.ToString(),
            LoanEstimateUnrounded = (double)999999.99,
            LoanEstimateRounded = (double)1000000,
            BuyerCharge = (double)1000000,
            BuyerAtClosing = (double)900000.00,
            BuyerChargePaymentMethod = AtClosingPaymentMethods.CHK.ToString(),
            BuyerBeforeClosing = (double)99999.99,
            BuyerPaidbyOther = (double)0.01,
            BuyerPaidbyOtherPaymentMethod = OtherPaymentMethods.POC.ToString(),
            BuyerLenderCheckbox = false,
            SellerCharge = (double)1000000,
            SellerCredit = (double)0.00,
            SellerCreditPaymentMethod = CreditPaymentMethods.AtClosing.ToString(),
            SellerPaidAtClosing = (double)900000.00,
            SellerChargePaymentMethod = AtClosingPaymentMethods.CHK.ToString(),
            SellerPaidBeforeClosing = (double)99999.99,
            SellerPaidbyOthers = (double)0.01,
            SellerPaidbyOtherPaymentMthd = OtherPaymentMethods.POC.ToString(),
            SellerLenderCheckbox = false,
            PartOfCheckbox = false,
            SectionHOtherCosts = true,
            TotalCharge = (double)2000000,
        };
        #endregion

        [TestMethod]
        [Description("Verify remove Survey instance using RemoveSurvey web service")]
        public void Scenario_1_Remove_Survey()
        {
            try
            {
                Reports.TestDescription = "Verify remove Survey instance using RemoveSurvey web service";

                FAST_Init_File();

                #region Navigate to Survey and create a new instance
                Reports.TestStep = "Navigate to Survey and create a new instance";
                FastDriver.SurveyDetail.Open();
                FastDriver.SurveyDetail.FindGABCode("415");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Remove Survey instance with RemoveSurvey()
                Reports.TestStep = "Remove Survey instance with RemoveSurvey()";
                var request = EscrowRequestFactory.GetSurveyRequest(File.FileID, seqNum: 1);
                var response = EscrowService.RemoveSurvey(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Verify Survey instance is removed in FAST
                Reports.TestStep = "Verify Survey instance is removed in FAST";
                FastDriver.SurveyDetail.Open();
                Support.AreEqual("", FastDriver.SurveyDetail.IDcodeLabel.FAGetText(), "IDcodeLabel");
                #endregion
            }
            catch(Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
