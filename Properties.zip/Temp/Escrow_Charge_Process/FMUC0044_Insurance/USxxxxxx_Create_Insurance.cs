﻿using FASTSelenium.Common;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.Escrow_Charge_Process.FMUC0044_Insurance
{
    [CodedUITest]
    public class USxxxxxx_Create_Insurance : FASTHelpers
    {
        #region paymentDetails
        protected FASTSelenium.DataObjects.IIS.PDD paymentDetails = new FASTSelenium.DataObjects.IIS.PDD()
        {
            AdditionalDescription = "test-description",
            UseDefaultChecked = true,
            BuyerCredit = (double)0.00,
            BuyerCreditPaymentMethod = CreditPaymentMethods.AtClosing.ToString(),
            LoanEstimateUnrounded = (double)999999.99,
            LoanEstimateRounded = (double)1000000,
            BuyerCharge = (double)1000000,
            BuyerAtClosing = (double)900000.00,
            BuyerChargePaymentMethod = AtClosingPaymentMethods.CHK.ToString(),
            BuyerBeforeClosing = (double)99999.99,
            BuyerPaidbyOther = (double)0.01,
            BuyerPaidbyOtherPaymentMethod = OtherPaymentMethods.POC.ToString(),
            BuyerLenderCheckbox = false,
            SellerCharge = (double)1000000,
            SellerCredit = (double)0.00,
            SellerCreditPaymentMethod = CreditPaymentMethods.AtClosing.ToString(),
            SellerPaidAtClosing = (double)900000.00,
            SellerChargePaymentMethod = AtClosingPaymentMethods.CHK.ToString(),
            SellerPaidBeforeClosing = (double)99999.99,
            SellerPaidbyOthers = (double)0.01,
            SellerPaidbyOtherPaymentMthd = OtherPaymentMethods.POC.ToString(),
            SellerLenderCheckbox = false,
            PartOfCheckbox = false,
            //SectionHOtherCosts = true,
            TotalCharge = (double)2000000,
        };
        #endregion

        [TestMethod]
        [Description("Verify create Insurance OTHER using CreateInsurance web service")]
        public void Scenario_1_Create_Insurance_OTHER()
        { 
            try
            {
                Reports.TestDescription = "Verify create Insurance OTHER using CreateInsurance web service";

                FAST_Init_File();

                #region Create Insurance OTHER with CreateInsurance()
                Reports.TestStep = "Create Insurance OTHER with CreateInsurance()";
                var request = EscrowRequestFactory.GetInsuranceRequest(File.FileID, seqNum: null);
                request.InsuranceInformation.InsuranceType = FASTWCFHelpers.FastEscrowService.InsuranceType.Others;
                request.InsuranceInformation.InsuranceAgentInformation = EscrowRequestFactory.GetFileBusinessParty("415");
                var response = EscrowService.CreateInsurance(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Verify Insurance OTHER in FAST
                Reports.TestStep = "Verify Insurance OTHER in FAST";
                FastDriver.InsuranceOther.Open();
                Support.AreEqual("415", FastDriver.InsuranceOther.GabCodeLabel.FAGetText(), "GabCodeLabel");
                #endregion
            }
            catch(Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify create Insurance OTHER charge PDD using CreateInsurance web service")]
        public void Scenario_2_Create_Insurance_OTHER_charge_PDD()
        {
            try
            {
                Reports.TestDescription = "Verify create Insurance OTHER charge PDD using CreateInsurance web service";

                FAST_Init_File();

                #region Create Insurance OTHER charge PDD with CreateInsurance()
                Reports.TestStep = "Create Insurance OTHER charge PDD with CreateInsurance()";
                var request = EscrowRequestFactory.GetInsuranceRequest(File.FileID, seqNum: null);
                request.InsuranceInformation.InsuranceType = FASTWCFHelpers.FastEscrowService.InsuranceType.Others;
                request.InsuranceInformation.InsuranceAgentInformation = EscrowRequestFactory.GetFileBusinessParty("415");
                request.InsuranceInformation.InsuranceCharges = new FASTWCFHelpers.FastEscrowService.InsuCharges()
                {
                    CDInsuranceChargesList = new FASTWCFHelpers.FastEscrowService.CDChargePaymentDetails[] { 
                        EscrowRequestFactory.GetCDChargePaymentDetails(),
                    }
                };
                var response = EscrowService.CreateInsurance(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Verify Insurance OTHER charge PDD in FAST
                Reports.TestStep = "Verify Insurance OTHER charge PDD in FAST";
                FastDriver.InsuranceOther.Open();
                FastDriver.InsuranceOther.OtherPaymentDetails.FAClick();
                FAST_VerifyPDD(paymentDetails);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }
        
        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
