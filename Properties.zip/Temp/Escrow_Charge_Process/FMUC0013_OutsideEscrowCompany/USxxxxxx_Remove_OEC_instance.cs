﻿using FASTSelenium.Common;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.Escrow_Charge_Process.FMUC0013_OutsideEscrowCompany
{
    [CodedUITest]
    public class USxxxxxx_Remove_OEC_instance : FASTHelpers
    {
        [TestMethod]
        [Description("Verify remove instance of Outside Escrow Company using DeleteOutsideEscrowCompany web service")]
        public void Scenario_1_Remove_OEC_instance()
        {
            try
            {
                Reports.TestDescription = "Verify remove instance of Outside Escrow Company using DeleteOutsideEscrowCompany web service";

                FAST_Init_File();

                #region Navigate to OEC screen and add business party
                Reports.TestStep = "Navigate to OEC screen and add business party";
                FastDriver.OutsideEscrowCompanyDetail.Open();
                FastDriver.OutsideEscrowCompanyDetail.FindGAB("415");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Retrieve OEC business party with DeleteOutsideEscrowCompany()
                Reports.TestStep = "Retrieve OEC business party with DeleteOutsideEscrowCompany()";
                FastDriver.OutsideEscrowCompanyDetail.Open();
                var request = EscrowRequestFactory.GetOECRequest(File.FileID, 1);
                var response = EscrowService.DeleteOutsideEscrowCompany(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Verify OEC business party is removed in FAST
                Reports.TestStep = "Verify OEC business party is removed in FAST";
                FastDriver.OutsideEscrowCompanyDetail.Open();
                Support.AreEqual("", FastDriver.OutsideEscrowCompanyDetail.GABcodeLabel.FAGetText(), "GABcodeLabel");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
