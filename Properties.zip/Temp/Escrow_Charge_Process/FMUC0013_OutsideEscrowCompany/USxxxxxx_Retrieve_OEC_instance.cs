﻿using FASTSelenium.Common;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.Escrow_Charge_Process.FMUC0013_OutsideEscrowCompany
{
    [CodedUITest]
    public class USxxxxxx_Retrieve_OEC_instance : FASTHelpers
    {
        #region paymentDetails
        protected FASTSelenium.DataObjects.IIS.PDD paymentDetails = new FASTSelenium.DataObjects.IIS.PDD()
        {
            AdditionalDescription = "test-description",
            UseDefaultChecked = true,
            BuyerCredit = (double)0.00,
            BuyerCreditPaymentMethod = CreditPaymentMethods.AtClosing.ToString(),
            LoanEstimateUnrounded = (double)999999.99,
            LoanEstimateRounded = (double)1000000,
            BuyerCharge = (double)1000000,
            BuyerAtClosing = (double)900000.00,
            BuyerChargePaymentMethod = AtClosingPaymentMethods.CHK.ToString(),
            BuyerBeforeClosing = (double)99999.99,
            BuyerPaidbyOther = (double)0.01,
            BuyerPaidbyOtherPaymentMethod = OtherPaymentMethods.POCL.ToString(),
            BuyerLenderCheckbox = true,
            SellerCharge = (double)1000000,
            SellerCredit = (double)0.00,
            SellerCreditPaymentMethod = CreditPaymentMethods.AtClosing.ToString(),
            SellerPaidAtClosing = (double)900000.00,
            SellerChargePaymentMethod = AtClosingPaymentMethods.CHK.ToString(),
            SellerPaidBeforeClosing = (double)99999.99,
            SellerPaidbyOthers = (double)0.01,
            SellerPaidbyOtherPaymentMthd = OtherPaymentMethods.POCL.ToString(),
            SellerLenderCheckbox = true,
            PartOfCheckbox = false,
            SectionHOtherCosts = true,
            TotalCharge = (double)2000000,
        };
        #endregion

        [TestMethod]
        [Description("Verify retrieve instance of Outside Escrow Company using GetOutsideEscrowCompanyDetails web service")]
        public void Scenario_1_Get_OEC_instance()
        {
            try
            {
                Reports.TestDescription = "Verify retrieve instance of Outside Escrow Company using GetOutsideEscrowCompanyDetails web service";

                FAST_Init_File();

                #region Navigate to OEC screen and add business party
                Reports.TestStep = "Navigate to OEC screen and add business party";
                FastDriver.OutsideEscrowCompanyDetail.Open();
                FastDriver.OutsideEscrowCompanyDetail.FindGAB("415");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Retrieve OEC business party with GetOutsideEscrowCompanyDetails()
                Reports.TestStep = "Retrieve OEC business party with GetOutsideEscrowCompanyDetails()";
                FastDriver.OutsideEscrowCompanyDetail.Open();
                var request = EscrowRequestFactory.GetServiceFileRequest(File.FileID);
                var details = EscrowService.GetOutsideEscrowCompanyDetails(request);
                Support.AreEqual("1", details.Status.ToString(), details.StatusDescription);
                #endregion

                #region Verify OEC business party is retrieved in FAST
                Reports.TestStep = "Verify OEC business party is retrieved in FAST";
                Support.AreEqual("415", details.OECInformations[0].OECFileBusinessParty.IDCode, "OECFileBusinessParty.IDCode");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify retrieve charge PDD for Outside Escrow Company using GetOutsideEscrowCompanyDetails web service")]
        public void Scenario_2_Get_OEC_with_Charge_PDD()
        {
            try
            {
                Reports.TestDescription = "Verify retrieve charge PDD for Outside Escrow Company using GetOutsideEscrowCompanyDetails web service";

                FAST_Init_File();

                #region Navigate to OEC screen and add business party + charge PDD
                Reports.TestStep = "Navigate to OEC screen and add business party + charge PDD";
                FastDriver.OutsideEscrowCompanyDetail.Open();
                FastDriver.OutsideEscrowCompanyDetail.FindGAB("415");
                FastDriver.OutsideEscrowCompanyDetail.ChargeDescription.Clear();
                FastDriver.OutsideEscrowCompanyDetail.ChargeDescription.FASetText("test-charge-description");
                FastDriver.OutsideEscrowCompanyDetail.PaymentDetails.FAClick();
                FAST_UpdatePDD(paymentDetails);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Retrieve OEC charge PDD with GetOutsideEscrowCompanyDetails()
                Reports.TestStep = "Retrieve OEC charge PDD with GetOutsideEscrowCompanyDetails()";
                FastDriver.OutsideEscrowCompanyDetail.Open();
                var request = EscrowRequestFactory.GetServiceFileRequest(File.FileID);
                var details = EscrowService.GetOutsideEscrowCompanyDetails(request);
                Support.AreEqual("1", details.Status.ToString(), details.StatusDescription);
                #endregion

                #region Verify OEC charge PDD is retrieved in FAST
                Reports.TestStep = "Verify OEC charge PDD is retrieved in FAST";
                FastDriver.OutsideEscrowCompanyDetail.PaymentDetails.FAClick();
                FAST_WCF_VerifyEscrowPDD(details.OECInformations[0].OECCharges.CDPaymentDetails[0], paymentDetails);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
