﻿using FASTSelenium.Common;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.Escrow_Charge_Process.FMUC0013_OutsideEscrowCompany
{
    [CodedUITest]
    public class USxxxxxx_Create_OEC_instance : FASTHelpers
    {
        #region paymentDetails
        protected FASTSelenium.DataObjects.IIS.PDD paymentDetails = new FASTSelenium.DataObjects.IIS.PDD()
        {
            AdditionalDescription = "test-description",
            UseDefaultChecked = true,
            BuyerCredit = (double)0.00,
            BuyerCreditPaymentMethod = CreditPaymentMethods.AtClosing.ToString(),
            LoanEstimateUnrounded = (double)999999.99,
            BuyerAtClosing = (double)900000.00,
            BuyerBeforeClosing = (double)99999.99,
            BuyerPaidbyOther = (double)0.01,
            BuyerPaidbyOtherPaymentMethod = OtherPaymentMethods.POC.ToString(),
            SellerCredit = (double)0.00,
            SellerCreditPaymentMethod = CreditPaymentMethods.AtClosing.ToString(),
            SellerPaidAtClosing = (double)900000.00,
            SellerPaidBeforeClosing = (double)99999.99,
            SellerPaidbyOthers = (double)0.01,
            SellerPaidbyOtherPaymentMthd = OtherPaymentMethods.POC.ToString(),
            PartOfCheckbox = false,
            //SectionsShoppedFor.None,
        };
        #endregion

        [TestMethod]
        [Description("Verify create instance of Outside Escrow Company using CreateOutsideEscrowCompany web service")]
        public void Scenario_1_Create_OEC_instance()
        {
            try
            {
                Reports.TestDescription = "Verify create instance of Outside Escrow Company using CreateOutsideEscrowCompany web service";

                FAST_Init_File();

                #region Create new OEC instance with CreateOutsideEscrowCompany()
                Reports.TestStep = "Create new OEC instance with CreateOutsideEscrowCompany()";
                var request = EscrowRequestFactory.GetOECRequest(File.FileID, null);
                request.OECInformation.OECFileBusinessParty = new FASTWCFHelpers.FastEscrowService.FileBusinessParty() { AddrBookEntryID = (int)AdminService.GetGABAddressBookEntryId("415") };
                var response = EscrowService.CreateOutsideEscrowCompany(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Verify new OEC instance is present in FAST
                Reports.TestStep = "Verify new OEC instance is present in FAST";
                FastDriver.OutsideEscrowCompanyDetail.Open();
                Support.AreEqual("415", FastDriver.OutsideEscrowCompanyDetail.GABcodeLabel.FAGetText(), "GABcodeLabel");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify create charge PDD for Outside Escrow Company using CreateOutsideEscrowCompany web service")]
        public void Scenario_2_Create_OEC_with_Charge_PDD()
        {
            try
            {
                Reports.TestDescription = "Verify create charge PDD for Outside Escrow Company using CreateOutsideEscrowCompany web service";

                FAST_Init_File();

                #region Create new OEC charge PDD with CreateOutsideEscrowCompany()
                Reports.TestStep = "Create new OEC charge PDD with CreateOutsideEscrowCompany()";
                var request = EscrowRequestFactory.GetOECRequest(File.FileID, null);
                request.OECInformation.OECFileBusinessParty = new FASTWCFHelpers.FastEscrowService.FileBusinessParty() { AddrBookEntryID = (int)AdminService.GetGABAddressBookEntryId("415") };
                request.OECInformation.OECCharges = new FASTWCFHelpers.FastEscrowService.OECCharge()
                {
                    CDPaymentDetails = new FASTWCFHelpers.FastEscrowService.CDChargePaymentDetails[] { 
                        EscrowRequestFactory.GetCDChargePaymentDetails(),
                    }
                };
                request.OECInformation.OECCharges.CDPaymentDetails[0].Description = "test-charge-description";
                var response = EscrowService.CreateOutsideEscrowCompany(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Verify new OEC charge PDD is present in FAST
                Reports.TestStep = "Verify new OEC charge PDD is present in FAST";
                FastDriver.OutsideEscrowCompanyDetail.Open();
                Support.AreEqual("415", FastDriver.OutsideEscrowCompanyDetail.GABcodeLabel.FAGetText(), "GABcodeLabel");
                FastDriver.OutsideEscrowCompanyDetail.PaymentDetails.FAClick();
                FAST_VerifyPDD(paymentDetails);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
