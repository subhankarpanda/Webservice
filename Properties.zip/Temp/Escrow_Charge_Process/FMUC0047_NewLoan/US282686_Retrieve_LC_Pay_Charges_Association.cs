﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects.IIS;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.Escrow_Charge_Process.FMUC0047_NewLoan
{
    [CodedUITest]
    public class US282686_Retrieve_LC_Pay_Charges_Association : SlaveTestClass
    {
        #region Payment Details
        protected FASTSelenium.DataObjects.IIS.PDD paymentDetails = new FASTSelenium.DataObjects.IIS.PDD()
        {
            BuyerAtClosing = (double)500000,
            BuyerCredit = (double)1000000,
            SellerPaidAtClosing = (double)500000,
            SellerCredit = (double)1000000,
            LoanEstimateUnrounded = (double)999999.99
        };
        #endregion

        [TestMethod]
        [Description("Verify New Loan LC Pay Charges association information")]
        public void Scenario_1_Get_LC_PayCharges()
        {
            try
            {
                Reports.TestDescription = "Verify New Loan LC Pay Charges association information";

                FAST_Init_File(GABRole: AdditionalRoleType.NewLender);

                #region Navigate to New Loan - Loan Charges and add charge details
                Reports.TestStep = "Navigate to New Loan - Loan Charges and add charge details";
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.ClickChargesTab();
                FastDriver.NewLoan.NewLoanChargesPaymentDetails.Click();
                FAST_UpdatePDD(paymentDetails);
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.LoanChargesOriginationChargePaymentDetails.Click();
                FAST_UpdatePDD(paymentDetails);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify charges are available for association
                Reports.TestStep = "Verify charges are available for association";
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.ClickChargesTab();
                FastDriver.NewLoan.LoanChargesPayCharges.Click();
                FastDriver.NewLoanDisbursements.WaitForScreenToLoad();
                for (int i = 0; i < 2; i++)
                    Support.AreEqual("false", FastDriver.NewLoanDisbursements.NthChargeSelect(i).GetAttribute("status").ToLowerInvariant());
                #endregion

                #region Associate Mortgage Broker charges using NewLoanMBPayChargesAssociation
                var fileId = File.FileID ?? 0;
                var details = FileService.GetNewLoanDetails(fileId, seqNum: 1);
                Support.AreEqual("1", details.Status.ToString(), details.StatusDescription);
                Support.AreEqual("2", details.LoanCharges.CDPayCharges.DisbursementCharges.Count().ToString());
                for (int i = 0; i < 2; i++)
                {
                    if (details.LoanCharges.CDPayCharges.DisbursementCharges[i].IsSelected == false)
                    {
                        var request = RequestFactory.GetNewLoanPayChargeAssociationRequest(
                            fileID: fileId,
                            seqNum: 1,
                            charge: details.LoanCharges.CDPayCharges.DisbursementCharges[i],
                            fileBusParty: details.LoanCharges.CDPayCharges.PayeeInformation[0]
                        );
                        var response = FileService.NewLoanPayChargesAssociation(request);
                        Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                    }
                }
                #endregion

                #region Verify association is showing in FAST after association request
                Reports.TestStep = "Verify association is showing in FAST after association request";
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.ClickChargesTab();
                FastDriver.NewLoan.LoanChargesPayCharges.Click();
                FastDriver.NewLoanDisbursements.WaitForScreenToLoad();
                for (int i = 0; i < 2; i++)
                    Support.AreEqual("true", FastDriver.NewLoanDisbursements.NthChargeSelect(i).GetAttribute("status").ToLowerInvariant());
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
