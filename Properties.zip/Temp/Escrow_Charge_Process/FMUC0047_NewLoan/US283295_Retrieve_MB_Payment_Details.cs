﻿using FASTSelenium.Common;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.Escrow_Charge_Process.FMUC0047_NewLoan
{
    [CodedUITest]
    public class US283295_Retrieve_MB_Payment_Details : SlaveTestClass
    {
        #region payment details
        protected FASTSelenium.DataObjects.IIS.PDD paymentDetails = new FASTSelenium.DataObjects.IIS.PDD()
        {
            ChargeDescription = "test-charge-description",
            AdditionalDescription = "",
            UseDefaultChecked = false,
            PayeeName = "test-payee-name",
            PayTo = "Continental Mortgage Corporation",
            LoanEstimateUnrounded = (double)15099.99,
            LoanEstimateRounded = (double)15100.00,
            PartOfCheckbox = true,
            SectionCDidShopFor = true,
            BuyerCharge = (double)30000,
            BuyerAtClosing = (double)15000,
            BuyerChargePaymentMethod = "RBL",
            BuyerBeforeClosing = (double)5000,
            BuyerPaidbyOther = (double)10000,
            BuyerPaidbyOtherPaymentMethod = "POC",
            BuyerCreditPaymentMethod = "Lender",
            //  BuyerLenderCheckbox is out of this scope
            BuyerLenderCheckbox = false,
            BuyerDoubleAsteriskChecked = false,
            SellerCharge = (double)24000,
            SellerPaidAtClosing = (double)12000,
            SellerChargePaymentMethod = "RBL",
            SellerPaidBeforeClosing = (double)6000,
            SellerPaidbyOthers = (double)6000,
            SellerPaidbyOtherPaymentMthd = "POC",
            SellerCreditPaymentMethod = "Lender",
            TotalCharge = (double)54000.00
        };
        #endregion

        [TestMethod]
        [Description("Verify New Loan - Mortgage Broker charge information using GetNewLoanDetails web service")]
        public void Scenario_1_Get_MB_Charge_PDD()
        {
            try
            {
                Reports.TestDescription = "Verify New Loan - Mortgage Broker charge information using GetNewLoanDetails web service";

                FAST_Init_File(GABRole: AdditionalRoleType.NewLender);

                #region Navigate to New Loan - Mortgage Broker charge details
                Reports.TestStep = "Navigate to New Loan - Mortgage Broker charge details";
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.ClickMortgageBrokerTab();
                FastDriver.NewLoan.MortgageFindGABCode("415");
                FastDriver.NewLoan.MortgageAttention.FASelectItem("automation-user");
                FastDriver.NewLoan.MBChargesPaymentDetails.Click();
                FAST_UpdatePDD(paymentDetails);
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                #endregion

                #region Verify New Loan - Mortgage Broker charge's details using GetCDDetails()
                Reports.TestStep = "Verify New Loan - Mortgage Broker charge's details using GetCDDetails()";
                var details = FileService.GetNewLoanDetails(File.FileID, 1);
                Support.AreEqual("1", details.Status.ToString(), details.StatusDescription);
                FAST_WCF_VerifyFilePDD(details.MortgageBroker.CDMortgageBrokerCharges[0], paymentDetails);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
