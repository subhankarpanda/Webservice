﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.Escrow_Charge_Process.FMUC0047_NewLoan
{
    [CodedUITest]
    public class US303027_Retrieve_Payment_Details : SlaveTestClass
    {
        #region payment details
        protected PDD paymentDetails = new PDD()
        {
            ChargeDescription = "test-charge-description",
            AdditionalDescription = "",
            UseDefaultChecked = false,
            PayeeName = "test-payee-name",
            PayTo = "Continental Mortgage Corporation",
            LoanEstimateUnrounded = (double)15099.99,
            LoanEstimateRounded = (double)15100.00,
            PartOfCheckbox = true,
            SectionCDidShopFor = true,
            BuyerCharge = (double)30000,
            BuyerAtClosing = (double)15000,
            BuyerChargePaymentMethod = "RBL",
            BuyerBeforeClosing = (double)5000,
            BuyerPaidbyOther = (double)10000,
            BuyerPaidbyOtherPaymentMethod = "POC",
            BuyerCreditPaymentMethod = "Lender",
            //  BuyerLenderCheckbox is out of this scope
            BuyerLenderCheckbox = false,
            BuyerDoubleAsteriskChecked = false,
            SellerCharge = (double)24000,
            SellerPaidAtClosing = (double)12000,
            SellerChargePaymentMethod = "RBL",
            SellerPaidBeforeClosing = (double)6000,
            SellerPaidbyOthers = (double)6000,
            SellerPaidbyOtherPaymentMthd = "POC",
            SellerCreditPaymentMethod = "Lender",
            TotalCharge = (double)54000.00
        };
        #endregion
        
        [TestMethod]
        [Description("Verify New Loan Charge Payment details using GetNewLoanDetails() after update in FAST")]
        public void Scenario_1_Retrieve_PDD_after_FAST()
        {
            try 
            {
                Reports.TestDescription = "Verify New Loan Charge Payment details using GetNewLoanDetails() after update in FAST";

                FAST_Init_File(LenderID: "415", loanAmt: 1500000);

                #region Add New Loan Charge with PDD
                Reports.TestStep = "Add New Loan Charge with PDD";
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.ClickChargesTab();
                FastDriver.NewLoan.NewLoanChargesPaymentDetails.Click();
                FAST_UpdatePDD(paymentDetails);
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();
                #endregion

                #region Verify New Loan Charge's information using GetCDDetails()
                Reports.TestStep = "Verify New Loan Charge's information using GetCDDetails()";
                FAST_WCF_VerifyNewLoanPDD(File.FileID ?? 0, seqNum: 1, pdd: paymentDetails);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify New Loan Charge Payment details using GetNewLoanDetails() after update with CreateNewLoan()")]
        public void Scenario_2_Retrieve_PDD_after_CreateNewLoan()
        {
            try
            {
                Reports.TestDescription = "Verify New Loan Charge Payment details using GetNewLoanDetails() after update with CreateNewLoan()";

                FAST_Init_File();

                #region Add New Loan Charge with PDD using CreateNewLoan()
                Reports.TestStep = "Add New Loan Charge with PDD using CreateNewLoan()";
                var request = RequestFactory.GetNewLoanRequest(File.FileID ?? 0, seqNum: 1);
                request.LoanDetails = new NewLoanDetail()
                {
                    LoanNumber = "1234567890",
                    LoanAmount = 1500000,
                    LenderInformation = new PayChargeFileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("415")
                    }
                };
                request.LoanCharges.CDNewLoanCharges = new CDChargePaymentDetails[]{
                    new CDChargePaymentDetails(){
                        Description = "test-charge-description",
                        UseDefault = false,
                        PayeeNameOnCDOrSettlementStmt = "test-payee-name",
                        LEAmount = (decimal)15099.99,
                        PartOf = true,
                        //  eSectionShop is UI disabled
                        PBBuyerAtClosing = (decimal)15000,
                        PBBuyerBeforeClosing = (decimal)5000,
                        PBOthersForBuyer = (decimal)10000,
                        PBOthersForBuyerPMTypeCdID = OtherPaymentMethods.POC,
                        DisplayLBuyer = false,
                        BuyerCreditPaymentMethodTypeCdID = CreditPaymentMethods.Lender,
                        DoubleAsteriskIndicator = false,
                        PBSellerAtClosing = (decimal)12000,
                        PBSellerBeforeClosing = (decimal)6000,
                        PBOthersForSeller = (decimal)6000,
                        PBOthersForSellerPMTypeCdID = OtherPaymentMethods.POC,
                        SellerCreditPaymentMethodTypeCdID = CreditPaymentMethods.Lender,
                        SeqNum = 1,
                    },
                };
                var response = FileService.CreateNewLoan(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Verify New Loan Charge's information using GetCDDetails()
                Reports.TestStep = "Verify New Loan Charge's information using GetCDDetails()";
                FastDriver.NewLoanSummary.Open(2);
                FastDriver.NewLoan.ClickChargesTab();
                FastDriver.NewLoan.NewLoanChargesPaymentDetails.Click();
                var paymentDetailsCopy = paymentDetails;
                paymentDetailsCopy.BuyerCreditPaymentMethod = "None";
                paymentDetailsCopy.SellerCreditPaymentMethod = "None";
                FAST_WCF_VerifyNewLoanPDD(File.FileID ?? 0, seqNum: 2, pdd: paymentDetailsCopy);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify New Loan Charge Payment details using GetNewLoanDetails() after update with UpdateNewLoan()")]
        public void Scenario_3_Retrieve_PDD_after_UpdateNewLoan()
        {
            try
            {
                Reports.TestDescription = "Verify New Loan Charge Payment details using GetNewLoanDetails() after update with UpdateNewLoan()";

                FAST_Init_File();

                #region Add New Loan Charge with PDD using UpdateNewLoan()
                Reports.TestStep = "Add New Loan Charge with PDD using UpdateNewLoan()";
                var request = RequestFactory.GetNewLoanRequest(File.FileID ?? 0, seqNum: 1);
                request.LoanDetails = new NewLoanDetail()
                {
                    LoanNumber = "1234567890",
                    LoanAmount = 1500000,
                    LenderInformation = new PayChargeFileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("415")
                    }
                };
                request.LoanCharges.CDNewLoanCharges = new CDChargePaymentDetails[]{
                    new CDChargePaymentDetails(){
                        Description = "test-charge-description",
                        UseDefault = false,
                        PayeeNameOnCDOrSettlementStmt = "test-payee-name",
                        LEAmount = (decimal)15099.99,
                        PartOf = true,
                        eSectionShop = SectionsShoppedFor.SectionCdidShopFor,
                        PBBuyerAtClosing = (decimal)15000,
                        PBBuyerBeforeClosing = (decimal)5000,
                        PBOthersForBuyer = (decimal)10000,
                        PBOthersForBuyerPMTypeCdID = OtherPaymentMethods.POC,
                        DisplayLBuyer = false,
                        BuyerCreditPaymentMethodTypeCdID = CreditPaymentMethods.Lender,
                        DoubleAsteriskIndicator = false,
                        PBSellerAtClosing = (decimal)12000,
                        PBSellerBeforeClosing = (decimal)6000,
                        PBOthersForSeller = (decimal)6000,
                        PBOthersForSellerPMTypeCdID = OtherPaymentMethods.POC,
                        SellerCreditPaymentMethodTypeCdID = CreditPaymentMethods.Lender,
                        SeqNum = 1,
                    },
                };
                var response = FileService.UpdateNewLoan(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Verify New Loan Charge's information using GetCDDetails()
                Reports.TestStep = "Verify New Loan Charge's information using GetCDDetails()";
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.ClickChargesTab();
                FastDriver.NewLoan.NewLoanChargesPaymentDetails.Click();
                FAST_WCF_VerifyNewLoanPDD(File.FileID ?? 0, seqNum:1, pdd: paymentDetails);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
