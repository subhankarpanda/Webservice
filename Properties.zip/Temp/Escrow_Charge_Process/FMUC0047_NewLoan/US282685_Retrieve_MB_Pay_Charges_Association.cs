﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects.IIS;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.Escrow_Charge_Process.FMUC0047_NewLoan
{
    [CodedUITest]
    public class US282685_Retrieve_MB_Pay_Charges_Association : SlaveTestClass
    {
        [TestMethod]
        [Description("Verify retrieve New Loan MB Pay Charges association information")]
        public void Scenario_1_Retrieve_MB_Pay_Charges_Association()
        {
            try
            {
                Reports.TestDescription = "Verify retrieve New Loan MB Pay Charges association information";

                FAST_Init_File();

                #region Navigate to New Loan and add Mortgage Broker charges
                Reports.TestStep = "Navigate to New Loan and add Mortgage Broker charges";
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.ClickMortgageBrokerTab();
                FastDriver.NewLoan.MortgageGABcode.FASetText("415");
                FastDriver.NewLoan.MortgageFind.Click();
                FastDriver.NewLoan.WaitCreation(FastDriver.WebDriver.FindElement(By.CssSelector("#tblBusPartyDetails span:contains('415')")));
                FastDriver.NewLoan.MortgageYieldSpreadPremiumAmount.FASetText("999999.99");
                FastDriver.NewLoan.MortgageGFE_3MortgageBrokerChargesPaymentDetails.Click();
                var paymentDetails = new FASTSelenium.DataObjects.IIS.PDD()
                {
                    BuyerAtClosing = (double)500000,
                    BuyerCredit = (double)1000000,
                    SellerPaidAtClosing = (double)500000,
                    SellerCredit = (double)1000000,
                    LoanEstimateUnrounded = (double)999999.99
                };
                FAST_UpdatePDD(paymentDetails);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.MortgageGFE_6MortgageBrokerChargesPaymentDetails.Click();
                FAST_UpdatePDD(paymentDetails);
                FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.NewLoan.MortgageGFE_7FutureRecordingFeescollectedbyLenderMBPaymentDetails.Click();
                FAST_UpdatePDD(paymentDetails);
                //FastDriver.NewLoan.SwitchToContentFrame();
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify charges are available for association
                Reports.TestStep = "Verify charges are available for association";
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.ClickMortgageBrokerTab();
                FastDriver.NewLoan.MortgagePayCharges.Click();
                FastDriver.NewLoanDisbursements.WaitForScreenToLoad();
                Support.AreEqual("true", FastDriver.WebDriver.FindElement(By.Id("dgridCharges_0_chkSel")).GetAttribute("status").ToLowerInvariant());
                Support.AreEqual("false", FastDriver.WebDriver.FindElement(By.Id("dgridCharges_1_chkSel")).GetAttribute("status").ToLowerInvariant());
                Support.AreEqual("false", FastDriver.WebDriver.FindElement(By.Id("dgridCharges_2_chkSel")).GetAttribute("status").ToLowerInvariant());
                Support.AreEqual("false", FastDriver.WebDriver.FindElement(By.Id("dgridCharges_3_chkSel")).GetAttribute("status").ToLowerInvariant());
                #endregion

                #region Associate Mortgage Broker charges using NewLoanMBPayChargesAssociation
                var fileId = File.FileID ?? 0;
                var newLoanDetails = FileService.GetNewLoanDetails(fileId, seqNum: 1);
                Support.AreEqual("1", newLoanDetails.Status.ToString(), newLoanDetails.StatusDescription);
                Support.AreEqual("4", newLoanDetails.MortgageBroker.CDPayCharges.DisbursementCharges.Count().ToString());
                for (int i = 0; i < 4; i++)
                {
                    if (newLoanDetails.MortgageBroker.CDPayCharges.DisbursementCharges[i].IsSelected == false)
                    {
                        var request = RequestFactory.GetNewLoanPayChargeAssociationRequest(
                            fileID: fileId,
                            seqNum: 1,
                            charge: newLoanDetails.MortgageBroker.CDPayCharges.DisbursementCharges[i],
                            fileBusParty: newLoanDetails.MortgageBroker.CDPayCharges.PayeeInformation[0]
                        );
                        var response = FileService.NewLoanMBPayChargesAssociation(request);
                        Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                    }
                }
                #endregion

                #region Verify association is showing in FAST after association request
                Reports.TestStep = "Verify association is showing in FAST after association request";
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.ClickMortgageBrokerTab();
                FastDriver.NewLoan.MortgagePayCharges.Click();
                FastDriver.NewLoanDisbursements.WaitForScreenToLoad();
                Support.AreEqual("true", FastDriver.WebDriver.FindElement(By.Id("dgridCharges_0_chkSel")).GetAttribute("status").ToLowerInvariant());
                Support.AreEqual("true", FastDriver.WebDriver.FindElement(By.Id("dgridCharges_1_chkSel")).GetAttribute("status").ToLowerInvariant());
                Support.AreEqual("true", FastDriver.WebDriver.FindElement(By.Id("dgridCharges_2_chkSel")).GetAttribute("status").ToLowerInvariant());
                Support.AreEqual("true", FastDriver.WebDriver.FindElement(By.Id("dgridCharges_3_chkSel")).GetAttribute("status").ToLowerInvariant());
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
