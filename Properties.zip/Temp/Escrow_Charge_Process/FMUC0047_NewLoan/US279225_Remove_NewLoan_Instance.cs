﻿using FASTSelenium.Common;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;


namespace Web_Services_Regression.Escrow_Charge_Process.FMUC0047_NewLoan
{
    [CodedUITest]
    public class US279225_Remove_NewLoan_Instance : SlaveTestClass
    {
        private void OpenNewLoan(int newLoanIndex)
        {
            if (newLoanIndex <= 1) { FastDriver.NewLoan.Open(); }
            else { FastDriver.NewLoanSummary.Open(newLoanIndex); }
        }

        private void Create2ndNewLoan()
        {
            #region Create a second New Loan
            Reports.TestStep = "Create a second New Loan";
            FastDriver.NewLoan.Open();
            FastDriver.BottomFrame.New();
            FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();
            FastDriver.NewLoan.FindGABCode("488");
            FastDriver.BottomFrame.Done();
            FastDriver.NewLoanSummary.WaitForScreenToLoad();
            #endregion
        }

        private void TestRemoveNewLoan(int newLoanIndex, FormType formType)
        {
            FAST_Login_IIS();

            FAST_WCF_File_IIS(GABRole: AdditionalRoleType.NewLender, formType: formType);

            if (newLoanIndex == 2)
                Create2ndNewLoan();

            #region Add Loan Charges for New Loan plus Mortgage Broker
            Reports.TestStep = "Add Loan Charges for New Loan plus Mortgage Broker";
            OpenNewLoan(newLoanIndex);
            FastDriver.NewLoan.ClickChargesTab();
            FastDriver.NewLoan.LoanChargesPrincipalBalanceChargesBuyercredit.FASetText("1,000.00");
            KeyboardSendKeys(FAKeys.TabAway);
            FastDriver.NewLoan.ClickMortgageBrokerTab();
            FastDriver.NewLoan.MortgageFindGAB(GABName: "BOA");
            FastDriver.BottomFrame.Done();
            Playback.Wait(3000);
            #endregion

            #region Remove New Loan instance
            Reports.TestStep = "Remove New Loan instance " + newLoanIndex;
            var request = RequestFactory.GetRemoveNewLoanRequest(File.FileID, seqNum: newLoanIndex);
            var response = FileService.RemoveNewLoan(request);
            Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
            #endregion

            #region Verify Loan Charges are removed after removing New Loan instance
            Reports.TestStep = "Verify Loan Charges are removed after removing New Loan instance";
            OpenNewLoan(newLoanIndex);
            FastDriver.NewLoan.ClickChargesTab();
            Support.AreEqual("", FastDriver.NewLoan.LoanChargesPrincipalBalanceChargesBuyercredit.FAGetValue(), "Buyer Credit");
            #endregion
        }

        [TestMethod]
        [Description("Verify removing 1st New Loan instance using RemoveNewLoan web service when File is CD")]
        public void Scenario_1_CD_Remove_1st_Instance()
        {
            try
            {
                Reports.TestDescription = "Verify removing 1st New Loan instance using RemoveNewLoan web service when File is CD";

                TestRemoveNewLoan(newLoanIndex: 1, formType: FormType.CD);
            }
            catch (Exception ex)
            { 
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify removing 2nd New Loan instance using RemoveNewLoan web service when File is CD")]
        public void Scenario_2_CD_Remove_2nd_Instance()
        {
            try
            {
                Reports.TestDescription = "Verify removing 2nd New Loan instance using RemoveNewLoan web service when File is CD";

                TestRemoveNewLoan(newLoanIndex: 2, formType: FormType.CD);
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify removing 1st New Loan instance using RemoveNewLoan web service when File is HUD")]
        public void Scenario_3_HUD_Remove_1st_Instance()
        {
            try
            {
                Reports.TestDescription = "Verify removing 1st New Loan instance using RemoveNewLoan web service when File is HUD";

                TestRemoveNewLoan(newLoanIndex: 1, formType: FormType.HUD);
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify removing 2nd New Loan instance using RemoveNewLoan web service when File is HUD")]
        public void Scenario_4_HUD_Remove_2nd_Instance()
        {
            try
            {
                Reports.TestDescription = "Verify removing 2nd New Loan instance using RemoveNewLoan web service when File is HUD";

                TestRemoveNewLoan(newLoanIndex: 2, formType: FormType.HUD);
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }
        
        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
