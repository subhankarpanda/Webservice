﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.Escrow_Charge_Process.FMUC0047_NewLoan
{
    [CodedUITest]
    public class US384987_Retrieve_NewLoan_Recap : SlaveTestClass
    {
        [TestMethod]
        [Description("Verify New Loan - Recap tab information using GetNewLoanDetails web service")]
        public void Scenario_1_Retrieve_NewLoan_Recap()
        {
            try
            {
                Reports.TestDescription = "Verify New Loan - Recap tab information using GetNewLoanDetails web service";

                FAST_Init_File(LenderID: "415", loanAmt: 1500000);
                
                #region Add New Loan Charge with PDD
                Reports.TestStep = "Add New Loan Charge with PDD";
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.ClickChargesTab();
                var paymentDetails = new PDD()
                {
                    ChargeDescription = "test-charge-description",
                    UseDefaultChecked = false,
                    PayeeName = "test-payee-name",
                    LoanEstimateUnrounded = (double)15099.99,
                    PartOfCheckbox = true,
                    SectionCDidShopFor = true,
                    BuyerAtClosing = (double)15000,
                    BuyerBeforeClosing = (double)5000,
                    BuyerPaidbyOther = (double)10000,
                    BuyerPaidbyOtherPaymentMethod = "POC-L",
                    BuyerLenderCheckbox = false,
                    BuyerDoubleAsteriskChecked = false,
                    SellerPaidAtClosing = (double)12000,
                    SellerPaidBeforeClosing = (double)6000,
                    SellerPaidbyOthers = (double)6000,
                    SellerPaidbyOtherPaymentMthd = "POC-MB",
                };
                FastDriver.NewLoan.NewLoanChargesPaymentDetails.Click();
                FAST_UpdatePDD(paymentDetails);
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                FastDriver.NewLoan.ClickMortgageBrokerTab();
                FastDriver.NewLoan.MortgageFindGABCode("415");
                FastDriver.NewLoan.LoanChargesGFE_3NewLoanChargesPaymentDetails.Click();
                FAST_UpdatePDD(paymentDetails);
                FastDriver.BottomFrame.Done();
                FastDriver.NewLoan.WaitForScreenToLoad();
                FastDriver.NewLoan.ClickRecapTab();
                FastDriver.NewLoan.WaitForRecapToLoad();
                #endregion

                #region Verify New Loan Charge's information using GetCDDetails()
                Reports.TestStep = "Verify New Loan Charge's information using GetCDDetails()";
                var request = EscrowReqFactory.GetNewLoanDetailsRequest(File.FileID, seqNum: 1);
                var details = EscrowService.GetNewLoanDetails(request);
                Support.AreEqual("1", details.Status.ToString(), details.StatusDescription);
                Support.AreEqual("0.00", details.CDRecapInformation.CheckReducedByTitleEscrowFeesPaidMortgageBroker, "CheckReducedByTitleEscrowFeesPaidMortgageBroker");
                Support.AreEqual("New Loan 1:Continental Mortgage Corporation/Continental Mortgage Corporation$1,500,000.00", details.CDRecapInformation.HeaderTxt, "HeaderTxt");
                Support.AreEqual("1,500,000.00", details.CDRecapInformation.LoanAmount, "LoanAmount");
                //  Lender
                Support.AreEqual("", details.CDRecapInformation.Lender.BrokerFeeCheck ?? "", "Lender.BrokerFeeCheck");
                Support.AreEqual("-27,000.00", details.CDRecapInformation.Lender.ChargeAmount, "Lender.ChargeAmount");
                Support.AreEqual("-0.00", details.CDRecapInformation.Lender.FutureRecordingFeesPaid, "Lender.FutureRecordingFeesPaid");
                Support.AreEqual("0.00", details.CDRecapInformation.Lender.TitleEscrowFeesPaid, "Lender.TitleEscrowFeesPaid");
                Support.AreEqual("54,000.00", details.CDRecapInformation.LenderDetails.ChargesTotal, "LenderDetails.ChargesTotal");
                Support.AreEqual("0.00", details.CDRecapInformation.LenderDetails.NetCheck, "LenderDetails.NetCheck");
                Support.AreEqual("0.00", details.CDRecapInformation.LenderDetails.PaidatClosingCheck, "LenderDetails.PaidatClosingCheck");
                Support.AreEqual("27,000.00", details.CDRecapInformation.LenderDetails.PaidatClosingRBL, "LenderDetails.PaidatClosingRBL");
                Support.AreEqual("5,000.00", details.CDRecapInformation.LenderDetails.PaidbyBuyerbeforeClosing, "LenderDetails.PaidbyBuyerbeforeClosing");
                Support.AreEqual("10,000.00", details.CDRecapInformation.LenderDetails.PaidbyOthersLender, "LenderDetails.PaidbyOthersLender");
                Support.AreEqual("6,000.00", details.CDRecapInformation.LenderDetails.PaidbyOthersMortgageBroker, "LenderDetails.PaidbyOthersMortgageBroker");
                Support.AreEqual("0.00", details.CDRecapInformation.LenderDetails.PaidbyOthersPOC, "LenderDetails.PaidbyOthersPOC");
                Support.AreEqual("6,000.00", details.CDRecapInformation.LenderDetails.PaidbySellerbeforeClosing, "LenderDetails.PaidbySellerbeforeClosing");
                //  Mortgage Broker
                Support.AreEqual("0.00", details.CDRecapInformation.MortgageBroker.BrokerFeeCheck ?? "", "MortgageBroker.BrokerFeeCheck");
                Support.AreEqual("-27,000.00", details.CDRecapInformation.MortgageBroker.ChargeAmount, "MortgageBroker.BrokerFeeCheck");
                Support.AreEqual("-0.00", details.CDRecapInformation.MortgageBroker.FutureRecordingFeesPaid, "MortgageBroker.FutureRecordingFeesPaid");
                Support.AreEqual("0.00", details.CDRecapInformation.MortgageBroker.TitleEscrowFeesPaid, "MortgageBroker.TitleEscrowFeesPaid");
                Support.AreEqual("54,000.00", details.CDRecapInformation.MortgageBrokerDetails.ChargesTotal, "MortgageBrokerDetails.ChargesTotal");
                Support.AreEqual("0.00", details.CDRecapInformation.MortgageBrokerDetails.NetCheck, "MortgageBrokerDetails.NetCheck");
                Support.AreEqual("0.00", details.CDRecapInformation.MortgageBrokerDetails.PaidatClosingCheck, "MortgageBrokerDetails.PaidatClosingCheck");
                Support.AreEqual("27,000.00", details.CDRecapInformation.MortgageBrokerDetails.PaidatClosingRBL, "MortgageBrokerDetails.PaidatClosingRBL");
                Support.AreEqual("5,000.00", details.CDRecapInformation.MortgageBrokerDetails.PaidbyBuyerbeforeClosing, "MortgageBrokerDetails.PaidbyBuyerbeforeClosing");
                Support.AreEqual("10,000.00", details.CDRecapInformation.MortgageBrokerDetails.PaidbyOthersLender, "MortgageBrokerDetails.PaidbyOthersLender");
                Support.AreEqual("6,000.00", details.CDRecapInformation.MortgageBrokerDetails.PaidbyOthersMortgageBroker, "MortgageBrokerDetails.PaidbyOthersMortgageBroker");
                Support.AreEqual("0.00", details.CDRecapInformation.MortgageBrokerDetails.PaidbyOthersPOC, "MortgageBrokerDetails.PaidbyOthersPOC");
                Support.AreEqual("6,000.00", details.CDRecapInformation.MortgageBrokerDetails.PaidbySellerbeforeClosing, "MortgageBrokerDetails.PaidbySellerbeforeClosing");
                //
                Support.AreEqual("0.00", details.CDRecapInformation.MortgageBrokerGrossCheck, "MortgageBrokerGrossCheck");
                Support.AreEqual("1,446,000.00", details.CDRecapInformation.ProjectedLoanFunding, "ProjectedLoanFunding");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
