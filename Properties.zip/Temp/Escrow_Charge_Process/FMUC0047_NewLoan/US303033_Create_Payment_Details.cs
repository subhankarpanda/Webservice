﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.Escrow_Charge_Process.FMUC0047_NewLoan
{
    [CodedUITest]
    public class US303033_Create_Payment_Details : SlaveTestClass
    {
        #region var paymentDetails
        protected PDD paymentDetails = new PDD()
        {
            ChargeDescription = "test-charge-description",
            UseDefaultChecked = false,
            PayeeName = "test-payee-name",
            LoanEstimateUnrounded = (double)15099.99,
            PartOfCheckbox = true,
            BuyerAtClosing = (double)15000,
            BuyerBeforeClosing = (double)5000,
            BuyerPaidbyOther = (double)10000,
            BuyerPaidbyOtherPaymentMethod = "POC-L",
            BuyerLenderCheckbox = false,
            BuyerDoubleAsteriskChecked = false,
            SellerPaidAtClosing = (double)12000,
            SellerPaidBeforeClosing = (double)6000,
            SellerPaidbyOthers = (double)6000,
            SellerPaidbyOtherPaymentMthd = "POC",
            SectionBdidnotShopFor = false,
            SectionCDidShopFor = false,
            SectionHOtherCosts = false,
        };
        #endregion

        [TestMethod]
        [Description("Verify create New Loan Charge Payment Details using CreateNewLoan()")]
        public void Scenario_1_Create_PDD_with_CreateNewLoan() 
        {
            try
            {
                Reports.TestDescription = "Verify create New Loan Charge Payment Details using CreateNewLoan()";

                FAST_Init_File();

                #region Add New Loan Charge with PDD using CreateNewLoan()
                Reports.TestStep = "Add New Loan Charge with PDD using CreateNewLoan()";
                var request = RequestFactory.GetNewLoanRequest(File.FileID ?? 0, seqNum: 1);
                request.LoanDetails = new NewLoanDetail()
                {
                    LoanNumber = "1234567890",
                    LoanAmount = 1500000,
                    LenderInformation = new PayChargeFileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("415")
                    }
                };
                request.LoanCharges.CDNewLoanCharges = new CDChargePaymentDetails[]{
                    new CDChargePaymentDetails(){
                        Description = "test-charge-description",
                        UseDefault = false,
                        PayeeNameOnCDOrSettlementStmt = "test-payee-name",
                        LEAmount = (decimal)15099.99,
                        PartOf = true,
                        //  eSectionShop is UI disabled
                        PBBuyerAtClosing = (decimal)15000,
                        PBBuyerBeforeClosing = (decimal)5000,
                        PBOthersForBuyer = (decimal)10000,
                        PBOthersForBuyerPMTypeCdID = OtherPaymentMethods.POCL,
                        DisplayLBuyer = false,
                        BuyerCreditPaymentMethodTypeCdID = CreditPaymentMethods.Lender,
                        DoubleAsteriskIndicator = false,
                        PBSellerAtClosing = (decimal)12000,
                        PBSellerBeforeClosing = (decimal)6000,
                        PBOthersForSeller = (decimal)6000,
                        PBOthersForSellerPMTypeCdID = OtherPaymentMethods.POC,
                        SellerCreditPaymentMethodTypeCdID = CreditPaymentMethods.Lender,
                        SeqNum = 1,
                    },
                };
                var response = FileService.CreateNewLoan(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Verify New Loan Charge's information in FAST
                Reports.TestStep = "Verify New Loan Charge's information in FAST";
                FastDriver.NewLoanSummary.Open(2);
                FastDriver.NewLoan.ClickChargesTab();
                FastDriver.NewLoan.NewLoanChargesPaymentDetails.Click();                
                FAST_VerifyPDD(paymentDetails);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify update New Loan Charge Payment Details using UpdateNewLoan()")]
        public void Scenario_2_Update_PDD_with_UpdateNewLoan() 
        {
            try
            {
                Reports.TestDescription = "Verify create New Loan Charge Payment Details using CreateNewLoan()";

                FAST_Init_File();

                #region Add New Loan Charge with PDD using UpdateNewLoan()
                Reports.TestStep = "Add New Loan Charge with PDD using UpdateNewLoan()";
                var request = RequestFactory.GetNewLoanRequest(File.FileID ?? 0, seqNum: 1);
                request.LoanDetails = new NewLoanDetail()
                {
                    LoanNumber = "1234567890",
                    LoanAmount = 1500000,
                    LenderInformation = new PayChargeFileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("415")
                    }
                };
                request.LoanCharges.CDNewLoanCharges = new CDChargePaymentDetails[]{
                    new CDChargePaymentDetails(){
                        Description = "test-charge-description",
                        UseDefault = false,
                        PayeeNameOnCDOrSettlementStmt = "test-payee-name",
                        LEAmount = (decimal)15099.99,
                        PartOf = true,
                        eSectionShop = SectionsShoppedFor.SectionCdidShopFor,
                        PBBuyerAtClosing = (decimal)15000,
                        PBBuyerBeforeClosing = (decimal)5000,
                        PBOthersForBuyer = (decimal)10000,
                        PBOthersForBuyerPMTypeCdID = OtherPaymentMethods.POCL,
                        DisplayLBuyer = false,
                        BuyerCreditPaymentMethodTypeCdID = CreditPaymentMethods.Lender,
                        DoubleAsteriskIndicator = false,
                        PBSellerAtClosing = (decimal)12000,
                        PBSellerBeforeClosing = (decimal)6000,
                        PBOthersForSeller = (decimal)6000,
                        PBOthersForSellerPMTypeCdID = OtherPaymentMethods.POC,
                        SellerCreditPaymentMethodTypeCdID = CreditPaymentMethods.Lender,
                        SeqNum = 1,
                    },
                };
                var response = FileService.UpdateNewLoan(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Verify New Loan Charge's information in FAST
                Reports.TestStep = "Verify New Loan Charge's information in FAST";
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.ClickChargesTab();
                FastDriver.NewLoan.NewLoanChargesPaymentDetails.Click();
                var pdd = paymentDetails;
                pdd.SectionCDidShopFor = true;
                FAST_VerifyPDD(pdd);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
