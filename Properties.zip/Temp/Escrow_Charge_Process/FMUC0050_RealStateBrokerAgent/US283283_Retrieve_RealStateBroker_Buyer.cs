﻿using FASTSelenium.Common;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastEscrowService;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.Escrow_Charge_Process.FMUC0050_RealStateBrokerAgent
{
    [CodedUITest]
    public class US283283_Retrieve_RealEstateBroker_Buyer : FASTHelpers
    {
        private void VerifyRealEstateBrokerObject(RealEstateBrokerDetails broker, RealEstateBrokerType expectedType, bool creditBuyer, bool creditSeller)
        {
            Reports.TestStep = "Verify Real Estate Broker: " + expectedType.ToString();
            //  Real Estate Agent
            Support.AreEqual(AdminService.GetGABAddressBookEntryId("415").ToString(), broker.AgentInformation.FBP.AddrBookEntryID.ToString(), "AgentInformation.FBP.IDCode");
            //  CDCommissionChargeAmount
            //Support.AreEqual("Real Estate Commission", broker.CDCommissionChargeAmount.Description, "CDCommissionChargeAmount.Description");
            //  CDPOCByBroker
            Support.AreEqual("test-poc-by-broker", broker.CDPOCByBroker[0].Description, "CDPOCByBroker[0].Description");
            //  CDREBrokerCharges
            Support.AreEqual("test-real-estate-broker-charge", broker.CDREBrokerCharges[0].Description, "CDREBrokerCharges[0].Description");
            //  CDREBrokerCredits
            Support.AreEqual("test-real-estate-broker-credits", broker.CDREBrokerCredits[0].Description, "CDREBrokerCredits[0].Description");
            //  CommissionSummary
            Support.AreEqual("1,000,000", ((Decimal)broker.CommissionSummary.BrokerCharge).ToString("N0"), "CommissionSummary.BrokerCharge");
            Support.AreEqual("1,000,000", ((Decimal)broker.CommissionSummary.CommissionAmount).ToString("N0"), "CommissionSummary.CommissionAmount");
            Support.AreEqual("0", ((Decimal)broker.CommissionSummary.CommissionPercentage).ToString("N0"), "CommissionSummary.CommissionPercentage");
            Support.AreEqual("500,000", ((Decimal)broker.CommissionSummary.CreditBuyerAmt).ToString("N0"), "CommissionSummary.CreditBuyerAmt");
            Support.AreEqual("0", ((Decimal)broker.CommissionSummary.CreditBuyerBrokerAmt).ToString("N0"), "CommissionSummary.CreditBuyerBrokerAmt");
            Support.AreEqual(creditBuyer.ToString(), broker.CommissionSummary.CreditBuyerBrokerFlag.ToString(), "CommissionSummary.CreditBuyerBrokerFlag");
            Support.AreEqual("True", broker.CommissionSummary.CreditBuyerFlag.ToString(), "CommissionSummary.CreditBuyerFlag");
            Support.AreEqual("0", ((Decimal)broker.CommissionSummary.CreditFromOtherBroker).ToString("N0"), "CommissionSummary.CreditFromOtherBroker");
            Support.AreEqual("500,000", ((Decimal)broker.CommissionSummary.CreditSellerAmt).ToString("N0"), "CommissionSummary.CreditSellerAmt");
            Support.AreEqual("1,000,000", ((Decimal)broker.CommissionSummary.CreditSellerBrokerAmt).ToString("N0"), "CommissionSummary.CreditSellerBrokerAmt");
            Support.AreEqual(creditSeller.ToString(), broker.CommissionSummary.CreditSellerBrokerFlag.ToString(), "CommissionSummary.CreditSellerBrokerFlag");
            Support.AreEqual("True", broker.CommissionSummary.CreditSellerFlag.ToString(), "CommissionSummary.CreditSellerFlag");
            Support.AreEqual("0", ((Decimal)broker.CommissionSummary.HoldingEarnestMoneyAmount).ToString("N0"), "CommissionSummary.HoldingEarnestMoneyAmount");
            Support.AreEqual("0", ((Decimal)broker.CommissionSummary.HomeWarrantyAmount).ToString("N0"), "CommissionSummary.HomeWarrantyAmount");
            Support.AreEqual("-4,000,000", ((Decimal)broker.CommissionSummary.NetCheckAmount).ToString("N0"), "CommissionSummary.NetCheckAmount");
            Support.AreEqual("0", ((Decimal)broker.CommissionSummary.OtherChargespaidByBrokerAmt).ToString("N0"), "CommissionSummary.OtherChargespaidByBrokerAmt");
            Support.AreEqual("-5,000,000", ((Decimal)broker.CommissionSummary.OtherNetCheckAmount).ToString("N0"), "CommissionSummary.OtherNetCheckAmount");
            Support.AreEqual("4,000,000", ((Decimal)broker.CommissionSummary.SellingOrListingBrokerDisbAmount).ToString("N0"), "CommissionSummary.SellingOrListingBrokerDisbAmount");
            //  Disbursement
            Support.AreEqual(AdminService.GetGABAddressBookEntryId("488").ToString(), broker.DisbSummaryFBP[0].FBP.AddrBookEntryID.ToString(), "DisbSummaryFBP[0].FBP.IDCode");
            //  Real Estate Broker
            Support.AreEqual(AdminService.GetGABAddressBookEntryId("415").ToString(), broker.REBrokerInformation.FBP.AddrBookEntryID.ToString(), "REBrokerInformation.FBP.IDCode");
            //  Broker Type
            Support.AreEqual("True", (broker.REBrokerType == expectedType).ToString(), "REBrokerType");
        }

        [TestMethod]
        [Description("Verify Real State Broker - Buyer information using GetRealStateBroker web service")]
        public void Scenario_1_Retrieve_RealEstateBroker_Buyer()
        {
            try
            {
                Reports.TestDescription = "Verify Real State Broker information using GetRealStateBroker web service";

                FAST_Init_File();

                #region Navigate to Real Estate Broker/Agent and create a new instance for Buyer
                Reports.TestStep = "Navigate to Real Estate Broker/Agent and create a new instance for Buyer";
                FastDriver.RealEstateBrokerAgentSummary.Open();
                FastDriver.RealEstateBrokerAgentSummary.Buyer.Click();
                FastDriver.RealEstateBrokerAgentSummary.SellerBuyerEdit.Click();
                FAST_AddRealStateBroker(creditBuyer: false, creditSeller: true);
                FastDriver.RealEstateBrokerAgentSummary.WaitForScreenToLoad();
                #endregion
                
                #region Verify Real Estate Broker details using GetRealStateBroker web service
                Reports.TestStep = "Verify Real Estate Broker details using GetRealStateBroker web service";
                var request = EscrowRequestFactory.GetServiceFileRequest(File.FileID ?? 0);
                var details = EscrowService.GetRealStateBroker(request);
                Support.AreEqual("1", details.Status.ToString(), details.StatusDescription);
                VerifyRealEstateBrokerObject(details.BuyerBroker, RealEstateBrokerType.BUYER, creditBuyer: false, creditSeller: true);
                //
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
