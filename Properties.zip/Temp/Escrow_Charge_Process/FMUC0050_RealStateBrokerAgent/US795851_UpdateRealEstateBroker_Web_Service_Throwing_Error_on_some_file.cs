﻿using FASTSelenium.Common;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using OpenQA.Selenium;
using FASTWCFHelpers.FastFileService;
using OpenQA.Selenium.Support.UI;
using FASTSelenium.PageObjects;
using System.Diagnostics;
using Microsoft.Win32;
using FASTSelenium.DataObjects.IIS;
using FASTSelenium.DataObjects.ADM;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using System.Linq;
using System.Collections.Generic;
using OpenQA.Selenium.Interactions;
using System.Windows.Input;

namespace Web_Services_Regression.Escrow_Charge_Process.FMUC0050_RealStateBrokerAgent
{
    [CodedUITest]
    public class US795851_UpdateRealEstateBroker_Web_Service_Throwing_Error_on_some_file : FASTHelpers
    {
        [TestMethod]
        public void US795851_TC833344()
        {
            try
            {
                Reports.TestDescription = "To test US#795851, verify if UpdateRealEstateBroker() Web Service is throwing error";
                
                Reports.TestStep = "Create EOS File by Calling CreateFile()";
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyAddress[0].AddrLine1 = "1815 SW Marlow Ave";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "Portland";
                fileRequest.File.Properties[0].PropertyAddress[0].State = "OR";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "Multnomah";
                fileRequest.File.Properties[0].PropertyAddress[0].Zip = "97225";
                fileRequest.File.Buyers[0].Type = "Individual";
                fileRequest.File.Buyers[0].Name = "BuyerFirst";
                fileRequest.File.Buyers[0].LastName = "BuyerLast";
                fileRequest.File.Sellers[0].Type = "Individual";
                fileRequest.File.Sellers[0].Name = "SellerFirst";
                fileRequest.File.Sellers[0].LastName = "SellerLast";
                fileRequest.Source = "EOS";
                int? FileID = FileService.CreateFile(fileRequest).FileID;

                Reports.TestStep = "Open UpdateRealEstateBroker and set FileID, Source=EOS, LoginName, SeqNum=1, REBrokerType=BUYER and AddrBookEntryID";
                var REBrequest = new FASTWCFHelpers.FastEscrowService.RealEstateBrokerRequest();
                REBrequest.FileID = FileID;
                REBrequest.Source = "EOS";
                REBrequest.LoginName = "fastqa07";
                REBrequest.Target = "FAST";
                REBrequest.RealEstateBrokerInformation = new FASTWCFHelpers.FastEscrowService.RealEstateBrokerDetails
                {
                    REBrokerType = FASTWCFHelpers.FastEscrowService.RealEstateBrokerType.BUYER,
                    SeqNum = 1,
                    REBrokerInformation = new FASTWCFHelpers.FastEscrowService.RealEstateBrokerInformation
                    {
                        FBP = new FASTWCFHelpers.FastEscrowService.FileBusinessParty
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId(gabCode: "242")
                        }
                    }
                };

                Reports.TestStep = "Click on Run and verify the response";
                var response = EscrowService.UpdateRealEstateBroker(REBrequest);
                Support.AreEqual("REBroker of type BUYER with Sequence No: 1 Updated successfully", response.StatusDescription);

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }            
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}