﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastEscrowService;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.Escrow_Charge_Process.FMUC0049_Prorations
{
    [CodedUITest]
    public class US452256_Update_Prorations_Rent_Tax_Misc : FASTHelpers
    {
        [TestMethod]
        [Description("Verify update Proration - Rent information using UpdateProration web service")]
        public void Scenario_1_Update_Proration_Rent_Details()
        {
            try
            {
                Reports.TestDescription = "Verify update Proration - Rent information using UpdateProration web service";

                FAST_Init_File();

                #region Update Proration - Rent instance with UpdateProration()
                Reports.TestStep = "Update Proration - Rent instance with UpdateProration()";
                var index = 0;
                var request = EscrowRequestFactory.GetProrationRequest(File.FileID, index + 1, ProrationType.RENT);
                //request.ProrDetailsForCD.Description = null;
                var response = EscrowService.UpdateProration(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Verify updated Proration instance in FAST
                Reports.TestStep = "Verify updated Proration instance in FAST";
                FastDriver.ProrationRent.Open();
                var prorationData = request.ProrDetailsForCD as ProrationDetailsForCD;
                Support.AreEqual((prorationData.CreditSeller ?? false) ? "Yes" : "No", FastDriver.ProrationRent.NthCreditSeller(index).FAGetText(), "CreditSeller");
                Support.AreEqual((prorationData.DayOfClosePaidbySeller ?? false) ? "Yes" : "No", FastDriver.ProrationRent.NthDayofClosePaidbySeller(index).FAGetText(), "DayofClosePaidbySeller");
                Support.AreEqual(((Decimal)prorationData.Amount).ToString("C2"), FastDriver.ProrationRent.NthAmount(index).FAGetText(), "Amount");
                Support.AreEqual(((DateTime)prorationData.FromDate).ToDateString(), FastDriver.ProrationRent.NthFrom(index).FAGetText(), "FromDate");
                Support.AreEqual((prorationData.FromDateInclusive ?? false) ? "Yes" : "No", FastDriver.ProrationRent.NthFromInclusive(index).FAGetText(), "FromInclusive");
                Support.AreEqual((prorationData.FromDateIsProrateDate ?? false) ? "Yes" : "No", FastDriver.ProrationRent.NthFromProrateDate(index).FAGetText(), "FromProrateDate");
                Support.AreEqual(prorationData.AmountPeriod.ToString().ToLowerInvariant(), FastDriver.ProrationRent.NthPeriod(index).FAGetText().ToLowerInvariant(), "Period");
                Support.AreEqual(((DateTime)prorationData.ToDate).ToDateString(), FastDriver.ProrationRent.NthTo(index).FAGetText(), "ToDate");
                Support.AreEqual((prorationData.ToDateInclusive ?? false) ? "Yes" : "No", FastDriver.ProrationRent.NthToInclusive(index).FAGetText(), "ToInclusive");
                Support.AreEqual((prorationData.ToDateIsProrateDate ?? false) ? "Yes" : "No", FastDriver.ProrationRent.NthToProrateDate(index).FAGetText(), "ToProrateDate");
                if (prorationData.Description != null)
                    Support.AreEqual(prorationData.Description, FastDriver.ProrationRent.NthDescription(index).FAGetText(), "Description");
                Support.AreEqual(((Decimal)prorationData.BuyerCharge).ToString("N2"), FastDriver.ProrationRent.NthBuyerCharge(index).FAGetText(), "BuyerCharge");
                Support.AreEqual(((Decimal)prorationData.BuyerCredit).ToString("N2"), FastDriver.ProrationRent.NthBuyerCredit(index).FAGetText(), "BuyerCredit");
                Support.AreEqual(((Decimal)prorationData.SellerCharge).ToString("N2"), FastDriver.ProrationRent.NthSellerCharge(index).FAGetText(), "SellerCharge");
                Support.AreEqual(((Decimal)prorationData.SellerCredit).ToString("N2"), FastDriver.ProrationRent.NthSellerCredit(index).FAGetText(), "SellerCredit");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify update Proration - Tax information using UpdateProration web service")]
        public void Scenario_2_Update_Proration_Tax_Details()
        {
            try
            {
                Reports.TestDescription = "Verify update Proration - Tax information using UpdateProration web service";

                FAST_Init_File();

                #region Update Proration - Tax instance with UpdateProration()
                Reports.TestStep = "Update Proration - Tax instance with UpdateProration()";
                var index = 0;
                var request = EscrowRequestFactory.GetProrationRequest(File.FileID, index + 1, ProrationType.TAX);
                request.ProrDetailsForCD.Description = null;
                var response = EscrowService.UpdateProration(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Verify updated Proration instance in FAST
                Reports.TestStep = "Verify updated Proration instance in FAST";
                FastDriver.ProrationTax.Open();
                var prorationData = request.ProrDetailsForCD as ProrationDetailsForCD;
                Support.AreEqual((prorationData.CreditSeller ?? false) ? "Yes" : "No", FastDriver.ProrationTax.NthCreditSeller(index).FAGetText(), "CreditSeller");
                Support.AreEqual((prorationData.DayOfClosePaidbySeller ?? false) ? "Yes" : "No", FastDriver.ProrationTax.NthDayofClosePaidbySeller(index).FAGetText(), "DayofClosePaidbySeller");
                Support.AreEqual(((Decimal)prorationData.Amount).ToString("C2"), FastDriver.ProrationTax.NthAmount(index).FAGetText(), "Amount");
                Support.AreEqual(((DateTime)prorationData.FromDate).ToDateString(), FastDriver.ProrationTax.NthFrom(index).FAGetText(), "FromDate");
                Support.AreEqual((prorationData.FromDateInclusive ?? false) ? "Yes" : "No", FastDriver.ProrationTax.NthFromInclusive(index).FAGetText(), "FromInclusive");
                Support.AreEqual((prorationData.FromDateIsProrateDate ?? false) ? "Yes" : "No", FastDriver.ProrationTax.NthFromProrateDate(index).FAGetText(), "FromProrateDate");
                Support.AreEqual(prorationData.AmountPeriod.ToString().ToLowerInvariant(), FastDriver.ProrationTax.NthPeriod(index).FAGetText().ToLowerInvariant(), "Period");
                Support.AreEqual(((DateTime)prorationData.ToDate).ToDateString(), FastDriver.ProrationTax.NthTo(index).FAGetText(), "ToDate");
                Support.AreEqual((prorationData.ToDateInclusive ?? false) ? "Yes" : "No", FastDriver.ProrationTax.NthToInclusive(index).FAGetText(), "ToInclusive");
                Support.AreEqual((prorationData.ToDateIsProrateDate ?? false) ? "Yes" : "No", FastDriver.ProrationTax.NthToProrateDate(index).FAGetText(), "ToProrateDate");
                if (prorationData.Description != null)
                    Support.AreEqual(prorationData.Description, FastDriver.ProrationTax.NthDescription(index).FAGetText(), "Description");
                Support.AreEqual(((Decimal)prorationData.BuyerCharge).ToString("N2"), FastDriver.ProrationTax.NthBuyerCharge(index).FAGetText(), "BuyerCharge");
                Support.AreEqual(((Decimal)prorationData.BuyerCredit).ToString("N2"), FastDriver.ProrationTax.NthBuyerCredit(index).FAGetText(), "BuyerCredit");
                Support.AreEqual(((Decimal)prorationData.SellerCharge).ToString("N2"), FastDriver.ProrationTax.NthSellerCharge(index).FAGetText(), "SellerCharge");
                Support.AreEqual(((Decimal)prorationData.SellerCredit).ToString("N2"), FastDriver.ProrationTax.NthSellerCredit(index).FAGetText(), "SellerCredit");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify update Proration - Misc information using UpdateProration web service")]
        public void Scenario_3_Update_Proration_Misc_Details()
        {
            try
            {
                Reports.TestDescription = "Verify update Proration - Misc information using UpdateProration web service";

                FAST_Init_File();

                #region Update Proration - Miscellaneous instance with UpdateProration()
                Reports.TestStep = "Update Proration - Miscellaneous instance with UpdateProration()";
                var index = 0;
                var request = EscrowRequestFactory.GetProrationRequest(File.FileID, index + 1, ProrationType.MISCELLANEOUS);
                //request.ProrDetailsForCD.Description = null;
                var response = EscrowService.UpdateProration(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Verify updated Proration instance in FAST
                Reports.TestStep = "Verify updated Proration instance in FAST";
                FastDriver.ProrationMisc.Open();
                var prorationData = request.ProrDetailsForCD as ProrationDetailsForCD;
                Support.AreEqual((prorationData.CreditSeller ?? false) ? "Yes" : "No", FastDriver.ProrationMisc.NthCreditSeller(index).FAGetText(), "CreditSeller");
                Support.AreEqual((prorationData.DayOfClosePaidbySeller ?? false) ? "Yes" : "No", FastDriver.ProrationMisc.NthDayofClosePaidbySeller(index).FAGetText(), "DayofClosePaidbySeller");
                Support.AreEqual(((Decimal)prorationData.Amount).ToString("C2"), FastDriver.ProrationMisc.NthAmount(index).FAGetText(), "Amount");
                Support.AreEqual(((DateTime)prorationData.FromDate).ToDateString(), FastDriver.ProrationMisc.NthFrom(index).FAGetText(), "FromDate");
                Support.AreEqual((prorationData.FromDateInclusive ?? false) ? "Yes" : "No", FastDriver.ProrationMisc.NthFromInclusive(index).FAGetText(), "FromInclusive");
                Support.AreEqual((prorationData.FromDateIsProrateDate ?? false) ? "Yes" : "No", FastDriver.ProrationMisc.NthFromProrateDate(index).FAGetText(), "FromProrateDate");
                Support.AreEqual(prorationData.AmountPeriod.ToString().ToLowerInvariant(), FastDriver.ProrationMisc.NthPeriod(index).FAGetText().ToLowerInvariant(), "Period");
                Support.AreEqual(((DateTime)prorationData.ToDate).ToDateString(), FastDriver.ProrationMisc.NthTo(index).FAGetText(), "ToDate");
                Support.AreEqual((prorationData.ToDateInclusive ?? false) ? "Yes" : "No", FastDriver.ProrationMisc.NthToInclusive(index).FAGetText(), "ToInclusive");
                Support.AreEqual((prorationData.ToDateIsProrateDate ?? false) ? "Yes" : "No", FastDriver.ProrationMisc.NthToProrateDate(index).FAGetText(), "ToProrateDate");
                if (prorationData.Description != null)
                    Support.AreEqual(prorationData.Description, FastDriver.ProrationMisc.NthDescription(index).FAGetText(), "Description");
                Support.AreEqual(((Decimal)prorationData.BuyerCharge).ToString("N2"), FastDriver.ProrationMisc.NthBuyerCharge(index).FAGetText(), "BuyerCharge");
                Support.AreEqual(((Decimal)prorationData.BuyerCredit).ToString("N2"), FastDriver.ProrationMisc.NthBuyerCredit(index).FAGetText(), "BuyerCredit");
                Support.AreEqual(((Decimal)prorationData.SellerCharge).ToString("N2"), FastDriver.ProrationMisc.NthSellerCharge(index).FAGetText(), "SellerCharge");
                Support.AreEqual(((Decimal)prorationData.SellerCredit).ToString("N2"), FastDriver.ProrationMisc.NthSellerCredit(index).FAGetText(), "SellerCredit");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
