﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastEscrowService;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Web_Services_Regression.File_Management.FMUC0008_FeeEntry
{
    [CodedUITest]
    public class US393466_Update_Fee_Entry_PDD : FASTHelpers
    {
        #region payment details
        protected PDD paymentDetails = new PDD()
        {
            ChargeDescription = "",
            AdditionalDescription = "",
            UseDefaultChecked = false,
            PayeeName = "",
            PayTo = "",
            LEDescription = "",
            LoanEstimateUnrounded = (double)15099.99,
            LoanEstimateRounded = (double)15100.00,
            isPrimaryPolicy = false,
            PartOfCheckbox = true,
            SectionCDidShopFor = true,
            BuyerCharge = (double)30000,
            BuyerAtClosing = (double)15000,
            BuyerChargePaymentMethod = "Fee",
            BuyerBeforeClosing = (double)5000,
            BuyerPaidbyOther = (double)10000,
            BuyerPaidbyOtherPaymentMethod = "Lender",
            BuyerCreditPaymentMethod = "Lender",
            //  BuyerLenderCheckbox is out of this scope
            BuyerLenderCheckbox = true,
            BuyerDoubleAsteriskChecked = false,
            SellerCharge = (double)24000,
            SellerPaidAtClosing = (double)12000,
            SellerChargePaymentMethod = "Fee",
            SellerPaidBeforeClosing = (double)6000,
            SellerPaidbyOthers = (double)6000,
            SellerPaidbyOtherPaymentMthd = "Lender",
            SellerCreditPaymentMethod = "Lender",
            TotalCharge = (double)54000.00,
            SellerLenderCheckbox = true,
        };
        #endregion

        #region CdFileFee
        protected CdFileFee CDFileFee = new CdFileFee()
        {
            FeePaymentDetails = new FASTWCFHelpers.FastFileService.CdFeePaymentDetails()
            {
                BuyerDetails = new FASTWCFHelpers.FastFileService.CdChargeDetails()
                {
                    ChargeAmount = (decimal)30000.00,
                    DisplayLOnCD = true,
                    PaidByAtClosing = (decimal)15000.00,
                    PaidByBeforeClosing = (decimal)5000.00,
                    PaidByOthers = (decimal)10000.00,
                    PaidByOthersPMTypeCdID = FASTWCFHelpers.FastFileService.OtherPaymentMethods.Lender,
                    ePaymentMethod = FASTWCFHelpers.FastFileService.PaymentMethodType.FEE,
                },
                LoanEstimateUnrounded = (decimal)15099.99,
                SellerDetails = new FASTWCFHelpers.FastFileService.CdChargeDetails()
                {
                    ChargeAmount = (decimal)24000.00,
                    DisplayLOnCD = true,
                    PaidByAtClosing = (decimal)12000.00,
                    PaidByBeforeClosing = (decimal)6000.00,
                    PaidByOthers = (decimal)6000.00,
                    PaidByOthersPMTypeCdID = FASTWCFHelpers.FastFileService.OtherPaymentMethods.Lender,
                    ePaymentMethod = FASTWCFHelpers.FastFileService.PaymentMethodType.FEE,
                },
                PartOf = true,
                SectionShopDetails = new FASTWCFHelpers.FastFileService.FeeSectionShop()
                {
                    SectionShopped = FASTWCFHelpers.FastFileService.SectionsShoppedFor.SectionCdidShopFor
                },
                ServiceFileFeeId = 0,
                FeeID = 0,
                FeeTypeCdID = 0,
                ePaymentMethodType = FASTWCFHelpers.FastFileService.PaymentMethodType.NONE,
            },
            IsSelected = true,
        };
        #endregion

        [TestMethod]
        [Description("Verify update File Fees - Title and Escrow fee payment information using UpdateFeeEntryDetails web service")]
        public void Scenario_1_Update_TitleAndEscrowFees_PDD()
        {
            try
            {
                Reports.TestDescription = "Verify update File Fees - Title and Escrow fee payment information using UpdateFeeEntryDetails web service";

                FAST_Init_File(GABRole: FASTWCFHelpers.FastFileService.AdditionalRoleType.NewLender);

                #region Navigate to File Fees and add a Fee for Lender Policy
                Reports.TestStep = "Navigate to File Fees and add a Fee for Lender Policy";
                FastDriver.FileFees.Open();
                FastDriver.FileFees.AddFees.Click();
                paymentDetails.ChargeDescription = "ALTA Ext Loan Policy*";
                FAST_FeeSearch(new PDD[] { paymentDetails });
                FastDriver.BottomFrame.Done();
                #endregion

                #region Update Fee details with UpdateFeeEntryDetails()
                Reports.TestStep = "Update Fee details with UpdateFeeEntryDetails()";
                FastDriver.FileFees.Open();
                //
                var details = FileService.GetFeeEntryDetails(File.FileID ?? 0);
                Support.AreEqual("1", details.Status.ToString(), details.StatusDescription);
                //          
                CDFileFee.FeePaymentDetails.ServiceFileFeeId = details.TitleAndEscrow.CdFileFees[0].FeePaymentDetails.ServiceFileFeeId;
                CDFileFee.FeePaymentDetails.FeeID = details.TitleAndEscrow.CdFileFees[0].FeePaymentDetails.FeeID;
                CDFileFee.FeePaymentDetails.FeeTypeCdID = details.TitleAndEscrow.CdFileFees[0].FeePaymentDetails.FeeTypeCdID;
                var request = RequestFactory.GetFeeEntryRequest(File.FileID);
                request.TitleAndEscrow.CdFileFees = new CdFileFee[]{
                    CDFileFee,
                };                
                request.RecordingAndTax = null;
                var update = FileService.UpdateFeeEntryDetails(request);
                Support.AreEqual("1", update.TitleEscrowFileFeesResponse.Status.ToString(), update.TitleEscrowFileFeesResponse.StatusDescription );
                #endregion

                #region Verify Fee details in FAST
                Reports.TestDescription = "Verify Fee details in FAST";
                FastDriver.FileFees.Open();
                FastDriver.FileFees.FeeDetails.Click();
                paymentDetails.ChargeDescription = details.TitleAndEscrow.CdFileFees[0].FeePaymentDetails.Description;
                paymentDetails.LEDescription = details.TitleAndEscrow.CdFileFees[0].FeePaymentDetails.LoanEstimateDescription;
                paymentDetails.PayTo = details.TitleAndEscrow.CdFileFees[0].FeePaymentDetails.PayTo;
                paymentDetails.PayeeName = string.IsNullOrEmpty(details.TitleAndEscrow.CdFileFees[0].FeePaymentDetails.PayeeNameOnCDOrSettlementStmt) ?
                    details.TitleAndEscrow.CdFileFees[0].FeePaymentDetails.PayTo : details.TitleAndEscrow.CdFileFees[0].FeePaymentDetails.PayeeNameOnCDOrSettlementStmt;
                FAST_VerifyPDD(paymentDetails);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify update File Fees - Recording and Tax fee payment information using UpdateFeeEntryDetails web service")]
        public void Scenario_2_Update_RecordingAndTaxFees_PDD()
        {
            try
            {
                Reports.TestDescription = "Verify update File Fees - Recording and Tax fee payment information using UpdateFeeEntryDetails web service";

                FAST_Init_File(GABRole: FASTWCFHelpers.FastFileService.AdditionalRoleType.NewLender);

                #region Navigate to File Fees and add a Fee
                Reports.TestStep = "Navigate to File Fees and add a Fee";
                FastDriver.FileFees.Open();
                FastDriver.FileFees.RecordingandTax.Click();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.RecordingTable);
                FastDriver.FileFees.AddFeesTax.Click();
                paymentDetails.ChargeDescription = "CD - E Transfer Tax – Mortgage";
                FAST_FeeSearch(new PDD[] { paymentDetails });
                FastDriver.BottomFrame.Done();
                #endregion

                #region Update Fee details with UpdateFeeEntryDetails()
                Reports.TestStep = "Update Fee details with UpdateFeeEntryDetails()";
                FastDriver.FileFees.Open();
                FastDriver.FileFees.RecordingandTax.Click();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.RecordingTable);
                //
                var details = FileService.GetFeeEntryDetails(File.FileID ?? 0);
                Support.AreEqual("1", details.Status.ToString(), details.StatusDescription);
                //                
                CDFileFee.FeePaymentDetails.ServiceFileFeeId = details.RecordingAndTax.CdFileFees[0].FeePaymentDetails.ServiceFileFeeId;
                CDFileFee.FeePaymentDetails.FeeID = details.RecordingAndTax.CdFileFees[0].FeePaymentDetails.FeeID;
                CDFileFee.FeePaymentDetails.FeeTypeCdID = details.RecordingAndTax.CdFileFees[0].FeePaymentDetails.FeeTypeCdID;
                var request = RequestFactory.GetFeeEntryRequest(File.FileID);
                request.RecordingAndTax.CdFileFees = new CdFileFee[]{
                    CDFileFee,
                };
                request.TitleAndEscrow = null;
                var update = FileService.UpdateFeeEntryDetails(request);
                Support.AreEqual("1", update.RecordingTaxFileFeesResponse.Status.ToString(), update.RecordingTaxFileFeesResponse.StatusDescription);
                #endregion

                #region Verify Fee details in FAST
                Reports.TestDescription = "Verify Fee details in FAST";
                FastDriver.FileFees.Open();
                FastDriver.FileFees.RecordingandTax.Click();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.RecordingTable);
                FastDriver.FileFees.RecordingTaxFeeDetails.Click();
                paymentDetails.LoanEstimateUnrounded = (double)0;
                paymentDetails.SectionCDidShopFor = false;
                paymentDetails.ChargeDescription = details.RecordingAndTax.CdFileFees[0].FeePaymentDetails.Description;
                paymentDetails.LEDescription = details.RecordingAndTax.CdFileFees[0].FeePaymentDetails.LoanEstimateDescription;
                paymentDetails.PayTo = details.RecordingAndTax.CdFileFees[0].FeePaymentDetails.PayTo;
                paymentDetails.PayeeName = details.RecordingAndTax.CdFileFees[0].FeePaymentDetails.PayeeNameOnCDOrSettlementStmt;
                FAST_VerifyPDD(paymentDetails);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
