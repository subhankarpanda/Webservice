﻿using FASTSelenium.Common;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;
using FASTSelenium.DataObjects.IIS;
using System.Collections.Generic;


namespace Web_Services_Regression.File_Management.FMUC0008_FeeEntry
{
    [CodedUITest]
    public class US441576_Retrieve_FileFees_Recap : FASTHelpers
    {
        #region File Fees Data
        private PDD GetCDFileFeePDD(string description)
        {
            return new PDD()
            {
                ChargeDescription = description,
                BuyerAtClosing = 15000,
                BuyerBeforeClosing = 5000,
                BuyerPaidbyOther = 10000,
                BuyerPaidbyOtherPaymentMethod = OtherPaymentMethods.POC.ToString(),
                SellerPaidAtClosing = 5000,
            };
        }
        #endregion

        [TestMethod]
        [Description("Verify retrieving File Fees Recap using GetFeeEntryDetails and GetServiceFeeDetails web service when File is CD")]
        public void Scenario_1_CD_Get_FileFeesRecap()
        {
            try
            {
                Reports.TestDescription = "Verify retrieving File Fees Recap using GetFeeEntryDetails and GetServiceFeeDetails web service when File is CD";

                FAST_Login_IIS();

                FAST_WCF_File_IIS(isTO: true, isEO: true, formType: FormType.CD);

                #region Add File Fees type both FACC and non-FACC
                Reports.TestStep = "Add File Fees type both FACC and non-FACC";
                FastDriver.FileFees.Open();
                FAST_AddFileFees(new PDD[] { 
                    GetCDFileFeePDD("ALTA Ext Loan Policy 1056.06"),
                    GetCDFileFeePDD("ALTA Ext Owner Policy 1402.06 (6-17-06)"),
                    GetCDFileFeePDD("Cancellation Fee-Escrow"),
                    GetCDFileFeePDD("Loss Recovery Fee"),
                    GetCDFileFeePDD("General Excise Tax"),
                });
                FastDriver.FileFees.lenderAdjAmnt.FASetText("1000.00");
                FASTHelpers.KeyboardSendKeys(FAKeys.TabAway);
                FAST_AddFileFeesFACC(
                    recFees: new string[,] { 
                    { "Amendment", "56", "30000" }, 
                    { "Deed", "890", "15000" }},
                    summary: new string[,] { 
                    { "AMENDMENT - Recording Fee",      "",     "174.00",   "FACC E Transfer Tax Deed",             "Buyer",    "Prepaid Credit", "1,500.00", "", "", "1,500.00", "0.00", "1,500.00" }, 
                    { "DEED - Recording Fee",           "",     "2,673.00", "FACC E Transfer Tax Deed3",            "Buyer",    "Prepaid Credit", "1,500.00", "", "", "1,500.00", "0.00", "1,500.00" },
                    { "DEED - Documentary Transfer Tax","",     "16.50",   "FACC E Transfer Tax – Mortgage1",      "Seller",   "Prepaid Credit", "1,500.00", "", "", "0.00","1,500.00",  "1,500.00"},
                });
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);
                #endregion

                #region Verify File Fees Recap against GetFeeEntryDetails & GetServiceFeeDetails web service response
                Reports.TestStep = "Get fees details with GetFeeEntryDetails() & GetServiceFeeDetails()";
                FastDriver.FileFees.Open();
                var details = new Dictionary<string,FileFeeRecap>(){
                    {"GetFeeEntryDetails", FileService.GetFeeEntryDetails(File.FileID ?? 0).FileFeeRecap},
                    {"GetServiceFeeDetails", FileService.GetServiceFeeDetails(File.FileID ?? 0).FileFeeRecap}
                };
                Reports.TestStep = "Verify File Fees Recap against GetFeeEntryDetails & GetServiceFeeDetails web service response";
                foreach (var i in details)
                {
                    Reports.TestStep = i.Key;
                    var fileFeeRecap = i.Value;
                    Support.AreEqual(fileFeeRecap.Fees.Title.ToString("C2"), FastDriver.FileFees.TotalTitleFees.FAGetText(), "Title Fees");
                    Support.AreEqual(fileFeeRecap.Fees.Escrow.ToString("C2"), FastDriver.FileFees.TotalEscrowFees.FAGetText(), "Escrow Fees");
                    Support.AreEqual(fileFeeRecap.Fees.Other.ToString("C2"), FastDriver.FileFees.TotalOtherFees.FAGetText(), "Other Fees");
                    Support.AreEqual(fileFeeRecap.Fees.TransferTax.ToString("C2"), FastDriver.FileFees.TotalTransferTaxFees.FAGetText(), "Transfer Tax Fees");
                    Support.AreEqual(fileFeeRecap.Fees.TotalFees.ToString("C2"), FastDriver.FileFees.TotalFees.FAGetText(), "Total Fees");
                    Support.AreEqual(fileFeeRecap.DisbursementsAndPOC.PaidBeforeClosingAndPOC.ToString("C2"), FastDriver.FileFees.PocAmt.FAGetText(), "Paid Before Closing And POC Fees");
                }
                #endregion
            }
            catch(Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
