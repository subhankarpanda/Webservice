﻿using FASTSelenium.Common;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers.FastEscrowService;


namespace Web_Services_Regression.File_Management.FMUC0008_FeeEntry
{
    [CodedUITest]
    public class USxxxxxx_Update_Fees : FASTHelpers
    {
        #region File Fees Data
        private PDD GetCDFileFeePDD(string description)
        {
            return new PDD()
            {
                ChargeDescription = description,
            };
        }

        private PDD GetUpdatedCDFileFeePDD(string description)
        {
            return new PDD()
            {
                ChargeDescription = description,
                LoanEstimateUnrounded = 14999.99,
                PartOfCheckbox = false,
                UseDefaultChecked = true,
                BuyerCharge = 10000,
                BuyerAtClosing = 5000,
                BuyerChargePaymentMethod = FASTWCFHelpers.FastFileService.AtClosingPaymentMethods.FEE.ToString(),
                BuyerBeforeClosing = 3000,
                BuyerPaidbyOther = 2000,
                BuyerPaidbyOtherPaymentMethod = FASTWCFHelpers.FastFileService.OtherPaymentMethods.POC.ToString(),
                BuyerLenderCheckbox = false,
                BuyerDoubleAsteriskChecked = false,
                SectionHOtherCosts = true,
                SellerCharge = 5000,
                SellerPaidAtClosing = 3000,
                SellerChargePaymentMethod = FASTWCFHelpers.FastFileService.AtClosingPaymentMethods.FEE.ToString(),
                SellerPaidBeforeClosing = 1000,
                SellerPaidbyOthers = 1000,
                SellerPaidbyOtherPaymentMthd = FASTWCFHelpers.FastFileService.OtherPaymentMethods.POC.ToString(),
            };
        }

        private CdFileFee GetCDFileFee(CdFileFee receivedFileFee)
        {
            return new CdFileFee() {
                FeePaymentDetails = new FASTWCFHelpers.FastFileService.CdFeePaymentDetails()
                {
                    BuyerDetails = new FASTWCFHelpers.FastFileService.CdChargeDetails(){
                        ChargeAmount = 10000,
                        DisplayLOnCD = false,
                        PaidByAtClosing = 5000,
                        PaidByBeforeClosing = 3000,
                        PaidByOthers = 2000,
                        PaidByOthersPMTypeCdID = FASTWCFHelpers.FastFileService.OtherPaymentMethods.POC,
                        ePaymentMethod = FASTWCFHelpers.FastFileService.PaymentMethodType.FEE,
                    },
                    DoubleAsteriskIndicator = false,
                    FACCFeeFlag = receivedFileFee.FeePaymentDetails.FACCFeeFlag,
                    FACCServiceFileFeeID = receivedFileFee.FeePaymentDetails.FACCServiceFileFeeID,
                    FeeID = receivedFileFee.FeePaymentDetails.FeeID,
                    FeeTypeCdID = receivedFileFee.FeePaymentDetails.FeeTypeCdID,
                    LoanEstimateUnrounded = (decimal)14999.99,
                    PrimaryPolicy = receivedFileFee.FeePaymentDetails.PrimaryPolicy,
                    SectionShopDetails = new FASTWCFHelpers.FastFileService.FeeSectionShop(){ 
                        SectionShopped = FASTWCFHelpers.FastFileService.SectionsShoppedFor.SectionHotherCosts 
                    },
                    SellerDetails = new FASTWCFHelpers.FastFileService.CdChargeDetails() {
                        ChargeAmount = 5000,
                        DisplayLOnCD = false,
                        PaidByAtClosing = 3000,
                        PaidByBeforeClosing = 1000,
                        PaidByOthers = 1000,
                        PaidByOthersPMTypeCdID = FASTWCFHelpers.FastFileService.OtherPaymentMethods.POC,
                        ePaymentMethod = FASTWCFHelpers.FastFileService.PaymentMethodType.FEE,
                    },
                    ServiceFileFeeId = receivedFileFee.FeePaymentDetails.ServiceFileFeeId,
                },
                IsSelected = true,
            };
        }

        private CdFileFee GetCDFACCFileFee(CdFileFee receivedFileFee)
        {
            return new CdFileFee()
            {
                FeePaymentDetails = new FASTWCFHelpers.FastFileService.CdFeePaymentDetails()
                {
                    BuyerDetails = new FASTWCFHelpers.FastFileService.CdChargeDetails(){
                        ChargeAmount = receivedFileFee.FeePaymentDetails.BuyerDetails.ChargeAmount ?? 0,
                        DisplayLOnCD = receivedFileFee.FeePaymentDetails.BuyerDetails.DisplayLOnCD ?? false,
                        PaidByAtClosing = receivedFileFee.FeePaymentDetails.BuyerDetails.PaidByAtClosing ?? 0,
                        PaidByBeforeClosing = receivedFileFee.FeePaymentDetails.BuyerDetails.PaidByBeforeClosing ?? 0,
                        PaidByOthers = receivedFileFee.FeePaymentDetails.BuyerDetails.PaidByOthers ?? 0,
                        PaidByOthersPMTypeCdID = receivedFileFee.FeePaymentDetails.BuyerDetails.PaidByOthersPMTypeCdID,
                        ePaymentMethod = receivedFileFee.FeePaymentDetails.BuyerDetails.ePaymentMethod,
                    },
                    FACCFeeFlag = receivedFileFee.FeePaymentDetails.FACCFeeFlag,
                    FACCServiceFileFeeID = receivedFileFee.FeePaymentDetails.FACCServiceFileFeeID,
                    FeeID = receivedFileFee.FeePaymentDetails.FeeID,
                    FeeTypeCdID = receivedFileFee.FeePaymentDetails.FeeTypeCdID,
                    LoanEstimateUnrounded = receivedFileFee.FeePaymentDetails.LoanEstimateUnrounded,
                    PrimaryPolicy = receivedFileFee.FeePaymentDetails.PrimaryPolicy,
                    SectionShopDetails = receivedFileFee.FeePaymentDetails.SectionShopDetails,
                    SellerDetails = new FASTWCFHelpers.FastFileService.CdChargeDetails(){
                        ChargeAmount = receivedFileFee.FeePaymentDetails.SellerDetails.ChargeAmount ?? 0,
                        DisplayLOnCD = receivedFileFee.FeePaymentDetails.SellerDetails.DisplayLOnCD ?? false,
                        PaidByAtClosing = receivedFileFee.FeePaymentDetails.SellerDetails.PaidByAtClosing ?? 0,
                        PaidByBeforeClosing = receivedFileFee.FeePaymentDetails.SellerDetails.PaidByBeforeClosing ?? 0,
                        PaidByOthers = receivedFileFee.FeePaymentDetails.SellerDetails.PaidByOthers ?? 0,
                        PaidByOthersPMTypeCdID = receivedFileFee.FeePaymentDetails.SellerDetails.PaidByOthersPMTypeCdID,
                        ePaymentMethod = receivedFileFee.FeePaymentDetails.SellerDetails.ePaymentMethod,
                    },
                    ServiceFileFeeId = receivedFileFee.FeePaymentDetails.ServiceFileFeeId,
                },
                IsSelected = true,
            };
        }

        private FASTWCFHelpers.FastFileService.Product[] GetProducts()
        {
            return new FASTWCFHelpers.FastFileService.Product[] {
                new FASTWCFHelpers.FastFileService.Product() {
                    ObjectCD = "EAGLELENDR",
                    ProductID = 886,
                },
                new FASTWCFHelpers.FastFileService.Product() {
                    ObjectCD = "ALTAEXOW06",
                    ProductID = 1318,
                },
            };
        }
        #endregion

        [TestMethod]
        [Description("Verify updating Files Fees (not subject to calculation) using UpdateFeeEntryDetails web service")]
        public void Scenario_1_CD_Update_Fee_NotSubjectToCalculation()
        {
            try
            {
                Reports.TestDescription = "Verify updating Files Fees (not subject to calculation) using UpdateFeeEntryDetails web service";

                FAST_Login_IIS();

                FAST_WCF_File_IIS(isTO: true, isEO: true, formType: FASTWCFHelpers.FastFileService.FormType.CD);

                #region Add File Fees type Title Lender Policy and Title Owner Policy
                Reports.TestStep = "Add File Fees type Title Lender Policy and Title Owner Policy";
                FastDriver.FileFees.Open();
                FAST_AddFileFees(new PDD[] { 
                    GetCDFileFeePDD("ALTA Ext Loan Policy 1056.06"),
                    GetCDFileFeePDD("ALTA Ext Owner Policy 1402.06 (6-17-06)"),
                });
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);
                #endregion

                #region Get fees details with GetFeeEntryDetails()
                Reports.TestStep = "Get fees details with GetFeeEntryDetails()";
                var details = FileService.GetFeeEntryDetails(File.FileID ?? 0);
                Support.AreEqual("1", details.Status.ToString(), details.StatusDescription);
                #endregion

                #region Update fees details with UpdateFeeEntryDetails()
                Reports.TestStep = "Update fees details with UpdateFeeEntryDetails()";
                var request = RequestFactory.GetFeeEntryRequest(File.FileID);
                request.TitleAndEscrow.CdFileFees = new CdFileFee[]{
                    GetCDFileFee(details.TitleAndEscrow.CdFileFees[0]),
                    GetCDFileFee(details.TitleAndEscrow.CdFileFees[1])
                };
                var response = FileService.UpdateFeeEntryDetails(request);
                Support.AreEqual("1", response.TitleEscrowFileFeesResponse.Status.ToString(), response.TitleEscrowFileFeesResponse.StatusDescription);
                #endregion

                #region Verify fees are updated in FAST
                Reports.TestStep = "Verify fees are updated in FAST";
                FastDriver.FileFees.Open();
                FastDriver.FileFees.FeeDetails.FAClick();
                FAST_VerifyPDD(GetUpdatedCDFileFeePDD("ALTA Ext Loan Policy 1056.06"));
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.FeeDetails1.FAClick();
                FAST_VerifyPDD(GetUpdatedCDFileFeePDD("ALTA Ext Owner Policy 1402.06 (6-17-06)"));
                #endregion
            }
            catch(Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify updating Files Fees - Title Policy Calculations using UpdateFeeEntryDetails web service")]
        public void Scenario_2_CD_Update_TitlePolicyCalculations()
        {
            try
            {
                Reports.TestDescription = "Verify updating Files Fees - Title Policy Calculations using UpdateFeeEntryDetails web service";

                FAST_Login_IIS();

                FAST_WCF_File_IIS(isTO: true, isEO: true, formType: FASTWCFHelpers.FastFileService.FormType.CD);
                
                #region Update Files Fees - Title Policy Calculations with UpdateFeeEntryDetails()
                Reports.TestStep = "Update Files Fees - Title Policy Calculations with UpdateFeeEntryDetails()";
                var request = RequestFactory.GetFeeEntryRequest(File.FileID);
                request.TitleAndEscrow.TitlePolicyCalculationsForCD.FullLoanPremium.LoanEstimateUnrounded = 14000;
                request.TitleAndEscrow.TitlePolicyCalculationsForCD.DisclosedOwnerPremium.LoanEstimateUnrounded = 14000;
                var response = FileService.UpdateFeeEntryDetails(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Verify Files Fees - Title Policy Calculations are updated in FAST
                Reports.TestStep = "Verify Files Fees - Title Policy Calculations are updated in FAST";
                FastDriver.FileFees.Open();
                Support.AreEqual(((Decimal)0).ToString("C2"), FastDriver.FileFees.lenderAdjAmnt.FAGetValue(), "Full Loan Premium (Lender Adjusted)");
                Support.AreEqual(request.TitleAndEscrow.TitlePolicyCalculationsForCD.FullLoanPremium.LoanEstimateUnrounded.ToString("C2"), FastDriver.FileFees.LenderLoanEstimateAmount.FAGetValue(), "Full Loan Premium (LE-Unrounded)");
                Support.AreEqual(request.TitleAndEscrow.TitlePolicyCalculationsForCD.DisclosedOwnerPremium.LoanEstimateUnrounded.ToString("C2"), FastDriver.FileFees.OwnerLoanEstimateAmount.FAGetValue(), "Disclosed Owner Premium (LE-Unrounded)");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify updating Files Fees - Gov Rec and Transfer Tax Calculations using UpdateFeeEntryDetails web service")]
        public void Scenario_3_CD_Update_GovRecAndTransferTaxCalculations()
        {
            try
            {
                Reports.TestDescription = "Verify updating Files Fees - Gov Rec and Transfer Tax Calculations using UpdateFeeEntryDetails web service";

                FAST_Login_IIS();

                FAST_WCF_File_IIS(isTO: true, isEO: true, formType: FASTWCFHelpers.FastFileService.FormType.CD);

                #region Update Files Fees - Gov Rec and Transfer Tax Calculations with UpdateFeeEntryDetails()
                Reports.TestStep = "Update Files Fees - Gov Rec and Transfer Tax Calculations with UpdateFeeEntryDetails()";
                var request = RequestFactory.GetFeeEntryRequest(File.FileID);
                request.RecordingAndTax.GovernmentRecordingAndTransferTaxes.GovernmentCdRecordingCharges.LoanEstimateUnRounded = (decimal)13999.99;
                request.RecordingAndTax.GovernmentRecordingAndTransferTaxes.GovernmentCdRecordingCharges.LoanEstimateRounded = 14000;
                request.RecordingAndTax.GovernmentRecordingAndTransferTaxes.CdTransferTax.LoanEstimateUnRounded = (decimal)13999.99;
                request.RecordingAndTax.GovernmentRecordingAndTransferTaxes.CdTransferTax.LoanEstimateRounded = 14000;
                var response = FileService.UpdateFeeEntryDetails(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Verify Files Fees - Gov Rec and Transfer Tax Calculations are updated in FAST
                Reports.TestStep = "Verify Files Fees - Gov Rec and Transfer Tax Calculations are updated in FAST";
                FastDriver.FileFees.Open();
                FastDriver.FileFees.RecordingandTax.Click();
                FastDriver.FileFees.WaitForFeeScreen(FastDriver.FileFees.RecordingTable);
                Support.AreEqual(request.RecordingAndTax.GovernmentRecordingAndTransferTaxes.GovernmentCdRecordingCharges.LoanEstimateUnRounded.ToString("C2"), FastDriver.FileFees.RecordingLoanEstUnrounded.FAGetValue(), "Recording Fees and Future Recording Fees (LE-Unrounded)");
                Support.AreEqual(request.RecordingAndTax.GovernmentRecordingAndTransferTaxes.CdTransferTax.LoanEstimateUnRounded.ToString("C2"), FastDriver.FileFees.TranTaxLoanEstUnrounded.FAGetValue(), "Transfer Taxes (LE-Unrounded)");
                Support.AreEqual(request.RecordingAndTax.GovernmentRecordingAndTransferTaxes.GovernmentCdRecordingCharges.LoanEstimateRounded.ToString("C2"), FastDriver.FileFees.RecordingLoanEstRounded.FAGetValue(), "Recording Fees and Future Recording Fees (LE-Rounded)");
                Support.AreEqual(request.RecordingAndTax.GovernmentRecordingAndTransferTaxes.CdTransferTax.LoanEstimateRounded.ToString("C2"), FastDriver.FileFees.TranTaxLoanEstRounded.FAGetValue(), "Transfer Taxes (LE-Rounded)");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify updating Files Fees - Title Premium Adjustment using UpdateFeeEntryDetails web service")]
        public void Scenario_4_CD_Update_Fee_TitlePremiumAdjustment()
        {
            try
            {
                Reports.TestDescription = "Verify updating Files Fees - Title Premium Adjustment using UpdateFeeEntryDetails web service";

                FAST_Login_IIS();

                FAST_WCF_File_IIS(isTO: true, isEO: true, formType: FASTWCFHelpers.FastFileService.FormType.CD);

                #region Add File Fees type Title Lender Policy and Title Owner Policy
                Reports.TestStep = "Add File Fees type Title Lender Policy and Title Owner Policy";
                FastDriver.FileFees.Open();
                FAST_AddFileFees(new PDD[] { 
                    GetUpdatedCDFileFeePDD("ALTA Ext Loan Policy 1056.06 (6-17-06)(LP-10 Cons)"),
                    GetUpdatedCDFileFeePDD("ALTA Owner w/Reg.Exc 10-17-92 1402.92"),
                });
                FastDriver.FileFees.lenderAdjAmnt.FASetText("1000.00");
                FASTHelpers.KeyboardSendKeys(FAKeys.TabAway);
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);
                #endregion
                                
                #region Update fees details with UpdateFeeEntryDetails()
                Reports.TestStep = "Update fees details with UpdateFeeEntryDetails()";
                var details = FileService.GetFeeEntryDetails(File.FileID ?? 0);
                Support.AreEqual("1", details.Status.ToString(), details.StatusDescription);
                var request = RequestFactory.GetFeeEntryRequest(File.FileID);
                var primaryPolicy = GetCDFileFee(details.TitleAndEscrow.CdFileFees[0]);
                //  ...
                request.TitleAndEscrow.CdFileFees = new CdFileFee[] { primaryPolicy };
                request.TitleAndEscrow.TitlePolicyCalculationsForCD.FullLoanPremium.AdjustedOrPremiumAmount = 2500;
                request.TitleAndEscrow.TitlePolicyCalculationsForCD.TitlePremiumAdjustmentAmount = 10000;
                var response = FileService.UpdateFeeEntryDetails(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Verify fees are updated in FAST
                Reports.TestStep = "Verify fees are updated in FAST";
                FastDriver.FileFees.Open();
                Support.AreEqual(request.TitleAndEscrow.TitlePolicyCalculationsForCD.FullLoanPremium.AdjustedOrPremiumAmount.ToString("C2"), FastDriver.FileFees.lenderAdjAmnt.FAGetValue(), "Full Loan Premium (Lender Adjusted)");
                Support.AreEqual(request.TitleAndEscrow.TitlePolicyCalculationsForCD.TitlePremiumAdjustmentAmount.ToString("C2"), FastDriver.FileFees.SPA.FAGetValue(), "Title Premium Adjustment");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify restriction to update Adjusted Premium Amount from FACC")]
        public void Scenario_5_CD_Update_AjustedPremiumamount_Restricted()
        {
            try
            {
                Reports.TestDescription = "Verify restriction to update Adjusted Premium Amount from FACC";

                FAST_Login_IIS();

                FAST_WCF_File_IIS(isTO: true, isEO: true, formType: FASTWCFHelpers.FastFileService.FormType.CD, LenderID: "BOA", loanAmt: (decimal)2500000, SPAmt:(decimal)2500000, products: GetProducts());
                
                var faccSummary = new FACCSummary[]
                {
                    new FACCSummary() { ChargeTo = "BUYER", FASTFeeDescription = "1064_Title_Lender_Policy", OverrideAmount = (decimal)50000, OverrideReason = "Centralized Loan Rate" },
                    new FACCSummary() { ChargeTo = "BUYER", FASTFeeDescription = "CLTA Standard Coverage 1084 1990", OverrideAmount = (decimal)50000, OverrideReason = "Centralized Loan Rate" },
                    new FACCSummary() { ChargeTo = "SELLER", FASTFeeDescription = "Endorsement L", OverrideAmount = (decimal)50000, OverrideReason = "Permitted Rate Surcharge" },
                    new FACCSummary() { ChargeTo = "BUYER", FASTFeeDescription = "Endorsement O", OverrideAmount = (decimal)50000, OverrideReason = "Permitted Rate Surcharge" },
                    new FACCSummary() { ChargeTo = "BUYER", FASTFeeDescription = "FACC E Recording Fee - Release", OverrideAmount = (decimal)50000, OverrideReason = "Permitted Rate Surcharge" }
                };

                #region Add Second Lew Loan
                Reports.TestStep = "Add Second Lew Loan";
                FastDriver.NewLoan.Open();
                FastDriver.BottomFrame.New();
                FastDriver.NewLoan.WaitForLoanDetailsTabToLoad();
                FastDriver.NewLoan.LoanDetailsLoanAmount.FASetText("2500000.00");
                FastDriver.NewLoan.FindGABCode("488");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Add File Fees for Lender & Owner Policy from FACC
                Reports.TestStep = "Add File Fees for Lender Owner Policy from FACC";
                FastDriver.FileFees.Open();
                FastDriver.FileFees.AllFees.FAClick();
                FastDriver.FileFees.CalculateFees.FAClick();
                // Add Lender Policy
                FastDriver.CalculateFees.WaitForScreenToLoad(FastDriver.CalculateFees.TransactionInfoTable);
                FastDriver.CalculateFees.TitleFeesTitlePolicy.FASelectItem("ALTA Expanded (Eagle Loan) Policy");
                FastDriver.CalculateFees.TitleFeesAdd.FAClick();
                FastDriver.CalculateFees.WaitCreation(FastDriver.CalculateFees.AddEndorsementsButton_Product1);
                FastDriver.CalculateFees.AddEndorsementsButton_Product1.FAClick();
                //
                FastDriver.FACCEndorsementsDlg.WaitForScreenToLoad();
                FastDriver.FACCEndorsementsDlg.WaitCreation(FastDriver.FACCEndorsementsDlg.SelectEndorsement);
                FastDriver.FACCEndorsementsDlg.GetSelectEndorsement(0).FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();
                //  Add Owner Policy
                FastDriver.CalculateFees.WaitForScreenToLoad(FastDriver.CalculateFees.TransactionInfoTable);
                FastDriver.CalculateFees.TitleFeesTitlePolicy.FASelectItem("ALTA Extended Owner Policy");
                FastDriver.CalculateFees.TitleFeesAdd.FAClick();
                FastDriver.CalculateFees.WaitCreation(FastDriver.CalculateFees.AddEndorsementsButton_Product2);
                FastDriver.CalculateFees.AddEndorsementsButton_Product2.FAClick();
                //
                FastDriver.FACCEndorsementsDlg.WaitForScreenToLoad();
                FastDriver.FACCEndorsementsDlg.WaitCreation(FastDriver.FACCEndorsementsDlg.SelectEndorsement);
                FastDriver.FACCEndorsementsDlg.GetSelectEndorsement(10).FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();
                // Add Recording Document
                FastDriver.WebDriver.SwitchToWindow(Support.FASTWindowName);
                FastDriver.CalculateFees.waitForScreenToLoad();
                FastDriver.CalculateFees.RecordingFeesRecordingDocument.FASelectItem("Mortgage");
                FastDriver.CalculateFees.RecordingFeesPages.FASetText("1");
                FastDriver.CalculateFees.RecordingFeesAdd.FAClick();
                //
                FastDriver.CalculateFees.Next.FAClick();
                if (FastDriver.WebDriver.WaitForAlertToExist(5))
                    FastDriver.WebDriver.HandleDialogMessage(true, true);
                FastDriver.CalculateFees.WaitForScreenToLoad(FastDriver.CalculateFees.RecordingDocumentsTable);
                FastDriver.CalculateFees.Next.FAClick();
                //
                FastDriver.CalculateFees.WaitForScreenToLoad(FastDriver.CalculateFees.SummaryTable);
                for (int i = 0; i < faccSummary.Length; i++)
                    FastDriver.CalculateFees.EditSummaryFee(index: i, description: faccSummary[i].FASTFeeDescription, chargeTo: faccSummary[i].ChargeTo.ToUpperFirst(), overrideReason: faccSummary[i].OverrideReason, overrideAmount: faccSummary[i].OverrideAmount.ToString("N2"));
                FastDriver.BottomFrame.Done();
                //
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.lenderAdjAmnt.FASetText("1000.00");
                FASTHelpers.KeyboardSendKeys(FAKeys.TabAway);
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);
                #endregion
                
                #region Verify updating fees details with UpdateFeeEntryDetails() is restricted
                Reports.TestStep = "Verify updating fees details with UpdateFeeEntryDetails() is restricted";
                var details = FileService.GetFeeEntryDetails(File.FileID ?? 0);
                Support.AreEqual("1", details.Status.ToString(), details.StatusDescription);
                var request = RequestFactory.GetFeeEntryRequest(File.FileID);
                var nonPrimaryPolicy = GetCDFACCFileFee(details.TitleAndEscrow.CdFileFees[0]);
                var primaryPolicy = GetCDFACCFileFee(details.TitleAndEscrow.CdFileFees[2]);
                //  ...
                request.TitleAndEscrow.CdFileFees = new CdFileFee[] { nonPrimaryPolicy };
                request.TitleAndEscrow.TitlePolicyCalculationsForCD.FullLoanPremium.AdjustedOrPremiumAmount = 2500;
                request.TitleAndEscrow.TitlePolicyCalculationsForCD.TitlePremiumAdjustmentAmount = 10000;
                var response = FileService.UpdateFeeEntryDetails(request);
                Support.AreEqual("Adjusted amount can be provided only for a primary lender policy", response.TitleEscrowFileFeesResponse.StatusDescription, "StatusDescription");
                //
                request.TitleAndEscrow.CdFileFees = new CdFileFee[] { primaryPolicy };
                var response2 = FileService.UpdateFeeEntryDetails(request);
                Support.AreEqual("Adjusted/Premium Amount cannot be edited for FACC fees", response2.TitleEscrowFileFeesResponse.StatusDescription, "StatusDescription");
                #endregion

                #region Verify Adjusted Premium Amount does not change in FAST
                Reports.TestStep = "Verify Adjusted Premium Amount does not change in FAST";
                FastDriver.FileFees.Open();
                Support.AreEqual(request.TitleAndEscrow.TitlePolicyCalculationsForCD.FullLoanPremium.AdjustedOrPremiumAmount.ToString("C2"), FastDriver.FileFees.lenderAdjAmnt.FAGetValue(), "Full Loan Premium (Lender Adjusted)");
                Support.AreEqual(((Decimal)0).ToString("C2"), FastDriver.FileFees.SPA.FAGetValue(), "Title Premium Adjustment");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
