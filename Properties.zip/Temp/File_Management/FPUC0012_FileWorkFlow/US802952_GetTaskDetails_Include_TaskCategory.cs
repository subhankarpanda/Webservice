﻿using FASTSelenium.Common;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using OpenQA.Selenium;
using FASTWCFHelpers.FastFileService;
using OpenQA.Selenium.Support.UI;
using FASTSelenium.PageObjects;
using System.Diagnostics;
using Microsoft.Win32;
using FASTSelenium.DataObjects.IIS;
using FASTSelenium.DataObjects.ADM;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using System.Linq;
using System.Collections.Generic;
using OpenQA.Selenium.Interactions;
using System.Windows.Input;

namespace Web_Services_Regression.File_Management.FPUC0012_FileWorkFlow
{
    [CodedUITest]
    public class US802952_GetTaskDetails_Include_TaskCategory : MasterTestClass
    {
        #region Test Case 818126

        [TestMethod]
        public void US802952_TC818126()
        {
            try
            {
                Reports.TestDescription = "To verify US 802952 - GetTaskDetails() to include the Task CategoryID and CategoryName properties";

                Reports.TestStep = "Create a basic File";
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                int? FileID = FileService.CreateFile(fileRequest).FileID;

                Reports.StatusUpdate("The FileID used for this test is: " + FileID, true);
                Reports.TestStep = "Open GetWorkflowDetails() method, type the FileID and Click on Send and Get a TaskID from the response";
                var WorkFlowResponse = FileService.GetWorkflowDetails((int)FileID);
                var taskID = WorkFlowResponse.Tasks[0].TaskID;
                var TaskCategoryID = WorkFlowResponse.Tasks[0].CategoryId;
                var TaskCategoryName = WorkFlowResponse.Tasks[0].CategoryName;

                Reports.TestStep = "Open GetTaskDetails() method, type the FileID, TaskID and Click on Send";
                var taskDetails = new FASTWCFHelpers.FastFileService.GetTaskDetailsRequest();
                taskDetails.FileID = FileID;
                taskDetails.TaskID = taskID;

                Reports.TestStep = "Response should have CategoryID and CategoryName fields";
                var TaskDetailsResponse = FileService.GetTaskDetails(taskDetails);

                Support.AreEqual(TaskCategoryID.ToString(), TaskDetailsResponse.Task.CategoryId.ToString(), "Category ID verification");
                Support.AreEqual(TaskCategoryName, TaskDetailsResponse.Task.CategoryName, "Category Name verification");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #endregion

        #region Test Case 856011

        [TestMethod]
        public void US802952_TC856011()
        {
            try
            {
                Reports.TestDescription = "To verify US 802952 - GetWorkflowDetails() to include the Task CategoryID and CategoryName properties";

                Reports.TestStep = "Create a basic File";
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                int? FileID = FileService.CreateFile(fileRequest).FileID;

                Reports.StatusUpdate("The FileID used for this test is: " + FileID,true);
                Reports.TestStep = "Open GetWorkflowDetails() method, type the FileID and Click on Send and Get a TaskID from the response";
                var WorkFlowResponse = FileService.GetWorkflowDetails((int)FileID);

                Reports.TestStep = "Verify responds contains Task Category ID and Task Category Name for each task";
                for (int i = 0; i <= WorkFlowResponse.Tasks.Length-1; i++)
                {
                    Support.AreEqual("True", WorkFlowResponse.Tasks[i].CategoryId.HasValue.ToString(), "Verified is TaskCategory ID " + i + " is displayed");
                    Support.AreEqual("False", string.IsNullOrEmpty(WorkFlowResponse.Tasks[i].CategoryName).ToString(), "Verified is TaskCategory Name " + i + " is empty or null");
                }
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }            
        }

        #endregion

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }    
    }
}
