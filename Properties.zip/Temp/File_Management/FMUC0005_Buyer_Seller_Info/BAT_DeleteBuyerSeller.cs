﻿using FASTSelenium.Common;
using FASTWCFHelpers;
using FASTWCFHelpers.DataObjects;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;

namespace Web_Services_Regression.File_Management.FMUC0005_Buyer_Seller_Info
{
    [CodedUITest]
    public class BAT_DeleteBuyerSeller : FASTHelpers
    {
        #region BUYER BAT
        [TestMethod]
        [Description("Delete Buyer")]
        public void BUYER_BAT0001()
        {
            try
            {
                Reports.TestDescription = "Delete Buyer";

                FAST_Login_IIS();
                FAST_WCF_File_IIS();

                #region Request new Individual Buyer type
                Reports.TestStep = "Request new Individual Buyer type";
                var request = GetIndividualBuyerSellerRequest();
                request.BuyerSeller.BuyerSellerTypeID = BuyerSellerTypeCdID.Individual;
                request.PrincipalType = BuyerSellerPrincipalTypeOCD.Buyer;
                var response = FileService.AddBuyerSeller(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Request new Husband/Wife Buyer type
                Reports.TestStep = "Request new Husband/Wife Buyer type";
                request = GetHusbandWifeBuyerSellerRequest();
                request.BuyerSeller.BuyerSellerTypeID = BuyerSellerTypeCdID.HusbandAndWife;
                request.PrincipalType = BuyerSellerPrincipalTypeOCD.Buyer;
                response = FileService.AddBuyerSeller(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Request new Trust/Estate Buyer type
                Reports.TestStep = "Request new Trust/Estate Buyer type";
                request = GetTrustEstateBuyerSellerRequest();
                request.BuyerSeller.BuyerSellerTypeID = BuyerSellerTypeCdID.TrustEstate;
                request.PrincipalType = BuyerSellerPrincipalTypeOCD.Buyer;
                response = FileService.AddBuyerSeller(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Request new Business Trust Buyer type
                Reports.TestStep = "Request new Business Trust Buyer type";
                request = GetBusinessTrustBuyerSellerRequest();
                request.BuyerSeller.BuyerSellerTypeID = BuyerSellerTypeCdID.BusinessEntity;
                request.PrincipalType = BuyerSellerPrincipalTypeOCD.Buyer;
                response = FileService.AddBuyerSeller(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Remove all Buyer instances
                Reports.TestStep = "Remove all Buyer instances";
                var requests = new DeleteBuyerSellerRequest[]{
                    RequestFactory.GetDeleteBuyerSellerRequest(File.FileID ?? 0, BuyerSellerPrincipalTypeOCD.Buyer, seqNum: 1),
                    RequestFactory.GetDeleteBuyerSellerRequest(File.FileID ?? 0, BuyerSellerPrincipalTypeOCD.Buyer, seqNum: 2),
                    RequestFactory.GetDeleteBuyerSellerRequest(File.FileID ?? 0, BuyerSellerPrincipalTypeOCD.Buyer, seqNum: 3),
                    RequestFactory.GetDeleteBuyerSellerRequest(File.FileID ?? 0, BuyerSellerPrincipalTypeOCD.Buyer, seqNum: 4),
                };
                foreach(var deleteReq in requests)
                {
                    var delResponse = FileService.DeleteBuyerSeller(deleteReq);
                    Support.AreEqual("1", delResponse.Status.ToString(), delResponse.StatusDescription);
                }
                #endregion

                #region Verify Buyer instances are not available
                Reports.TestStep = "Verify Buyer instances are not available";
                FastDriver.BuyerSellerSummary.Open(isBuyer: true);
                var tableText = FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.Text;
                Support.Match(@"1\s+Available\s+Individual", tableText);
                Support.Match(@"2\s+Available\s+/\s+Available\s+Husband/Wife", tableText);
                Support.Match(@"3\s+Available\s+Trust/Estate", tableText);
                Support.Match(@"4\s+Available\s+BusinessEntity", tableText);
                #endregion
            }
            catch (Exception ex)
            { 
                FailTest(GetExceptionInfo(ex));
            }
        }
        #endregion

        #region SELLER BAT
        [TestMethod]
        [Description("Delete Seller")]
        public void SELLER_BAT0001()
        {
            try
            {
                Reports.TestDescription = "Delete Seller";

                FAST_Login_IIS();
                FAST_WCF_File_IIS();

                #region Request new Individual Seller type
                Reports.TestStep = "Request new Individual Seller type";
                var request = GetIndividualBuyerSellerRequest();
                request.BuyerSeller.BuyerSellerTypeID = BuyerSellerTypeCdID.Individual;
                request.PrincipalType = BuyerSellerPrincipalTypeOCD.Seller;
                var response = FileService.AddBuyerSeller(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Request new Husband/Wife Seller type
                Reports.TestStep = "Request new Husband/Wife Seller type";
                request = GetHusbandWifeBuyerSellerRequest();
                request.BuyerSeller.BuyerSellerTypeID = BuyerSellerTypeCdID.HusbandAndWife;
                request.PrincipalType = BuyerSellerPrincipalTypeOCD.Seller;
                response = FileService.AddBuyerSeller(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Request new Trust/Estate Seller type
                Reports.TestStep = "Request new Trust/Estate Seller type";
                request = GetTrustEstateBuyerSellerRequest();
                request.BuyerSeller.BuyerSellerTypeID = BuyerSellerTypeCdID.TrustEstate;
                request.PrincipalType = BuyerSellerPrincipalTypeOCD.Seller;
                response = FileService.AddBuyerSeller(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Request new Business Trust Seller type
                Reports.TestStep = "Request new Business Trust Seller type";
                request = GetBusinessTrustBuyerSellerRequest();
                request.BuyerSeller.BuyerSellerTypeID = BuyerSellerTypeCdID.BusinessEntity;
                request.PrincipalType = BuyerSellerPrincipalTypeOCD.Seller;
                response = FileService.AddBuyerSeller(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Remove all Seller instances
                Reports.TestStep = "Remove all Seller instances";
                var requests = new DeleteBuyerSellerRequest[]{
                    RequestFactory.GetDeleteBuyerSellerRequest(File.FileID ?? 0, BuyerSellerPrincipalTypeOCD.Seller, seqNum: 1),
                    RequestFactory.GetDeleteBuyerSellerRequest(File.FileID ?? 0, BuyerSellerPrincipalTypeOCD.Seller, seqNum: 2),
                    RequestFactory.GetDeleteBuyerSellerRequest(File.FileID ?? 0, BuyerSellerPrincipalTypeOCD.Seller, seqNum: 3),
                    RequestFactory.GetDeleteBuyerSellerRequest(File.FileID ?? 0, BuyerSellerPrincipalTypeOCD.Seller, seqNum: 4),
                };
                foreach (var deleteReq in requests)
                {
                    var delResponse = FileService.DeleteBuyerSeller(deleteReq);
                    Support.AreEqual("1", delResponse.Status.ToString(), delResponse.StatusDescription);
                }
                #endregion

                #region Verify Buyer instances are not available
                Reports.TestStep = "Verify Buyer instances are not available";
                FastDriver.BuyerSellerSummary.Open(isBuyer: false);
                var tableText = FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.Text;
                Support.Match(@"1\s+Available\s+Individual", tableText);
                Support.Match(@"2\s+Available\s+/\s+Available\s+Husband/Wife", tableText);
                Support.Match(@"3\s+Available\s+Trust/Estate", tableText);
                Support.Match(@"4\s+Available\s+BusinessEntity", tableText);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        #endregion

        #region Private Methods
        private AddBuyerSellerRequest GetBuyerSellerRequest()
        {
            var request = RequestFactory.GetAddBuyerSellerRequest(BuyerSellerTypeOCD.Individual);
            request.FileID = File.FileID ?? 0;
            request.BuyerSeller.CurrentAddress = new FASTWCFHelpers.FastFileService.BuyerSellerAddress()
            {
                AddrLine1 = "CurrentAddress",
                AddrLine2 = "street line 2",
                AddrLine3 = "street line 3",
                AddrLine4 = "street line 4",
                BuyerSellerAddressTypeCdID = 80,
                City = "CurrentCity",
                Country = "USA",
                County = "Orange",
                State = "CA",
                Zip = "92130"
            };
            request.BuyerSeller.ForwardingAddress = new FASTWCFHelpers.FastFileService.BuyerSellerAddress()
            {
                AddrLine1 = "CurrentAddress",
                AddrLine2 = "street line 2",
                AddrLine3 = "street line 3",
                AddrLine4 = "street line 4",
                BuyerSellerAddressTypeCdID = 80,
                City = "CurrentCity",
                Country = "USA",
                County = "Orange",
                State = "CA",
                Zip = "92130"
            };
            request.BuyerSeller.ContactAddresses = new FASTWCFHelpers.FastFileService.ContactAddress[]
            {
                new FASTWCFHelpers.FastFileService.ContactAddress()
                {
                    ContextTypeCdID = ContextTypeCdID.Current,
                    Value = "(991)889-8383",
                    TypeCdID = ContactAddressTypeCdID.HomePhone,
                },
                new FASTWCFHelpers.FastFileService.ContactAddress()
                {
                    ContextTypeCdID = ContextTypeCdID.Forwarding,
                    Value = "(991)889-8383",
                    TypeCdID = ContactAddressTypeCdID.HomePhone,
                }
            };

            return request;
        }

        private AddBuyerSellerRequest GetIndividualBuyerSellerRequest()
        {
            var request = GetBuyerSellerRequest();
            request.BuyerSeller.LoanApplicant = true;
            request.BuyerSeller.FirstName = "John";
            request.BuyerSeller.MiddleName = "Peter";
            request.BuyerSeller.LastName = "Colwyn";
            request.BuyerSeller.Suffix = "Jr.";
            request.BuyerSeller.SSN = "123456789";
            request.BuyerSeller.MaritalStatusCdID = BuyerSellerMaritalStatusCdID.SingleMan;
            request.BuyerSeller.VestingTypeCdID = BuyerSellerVestingCdID.ToBeDetermined;
            request.BuyerSeller.Salutation = "Dear Maestro";

            return request;
        }

        private AddBuyerSellerRequest GetHusbandWifeBuyerSellerRequest()
        {
            var request = GetBuyerSellerRequest();
            request.BuyerSeller.LoanApplicant = true;
            request.BuyerSeller.SpouseLoanApplicant = false;
            request.BuyerSeller.FirstName = "John";
            request.BuyerSeller.MiddleName = "Peter";
            request.BuyerSeller.LastName = "Colwyn";
            request.BuyerSeller.Suffix = "Jr.";
            request.BuyerSeller.SSN = "123456789";
            request.BuyerSeller.MaritalStatusCdID = BuyerSellerMaritalStatusCdID.MarriedMan;
            request.BuyerSeller.VestingTypeCdID = BuyerSellerVestingCdID.ToBeDetermined;
            request.BuyerSeller.Salutation = "Dear Mr. & Mrs. Colwyn";
            request.BuyerSeller.SpouseFirstName = "Linda";
            request.BuyerSeller.SpouseMiddleName = "Elizabeth";
            request.BuyerSeller.SpouseLastName = "Colwyn";
            request.BuyerSeller.SpouseSuffix = "1st";
            request.BuyerSeller.SpouseSSN = "123456781";

            return request;
        }

        private AddBuyerSellerRequest GetTrustEstateBuyerSellerRequest()
        {
            var request = GetBuyerSellerRequest();
            request.BuyerSeller.LoanApplicant = true;
            request.BuyerSeller.ShortName = "FAST Trust";
            request.BuyerSeller.Dated = DateTime.Today.AddYears(-1);
            request.BuyerSeller.TrustNumber = "12345678";
            request.BuyerSeller.SSN = "123456789";
            request.BuyerSeller.Salutation = "FAST Trust and Associates";

            return request;
        }

        private AddBuyerSellerRequest GetBusinessTrustBuyerSellerRequest()
        {
            var request = GetBuyerSellerRequest();
            request.BuyerSeller.LoanApplicant = false;
            request.BuyerSeller.ShortName = "FAST Business Trust";
            request.BuyerSeller.SSN = "123456789";
            request.BuyerSeller.Salutation = "FAST Trust and Associates";
            request.BuyerSeller.StateOfIncorporationID = BuyerSellerStateOfIncorporationCdID.California;
            request.BuyerSeller.EntityTypeID = BuyerSellerEntityTypeCdID.BusinessTrust;

            return request;
        }
        #endregion

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
