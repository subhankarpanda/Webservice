﻿using FASTSelenium.Common;
using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using OpenQA.Selenium;
using FASTWCFHelpers.FastFileService;
using OpenQA.Selenium.Support.UI;
using FASTSelenium.PageObjects;
using System.Diagnostics;
using Microsoft.Win32;
using FASTSelenium.DataObjects.IIS;
using FASTSelenium.DataObjects.ADM;
using Microsoft.VisualStudio.TestTools.UITesting.HtmlControls;
using Microsoft.VisualStudio.TestTools.UITesting.WinControls;
using System.Linq;
using System.Collections.Generic;
using OpenQA.Selenium.Interactions;
using System.Windows.Input;


namespace Web_Services_Regression.File_Management.FMUC0005_Buyer_Seller_Info
{
    [CodedUITest]
    public class US339070_AddBuyerSelller_Service_To_Add_The_Vesting_Information : FASTHelpers
    {
        [TestMethod]
        public void US339070_TC818133()
        {
            try
            {

                Reports.TestDescription = "To test US#795851, verify if UpdateRealEstateBroker() Web Service is throwing error";

                Reports.TestStep = " Create a basic file";
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].PropertyAddress[0].AddrLine1 = "1815 SW Marlow Ave";
                fileRequest.File.Properties[0].PropertyAddress[0].City = "Portland";
                fileRequest.File.Properties[0].PropertyAddress[0].State = "OR";
                fileRequest.File.Properties[0].PropertyAddress[0].County = "Multnomah";
                fileRequest.File.Properties[0].PropertyAddress[0].Zip = "97225";
                fileRequest.File.Buyers = null;
                fileRequest.File.Sellers = null;
                fileRequest.Source = "EOS";
                var File = FileService.GetOrderDetails((int)FileService.CreateFile(fileRequest).FileID);
                
                Reports.TestStep = " In WCF open the AddBuyerSeller method and insert the required value";
                var AddBS = new FASTWCFHelpers.FastFileService.AddBuyerSellerRequest();
                AddBS.BuyerSeller = new FASTWCFHelpers.FastFileService.BuyerSeller
                {
                    BuyerSellerTypeID = 48,
                    ContactAddresses = null,
                    CurrentAddress = null,
                    ForwardingAddress = null,
                    LastName = "Buyer1Lastname",
                    MaritalStatusCdID = 35,
                    VestingTypeCdID = 50
                };
                AddBS.FileID = (int)File.FileID;
                AddBS.PrincipalType = "Buyer";
                AddBS.Source = "EOS";
                AddBS.Target = "FAST";

                var response = FileService.AddBuyerSeller(AddBS).StatusDescription;
                Support.AreEqual("Buyer Added successfully.", response);

                Reports.TestStep = "Go to Fast IIS and Verify the Buyer/seller was created";
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                #endregion

                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

                FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>("Home>Order Entry>Buyers").WaitForScreenToLoad();
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 1, TableAction.Click);
                FastDriver.BuyerSellerSummary.btnEdit.FAClick();
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                Support.AreEqual("husband and wife", FastDriver.BuyerSellerSetup.MaritalStatus.FAGetSelectedItem());
                Support.AreEqual("as tenants in common", FastDriver.BuyerSellerSetup.Vesting.FAGetSelectedItem());
                

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }   
        }

        [ClassCleanup]
        public static void ClassCleanup()
        {
            CloseRelatedProcesses();
            MasterTestClass.CleanupClass();
        }
    }
}
