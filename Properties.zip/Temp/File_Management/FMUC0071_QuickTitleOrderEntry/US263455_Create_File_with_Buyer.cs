﻿using FASTSelenium.Common;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;

namespace Web_Services_Regression.File_Management.FMUC0071_QuickTitleOrderEntry
{
    [CodedUITest]
    public class US263455_Create_File_with_Buyer : FASTHelpers
    {
        private BuyerSeller[] GetBuyers()
        {
            return new BuyerSeller[]{
                    new BuyerSeller()
                    { 
                        Type = "INDIVIDUAL",
                        BuyerSellerTypeID = 48,
                        FirstName = "Buyer1Firstname",
                        LastName = "Buyer1Lastname",
                        LoanApplicant = true,
                    },
                    new BuyerSeller()
                    { 
                        Type = "HUSBAND AND WIFE",
                        BuyerSellerTypeID = 49,
                        FirstName = "Buyer2Firstname",
                        LastName = "Buyer2Lastname",
                        SpouseFirstName = "Buyer2SpouseName",
                        SpouseLastName = "Buyer2Lastname",
                        LoanApplicant = true,
                        SpouseLoanApplicant = true,
                    },
                    new BuyerSeller()
                    {
                        Type = "TRUST/ESTATE",
                        BuyerSellerTypeID = 50,
                        ShortName = "Springfield Trust",
                        LoanApplicant = true,
                    },
                    new BuyerSeller()
                    {
                        Type = "BUSINESS ENTITY",
                        BuyerSellerTypeID = 51,
                        Name = "Springfield Corp",
                        ShortName = "Springfield Corp",
                        LoanApplicant = true,
                    }
                };
        }

        [TestMethod]
        [Description("Verify Loan Applicant for Buyer created using CreateFile web service")]
        public void Scenario_1_Add_Buyer_LoanApplicant_with_CreateFile()
        {
            try
            {
                Reports.TestDescription = "Verify Loan Applicant for Buyer created using CreateFile web service";

                #region Create File with Buyers as Loan Applicants
                var request = RequestFactory.GetCreateFileDefaultRequest();
                request.File.Sellers = null;
                request.File.Buyers = GetBuyers();
                var response = FileService.CreateFile(request);
                Support.AreEqual("1", response.OperationResponse.Status.ToString(), response.OperationResponse.StatusDescription);
                #endregion

                #region Open file in FAST
                var details = FileService.GetOrderDetails(response.FileID ?? 0);
                FAST_Login_IIS(int.Parse(details.FileNumber));
                #endregion

                #region Verify Individual entity Loan Applicant property is set in FAST
                Reports.TestStep = "Verify Individual entity Loan Applicant property is set in FAST";
                FastDriver.BuyerSellerSummary.Open(isBuyer: true, index: 1);
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                Support.AreEqual(details.Buyers[0].LoanApplicant.ToString().ToLowerInvariant(), FastDriver.BuyerSellerSetup.LoanApplicant.FAGetAttribute("status").ToLowerInvariant(), "BUYER | Individual | LoanApplicant");
                #endregion

                #region Verify Husband/Wife entity Loan Applicant property is set in FAST
                Reports.TestStep = "Verify Husband/Wife entity Loan Applicant property is set in FAST";
                FastDriver.BuyerSellerSummary.Open(isBuyer: true, index: 2);
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                Support.AreEqual(details.Buyers[1].LoanApplicant.ToString().ToLowerInvariant(), FastDriver.BuyerSellerSetup.Spouse1LoanApplicant.FAGetAttribute("status").ToLowerInvariant(), "BUYER | Husband/Wife | Spouse1LoanApplicant");
                Support.AreEqual(details.Buyers[1].SpouseLoanApplicant.ToString().ToLowerInvariant(), FastDriver.BuyerSellerSetup.Spouse2LoanApplicant.FAGetAttribute("status").ToLowerInvariant(), "BUYER | Husband/Wife | Spouse2LoanApplicant");
                #endregion

                #region Verify Trust/Estate entity Loan Applicant property is set in FAST
                Reports.TestStep = "Verify Trust/Estate entity Loan Applicant property is set in FAST";
                FastDriver.BuyerSellerSummary.Open(isBuyer: true, index: 3);
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                Support.AreEqual(details.Buyers[2].LoanApplicant.ToString().ToLowerInvariant(), FastDriver.BuyerSellerSetup.TrusteeLoanApplicant.FAGetAttribute("status").ToLowerInvariant(), "BUYER | Trust/Estate | LoanApplicant");
                #endregion

                #region Verify Business Entity entity Loan Applicant property is set in FAST
                Reports.TestStep = "Verify Business Entity entity Loan Applicant property is set in FAST";
                FastDriver.BuyerSellerSummary.Open(isBuyer: true, index: 4);
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                Support.AreEqual(details.Buyers[3].LoanApplicant.ToString().ToLowerInvariant(), FastDriver.BuyerSellerSetup.TrusteeLoanApplicant.FAGetAttribute("status").ToLowerInvariant(), "BUYER | Business Entity | LoanApplicant");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify Loan Applicant for Buyer created using AddBuyerSeller web service")]
        public void Scenario_2_Add_Buyer_LoanApplicant_with_AddBuyerSeller()
        {
            try
            {
                Reports.TestDescription = "Verify Loan Applicant for Buyer created using AddBuyerSeller web service";

                FAST_Login_IIS();

                FAST_WCF_File_IIS();

                #region Add Buyers with AddBuyerSeller()
                Reports.TestStep = "Add Buyers with AddBuyerSeller()";
                var buyers = GetBuyers();
                var request = new AddBuyerSellerRequest()
                {
                    FileID = File.FileID ?? 0,
                    LoginName = AutoConfig.UserName,
                    PrincipalType = "BUYER",
                    Source = @"FAMOS",
                };
                request.BuyerSeller = buyers[0];
                var response = FileService.AddBuyerSeller(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription); 
                request.BuyerSeller = buyers[1];
                var response2 = FileService.AddBuyerSeller(request);
                Support.AreEqual("1", response2.Status.ToString(), response2.StatusDescription); 
                request.BuyerSeller = buyers[2];
                var response3 = FileService.AddBuyerSeller(request);
                Support.AreEqual("1", response3.Status.ToString(), response3.StatusDescription); 
                request.BuyerSeller = buyers[3];
                var response4 = FileService.AddBuyerSeller(request);
                Support.AreEqual("1", response4.Status.ToString(), response4.StatusDescription);
                var details = FileService.GetOrderDetails(File.FileID ?? 0);
                #endregion

                #region Verify Individual entity Loan Applicant property is set in FAST
                Reports.TestStep = "Verify Individual entity Loan Applicant property is set in FAST";
                FastDriver.BuyerSellerSummary.Open(isBuyer: true, index: 1);
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                Support.AreEqual(details.Buyers[0].LoanApplicant.ToString().ToLowerInvariant(), FastDriver.BuyerSellerSetup.LoanApplicant.FAGetAttribute("status").ToLowerInvariant(), "BUYER | Individual | LoanApplicant");
                #endregion

                #region Verify Husband/Wife entity Loan Applicant property is set in FAST
                Reports.TestStep = "Verify Husband/Wife entity Loan Applicant property is set in FAST";
                FastDriver.BuyerSellerSummary.Open(isBuyer: true, index: 2);
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                Support.AreEqual(details.Buyers[1].LoanApplicant.ToString().ToLowerInvariant(), FastDriver.BuyerSellerSetup.Spouse1LoanApplicant.FAGetAttribute("status").ToLowerInvariant(), "BUYER | Husband/Wife | Spouse1LoanApplicant");
                Support.AreEqual(details.Buyers[1].SpouseLoanApplicant.ToString().ToLowerInvariant(), FastDriver.BuyerSellerSetup.Spouse2LoanApplicant.FAGetAttribute("status").ToLowerInvariant(), "BUYER | Husband/Wife | Spouse2LoanApplicant");
                #endregion

                #region Verify Trust/Estate entity Loan Applicant property is set in FAST
                Reports.TestStep = "Verify Trust/Estate entity Loan Applicant property is set in FAST";
                FastDriver.BuyerSellerSummary.Open(isBuyer: true, index: 3);
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                Support.AreEqual(details.Buyers[2].LoanApplicant.ToString().ToLowerInvariant(), FastDriver.BuyerSellerSetup.TrusteeLoanApplicant.FAGetAttribute("status").ToLowerInvariant(), "BUYER | Trust/Estate | LoanApplicant");
                #endregion

                #region Verify Business Entity entity Loan Applicant property is set in FAST
                Reports.TestStep = "Verify Business Entity entity Loan Applicant property is set in FAST";
                FastDriver.BuyerSellerSummary.Open(isBuyer: true, index: 4);
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                Support.AreEqual(details.Buyers[3].LoanApplicant.ToString().ToLowerInvariant(), FastDriver.BuyerSellerSetup.TrusteeLoanApplicant.FAGetAttribute("status").ToLowerInvariant(), "BUYER | Business Entity | LoanApplicant");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
