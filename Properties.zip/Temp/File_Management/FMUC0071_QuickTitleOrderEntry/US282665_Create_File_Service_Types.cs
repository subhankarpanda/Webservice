﻿using FASTSelenium.Common;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;


namespace Web_Services_Regression.File_Management.FMUC0071_QuickTitleOrderEntry
{
    [CodedUITest]
    public class US282665_Create_File_Service_Types : FASTHelpers
    {
        [TestMethod]
        [Description("Verify creating Files for services TO EO TEO TSO ESO using CreateFile web service")]
        public void Scenario_1_Create_File_TO_EO_TEO_TSO_ESO()
        {
            try
            {
                Reports.TestDescription = "Verify creating Files for services TO EO TEO TSO ESO using CreateFile web service";

                #region Verify creating Title file with CreateFile()
                Reports.TestStep = "Verify creating Title file with CreateFile()";
                var request = RequestFactory.GetCreateFileDefaultRequest();
                request.File.Services = RequestFactory.GetServices(isTO: true, isEO: false, isSEO: false);
                var response = FileService.CreateFile(request);
                Support.AreEqual("1", response.OperationResponse.Status.ToString(), response.OperationResponse.StatusDescription);
                #endregion

                #region Verify creating Title+Escrow file with CreateFile()
                Reports.TestStep = "Verify creating Title+Escrow file with CreateFile()";
                var request2 = RequestFactory.GetCreateFileDefaultRequest();
                request2.File.Services = RequestFactory.GetServices(isTO: true, isEO: true, isSEO: false);
                var response2 = FileService.CreateFile(request2);
                Support.AreEqual("1", response2.OperationResponse.Status.ToString(), response2.OperationResponse.StatusDescription);
                #endregion

                #region Verify creating Title+SubEscrow file with CreateFile()
                Reports.TestStep = "Verify creating Title+SubEscrow file with CreateFile()";
                var request3 = RequestFactory.GetCreateFileDefaultRequest();
                request3.File.Services = RequestFactory.GetServices(isTO: true, isEO: false, isSEO: true);
                var response3 = FileService.CreateFile(request3);
                Support.AreEqual("1", response3.OperationResponse.Status.ToString(), response3.OperationResponse.StatusDescription);
                #endregion

                #region Verify creating Escrow file with CreateFile()
                Reports.TestStep = "Verify creating Escrow file with CreateFile()";
                var request4 = RequestFactory.GetCreateFileDefaultRequest();
                request4.File.Services = RequestFactory.GetServices(isTO: false, isEO: true, isSEO: false);
                var response4 = FileService.CreateFile(request4);
                Support.AreEqual("1", response4.OperationResponse.Status.ToString(), response4.OperationResponse.StatusDescription);
                #endregion

                #region Verify creating Escrow+SubEscrow file with CreateFile()
                Reports.TestStep = "Verify creating Escrow+SubEscrow file with CreateFile()";
                var request5 = RequestFactory.GetCreateFileDefaultRequest();
                request5.File.Services = RequestFactory.GetServices(isTO: false, isEO: true, isSEO: true);
                var response5 = FileService.CreateFile(request5);
                Support.AreEqual("1", response5.OperationResponse.Status.ToString(), response5.OperationResponse.StatusDescription);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
