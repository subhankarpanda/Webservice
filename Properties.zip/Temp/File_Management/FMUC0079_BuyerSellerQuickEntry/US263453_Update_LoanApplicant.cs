﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Linq;

namespace Web_Services_Regression.File_Management.FMUC0079_BuyerSellerQuickEntry
{
    [CodedUITest]
    public class US263453_Update_LoanApplicant : FASTHelpers
    {
        private UpdateBuyerSellerResponse UpdateBuyerSeller(int seqNum, string entityType, int entityTypeID)
        {
            var request = RequestFactory.GetUpdateBuyerSellerRequest(entityType.ToUpperInvariant(), fileId: File.FileID);
            request.BuyerSeller = new BuyerSeller()
            {
                BuyerSellerTypeID = entityTypeID,
                LoanApplicant = false,
                SeqNum = seqNum,
            };
            if (entityTypeID == 49)
                request.BuyerSeller.SpouseLoanApplicant = false;
            return FileService.UpdateBuyerSeller(request);
        }

        private void UpdateEntityLoanApplicant(bool entityIsBuyer = true, string entityType = "Buyer")
        {
            FAST_Login_IIS();

            FAST_WCF_File_IIS();

            #region Add entity type Individual with Loan Applicant property set
            Reports.TestStep = "Add entity type Individual with Loan Applicant property set";
            FastDriver.BuyerSellerSetup.Open(isBuyer: entityIsBuyer);
            FastDriver.BuyerSellerSetup.SetIndividual(new BuyerParameters()
            {
                First = "Homer",
                Last = "Simpson",
                LoanApplicant = true,
            });
            FastDriver.BottomFrame.Done();
            #endregion

            #region Add entity type Husband/Wife with Loan Applicant property set
            Reports.TestStep = "Add entity type Husband/Wife with Loan Applicant property set";
            FastDriver.BuyerSellerSummary.Open(isBuyer: entityIsBuyer);
            FastDriver.BuyerSellerSummary.New();
            FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
            FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItem("Husband/Wife");
            FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
            FastDriver.BuyerSellerSetup.SetHusbandAndWife(new BuyerParameters()
            {
                HusbandFirstName = "Homer",
                HusbandLastName = "Simpson",
                HusbandSpouseFirstName = "March",
                HusbandSpouseLastName = "Simpson",
                Spouse1LoanApplicant = true,
                Spouse2LoanApplicant = true,
            });
            FastDriver.BottomFrame.Done();
            #endregion

            #region Add entity type Trust/Estate with Loan Applicant property set
            Reports.TestStep = "Add entity type Trust/Estate with Loan Applicant property set";
            FastDriver.BuyerSellerSummary.Open(isBuyer: entityIsBuyer);
            FastDriver.BuyerSellerSummary.New();
            FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
            FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItem("Trust/Estate");
            FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
            FastDriver.BuyerSellerSetup.SetTrustEstate(new BuyerParameters()
            {
                TrusteeName = "Springfield Trust",
                LoanApplicant = true,
            });
            FastDriver.BottomFrame.Done();
            #endregion

            #region Add entity type Business Entity with Loan Applicant property set
            Reports.TestStep = "Add entity type Business Entity with Loan Applicant property set";
            FastDriver.BuyerSellerSummary.Open(isBuyer: entityIsBuyer);
            FastDriver.BuyerSellerSummary.New();
            FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
            FastDriver.BuyerSellerSetup.BuyerTypes.FASelectItem("Business Entity");
            FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
            FastDriver.BuyerSellerSetup.SetBusinessEntity(new BuyerParameters()
            {
                BusinessEntityShortname = "Springfield Corp",
                LoanApplicant = true,
            });
            FastDriver.BottomFrame.Done();
            #endregion
            
            #region Update Individual entity Loan Applicant property with UpdateBuyerSeller()
            Reports.TestStep = "Update Individual entity Loan Applicant property with UpdateBuyerSeller()";
            var response = UpdateBuyerSeller(seqNum: 1, entityType: entityType, entityTypeID: 48);
            Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
            #endregion

            #region Update Husband/Wife entity Loan Applicant property with UpdateBuyerSeller()
            Reports.TestStep = "Update Husband/Wife entity Loan Applicant property with UpdateBuyerSeller()";
            var response2 = UpdateBuyerSeller(seqNum: 2, entityType: entityType, entityTypeID: 49);
            Support.AreEqual("1", response2.Status.ToString(), response2.StatusDescription);
            #endregion

            #region Update Trust/Estate entity Loan Applicant property with UpdateBuyerSeller()
            Reports.TestStep = "Update Trust/Estate entity Loan Applicant property with UpdateBuyerSeller()";
            var response3 = UpdateBuyerSeller(seqNum: 3, entityType: entityType, entityTypeID: 50);
            Support.AreEqual("1", response3.Status.ToString(), response3.StatusDescription);
            #endregion

            #region Update Business entity Loan Applicant property with UpdateBuyerSeller()
            Reports.TestStep = "Update Business entity Loan Applicant property with UpdateBuyerSeller()";
            var response4 = UpdateBuyerSeller(seqNum: 4, entityType: entityType, entityTypeID: 51);
            Support.AreEqual("1", response4.Status.ToString(), response4.StatusDescription);
            #endregion

            #region Verify Individual entity Loan Applicant property is unset in FAST
            Reports.TestStep = "Verify Individual entity Loan Applicant property is unset in FAST";
            FastDriver.BuyerSellerSummary.Open(isBuyer: entityIsBuyer, index: 1);
            FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
            Support.AreEqual("false", FastDriver.BuyerSellerSetup.LoanApplicant.FAGetAttribute("status").ToLowerInvariant(), entityType.ToUpperInvariant() + " | Individual | LoanApplicant");
            #endregion

            #region Verify Husband/Wife entity Loan Applicant property is unset in FAST
            Reports.TestStep = "Verify Husband/Wife entity Loan Applicant property is unset in FAST";
            FastDriver.BuyerSellerSummary.Open(isBuyer: entityIsBuyer, index: 2);
            FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
            Support.AreEqual("false", FastDriver.BuyerSellerSetup.Spouse1LoanApplicant.FAGetAttribute("status").ToLowerInvariant(), entityType.ToUpperInvariant() + " | Husband/Wife | Spouse1LoanApplicant");
            Support.AreEqual("false", FastDriver.BuyerSellerSetup.Spouse2LoanApplicant.FAGetAttribute("status").ToLowerInvariant(), entityType.ToUpperInvariant() + " | Husband/Wife | Spouse2LoanApplicant");
            #endregion

            #region Verify Trust/Estate entity Loan Applicant property is unset in FAST
            Reports.TestStep = "Verify Trust/Estate entity Loan Applicant property is unset in FAST";
            FastDriver.BuyerSellerSummary.Open(isBuyer: entityIsBuyer, index: 3);
            FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
            Support.AreEqual("false", FastDriver.BuyerSellerSetup.TrusteeLoanApplicant.FAGetAttribute("status").ToLowerInvariant(), entityType.ToUpperInvariant() + " | Trust/Estate | LoanApplicant");
            #endregion

            #region Verify Business Entity entity Loan Applicant property is unset in FAST
            Reports.TestStep = "Verify Business Entity entity Loan Applicant property is unset in FAST";
            FastDriver.BuyerSellerSummary.Open(isBuyer: entityIsBuyer, index: 4);
            FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
            Support.AreEqual("false", FastDriver.BuyerSellerSetup.TrusteeLoanApplicant.FAGetAttribute("status").ToLowerInvariant(), entityType.ToUpperInvariant() + " | Business Entity | LoanApplicant");
            #endregion
        }

        [TestMethod]
        [Description("Verify Update Buyer includes Loan Applicant to be updated in the Buyer Screen")]
        public void Scenario_1_Update_Buyer_LoanApplicant()
        {
            try
            {
                Reports.TestDescription = "Verify Update Buyer includes Loan Applicant to be updated in the Buyer Screen";

                UpdateEntityLoanApplicant(entityIsBuyer: true);
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
