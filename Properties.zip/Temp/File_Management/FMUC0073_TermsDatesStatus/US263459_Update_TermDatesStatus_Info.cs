﻿using FASTSelenium.Common;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;

namespace Web_Services_Regression.File_Management.FMUC0073_TermsDatesStatus
{
    [CodedUITest]
    public class US263459_Update_TermDatesStatus_Info : FASTHelpers
    {
        [TestMethod]
        [Description("Verify upating Property Value using UpdateTermsDatesStatus web service")]
        public void Scenario_1_Update_PropertyValue()
        {
            try
            {
                Reports.TestDescription = "Verify upating Property Value using UpdateTermsDatesStatus web service";

                FAST_Login_IIS();

                #region Create File with transaction type Sale w/Mortgage
                Reports.TestStep = "Create File with transaction type Sale w/Mortgage";
                FAST_WCF_File_IIS();
                #endregion

                #region Verify that Property Value cannot be updated with UpdateTermsDatesStatus()
                Reports.TestStep = "Verify that Property Value cannot be updated with UpdateTermsDatesStatus()";
                var request = RequestFactory.GetTermsDatesStatusRequest(File.FileID);
                request.PropertyValue = (decimal)1500000;
                request.PropertyValueTypeCD = 2556;
                var response = FileService.UpdateTermsDatesStatus(request);
                Support.AreEqual("Property Value and Type are applicable only on File(s) with Transaction Type of Refinance, Equity Loan, Mortgage Modification, Construction Disbursement, Mtg Mod w/Endorsement, Mtg Mod w/Increased Liability or Construction Finance.", response.StatusDescription, "StatusDescription");
                #endregion

                #region Update File Hompage with transaction type Refinance/Equity Loan/Mortgage Modification/Construction Finance/Construction Disbursement
                Reports.TestStep = "Update File Hompage with transaction type Refinance/Equity Loan/Mortgage Modification/Construction Finance/Construction Disbursement";
                FastDriver.FileHomepage.Open();
                var transactionTypes = new string[] { "Construction Finance", "Construction Disbursement", "Equity Loan", "Mtg Mod w/Endorsement", "Mtg Mod w/Increased Liability", "Refinance" };
                var randomIndex = new Random();
                FastDriver.FileHomepage.TransactionType.FASelectItemBySendingKeys(transactionTypes[randomIndex.Next(0, 4)]);
                Support.AreEqual("The sale price and all seller charges and credits will be removed, Continue?", FastDriver.WebDriver.HandleDialogMessage(true, true));
                FastDriver.BottomFrame.Done();
                Playback.Wait(3000);
                #endregion

                #region Verify that Property Value can be updated with UpdateTermsDatesStatus()
                Reports.TestStep = "Verify that Property Value can be updated with UpdateTermsDatesStatus()";
                var response2 = FileService.UpdateTermsDatesStatus(request);
                Support.AreEqual("1", response2.Status.ToString(), response2.StatusDescription);
                #endregion

                #region Verify Property Value and Type in Terms/Dates/Status
                Reports.TestStep = "Verify Property Value and Type in Terms/Dates/Status";
                FastDriver.TermsDatesStatus.Open();
                Support.AreEqual("1,500,000.00", FastDriver.TermsDatesStatus.PropertyValue.FAGetValue(), "PropertyValue");
                Support.AreEqual("true", FastDriver.TermsDatesStatus.EstimatedPropValue.FAGetAttribute("status").ToLowerInvariant(), "EstimatedPropValue");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
