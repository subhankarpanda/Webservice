﻿using FASTSelenium.Common;
using FASTWCFHelpers;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;

namespace Web_Services_Regression.File_Management.FMUC0073_TermsDatesStatus
{
    [CodedUITest]
    public class US263463_Retrieve_TermsDatesStatus_Info : FASTHelpers
    {
        [TestMethod]
        [Description("Verify retrieving Terms/Dates/Status using GetTermsDatesStatus web service")]
        public void Scenario_1_Get_Dates_Info()
        {
            try
            {
                Reports.TestDescription = "Verify retrieving Terms/Dates/Status using GetTermsDatesStatus web service";

                #region Test Data
                int daylightSavingTime = TimeZoneInfo.Local.IsDaylightSavingTime(DateTime.UtcNow) ? 1 : 0;
                var orderReceivedTime = DateTime.UtcNow.AddHours(daylightSavingTime).ToString("hh:mm tt");
                var now = DateTime.UtcNow.AddHours(daylightSavingTime).ToPST();
                var today = now.ToDateString();
                var tomorrow = now.AddDays(1).ToDateString();
                var nextWeek = now.AddDays(7).ToDateString();
                var nextMonth = now.AddDays(28).ToDateString();
                var time = now.ToString("hh:mm tt");
                #endregion

                FAST_Login_IIS();

                FAST_WCF_File_IIS();

                #region Set up Closing Disclosure [ Delivery Options ]
                Reports.TestStep = "Set up Closing Disclosure [ Delivery Options ]";
                FastDriver.ClosingDisclosure.Open();
                FastDriver.ClosingDisclosure.DeliveryOptions.Click();
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.InitialCD);
                FastDriver.ClosingDisclosure.CCDPriortoClosing.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.LenderIssueProvided.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.WaitCreation(FastDriver.ClosingDisclosure.DateIssuedtxt);
                FastDriver.ClosingDisclosure.DateIssuedtxt.FASetText(today);
                FastDriver.ClosingDisclosure.ClosingDatetxt.FASetText(nextWeek);
                FastDriver.ClosingDisclosure.DisbursementDatetxt.FASetText(nextMonth);
                FastDriver.ClosingDisclosure.DateReceived.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.DateRecievedText.FASetText(nextMonth);
                FastDriver.ClosingDisclosure.BuyerOnly.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.DeliveryMethod.FASelectItem("Print");
                FastDriver.ClosingDisclosure.DeliveryButton.FAClick();
                FastDriver.PrintDlg.SendPrint("TEXT_FILE_PRINTER");
                FastDriver.WebDriver.WaitForDeliveryWindow();
                #endregion

                #region Set up Terms/Dates/Status Settlement Statement Dates
                Reports.TestStep = "Set up Terms/Dates/Status Settlement Statement Dates";
                FastDriver.TermsDatesStatus.Open();
                FastDriver.TermsDatesStatus.EstimattedDaysToClose.FASetText("7");
                FASTHelpers.KeyboardSendKeys(FAKeys.TabAway);
                Support.AreEqual("The Est. Settlement Date has changed. Would you like to update the Prorate As of Date?", FastDriver.WebDriver.HandleDialogMessage(true, true));
                FastDriver.ProrationDateChangedDlg.WaitForScreenToLoad();
                Playback.Wait(3000);
                FastDriver.ProrationDateChangedDlg.SelectAll.FASetCheckbox(true);
                FastDriver.DialogBottomFrame.ClickDone();
                Support.AreEqual("The Prorate As of Date has changed. Would you like to update the Disbursement Date?", FastDriver.WebDriver.HandleDialogMessage(false, true));
                Support.AreEqual("The Est. Settlement Date has changed. Would you like to update the Funding Date for Loans?", FastDriver.WebDriver.HandleDialogMessage(true, true));
                FastDriver.TermsDatesStatus.WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.ClosingAppointmentDate1.FASetText(nextWeek);
                FastDriver.TermsDatesStatus.ClosingAppointmentDate2.FASetText(nextWeek);
                FastDriver.TermsDatesStatus.OrderRecievedDate.FASetText(nextWeek);
                FastDriver.TermsDatesStatus.DateofContract.FASetText(nextWeek);
                FastDriver.TermsDatesStatus.FeeDate.FASetText(nextWeek);
                FastDriver.TermsDatesStatus.ClosingAppointmentTime1.FASetText(time);
                FastDriver.TermsDatesStatus.ClosingAppointmentTime2.FASetText(time);
                FastDriver.TermsDatesStatus.OrderRecievedTime.FASetText(time);
                FastDriver.TermsDatesStatus.DateofContractAcceptance.FASetText(nextWeek);
                FastDriver.TermsDatesStatus.FileCompleteDate.FASetText(nextWeek);
                FASTHelpers.KeyboardSendKeys(FAKeys.TabAway);
                Support.AreEqual("The File Complete Date has changed. Would you like to update the Settlement Date?", FastDriver.WebDriver.HandleDialogMessage(true, true));
                FastDriver.TermsDatesStatus.WaitForScreenToLoad();
                FastDriver.TermsDatesStatus.TCIssuedDate.FASetText(nextWeek);
                FastDriver.TermsDatesStatus.DaystoExpirationdate.FASetText("28");
                //
                FastDriver.BottomFrame.Done();
                #endregion

                #region Verify Dates with GetTermsDatesStatus()
                Reports.TestStep = "Verify Dates with GetTermsDatesStatus()";
                var details = FileService.GetTermsDatesStatusDetails(File.FileID ?? 0);
                Support.AreEqual("7", details.EstDaysToClose.ToString(), "EstDaysToClose");
                Support.AreEqual(now.AddDays(7).ToString("MM-dd-yyyy '12:00:00 AM'"), details.EstSettlementDate.ToString("MM-dd-yyyy hh:mm:ss tt"), "EstSettlementDate");
                Support.AreEqual(nextWeek, ((DateTime)details.ClosingAppointmentDateTime1).ToDateString(), "ClosingAppointmentDate1");
                Support.AreEqual(nextWeek, ((DateTime)details.ClosingAppointmentDateTime2).ToDateString(), "ClosingAppointmentDate2");
                Support.AreEqual(nextWeek, ((DateTime)details.OrderReceivedDateTime).ToDateString(), "OrderReceivedDate");
                Support.AreEqual(nextWeek, ((DateTime)details.DateOfContract).ToDateString(), "DateOfContract");
                Support.AreEqual(nextWeek, ((DateTime)details.FeeDate).ToDateString(), "FeeDate");
                Support.AreEqual(now.AddDays(7).ToString("MM-dd-yyyy '12:00:00 AM'"), details.ProrateAsOfDate.ToString("MM-dd-yyyy hh:mm:ss tt"), "ProrateAsOfDate");
                Support.AreEqual(now.AddDays(7).ToString("MM-dd-yyyy '12:00:00 AM'"), details.DisbursementDate.ToString("MM-dd-yyyy hh:mm:ss tt"), "DisbursementDate");
                Support.AreEqual(time, details.ClosingAppointmentDateTime1.ToString("hh:mm tt"), "ClosingAppointmentTime1");
                Support.AreEqual(time, details.ClosingAppointmentDateTime2.ToString("hh:mm tt"), "ClosingAppointmentTime2");
                Support.AreEqual(orderReceivedTime, details.OrderReceivedDateTime.ToString("hh:mm tt"), "OrderReceivedTime");
                Support.AreEqual(nextWeek, ((DateTime)details.DateOfContactAcceptance).ToDateString(), "DateOfContactAcceptance");
                Support.AreEqual(nextWeek, ((DateTime)details.SettlementDate).ToDateString(), "SettlementDate");
                Support.AreEqual(nextWeek, ((DateTime)details.FileCompleteDate).ToDateString(), "FileCompleteDate");
                //  "TC Issued Date"
                //  "Days to Expiration Date"
                //  "TC Expiration Date"
                Support.AreEqual(today, details.ClosingDisclosureDeliveryOptions.DateIssued.Replace('/','-'), "DateIssued");
                Support.AreEqual(nextMonth, details.ClosingDisclosureDeliveryOptions.Disbursement_LenderFundingDate.Replace('/', '-'), "Disbursement_LenderFundingDate");
                Support.AreEqual(nextMonth, details.ClosingDisclosureDeliveryOptions.DateReceived.Replace('/', '-'), "DateReceived");
                Support.AreEqual("1", details.ClosingDisclosureDeliveryOptions.IsDateReceivedAck.ToString(), "IsDateReceivedAck");
                Support.AreEqual("1", details.ClosingDisclosureDeliveryOptions.IsDeliveryTypeOther.ToString(), "IsDeliveryTypeOther");
                Support.AreEqual("1", details.ClosingDisclosureDeliveryOptions.IsCorrectedClosingDisclosurePriorToClosing.ToString(), "IsCorrectedClosingDisclosurePriorToClosing");
                Support.AreEqual(nextWeek, details.ClosingDisclosureDeliveryOptions.Closing_ConsummationDate.Replace('/', '-'), "Closing_ConsummationDate");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
