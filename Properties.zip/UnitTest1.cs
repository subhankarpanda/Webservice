﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using FASTWCFHelpers.Factories;
using System.Reflection;
using System.Linq;

namespace WebServices
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            //RequestFactory.Resolve<CreateNewLoanRequest>()
        }
    }

    public class Factory
    {

        //TODO: add new method to test below resolver

        public static T Resolve<T>()
        {
            MethodInfo method = typeof(Factory).GetMethods(BindingFlags.Static).First(r => r.ReturnType == typeof(T));
            return (T)method.Invoke(null, null);
        }
    }
}
