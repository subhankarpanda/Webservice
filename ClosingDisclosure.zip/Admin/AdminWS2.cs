﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using FASTSelenium.DataObjects.IIS;
using FASTSelenium.PageObjects;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.DataObjects;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastAdminService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using WebServices.Helpers.Admin;

namespace WebServices.Admin
{
    [CodedUITest]
    public partial class AdminWS2 : MasterTestClass
    {
        [TestMethod]
        public void REG00_GetEmployeesByFunctionTypes()
        {
            try
            {
                Reports.TestDescription = "Verify GetEmployeesByFunctionTypes() service.";

                int[] functionTypes =
                {
                    EmployeeFunctionTypeCdID.SalesRep,
                    EmployeeFunctionTypeCdID.TitleOfficer,
                    EmployeeFunctionTypeCdID.EscrowOfficer,
                    EmployeeFunctionTypeCdID.Other,
                    EmployeeFunctionTypeCdID.TitleAssistant,
                    EmployeeFunctionTypeCdID.EscrowAssistant,
                    EmployeeFunctionTypeCdID.UCCSpecialist
                };

                GetEmployeesByFunctionTypesResponse response = null;
                //FastDriver.WebDriver.WaitForActionToComplete(() =>
                //{
                    Reports.TestStep = "Invoke GetEmployeesByFunctionTypes request.";
                    response = AdminService.GetEmployeesByFunctionTypes(AdminRequestFactory.GetEmployeesByFunctionTypesRequest(functionTypes, 191));
                   // return !(response == null);
                //}, timeout: 600, idleInterval: 5);

                var employeeInfo = response.Employees.ToList().FirstOrDefault(e => e.LastName == "FASTQA02");

                Reports.TestStep = "Validate GetEmployeesByFunctionTypes succeeded.";
                Support.AreEqual("91754", employeeInfo.EmployeeID.ToString(), "Validating response from GetEmployeesByFunctionTypes");
                Support.AreEqual("FASTTS", employeeInfo.FirstName, "Validating response from GetEmployeesByFunctionTypes");
                Support.AreEqual("FASTQA02", employeeInfo.LastName, "Validating response from GetEmployeesByFunctionTypes");
                Support.AreEqual("X_fastqa07", employeeInfo.LoginName, "Validating response from GetEmployeesByFunctionTypes");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG00_GetAltAddressesByBusOrgID()
        {
            try
            {
                Reports.TestDescription = "Verify GetAltAddressesByBusOrgID() service.";
                
                Reports.TestStep = "Invoke GetAltAddressesByBusOrgID request.";
                var response = AdminService.GetAltAddressesByBusOrgId(AdminRequestFactory.GetGABRequest(58906206));
                response.ToJSON();

                Reports.TestStep = "Validate GetAltAddressesByBusOrgID succeeded.";
                Support.AreEqual("500 Cascade West Parkway", response.AltAddressesList[0].AddrLine1, "Validating response from GetAltAddressesByBusOrgID");
                Support.AreEqual("Business", response.AltAddressesList[0].AddressType, "Validating response from GetAltAddressesByBusOrgID");
                Support.AreEqual("500 Cascade West Parkway", response.AltAddressesList[1].AddrLine1, "Validating response from GetAltAddressesByBusOrgID");
                Support.AreEqual("Mailing", response.AltAddressesList[1].AddressType, "Validating response from GetAltAddressesByBusOrgID");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
    }
}