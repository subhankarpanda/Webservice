﻿using FASTSelenium.Common;
using FASTWCFHelpers;
using FASTWCFHelpers.DataObjects;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;

namespace WebServices.CD
{
    [CodedUITest]
    public class FormDeliveryWS : MasterTestClass
    {
        [TestMethod]
        [Description("Verify Email delivery using CDFormDelivery(*) web service")]
        public void REG0001_Test_CDFormDelivery_Email()
        { 
            try
            {
                Reports.TestDescription = "Verify Email delivery using CDFormDelivery(*) web service";

                #region Create File with Buyer | Seller | New Loan
                Reports.TestStep = "Create File with Buyer | Seller | New Loan";
                FASTHelpers.WCF_Create_File(LenderID: "BOA", loanAmt: 123456789M, hasBuyer: true, hasSeller: true);
                #endregion

                #region Deliver CD Form by E-mail
                Reports.TestStep = "Deliver CD Form by E-mail";
                var request = CDRequestFactory.GetCDFormDeliveryRequest(FASTHelpers.File.FileID);
                request.EmailOptions = CDRequestFactory.GetEmailOptions();
                request.eDeliveryMethod = FASTWCFHelpers.FastClosingDisclosureService.DeliveryMethod.Email;
                var response = ClosingDisclosureService.CDFormDelivery(request);
                Support.AreEqual("-1", response.Status.ToString(), response.StatusDescription);
                #endregion
            }
            catch(Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify Fax delivery using CDFormDelivery(*) web service")]
        public void REG0002_Test_CDFormDelivery_Fax()
        {
            try
            {
                Reports.TestDescription = "Verify Fax delivery using CDFormDelivery(*) web service";

                #region Create File with Buyer | Seller | New Loan
                Reports.TestStep = "Create File with Buyer | Seller | New Loan";
                FASTHelpers.WCF_Create_File(LenderID: "BOA", loanAmt: 123456789M, hasBuyer: true, hasSeller: true);
                #endregion

                #region Deliver CD Form by Fax
                Reports.TestStep = "Deliver CD Form by Fax";
                var request = CDRequestFactory.GetCDFormDeliveryRequest(FASTHelpers.File.FileID);
                request.FaxOptions = CDRequestFactory.GetFaxOptions();
                request.eDeliveryMethod = FASTWCFHelpers.FastClosingDisclosureService.DeliveryMethod.Fax;
                var response = ClosingDisclosureService.CDFormDelivery(request);
                Support.AreEqual("-1", response.Status.ToString(), response.StatusDescription);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify ImageDoc delivery using CDFormDelivery(*) web service")]
        public void REG0003_Test_CDFormDelivery_ImageDoc()
        {
            try
            {
                Reports.TestDescription = "Verify ImageDoc delivery using CDFormDelivery(*) web service";
                
                #region Create File with Buyer | Seller | New Loan
                Reports.TestStep = "Create File with Buyer | Seller | New Loan";
                FASTHelpers.WCF_Create_File(LenderID: "BOA", loanAmt: 123456789M, hasBuyer: true, hasSeller: true);
                #endregion

                #region Deliver CD Form by ImageDoc
                Reports.TestStep = "Deliver CD Form by ImageDoc";
                var request = CDRequestFactory.GetCDFormDeliveryRequest(FASTHelpers.File.FileID);
                request.ImageDocOptions = CDRequestFactory.GetImageDocOptions();
                request.eDeliveryMethod = FASTWCFHelpers.FastClosingDisclosureService.DeliveryMethod.ImageDoc;
                var response = ClosingDisclosureService.CDFormDelivery(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                FASTHelpers.FAST_Login_IIS(int.Parse(FASTHelpers.File.FileNumber));

                #region Verify that CD Delivery Options are updated in FAST
                Reports.TestStep = "Verify that CD Delivery Options are updated in FAST";
                FastDriver.ClosingDisclosure.Open();
                FastDriver.ClosingDisclosure.DeliveryOptions.FAClick();
                FastDriver.ClosingDisclosure.WaitForDeliveryOptionsScreenToLoad();
                Support.AreEqual(true.ToString(), FastDriver.ClosingDisclosure.InitialCD.FAGetAttribute("checked").ToUpperFirst(), "Initial Closing Disclosure");
                Support.AreEqual(true.ToString(), FastDriver.ClosingDisclosure.LenderIssueProvided.FAGetAttribute("checked").ToUpperFirst(), "Lender Issue Provided");
                Support.AreEqual(true.ToString(), FastDriver.ClosingDisclosure.DelveryType_Personal_RdoBtn.FAGetAttribute("selected").ToUpperFirst(), "Delivery Type Personal");
                string todaysDate = DateTime.Today.ToDateString();
                Support.AreEqual(todaysDate, FastDriver.ClosingDisclosure.DateIssuedtxt.FAGetValue(), "Date Issued");
                Support.AreEqual(todaysDate, FastDriver.ClosingDisclosure.ClosingDatetxt.FAGetValue(), "Closing/Consummation Date");
                Support.AreEqual(todaysDate, FastDriver.ClosingDisclosure.DisbursementDatetxt.FAGetValue(), "Disbursement/Lender Funding Date");
                Support.AreEqual(todaysDate, FastDriver.ClosingDisclosure.DateRecievedText.FAGetValue(), "Date Received");
                #endregion

                #region Verify that CD Delivery is showing ImageDoc in events table
                Reports.TestStep = "Verify that CD Delivery is showing ImageDoc in events table";
                FastDriver.EventTrackingLog.Open();
                FastDriver.EventTrackingLog.SelectEventCategory("CD Delivery");
                var logText = FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[ImageDoc]", "Comments", TableAction.GetText).Message;
                Support.Match("ImageDoc Successful CD - Combined - Initial", logText, "CD Delivery Log Comment");
                #endregion

                #region Verify there is an ImageDoc document in documents table
                Reports.TestStep = "Verify there is an ImageDoc document in documents table";
                FastDriver.DocumentRepository.Open();
                var docStatus = FastDriver.DocumentRepository.DocumentsTable.PerformTableAction("Name", "CD - Combined - Initial", "Status", TableAction.GetText).Message;
                Support.AreEqual("Imaged", docStatus, "Document Status as seen in Document Repository");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify CD Delivery Options using GetClosingDisclosureDeliveryOptions(*) web service")]
        public void REG0004_Test_GetClosingDisclosureDeliveryOptions()
        {
            try
            {
                Reports.TestDescription = "Verify CD Delivery Options using GetClosingDisclosureDeliveryOptions(*) web service";

                #region Create File with Buyer | Seller | New Loan
                Reports.TestStep = "Create File with Buyer | Seller | New Loan";
                FASTHelpers.WCF_Create_File(LenderID: "BOA", loanAmt: 123456789M, hasBuyer: true, hasSeller: true);
                #endregion

                FASTHelpers.FAST_Login_IIS(int.Parse(FASTHelpers.File.FileNumber));

                #region Update New Loan QCClosing transaction type
                var request = GetUpdateNewLoanRequest(FASTHelpers.File.FileID);
                var response = FileService.UpdateNewLoan(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Make an ImageDoc delivery of the CD Form
                Reports.TestStep = "Make an ImageDoc delivery of the CD Form";
                FastDriver.ClosingDisclosure.Open();
                FastDriver.ClosingDisclosure.DeliveryOptions.FAClick();
                FastDriver.ClosingDisclosure.WaitForDeliveryOptionsScreenToLoad();
                FastDriver.ClosingDisclosure.InitialCD.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.LenderIssueProvided.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.DelveryType_Personal_RdoBtn.FAClick();
                string todaysDate = DateTime.Today.ToDateString(slash: false);
                FastDriver.ClosingDisclosure.DateIssuedtxt.FASetText(todaysDate);
                FastDriver.ClosingDisclosure.ClosingDatetxt.FASetText(todaysDate);
                FastDriver.ClosingDisclosure.DisbursementDatetxt.FASetText(todaysDate);
                FastDriver.ClosingDisclosure.DateRecievedText.FASetText(todaysDate);
                FastDriver.ClosingDisclosure.Combined.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.Delivery("Imagedoc");
                FastDriver.ImageDocDlg.Deliver();
                FastDriver.WebDriver.WaitForDeliveryWindow(FADeliveryMethod.ImageDoc);
                FastDriver.EventTrackingLog.Open();
                FastDriver.EventTrackingLog.SelectEventCategory("CD Delivery");
                FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", "[ImageDoc]", "Comments", TableAction.Click);
                #endregion

                #region Verify using the web service GetClosingDisclosureDeliveryOptions(*)
                Reports.TestStep = "Verify using the web service GetClosingDisclosureDeliveryOptions(*)";
                var details = ClosingDisclosureService.GetClosingDisclosureDeliveryOptions(CDRequestFactory.GetCDDeliveryOptionsRequest(FASTHelpers.File.FileID));
                Support.AreEqual("1", details.Status.ToString(), details.StatusDescription);
                Support.IsTrue(details.DeliveryOptions.CDDeliveryOptionsImageDetailsList != null, "DeliveryOptions.CDDeliveryOptionsImageDetailsList is not NULL");
                Support.IsTrue(details.DeliveryOptions.CDDeliveryOptionsImageDetailsList.Length > 0, "DeliveryOptions.CDDeliveryOptionsImageDetailsList is not empty");
                todaysDate = DateTime.Today.ToDateString(slash: true, trim: true);
                Support.AreEqual(todaysDate, details.DeliveryOptions.Closing_ConsummationDate, "DeliveryOptions.Closing_ConsummationDate");
                Support.AreEqual(todaysDate, details.DeliveryOptions.DateIssued, "DeliveryOptions.DateIssued");
                Support.AreEqual(todaysDate, details.DeliveryOptions.DateReceived, "DeliveryOptions.DateReceived");
                Support.AreEqual(todaysDate, details.DeliveryOptions.DisbursementDate, "DeliveryOptions.DisbursementDate");
                Support.AreEqual("2", details.DeliveryOptions.IsCDFormDelivered.ToString(), "DeliveryOptions.IsCDFormDelivered");
                Support.AreEqual("1", details.DeliveryOptions.IsInitialClosingDisclosure.ToString(), "DeliveryOptions.IsInitialClosingDisclosure");
                Support.AreEqual("1", details.DeliveryOptions.IsLenderIssueorProvided.ToString(), "DeliveryOptions.IsLenderIssueorProvided");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        private NewLoanRequest GetUpdateNewLoanRequest(int? fileId, int seqNum = 1)
        {
            return new NewLoanRequest() 
            {
                FileID = fileId,
                QCClosingInformation = new QCClosing()
                {
                    TransactionTypeID = QCClosingTransactionTypeCdID.Purchase,
                },
                SeqNum = seqNum,
                EmployeeID = 1,
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
        }
    }
}
