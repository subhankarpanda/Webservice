﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using FASTSelenium.DataObjects.IIS;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using WebServices.Helpers.File;

namespace WebServices.Documents
{
    [CodedUITest]
    public class DeliveryWS : MasterTestClass
    {

        [TestMethod]
        public void REG0001_EmailDelivery()
        {
            try
            {
                Reports.TestDescription = "Validate EmailDelivery web method";

                Reports.TestStep = "Create a basic file (WS)";
                int fileID = WebServices.Helpers.File.GeneralFileServiceOperationsHelpers.CreateFile();
                string fileNumber = FASTWCFHelpers.FileService.GetOrderDetails(fileID).FileNumber;

                Reports.TestStep = "Add a document to the file (WS)";
                var response = DocumentsHelpers.GetDefaultDocTemplates();
                int templateID = Convert.ToInt32(response.Templates[0].TemplateID);
                string templateName = response.Templates[0].Descr;
                int docID = (int)WebServices.Helpers.Documents.DocumentsHelpers.CreateDocument(fileID, templateID).DocumentID;

                Reports.TestStep = "Log into FAST application";
                Login();

                Reports.TestStep = "Navigate to target file";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to Document Repository, validate document " + templateName + " is present";
                FastDriver.DocumentRepository.Open();
                Support.AreEqual(templateName, FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(9, "Created", 4, TableAction.GetText).Message, templateName);

                Reports.TestStep = "Finalize the document";
                var finalizeDocResponse = WebServices.Helpers.Documents.DocumentsHelpers.FinalizeDocument(fileID, docID);
                Support.AreEqual("1", finalizeDocResponse.Status.ToString(), "Status Operation");

                Reports.TestStep = "Invoke EmailDelivery and verify response";
                var EmailDeliveryRes = WebServices.Helpers.Documents.DeliveryHelpers.EmailDelivery(fileID, docID);
                Support.AreEqual("1", EmailDeliveryRes.Status.ToString(), "EmailDelivery Status");

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>("Home>Order Entry>Event/Tracking Log").WaitForScreenToLoad();
                Reports.TestStep = "Navigate to EventLog and check the status";
                FastDriver.EventTrackingLog.EventCategory.FASelectItem("Doc Delivery");
                FastDriver.EventTrackingLog.WaitForWindowToLoad();

                string Comment = FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[E-mail]", 5, TableAction.GetText).Message;
                if (Comment.Contains("Delivery Status: Delivery Successful"))
                {
                    Reports.StatusUpdate("Email Delivery Successful", true);
                }
                else Reports.StatusUpdate("Email Delivery Failed", false);

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { FastDriver.WebDriver.Quit(); }
        }


        [TestMethod]
        public void REG0002_FaxDelivery()
        {
            try
            {
                Reports.TestDescription = "Validate FaxDelivery web method";

                Reports.TestStep = "Create a basic file (WS)";
                int fileID = WebServices.Helpers.File.GeneralFileServiceOperationsHelpers.CreateFile();
                string fileNumber = FASTWCFHelpers.FileService.GetOrderDetails(fileID).FileNumber;

                Reports.TestStep = "Add a document to the file (WS)";
                var response = DocumentsHelpers.GetDefaultDocTemplates();
                int templateID = Convert.ToInt32(response.Templates[0].TemplateID);
                string templateName = response.Templates[0].Descr;
                int docID = (int)WebServices.Helpers.Documents.DocumentsHelpers.CreateDocument(fileID, templateID).DocumentID;

                Reports.TestStep = "Log into FAST application";
                Login();

                Reports.TestStep = "Navigate to target file";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to Document Repository, validate document " + templateName + " is present";
                FastDriver.DocumentRepository.Open();
                Support.AreEqual(templateName, FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(9, "Created", 4, TableAction.GetText).Message, templateName);

                Reports.TestStep = "Finalize the document";
                var finalizeDocResponse = WebServices.Helpers.Documents.DocumentsHelpers.FinalizeDocument(fileID, docID);
                Support.AreEqual("1", finalizeDocResponse.Status.ToString(), "Status Operation");

                Reports.TestStep = "Invoke FaxDelivery and verify response";
                var EmailDeliveryRes = WebServices.Helpers.Documents.DeliveryHelpers.FaxDelivery(fileID, docID);
                Support.AreEqual("1", EmailDeliveryRes.Status.ToString(), "FaxDelivery Status");

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>("Home>Order Entry>Event/Tracking Log").WaitForScreenToLoad();
                Reports.TestStep = "Navigate to EventLog and check the status";
                FastDriver.EventTrackingLog.EventCategory.FASelectItem("Doc Delivery");
                FastDriver.EventTrackingLog.WaitForWindowToLoad();

                string Comment = FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Fax]", 5, TableAction.GetText).Message;
                if (Comment.Contains("Delivery Status: Delivery Queued") || Comment.Contains("Delivery Successful, Email Confirmation sent.") || Comment.Contains("Delivery Status: Delivery Submitted"))
                {
                    Reports.StatusUpdate("Fax Delivery Successful", true);
                }
                else Reports.StatusUpdate("Fax Delivery Failed", false);

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { FastDriver.WebDriver.Quit(); }
        }



        [TestMethod]
        public void REG0003_RTMDelivery()
        {
            try
            {
                Reports.TestDescription = "Validate RTMDelivery web method";

                Reports.TestStep = "Create a basic file (WS)";
                int fileID = WebServices.Helpers.File.GeneralFileServiceOperationsHelpers.CreateFile();
                string fileNumber = FASTWCFHelpers.FileService.GetOrderDetails(fileID).FileNumber;

                Reports.TestStep = "Add a document to the file (WS)";
                var response = DocumentsHelpers.GetDefaultDocTemplates();
                int templateID = Convert.ToInt32(response.Templates[0].TemplateID);
                string templateName = response.Templates[0].Descr;
                int docID = (int)WebServices.Helpers.Documents.DocumentsHelpers.CreateDocument(fileID, templateID).DocumentID;

                Reports.TestStep = "Log into FAST application";
                Login();

                Reports.TestStep = "Navigate to target file";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to Document Repository, validate document " + templateName + " is present";
                FastDriver.DocumentRepository.Open();
                Support.AreEqual(templateName, FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(9, "Created", 4, TableAction.GetText).Message, templateName);

                Reports.TestStep = "Finalize the document";
                var finalizeDocResponse = WebServices.Helpers.Documents.DocumentsHelpers.FinalizeDocument(fileID, docID);
                Support.AreEqual("1", finalizeDocResponse.Status.ToString(), "Status Operation");

                Reports.TestStep = "Invoke FaxDelivery and verify response";
                var EmailDeliveryRes = WebServices.Helpers.Documents.DeliveryHelpers.FaxDelivery(fileID, docID);
                Support.AreEqual("1", EmailDeliveryRes.Status.ToString(), "FaxDelivery Status");

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>("Home>Order Entry>Event/Tracking Log").WaitForScreenToLoad();
                Reports.TestStep = "Navigate to EventLog and check the status";
                FastDriver.EventTrackingLog.EventCategory.FASelectItem("Doc Delivery");
                FastDriver.EventTrackingLog.WaitForWindowToLoad();

                string Comment = FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Fax]", 5, TableAction.GetText).Message;
                if (Comment.Contains("Delivery Status: Delivery Queued") || Comment.Contains("Delivery Successful, Email Confirmation sent.") || Comment.Contains("Delivery Status: Delivery Submitted"))
                {
                    Reports.StatusUpdate("Fax Delivery Successful", true);
                }
                else Reports.StatusUpdate("Fax Delivery Failed", false);

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { FastDriver.WebDriver.Quit(); }
        }


        [TestMethod]
        public void REG0004_FeeEntryDelivery()
        {
            try
            {
                Reports.TestDescription = "Validate FeeEntryDelivery web method";

                Reports.TestStep = "Create a basic file (WS)";
                int fileID = WebServices.Helpers.File.GeneralFileServiceOperationsHelpers.CreateFile();
                string fileNumber = FASTWCFHelpers.FileService.GetOrderDetails(fileID).FileNumber;

                Reports.TestStep = "Log into FAST application";
                Login();

                Reports.TestStep = "Navigate to target file";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Invoke FeeEntryDelivery service and verify response.";
                var FeeEntryDeliveryRes = WebServices.Helpers.Documents.DeliveryHelpers.FeeEntryDelivery(fileID);
                Support.AreEqual("1", FeeEntryDeliveryRes.Status.ToString(), "FeeEntryDelivery Status");

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>("Home>Order Entry>Event/Tracking Log").WaitForScreenToLoad();
                Reports.TestStep = "Navigate to EventLog and check the status";
                FastDriver.EventTrackingLog.EventCategory.FASelectItem("Doc Delivery");
                FastDriver.EventTrackingLog.WaitForWindowToLoad();

                string Comment = FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[E-mail]", 5, TableAction.GetText).Message;
                if ((Comment.Contains("Delivery Status: Delivery Successful") || Comment.Contains("Delivery Status: Delivery Queued")) && Comment.Contains("Documents: Fee List"))
                {
                    Reports.StatusUpdate("FeeEntry Delivery Successful", true);
                }
                else Reports.StatusUpdate("FeeEntry Delivery Failed", false);
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { FastDriver.WebDriver.Quit(); }
        }


        [TestMethod]
        public void REG0005_WintrackDelivery()
        {
            try
            {
                Reports.TestDescription = "Validate WintrackDelivery web method";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.Source = "WINTRACK";
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a WinTrack file using web service.";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                string fileNum = FileService.GetOrderDetails(fileId).FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(fileNum);

                Reports.TestStep = "Add a Form document to the file (WS)";
                var templateReq = FileRequestFactory.GetDocTemplatesDefaultRequest();
                templateReq.DocTemplateTypeCdID = 10; //Form
                var templateRes = FileService.GetDocTemplates(templateReq);
                int templateID = Convert.ToInt32(templateRes.Templates[0].TemplateID);
                string templateName = templateRes.Templates[0].Descr;
                int docID = (int)DocumentsHelpers.CreateDocument(fileId, templateID).DocumentID;

                Reports.TestStep = "Invoke WintrackDelivery web method and validate response (WS)";
                FASTWCFHelpers.FastDocumentService.DocumentList[] docs = new FASTWCFHelpers.FastDocumentService.DocumentList[]
                {
                    new FASTWCFHelpers.FastDocumentService.DocumentList
                    {
                        DocumentID = docID
                    }
                };
                var request = DocumentRequestFactory.GetWintrackDeliveryRequest(fileId, docs);
                var response = WebServices.Helpers.Documents.DeliveryHelpers.WintrackDelivery(request);
                Support.AreEqual("1", response.Status.ToString(), "Status");
                Support.AreEqual("WINTRACK Delivery Request Posted Successfully.", response.StatusDescription, "Status Description");

                Reports.TestStep = "Navigate to Event Tracking Log, validate [Interface Doc Delivery] event";
                FastDriver.EventTrackingLog.Open();
                FastDriver.EventTrackingLog.SelectEventCategory("Doc Delivery");
                Support.AreEqual("File Number: " + fileNum + " User Name: User, Super Documents: " + templateName + " Delivery Method: WINTRACK Delivery Status: Delivery Successful", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Interface Doc Delivery]", 5, TableAction.GetText).Message.Clean(), "[Interface Doc Delivery]");

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { FastDriver.WebDriver.Quit(); }
        }



        [TestMethod]
        public void REG0006_LACOMDelivery()
        {
            try
            {
                Reports.TestDescription = "Validate LACOMDelivery web method";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.Source = "LA.COM";
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a LA.COM file using web service.";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                string fileNum = FileService.GetOrderDetails(fileId).FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(fileNum);

                Reports.TestStep = "Add a Form document to the file (WS)";
                var templateReq = FileRequestFactory.GetDocTemplatesDefaultRequest();
                templateReq.DocTemplateTypeCdID = 10; //Form
                var templateRes = FileService.GetDocTemplates(templateReq);
                int templateID = Convert.ToInt32(templateRes.Templates[0].TemplateID);
                string templateName = templateRes.Templates[0].Descr;
                int docID = (int)DocumentsHelpers.CreateDocument(fileId, templateID).DocumentID;

                Reports.TestStep = "Invoke LACOMDelivery web method and validate response (WS)";
                FASTWCFHelpers.FastDocumentService.DocumentList[] docs = new FASTWCFHelpers.FastDocumentService.DocumentList[]
                {
                    new FASTWCFHelpers.FastDocumentService.DocumentList
                    {
                        DocumentID = docID
                    }
                };
                var request = DocumentRequestFactory.GetLACOMDeliveryRequest(fileId, docs);
                var response = WebServices.Helpers.Documents.DeliveryHelpers.LACOMDelivery(request);
                Support.AreEqual("1", response.Status.ToString(), "Status");
                Support.AreEqual("LA.COM Delivery Request Posted Successfully.", response.StatusDescription, "Status Description");

                Reports.TestStep = "Navigate to Event Tracking Log, validate [Interface Doc Delivery] event";
                FastDriver.EventTrackingLog.Open();
                FastDriver.EventTrackingLog.SelectEventCategory("Doc Delivery");
                Support.AreEqual("File Number: " + fileNum + " User Name: User, Super Documents: " + templateName + " Delivery Method: LA.COM Delivery Status: Delivery Successful", FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Interface Doc Delivery]", 5, TableAction.GetText).Message.Clean(), "[Interface Doc Delivery]");

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { FastDriver.WebDriver.Quit(); }
        }


        #region Private class methods

        private void Login(string url = null)
        {
            var credentials = new Credentials()
            {
                UserName = AutoConfig.UserName,
                Password = AutoConfig.UserPassword
            };

            FASTLogin.Login(url ?? AutoConfig.FASTHomeURL, credentials, true);
        }


        #endregion

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
