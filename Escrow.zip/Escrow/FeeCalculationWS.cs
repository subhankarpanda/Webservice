﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebServices.Helpers.Escrow;

namespace WebServices.Escrow
{
    [CodedUITest]
    public class FeeCalculationWS:MasterTestClass
    {
        [TestMethod]
        public void REG0001_GetCalculatedFee()
        {
            Reports.TestDescription = "Verify the GetCalculationFees (escrow) web service.";
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = FileRequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                #endregion

                #region Login to the FAST Application and create one file using web service.
                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a file using web service";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                string fileNum = FileService.GetOrderDetails(fileId).FileNumber;

                Reports.TestStep = "Open the newly created file in FAST application.";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNum);
                #endregion

                #region Navigate to the File Fees page and calculate for the title and endorsements fees.
                Reports.TestStep = "Navigate to the File Fees page.";
                FastDriver.FileFees.Open();

                Reports.TestStep = "Select the title and endorsement check box and click on the calculate fee button.";
                FastDriver.FileFees.SelectTitleAndEndorsementFees();
                FastDriver.FileFees.CalculateFees.FAClick();
                FastDriver.CalculateFees.waitForScreenToLoad(FastDriver.CalculateFees.AddEndorsementWOProductBtn);

                Reports.TestStep = "Add Title Product and click on the next button.";
                FastDriver.CalculateFees.SelectTitleProduct("ALTA Expanded (Eagle Loan) Policy");
                FastDriver.CalculateFees.PerformAddTitleProducts();
                FastDriver.CalculateFees.ClickNext();

                Reports.TestStep = "Add the Summary and complete the details.";
                FastDriver.CalculateFees.WaitForCalculationSummaryScreenToLoad();
                FastDriver.CalculateFees.SummaryFastFeeDescription.FASelectItemByIndex(2);
                FastDriver.CalculateFees.SummaryChargeTo.FASelectItemByIndex(2);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Invoke the GetCalculateFee Webservice.
                Reports.TestStep = "Invoke the GetCalculate webservice.";
                var response = FeeCalculationHelper.GetFeeCalculationSummaryDetail(fileId);
                #endregion

                #region Navigate to the File Fee summary page and verify the response in FAST Application.
                Reports.TestStep = "Navigate to the File Fee summary page and verify the response in FAST Application.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.CalculateFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Calculate Fees Summary");
                FastDriver.CalculateFees.WaitForCalculationSummaryScreenToLoad();

                Reports.TestStep = "Verify the Summary table value with the response in FAST application.";
                ServiceHelper.CompareWithUI(FastDriver.CalculateFees.SummaryTable.PerformTableAction(2, 1, TableAction.GetCell).Element, "value", response.FACCCalculationSummary[0].FACCFeeDescription);
                ServiceHelper.CompareWithUI(FastDriver.CalculateFees.SummaryTable.PerformTableAction(2, 3, TableAction.GetCell).Element, "value", string.Format("{0:0.00}", response.FACCCalculationSummary[0].CalculatedRate));
                ServiceHelper.CompareWithUI(FastDriver.CalculateFees.SummaryTable.PerformTableAction(2, 4, TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "select"), "Selecteditem", response.FACCCalculationSummary[0].FASTFeeDescription);
                ServiceHelper.CompareWithUI(FastDriver.CalculateFees.SummaryTable.PerformTableAction(2, 5, TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "select"), "selecteditem", response.FACCCalculationSummary[0].ChargeTo);
                ServiceHelper.CompareWithUI(FastDriver.CalculateFees.SummaryTable.PerformTableAction(2, 6, TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "select"), "selecteditem", response.FACCCalculationSummary[0].OverrideReason);
                ServiceHelper.CompareWithUI(FastDriver.CalculateFees.SummaryTable.PerformTableAction(2, 7, TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "input"), "text", string.Format("{0:0.00}", response.FACCCalculationSummary[0].OverrideAmount));
                ServiceHelper.CompareWithUI(FastDriver.CalculateFees.SummaryTable.PerformTableAction(2, 8, TableAction.GetCell).Element.FAFindElement(ByLocator.TagName,"input"), "value",string.Format("{0:0.00}",  response.FACCCalculationSummary[0].SplitPercentage));
                ServiceHelper.CompareWithUI(FastDriver.CalculateFees.SummaryTable.PerformTableAction(2, 9, TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "input"), "value", string.Format("{0:0.00}", response.FACCCalculationSummary[0].SplitAmount));
                ServiceHelper.CompareWithUI(FastDriver.CalculateFees.SummaryTable.PerformTableAction(2, 10, TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "input"), "value", string.Format("{0:0.00}", response.FACCCalculationSummary[0].BuyerCharge));
                ServiceHelper.CompareWithUI(FastDriver.CalculateFees.SummaryTable.PerformTableAction(2, 11, TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "input"), "value", string.Format("{0:0.00}", response.FACCCalculationSummary[0].SellerCharge));
                ServiceHelper.CompareWithUI(FastDriver.CalculateFees.SummaryTable.PerformTableAction(2, 12, TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "input"), "value", string.Format("{0:0.00}", response.FACCCalculationSummary[0].TotalCharge));

                Reports.TestStep = "Verify the Title products and endorsement details with the response.";
                ServiceHelper.CompareWithUI(FastDriver.CalculateFees.TitleProductAndEndrsmntTable.PerformTableAction(2, 1, TableAction.GetCell).Element, "value", response.titleProductsWithEndorsements[0].Group);
                ServiceHelper.CompareWithUI(FastDriver.CalculateFees.TitleProductAndEndrsmntTable.PerformTableAction(2, 2, TableAction.GetCell).Element, "value", response.titleProductsWithEndorsements[0].EffectiveDate);
                ServiceHelper.CompareWithUI(FastDriver.CalculateFees.TitleProductAndEndrsmntTable.PerformTableAction(2, 3, TableAction.GetCell).Element, "value", response.titleProductsWithEndorsements[0].TitlePolicyName);
                ServiceHelper.CompareWithUI(FastDriver.CalculateFees.TitleProductAndEndrsmntTable.PerformTableAction(2, 4, TableAction.GetCell).Element, "value", response.titleProductsWithEndorsements[0].RateTypeDescr);
                ServiceHelper.CompareWithUI(FastDriver.CalculateFees.TitleProductAndEndrsmntTable.PerformTableAction(2, 5, TableAction.GetText).Message,string.Format("{0:0.00}", response.titleProductsWithEndorsements[0].LiabAmount),true,false);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally { FastDriver.WebDriver.Quit(); }
        }

        [TestMethod]
        public void REG0002_GetFileFeeDescription()
        {
            Reports.TestDescription = "Verify the GetFileFeeDescription (escrow) webservice.";
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = FileRequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";
                #endregion

                #region Login to the FAST Application and create one file using web service.
                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a file using web service";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                string fileNum = FileService.GetOrderDetails(fileId).FileNumber;

                Reports.TestStep = "Open the newly created file in FAST application.";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNum);
                #endregion

                #region Navigate to the File Fees page and calculate for the title and endorsements fees.
                Reports.TestStep = "Navigate to the File Fees page.";
                FastDriver.FileFees.Open();

                Reports.TestStep = "Select the title and endorsement check box and click on the calculate fee button.";
                FastDriver.FileFees.SelectTitleAndEndorsementFees();
                FastDriver.FileFees.CalculateFees.FAClick();
                FastDriver.CalculateFees.waitForScreenToLoad(FastDriver.CalculateFees.AddEndorsementWOProductBtn);

                Reports.TestStep = "Add Title Product and click on the next button.";
                FastDriver.CalculateFees.SelectTitleProduct("ALTA Expanded (Eagle Loan) Policy");
                FastDriver.CalculateFees.PerformAddTitleProducts();
                FastDriver.CalculateFees.ClickNext();

                Reports.TestStep = "Add the Summary and complete the details.";
                FastDriver.CalculateFees.WaitForCalculationSummaryScreenToLoad();
                FastDriver.CalculateFees.SummaryFastFeeDescription.FASelectItemByIndex(2);
                FastDriver.CalculateFees.SummaryChargeTo.FASelectItemByIndex(2);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Invoke the GetCalculateFee Webservice.
                Reports.TestStep = "Invoke the GetCalculate webservice.";
                var response = FeeCalculationHelper.GetFeeCalculationSummaryDetail(fileId);
                #endregion

                #region Get the GetFileFeeDescription request and update it for the existing fees.
                Reports.TestStep = "Get the GetFileFeeDescription request and update it for the existing fees.";
                var request = EscrowRequestFactory.GetFastFeeDescriptionRequest(fileId, response.FACCCalculationSummary[0].FASTFeeDescription);
                request.FeeDescriptionInputParamLists[0].FASTProductCategory = response.FACCCalculationSummary[0].FASTProductCategory;
                request.FeeDescriptionInputParamLists[0].FACCKey = "470";
                request.FeeDescriptionInputParamLists[0].FeeCalcTypeCDID = response.FACCCalculationSummary[0].FeeCalcTypeCdID;
                request.FeeDescriptionInputParamLists[0].FeeID = response.FACCCalculationSummary[0].FeeID;
                request.FeeDescriptionInputParamLists[0].FeeTypeCDID = response.FACCCalculationSummary[0].FeeTypeCdID;
                #endregion

                #region Inovke the GetFastFeeDescription webservice and validate the response.
                Reports.TestStep = "Inovke the GetFastFeeDescription webservice and validate the response.";
                var response1 = FeeCalculationHelper.GetFastFeeDescription(request);
                #endregion

                #region Verify the responses in FAST application.
                Reports.TestStep = "Verify the responses in FAST application.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.CalculateFees>("Home>Order Entry>Title/Escrow Fees>Fee Entry>Calculate Fees Summary");
                FastDriver.CalculateFees.WaitForCalculationSummaryScreenToLoad();
                var feeOption=FastDriver.CalculateFees.SummaryTable.PerformTableAction(2, 4, TableAction.GetCell).Element.FAFindElement(ByLocator.TagName, "Select").FAGetDropdownOptions();

                Reports.TestStep = "Verify the Fee Description count available in UI.";
                ServiceHelper.CompareWithUI(response1.FastFeeDescriptionDetailsList[0].FeeDescriptionDetailsLists.Length.ToString(), feeOption.Count.ToString());

                Reports.TestStep = "Verify the fee descriptions of available in UI.";
                for(int i=0;i<response1.FastFeeDescriptionDetailsList[0].FeeDescriptionDetailsLists.Length;i++)
                {
                    ServiceHelper.CompareWithUI(response1.FastFeeDescriptionDetailsList[0].FeeDescriptionDetailsLists[i].FASTFeeDecsription, feeOption[i].FAGetText());
                }

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally { FastDriver.WebDriver.Quit(); }
        }
    }
}
