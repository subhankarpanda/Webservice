﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;




namespace WebServices.Escrow
{
    [CodedUITest]
    public class AdjustmentsWS : MasterTestClass
    {
        [TestMethod]
        public void REG0001_GetAdjustmentDetails()
        {
            try
            {
                Reports.TestDescription = "Verify UpdateAdjustment_Miscellaneous service";

                #region data setup
                string desc1 = "TestDesc Misc Create";
                string desc2 = "TestDesc OffSet Create";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetDetailedCreateFileDefaultRequest();
                #endregion

                #region Login and Create File
                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a file using web service";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                string fileNum = FileService.GetOrderDetails(fileId).FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(fileNum);
                #endregion

                #region Navigate to Miscellaneous Adjustments and fill in the charges
                Reports.TestStep = "Navigate to Miscellaneous Adjustments and fill in the charges";

                FastDriver.AdjustmentMisc.Open();
                FastDriver.AdjustmentMisc.AddCharge(FastDriver.AdjustmentMisc.miscellaneousAdjustmentTable, desc1, 11.11, 22.22, 33.33, 44.44);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to OffSet Adjustments and fill in the charges
                Reports.TestStep = "Navigate to OffSet Adjustments and fill in the charges";

                FastDriver.AdjustmentOffset.Open();
                FastDriver.AdjustmentOffset.AddOffsetCharges(desc2, 55.55, 66.66, 77.77, 88.88);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Invoke GetAdjustmentDetails service with proper input parameters and verify the response.
                Reports.TestStep = "Invoke GetAdjustmentDetails service with proper input parameters";
                var request = EscrowRequestFactory.GetServiceFileRequest(fileId);
                var response = EscrowService.GetAdjustmentDetails(request);

                Reports.TestStep = "Verify the response of GetAdjustmentDetails operation.";
                Reports.StatusUpdate("Is status == 1 in the response ?", Convert.ToInt16(response.Status).Equals(1));
                Reports.StatusUpdate("Is the status description as expected in the response ?", response.StatusDescription.ToString().Contains("GetAdjustmentDetails operation is succeed."));
                #endregion

                #region Misc variables validation

                Reports.TestStep = "Validate the Miscellaneous adjustment charges.";
                int offSetChargeCount = 0;
                int miscChargeCount = 0;
                if (AutoConfig.FormType == "HUD")
                {
                    offSetChargeCount = response.OffSet.ChargeList.Length;
                    miscChargeCount = response.Misc.ChargeList.Length;
                }
                else
                {
                    offSetChargeCount = response.OffSet.CDChargeList.Length;
                    miscChargeCount = response.Misc.CDChargeList.Length;
                }

                FastDriver.AdjustmentMisc.Open();
                ServiceHelper.CompareWithUI(FastDriver.AdjustmentMisc.BuyerTotal, "value", response.Misc.BuyerTotal.ToString(), true, true);
                ServiceHelper.CompareWithUI(FastDriver.AdjustmentMisc.SellerTotal, "value", response.Misc.SellerTotal.ToString(), true, true);

                if (AutoConfig.FormType == "HUD")
                {
                    ServiceHelper.CompareWithUI(desc1, response.Misc.ChargeList[miscChargeCount - 1].Description.ToString().Trim().ToLower(), true, true);
                    ServiceHelper.CompareWithUI(FastDriver.AdjustmentMisc.miscellaneousAdjustmentTable.PerformTableAction("Description", desc1, "Buyer Charge", TableAction.GetInputValue).Message.ToString(), response.Misc.ChargeList[miscChargeCount - 1].BuyerCharge.ToString(), true, true);
                    ServiceHelper.CompareWithUI(FastDriver.AdjustmentMisc.miscellaneousAdjustmentTable.PerformTableAction("Description", desc1, "Buyer Credit", TableAction.GetInputValue).Message.ToString(), response.Misc.ChargeList[miscChargeCount - 1].BuyerCredit.ToString(), true, true);
                    ServiceHelper.CompareWithUI(FastDriver.AdjustmentMisc.miscellaneousAdjustmentTable.PerformTableAction("Description", desc1, "Seller Charge", TableAction.GetInputValue).Message.ToString(), response.Misc.ChargeList[miscChargeCount - 1].SellerCharge.ToString(), true, true);
                    ServiceHelper.CompareWithUI(FastDriver.AdjustmentMisc.miscellaneousAdjustmentTable.PerformTableAction("Description", desc1, "Seller Credit", TableAction.GetInputValue).Message.ToString(), response.Misc.ChargeList[miscChargeCount - 1].SellerCredit.ToString(), true, true);
                }
                else
                {
                    ServiceHelper.CompareWithUI(desc1, response.Misc.CDChargeList[miscChargeCount - 1].Description.ToString().Trim().ToLower(), true, true);
                    ServiceHelper.CompareWithUI(FastDriver.AdjustmentMisc.miscellaneousAdjustmentTable.PerformTableAction("Description", desc1, "Buyer Charge", TableAction.GetInputValue).Message.ToString(), response.Misc.CDChargeList[miscChargeCount - 1].BuyerCharge.ToString(), true, true);
                    ServiceHelper.CompareWithUI(FastDriver.AdjustmentMisc.miscellaneousAdjustmentTable.PerformTableAction("Description", desc1, "Buyer Credit", TableAction.GetInputValue).Message.ToString(), response.Misc.CDChargeList[miscChargeCount - 1].BuyerCredit.ToString(), true, true);
                    ServiceHelper.CompareWithUI(FastDriver.AdjustmentMisc.miscellaneousAdjustmentTable.PerformTableAction("Description", desc1, "Seller Charge", TableAction.GetInputValue).Message.ToString(), response.Misc.CDChargeList[miscChargeCount - 1].SellerCharge.ToString(), true, true);
                    ServiceHelper.CompareWithUI(FastDriver.AdjustmentMisc.miscellaneousAdjustmentTable.PerformTableAction("Description", desc1, "Seller Credit", TableAction.GetInputValue).Message.ToString(), response.Misc.CDChargeList[miscChargeCount - 1].SellerCredit.ToString(), true, true);
                }
                #endregion

                #region OffSet variables validation
                Reports.TestStep = "Validate the Offset adjustment charges.";
                FastDriver.AdjustmentOffset.Open();
                ServiceHelper.CompareWithUI(FastDriver.AdjustmentOffset.BuyerTotal, "value", response.OffSet.BuyerTotal.ToString(), true, true);
                ServiceHelper.CompareWithUI(FastDriver.AdjustmentOffset.SellerTotal, "value", response.OffSet.SellerTotal.ToString(), true, true);

                if (AutoConfig.FormType == "HUD")
                {
                    ServiceHelper.CompareWithUI(desc2, response.OffSet.ChargeList[offSetChargeCount - 1].Description.ToString().Trim().ToLower(), true, true);
                    ServiceHelper.CompareWithUI(FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction("Description", desc2, "Buyer Charge", TableAction.GetInputValue).Message.ToString(), response.OffSet.ChargeList[offSetChargeCount - 1].BuyerCharge.ToString(), true, true);
                    ServiceHelper.CompareWithUI(FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction("Description", desc2, "Buyer Credit", TableAction.GetInputValue).Message.ToString(), response.OffSet.ChargeList[offSetChargeCount - 1].BuyerCredit.ToString(), true, true);
                    ServiceHelper.CompareWithUI(FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction("Description", desc2, "Seller Charge", TableAction.GetInputValue).Message.ToString(), response.OffSet.ChargeList[offSetChargeCount - 1].SellerCharge.ToString(), true, true);
                    ServiceHelper.CompareWithUI(FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction("Description", desc2, "Seller Credit", TableAction.GetInputValue).Message.ToString(), response.OffSet.ChargeList[offSetChargeCount - 1].SellerCredit.ToString(), true, true);
                }
                else
                {
                    ServiceHelper.CompareWithUI(desc2, response.OffSet.CDChargeList[offSetChargeCount - 1].Description.ToString().Trim().ToLower(), true, true);
                    ServiceHelper.CompareWithUI(FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction("Description", desc2, "Buyer Charge", TableAction.GetInputValue).Message.ToString(), response.OffSet.CDChargeList[offSetChargeCount - 1].BuyerCharge.ToString(), true, true);
                    ServiceHelper.CompareWithUI(FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction("Description", desc2, "Buyer Credit", TableAction.GetInputValue).Message.ToString(), response.OffSet.CDChargeList[offSetChargeCount - 1].BuyerCredit.ToString(), true, true);
                    ServiceHelper.CompareWithUI(FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction("Description", desc2, "Seller Charge", TableAction.GetInputValue).Message.ToString(), response.OffSet.CDChargeList[offSetChargeCount - 1].SellerCharge.ToString(), true, true);
                    ServiceHelper.CompareWithUI(FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction("Description", desc2, "Seller Credit", TableAction.GetInputValue).Message.ToString(), response.OffSet.CDChargeList[offSetChargeCount - 1].SellerCredit.ToString(), true, true);
                }
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally { FastDriver.WebDriver.Quit(); }
        }

        [TestMethod]
        public void REG0002_UpdateAdjustment_Miscellaneous()
        {
            try
            {
                Reports.TestDescription = "Verify UpdateAdjustment_Miscellaneous service";

                #region data setup
                string desc1 = "TestDesc Misc Create";
                string desc2 = "TestDesc OffSet Create";
                string desc3 = "TestDesc Misc Update";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetDetailedCreateFileDefaultRequest();
                #endregion

                #region Login and Create File
                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a file using web service";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                string fileNum = FileService.GetOrderDetails(fileId).FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(fileNum);
                #endregion

                #region Navigate to Miscellaneous Adjustments and fill in the charges
                Reports.TestStep = "Navigate to Miscellaneous Adjustments and fill in the charges";

                FastDriver.AdjustmentMisc.Open();
                FastDriver.AdjustmentMisc.AddCharge(FastDriver.AdjustmentMisc.miscellaneousAdjustmentTable, desc1, 11.11, 22.22, 33.33, 44.44);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to OffSet Adjustments and fill in the charges
                Reports.TestStep = "Navigate to OffSet Adjustments and fill in the charges";

                FastDriver.AdjustmentOffset.Open();
                FastDriver.AdjustmentOffset.AddOffsetCharges(desc2, 55.55, 66.66, 77.77, 88.88);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Invoke GetAdjustmentDetails service with proper input parameters and verify the response.
                Reports.TestStep = "Invoke GetAdjustmentDetails service with proper input parameters";
                var request = EscrowRequestFactory.GetServiceFileRequest(fileId);
                var response = EscrowService.GetAdjustmentDetails(request);

                int offSetChargeCount = 0;
                int miscChargeCount = 0;
                int MiscSeqNum = 0;
                int OffsetSeqNum = 0;
                if (AutoConfig.FormType == "HUD")
                {
                    offSetChargeCount = response.OffSet.ChargeList.Length;
                    miscChargeCount = response.Misc.ChargeList.Length;
                }
                else
                {
                    offSetChargeCount = response.OffSet.CDChargeList.Length;
                    miscChargeCount = response.Misc.CDChargeList.Length;
                }

                if (AutoConfig.FormType == "HUD")
                {
                    MiscSeqNum = response.Misc.ChargeList[miscChargeCount - 1].SeqNum.Value;
                    OffsetSeqNum = response.OffSet.ChargeList[offSetChargeCount - 1].SeqNum.Value;
                }
                else
                {
                    MiscSeqNum = response.Misc.CDChargeList[miscChargeCount - 1].SeqNum.Value;
                    OffsetSeqNum = response.OffSet.CDChargeList[offSetChargeCount - 1].SeqNum.Value;
                }


                Reports.TestStep = "Verify the response of GetAdjustmentDetails operation.";
                Reports.StatusUpdate("Is status == 1 in the response ?", Convert.ToInt16(response.Status).Equals(1));
                Reports.StatusUpdate("Is the status description as expected in the response ?", response.StatusDescription.ToString().Contains("GetAdjustmentDetails operation is succeed."));

                Reports.TestStep = "Invoke UpdateAdjustment service with proper input parameters";
                var Updaterequest = EscrowRequestFactory.GetAdjustmentRequest(fileId, FASTWCFHelpers.FastEscrowService.AdjustmentType.Miscellaneous);
                Updaterequest.ChargeList = new FASTWCFHelpers.FastEscrowService.ChargeSet[]
                {
                    EscrowRequestFactory.GetChargeSet(MiscSeqNum, bCharge:(decimal)111.11, bCredit:(decimal)222.22, sCharge:(decimal)333.33, sCredit:(decimal)444.44, desc:desc3),
                };
                var Updateresponse = EscrowService.UpdateAdjustments(Updaterequest);

                Reports.TestStep = "Verify the response of GetAdjustmentDetails operation.";
                Reports.StatusUpdate("Is status == 1 in the response ?", Convert.ToInt16(response.Status).Equals(1));
                Reports.StatusUpdate("Is the status description as expected in the response ?", Updateresponse.StatusDescription.ToString().Contains("Adjustments of type MISCELLANEOUS saved successfully"));

                var requestAfterUpdate = EscrowRequestFactory.GetServiceFileRequest(fileId);
                var responseAfterUpdate = EscrowService.GetAdjustmentDetails(requestAfterUpdate);
                #endregion

                #region Misc variables validation
                Reports.TestStep = "Validate the Updated Miscellaneous adjustment charges.";
                FastDriver.AdjustmentMisc.Open();
                ServiceHelper.CompareWithUI(FastDriver.AdjustmentMisc.BuyerTotal, "value", responseAfterUpdate.Misc.BuyerTotal.ToString(), true, true);
                ServiceHelper.CompareWithUI(FastDriver.AdjustmentMisc.SellerTotal, "value", responseAfterUpdate.Misc.SellerTotal.ToString(), true, true);

                if (AutoConfig.FormType == "HUD")
                {
                    ServiceHelper.CompareWithUI(desc3, responseAfterUpdate.Misc.ChargeList[miscChargeCount - 1].Description.ToString().Trim().ToLower(), true, true);
                    ServiceHelper.CompareWithUI(FastDriver.AdjustmentMisc.miscellaneousAdjustmentTable.PerformTableAction("Description", desc3, "Buyer Charge", TableAction.GetInputValue).Message.ToString(), responseAfterUpdate.Misc.ChargeList[miscChargeCount - 1].BuyerCharge.ToString(), true, true);
                    ServiceHelper.CompareWithUI(FastDriver.AdjustmentMisc.miscellaneousAdjustmentTable.PerformTableAction("Description", desc3, "Buyer Credit", TableAction.GetInputValue).Message.ToString(), responseAfterUpdate.Misc.ChargeList[miscChargeCount - 1].BuyerCredit.ToString(), true, true);
                    ServiceHelper.CompareWithUI(FastDriver.AdjustmentMisc.miscellaneousAdjustmentTable.PerformTableAction("Description", desc3, "Seller Charge", TableAction.GetInputValue).Message.ToString(), responseAfterUpdate.Misc.ChargeList[miscChargeCount - 1].SellerCharge.ToString(), true, true);
                    ServiceHelper.CompareWithUI(FastDriver.AdjustmentMisc.miscellaneousAdjustmentTable.PerformTableAction("Description", desc3, "Seller Credit", TableAction.GetInputValue).Message.ToString(), responseAfterUpdate.Misc.ChargeList[miscChargeCount - 1].SellerCredit.ToString(), true, true);
                }
                else
                {
                    ServiceHelper.CompareWithUI(desc3, responseAfterUpdate.Misc.CDChargeList[miscChargeCount - 1].Description.ToString().Trim().ToLower(), true, true);
                    ServiceHelper.CompareWithUI(FastDriver.AdjustmentMisc.miscellaneousAdjustmentTable.PerformTableAction("Description", desc3, "Buyer Charge", TableAction.GetInputValue).Message.ToString(), responseAfterUpdate.Misc.CDChargeList[miscChargeCount - 1].BuyerCharge.ToString(), true, true);
                    ServiceHelper.CompareWithUI(FastDriver.AdjustmentMisc.miscellaneousAdjustmentTable.PerformTableAction("Description", desc3, "Buyer Credit", TableAction.GetInputValue).Message.ToString(), responseAfterUpdate.Misc.CDChargeList[miscChargeCount - 1].BuyerCredit.ToString(), true, true);
                    ServiceHelper.CompareWithUI(FastDriver.AdjustmentMisc.miscellaneousAdjustmentTable.PerformTableAction("Description", desc3, "Seller Charge", TableAction.GetInputValue).Message.ToString(), responseAfterUpdate.Misc.CDChargeList[miscChargeCount - 1].SellerCharge.ToString(), true, true);
                    ServiceHelper.CompareWithUI(FastDriver.AdjustmentMisc.miscellaneousAdjustmentTable.PerformTableAction("Description", desc3, "Seller Credit", TableAction.GetInputValue).Message.ToString(), responseAfterUpdate.Misc.CDChargeList[miscChargeCount - 1].SellerCredit.ToString(), true, true);

                }
                #endregion

                #region OffSet variables validation
                Reports.TestStep = "Validate the Original Offset adjustment charges.";
                FastDriver.AdjustmentOffset.Open();
                ServiceHelper.CompareWithUI(FastDriver.AdjustmentOffset.BuyerTotal, "value", response.OffSet.BuyerTotal.ToString(), true, true);
                ServiceHelper.CompareWithUI(FastDriver.AdjustmentOffset.SellerTotal, "value", response.OffSet.SellerTotal.ToString(), true, true);

                if (AutoConfig.FormType == "HUD")
                {
                    ServiceHelper.CompareWithUI(desc2, response.OffSet.ChargeList[offSetChargeCount - 1].Description.ToString().Trim().ToLower(), true, true);
                    ServiceHelper.CompareWithUI(FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction("Description", desc2, "Buyer Charge", TableAction.GetInputValue).Message.ToString(), response.OffSet.ChargeList[offSetChargeCount - 1].BuyerCharge.ToString(), true, true);
                    ServiceHelper.CompareWithUI(FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction("Description", desc2, "Buyer Credit", TableAction.GetInputValue).Message.ToString(), response.OffSet.ChargeList[offSetChargeCount - 1].BuyerCredit.ToString(), true, true);
                    ServiceHelper.CompareWithUI(FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction("Description", desc2, "Seller Charge", TableAction.GetInputValue).Message.ToString(), response.OffSet.ChargeList[offSetChargeCount - 1].SellerCharge.ToString(), true, true);
                    ServiceHelper.CompareWithUI(FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction("Description", desc2, "Seller Credit", TableAction.GetInputValue).Message.ToString(), response.OffSet.ChargeList[offSetChargeCount - 1].SellerCredit.ToString(), true, true);
                }
                else
                {
                    ServiceHelper.CompareWithUI(desc2, response.OffSet.CDChargeList[offSetChargeCount - 1].Description.ToString().Trim().ToLower(), true, true);
                    ServiceHelper.CompareWithUI(FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction("Description", desc2, "Buyer Charge", TableAction.GetInputValue).Message.ToString(), response.OffSet.CDChargeList[offSetChargeCount - 1].BuyerCharge.ToString(), true, true);
                    ServiceHelper.CompareWithUI(FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction("Description", desc2, "Buyer Credit", TableAction.GetInputValue).Message.ToString(), response.OffSet.CDChargeList[offSetChargeCount - 1].BuyerCredit.ToString(), true, true);
                    ServiceHelper.CompareWithUI(FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction("Description", desc2, "Seller Charge", TableAction.GetInputValue).Message.ToString(), response.OffSet.CDChargeList[offSetChargeCount - 1].SellerCharge.ToString(), true, true);
                    ServiceHelper.CompareWithUI(FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction("Description", desc2, "Seller Credit", TableAction.GetInputValue).Message.ToString(), response.OffSet.CDChargeList[offSetChargeCount - 1].SellerCredit.ToString(), true, true);

                }
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally { FastDriver.WebDriver.Quit(); }
        }

        [TestMethod]
        public void REG0003_UpdateAdjustment_Offset()
        {
            try
            {
                Reports.TestDescription = "Verify UpdateAdjustment_Offset service";

                #region data setup
                string desc1 = "TestDesc Misc Create";
                string desc2 = "TestDesc OffSet Create";
                string desc3 = "TestDesc OffSet Update";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetDetailedCreateFileDefaultRequest();
                #endregion

                #region Login and Create File
                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a file using web service";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                string fileNum = FileService.GetOrderDetails(fileId).FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(fileNum);
                #endregion

                #region Navigate to Miscellaneous Adjustments and fill in the charges
                Reports.TestStep = "Navigate to Miscellaneous Adjustments and fill in the charges";

                FastDriver.AdjustmentMisc.Open();
                FastDriver.AdjustmentMisc.AddCharge(FastDriver.AdjustmentMisc.miscellaneousAdjustmentTable, desc1, 11.11, 22.22, 33.33, 44.44);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Navigate to OffSet Adjustments and fill in the charges
                Reports.TestStep = "Navigate to OffSet Adjustments and fill in the charges";

                FastDriver.AdjustmentOffset.Open();
                FastDriver.AdjustmentOffset.AddOffsetCharges(desc2, 55.55, 66.66, 77.77, 88.88);
                FastDriver.BottomFrame.Done();
                #endregion

                #region Invoke GetAdjustmentDetails service with proper input parameters and verify the response.
                Reports.TestStep = "Invoke GetAdjustmentDetails service with proper input parameters";
                var request = EscrowRequestFactory.GetServiceFileRequest(fileId);
                var response = EscrowService.GetAdjustmentDetails(request);

                int offSetChargeCount = 0;
                int miscChargeCount = 0;
                int MiscSeqNum = 0;
                int OffsetSeqNum = 0;
                if (AutoConfig.FormType == "HUD")
                {
                    offSetChargeCount = response.OffSet.ChargeList.Length;
                    miscChargeCount = response.Misc.ChargeList.Length;
                }
                else
                {
                    offSetChargeCount = response.OffSet.CDChargeList.Length;
                    miscChargeCount = response.Misc.CDChargeList.Length;
                }

                if (AutoConfig.FormType == "HUD")
                {
                    MiscSeqNum = response.Misc.ChargeList[miscChargeCount - 1].SeqNum.Value;
                    OffsetSeqNum = response.OffSet.ChargeList[offSetChargeCount - 1].SeqNum.Value;
                }
                else
                {
                    MiscSeqNum = response.Misc.CDChargeList[miscChargeCount - 1].SeqNum.Value;
                    OffsetSeqNum = response.OffSet.CDChargeList[offSetChargeCount - 1].SeqNum.Value;
                }

                Reports.TestStep = "Verify the response of GetAdjustmentDetails operation.";
                Reports.StatusUpdate("Is status == 1 in the response ?", Convert.ToInt16(response.Status).Equals(1));
                Reports.StatusUpdate("Is the status description as expected in the response ?", response.StatusDescription.ToString().Contains("GetAdjustmentDetails operation is succeed."));

                Reports.TestStep = "Invoke UpdateAdjustment service with proper input parameters";
                var Updaterequest = EscrowRequestFactory.GetAdjustmentRequest(fileId, FASTWCFHelpers.FastEscrowService.AdjustmentType.Offset);
                Updaterequest.ChargeList = new FASTWCFHelpers.FastEscrowService.ChargeSet[]
                {
                    EscrowRequestFactory.GetChargeSet(OffsetSeqNum, bCharge:(decimal)555.55, bCredit:(decimal)666.66, sCharge:(decimal)777.77, sCredit:(decimal)888.88, desc:desc3),
                };
                var Updateresponse = EscrowService.UpdateAdjustments(Updaterequest);

                Reports.TestStep = "Verify the response of GetAdjustmentDetails operation.";
                Reports.StatusUpdate("Is status == 1 in the response ?", Convert.ToInt16(response.Status).Equals(1));
                Reports.StatusUpdate("Is the status description as expected in the response ?", Updateresponse.StatusDescription.ToString().Contains("Adjustments of type OFFSET saved successfully"));

                var requestAfterUpdate = EscrowRequestFactory.GetServiceFileRequest(fileId);
                var responseAfterUpdate = EscrowService.GetAdjustmentDetails(requestAfterUpdate);
                #endregion

                #region Offset variables validation
                Reports.TestStep = "Validate the Updated Offset adjustment charges.";
                FastDriver.AdjustmentOffset.Open();
                ServiceHelper.CompareWithUI(FastDriver.AdjustmentOffset.BuyerTotal, "value", responseAfterUpdate.OffSet.BuyerTotal.ToString(), true, true);
                ServiceHelper.CompareWithUI(FastDriver.AdjustmentOffset.SellerTotal, "value", responseAfterUpdate.OffSet.SellerTotal.ToString(), true, true);

                if (AutoConfig.FormType == "HUD")
                {
                    ServiceHelper.CompareWithUI(desc3, responseAfterUpdate.OffSet.ChargeList[offSetChargeCount - 1].Description.ToString().Trim().ToLower(), true, true);
                    ServiceHelper.CompareWithUI(FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction("Description", desc3, "Buyer Charge", TableAction.GetInputValue).Message.ToString(), responseAfterUpdate.OffSet.ChargeList[offSetChargeCount - 1].BuyerCharge.ToString(), true, true);
                    ServiceHelper.CompareWithUI(FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction("Description", desc3, "Buyer Credit", TableAction.GetInputValue).Message.ToString(), responseAfterUpdate.OffSet.ChargeList[offSetChargeCount - 1].BuyerCredit.ToString(), true, true);
                    ServiceHelper.CompareWithUI(FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction("Description", desc3, "Seller Charge", TableAction.GetInputValue).Message.ToString(), responseAfterUpdate.OffSet.ChargeList[offSetChargeCount - 1].SellerCharge.ToString(), true, true);
                    ServiceHelper.CompareWithUI(FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction("Description", desc3, "Seller Credit", TableAction.GetInputValue).Message.ToString(), responseAfterUpdate.OffSet.ChargeList[offSetChargeCount - 1].SellerCredit.ToString(), true, true);
                }
                else
                {
                    ServiceHelper.CompareWithUI(desc3, responseAfterUpdate.OffSet.CDChargeList[offSetChargeCount - 1].Description.ToString().Trim().ToLower(), true, true);
                    ServiceHelper.CompareWithUI(FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction("Description", desc3, "Buyer Charge", TableAction.GetInputValue).Message.ToString(), responseAfterUpdate.OffSet.CDChargeList[offSetChargeCount - 1].BuyerCharge.ToString(), true, true);
                    ServiceHelper.CompareWithUI(FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction("Description", desc3, "Buyer Credit", TableAction.GetInputValue).Message.ToString(), responseAfterUpdate.OffSet.CDChargeList[offSetChargeCount - 1].BuyerCredit.ToString(), true, true);
                    ServiceHelper.CompareWithUI(FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction("Description", desc3, "Seller Charge", TableAction.GetInputValue).Message.ToString(), responseAfterUpdate.OffSet.CDChargeList[offSetChargeCount - 1].SellerCharge.ToString(), true, true);
                    ServiceHelper.CompareWithUI(FastDriver.AdjustmentOffset.offsetAdjustmentTable.PerformTableAction("Description", desc3, "Seller Credit", TableAction.GetInputValue).Message.ToString(), responseAfterUpdate.OffSet.CDChargeList[offSetChargeCount - 1].SellerCredit.ToString(), true, true);

                }
                #endregion

                #region Misc variables validation

                Reports.TestStep = "Validate the Original Miscellaneous adjustment charges.";

                FastDriver.AdjustmentMisc.Open();
                ServiceHelper.CompareWithUI(FastDriver.AdjustmentMisc.BuyerTotal, "value", response.Misc.BuyerTotal.ToString(), true, true);
                ServiceHelper.CompareWithUI(FastDriver.AdjustmentMisc.SellerTotal, "value", response.Misc.SellerTotal.ToString(), true, true);

                if (AutoConfig.FormType == "HUD")
                {
                    ServiceHelper.CompareWithUI(desc1, response.Misc.ChargeList[miscChargeCount - 1].Description.ToString().Trim().ToLower(), true, true);
                    ServiceHelper.CompareWithUI(FastDriver.AdjustmentMisc.miscellaneousAdjustmentTable.PerformTableAction("Description", desc1, "Buyer Charge", TableAction.GetInputValue).Message.ToString(), response.Misc.ChargeList[miscChargeCount - 1].BuyerCharge.ToString(), true, true);
                    ServiceHelper.CompareWithUI(FastDriver.AdjustmentMisc.miscellaneousAdjustmentTable.PerformTableAction("Description", desc1, "Buyer Credit", TableAction.GetInputValue).Message.ToString(), response.Misc.ChargeList[miscChargeCount - 1].BuyerCredit.ToString(), true, true);
                    ServiceHelper.CompareWithUI(FastDriver.AdjustmentMisc.miscellaneousAdjustmentTable.PerformTableAction("Description", desc1, "Seller Charge", TableAction.GetInputValue).Message.ToString(), response.Misc.ChargeList[miscChargeCount - 1].SellerCharge.ToString(), true, true);
                    ServiceHelper.CompareWithUI(FastDriver.AdjustmentMisc.miscellaneousAdjustmentTable.PerformTableAction("Description", desc1, "Seller Credit", TableAction.GetInputValue).Message.ToString(), response.Misc.ChargeList[miscChargeCount - 1].SellerCredit.ToString(), true, true);
                }
                else
                {
                    ServiceHelper.CompareWithUI(desc1, response.Misc.CDChargeList[miscChargeCount - 1].Description.ToString().Trim().ToLower(), true, true);
                    ServiceHelper.CompareWithUI(FastDriver.AdjustmentMisc.miscellaneousAdjustmentTable.PerformTableAction("Description", desc1, "Buyer Charge", TableAction.GetInputValue).Message.ToString(), response.Misc.CDChargeList[miscChargeCount - 1].BuyerCharge.ToString(), true, true);
                    ServiceHelper.CompareWithUI(FastDriver.AdjustmentMisc.miscellaneousAdjustmentTable.PerformTableAction("Description", desc1, "Buyer Credit", TableAction.GetInputValue).Message.ToString(), response.Misc.CDChargeList[miscChargeCount - 1].BuyerCredit.ToString(), true, true);
                    ServiceHelper.CompareWithUI(FastDriver.AdjustmentMisc.miscellaneousAdjustmentTable.PerformTableAction("Description", desc1, "Seller Charge", TableAction.GetInputValue).Message.ToString(), response.Misc.CDChargeList[miscChargeCount - 1].SellerCharge.ToString(), true, true);
                    ServiceHelper.CompareWithUI(FastDriver.AdjustmentMisc.miscellaneousAdjustmentTable.PerformTableAction("Description", desc1, "Seller Credit", TableAction.GetInputValue).Message.ToString(), response.Misc.CDChargeList[miscChargeCount - 1].SellerCredit.ToString(), true, true);

                }
                #endregion

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally { FastDriver.WebDriver.Quit(); }
        }

        #region PrivateMethods


        #endregion
    }
}
