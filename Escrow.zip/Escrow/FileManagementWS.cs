﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastEscrowService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;
using WebServices.Helpers.Escrow;
using System.Linq;
using FASTSelenium.PageObjects.IIS;
using WebServices.Helpers.File;
using System.Threading;

namespace WebServices.Escrow
{
    [CodedUITest]
    public class FileManagementWS : MasterTestClass
    {
        [TestMethod]
        public void REG0001_AddSubordination()
        {
            try
            {
                Reports.TestDescription = "Verify AddSubordination() Service";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a file using web service";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                var file = FileService.GetOrderDetails(fileId).FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(file);

                var AddSubordinationRequest = EscrowRequestFactory.GetAddSubordinationRequest(fileId);

                Reports.TestStep = "Invoke AddSubordination Service";
                var response = EscrowService.AddSubordination(AddSubordinationRequest);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);

                Reports.TestStep = "Navigate to Subordination Summary";
                FastDriver.Subordination_Summary.Open();

                Reports.TestStep = "Select the created Subordination and click on Edit button";
                FastDriver.Subordination_Summary.SubordinateSummary.PerformTableAction(2, 1, TableAction.Click);
                FastDriver.Subordination_Summary.SubordinateSummaryEdit.FAClick();
                FastDriver.Subordination.WaitForScreenToLoad();

                Reports.TestStep = "Verify Subordination is filled with data from the web service request.";
                Support.AreEqual("BOA", FastDriver.Subordination.GaBCodeLabel.FAGetText(), "GAB Code");
                Support.AreEqual(AddSubordinationRequest.Subordination.SubLender.Position.Value.ToString(), FastDriver.Subordination.Position.FAGetValue(), "Position");
                Support.AreEqual(AddSubordinationRequest.Subordination.SubLender.ResponsibleParty.ToString(), FastDriver.Subordination.ResponsibleParty.FAGetValue(), "Responsible Party");
                Support.AreEqual(AddSubordinationRequest.Subordination.SubLender.LoanNumber.ToString(), FastDriver.Subordination.LoanNumber.FAGetValue(), "Loan Number");
                Support.AreEqual(AddSubordinationRequest.Subordination.SubLender.LoanAmount.ToString().FormatAsMoney(), FastDriver.Subordination.LoanAmount.FAGetValue(), "Loan Amount");
                Support.AreEqual(AddSubordinationRequest.Subordination.SubLender.SubOrdinationOrderDate.Value.ToDateString(), FastDriver.Subordination.SubordinationOrderDate.FAGetValue(), "Subordination Order Date");
                Support.AreEqual(AddSubordinationRequest.Subordination.SubLender.SubRecordedDate.Value.ToDateString(), FastDriver.Subordination.SubRecordedDate.FAGetValue(), "Sub Recorded Date");
                Support.AreEqual(AddSubordinationRequest.Subordination.SubLender.AssignmentDate.Value.ToDateString(), FastDriver.Subordination.SubLenderAssignmentDate.FAGetValue(), "Assignment Date");
                Support.AreEqual(AddSubordinationRequest.Subordination.SubLender.Instrument.ToString(), FastDriver.Subordination.SubLenderInstrument.FAGetValue(), "Instrument #");
                Support.AreEqual(AddSubordinationRequest.Subordination.SubLender.Book.ToString(), FastDriver.Subordination.SubLenderBook.FAGetValue(), "Book");
                Support.AreEqual(AddSubordinationRequest.Subordination.SubLender.Page.ToString(), FastDriver.Subordination.SubLenderPage.FAGetValue(), "Page");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0002_UpdateSubordination()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                #endregion

                Reports.TestDescription = "Verify UpdateSubordination() Service";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a file using web service";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                var file = FileService.GetOrderDetails(fileId).FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(file);

                var AddSubordinationRequest = EscrowRequestFactory.GetAddSubordinationRequest(fileId);

                Reports.TestStep = "Invoke AddSubordination Service";
                var AddSubordinationResponse = EscrowService.AddSubordination(AddSubordinationRequest);
                Support.AreEqual("1", AddSubordinationResponse.Status.ToString(), AddSubordinationResponse.StatusDescription);

                Reports.TestStep = "Invoke UpdateSubordination Service";
                var UpdateSubordinationRequest = EscrowRequestFactory.GetUpdateSubordinationRequest(fileId);

                var response = EscrowService.UpdateSubordination(UpdateSubordinationRequest);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);

                Reports.TestStep = "Navigate to Subordination Summary";
                FastDriver.Subordination_Summary.Open();

                Reports.TestStep = "Select the created Subordination and click on Edit button";
                FastDriver.Subordination_Summary.SubordinateSummary.PerformTableAction(2, 1, TableAction.Click);
                FastDriver.Subordination_Summary.SubordinateSummaryEdit.FAClick();
                FastDriver.Subordination.WaitForScreenToLoad();

                Reports.TestStep = "Verify Subordination is filled with data from the web service request.";
                Support.AreEqual("BOA", FastDriver.Subordination.GaBCodeLabel.FAGetText(), "GAB Code");
                Support.AreEqual(UpdateSubordinationRequest.Subordination.SubLender.Position.Value.ToString(), FastDriver.Subordination.Position.FAGetValue(), "Position");
                Support.AreEqual(UpdateSubordinationRequest.Subordination.SubLender.ResponsibleParty.ToString(), FastDriver.Subordination.ResponsibleParty.FAGetValue(), "Responsible Party");
                Support.AreEqual(UpdateSubordinationRequest.Subordination.SubLender.LoanNumber.ToString(), FastDriver.Subordination.LoanNumber.FAGetValue(), "Loan Number");
                Support.AreEqual(UpdateSubordinationRequest.Subordination.SubLender.LoanAmount.ToString().FormatAsMoney(), FastDriver.Subordination.LoanAmount.FAGetValue(), "Loan Amount");
                Support.AreEqual(UpdateSubordinationRequest.Subordination.SubLender.SubOrdinationOrderDate.Value.ToDateString(), FastDriver.Subordination.SubordinationOrderDate.FAGetValue(), "Subordination Order Date");
                Support.AreEqual(UpdateSubordinationRequest.Subordination.SubLender.SubRecordedDate.Value.ToDateString(), FastDriver.Subordination.SubRecordedDate.FAGetValue(), "Sub Recorded Date");
                Support.AreEqual(UpdateSubordinationRequest.Subordination.SubLender.AssignmentDate.Value.ToDateString(), FastDriver.Subordination.SubLenderAssignmentDate.FAGetValue(), "Assignment Date");
                Support.AreEqual(UpdateSubordinationRequest.Subordination.SubLender.Instrument.ToString(), FastDriver.Subordination.SubLenderInstrument.FAGetValue(), "Instrument #");
                Support.AreEqual(UpdateSubordinationRequest.Subordination.SubLender.Book.ToString(), FastDriver.Subordination.SubLenderBook.FAGetValue(), "Book");
                Support.AreEqual(UpdateSubordinationRequest.Subordination.SubLender.Page.ToString(), FastDriver.Subordination.SubLenderPage.FAGetValue(), "Page");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0003_DeleteSubordination()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                #endregion

                Reports.TestDescription = "Verify DeleteSubordination() Service";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a file using web service";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                var file = FileService.GetOrderDetails(fileId).FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(file);

                var AddSubordinationRequest = EscrowRequestFactory.GetAddSubordinationRequest(fileId);

                Reports.TestStep = "Invoke AddSubordination Service";
                var AddSubordinationResponse = EscrowService.AddSubordination(AddSubordinationRequest);
                Support.AreEqual("1", AddSubordinationResponse.Status.ToString(), AddSubordinationResponse.StatusDescription);

                Reports.TestStep = "Invoke DeleteSubordination Service";
                var DeleteSubordinationRequest = EscrowRequestFactory.GetDeleteSubordinationRequest(fileId);

                var response = EscrowService.DeleteSubordination(DeleteSubordinationRequest);
                Support.AreEqual("1", response.Status.ToString(), "Status Code");
                Support.AreEqual("Subordination is deleted successfully.", response.StatusDescription, "Status Description");
                
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0004_GetSubordinationDetails()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                #endregion

                Reports.TestDescription = "Verify GetSubordinationDetails() Service";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a file using web service";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                var file = FileService.GetOrderDetails(fileId).FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(file);

                var AddSubordinationRequest = EscrowRequestFactory.GetAddSubordinationRequest(fileId);

                Reports.TestStep = "Invoke AddSubordination Service";
                var AddSubordinationResponse = EscrowService.AddSubordination(AddSubordinationRequest);
                Support.AreEqual("1", AddSubordinationResponse.Status.ToString(), AddSubordinationResponse.StatusDescription);

                Reports.TestStep = "Invoke GetSubordinationDetails Service";
                var GetSubordinationDetailsRequest = EscrowRequestFactory.GetSubordinationDetailsRequest(fileId);
                var GetSubordinationDetailsResponse = EscrowService.GetSubordinationDetails(GetSubordinationDetailsRequest);
                Support.AreEqual("1", GetSubordinationDetailsResponse.Status.ToString(), GetSubordinationDetailsResponse.StatusDescription);

                Reports.TestStep = "Navigate to Subordination Summary";
                FastDriver.Subordination_Summary.Open();

                Reports.TestStep = "Select the created Subordination and click on Edit button";
                FastDriver.Subordination_Summary.SubordinateSummary.PerformTableAction(2, 1, TableAction.Click);
                FastDriver.Subordination_Summary.SubordinateSummaryEdit.FAClick();
                FastDriver.Subordination.WaitForScreenToLoad();

                Reports.TestStep = "Verify Subordination is filled with data from the web service request.";
                Support.AreEqual("BOA", FastDriver.Subordination.GaBCodeLabel.FAGetText(), "GAB Code");
                Support.AreEqual(GetSubordinationDetailsResponse.Subordination.SubLender.Position.Value.ToString(), FastDriver.Subordination.Position.FAGetValue(), "Position");
                Support.AreEqual(GetSubordinationDetailsResponse.Subordination.SubLender.ResponsibleParty.ToString(), FastDriver.Subordination.ResponsibleParty.FAGetValue(), "Responsible Party");
                Support.AreEqual(GetSubordinationDetailsResponse.Subordination.SubLender.LoanNumber.ToString(), FastDriver.Subordination.LoanNumber.FAGetValue(), "Loan Number");
                Support.AreEqual(GetSubordinationDetailsResponse.Subordination.SubLender.LoanAmount.ToString().FormatAsMoney(), FastDriver.Subordination.LoanAmount.FAGetValue(), "Loan Amount");
                Support.AreEqual(GetSubordinationDetailsResponse.Subordination.SubLender.SubOrdinationOrderDate.Value.ToDateString(), FastDriver.Subordination.SubordinationOrderDate.FAGetValue(), "Subordination Order Date");
                Support.AreEqual(GetSubordinationDetailsResponse.Subordination.SubLender.SubRecordedDate.Value.ToDateString(), FastDriver.Subordination.SubRecordedDate.FAGetValue(), "Sub Recorded Date");
                Support.AreEqual(GetSubordinationDetailsResponse.Subordination.SubLender.AssignmentDate.Value.ToDateString(), FastDriver.Subordination.SubLenderAssignmentDate.FAGetValue(), "Assignment Date");
                Support.AreEqual(GetSubordinationDetailsResponse.Subordination.SubLender.Instrument.ToString(), FastDriver.Subordination.SubLenderInstrument.FAGetValue(), "Instrument #");
                Support.AreEqual(GetSubordinationDetailsResponse.Subordination.SubLender.Book.ToString(), FastDriver.Subordination.SubLenderBook.FAGetValue(), "Book");
                Support.AreEqual(GetSubordinationDetailsResponse.Subordination.SubLender.Page.ToString(), FastDriver.Subordination.SubLenderPage.FAGetValue(), "Page");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0005_GetSubordinationSummary()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                #endregion

                Reports.TestDescription = "Verify GetSubordinationSummary() Service";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a file using web service";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                var file = FileService.GetOrderDetails(fileId).FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(file);

                var AddSubordinationRequest = EscrowRequestFactory.GetAddSubordinationRequest(fileId);

                Reports.TestStep = "Invoke AddSubordination Service";
                var AddSubordinationResponse = EscrowService.AddSubordination(AddSubordinationRequest);
                Support.AreEqual("1", AddSubordinationResponse.Status.ToString(), AddSubordinationResponse.StatusDescription);

                Reports.TestStep = "Invoke GetSubordinationSummary Service";
                var GetSubordinationSummaryRequest = EscrowRequestFactory.GetSubordinationSummaryRequest(fileId);

                var response = EscrowService.GetSubordinationSummary(GetSubordinationSummaryRequest);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);

                Reports.TestStep = "Navigate to Subordination Summary";
                FastDriver.Subordination_Summary.Open();

                Reports.TestStep = "Verify Subordination is filled with data from the web service request.";
                Support.AreEqual(response.SubordinationSummaryList[0].Name.ToString(), FastDriver.Subordination_Summary.SubordinateSummary.PerformTableAction(2, 2, TableAction.GetText).Message, "Name");
                Support.AreEqual(response.SubordinationSummaryList[0].Position.ToString(), FastDriver.Subordination_Summary.SubordinateSummary.PerformTableAction(2, 3, TableAction.GetText).Message, "Position");
                Support.AreEqual(response.SubordinationSummaryList[0].LoanNumber.ToString(), FastDriver.Subordination_Summary.SubordinateSummary.PerformTableAction(2, 5, TableAction.GetText).Message, "Loan Number");
                Support.AreEqual(response.SubordinationSummaryList[0].ResponsibleParty.ToString(), FastDriver.Subordination_Summary.SubordinateSummary.PerformTableAction(2, 6, TableAction.GetText).Message, "Responsible Party");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0006_GetRestrictLenderUpdateStatus()
        {
            try
            {
                Reports.TestDescription = "Verify GetRestrictLenderUpdateStatus() Service";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.NewLoan.FileBusinessParty.AddrBookEntryID = AdminService.GetGABAddressBookEntryId("BOA", Convert.ToInt32(AutoConfig.SelectedRegionBUID));
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a file with BOA as a new lender using web service";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                var file = FileService.GetOrderDetails(fileId).FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(file);

                Reports.TestStep = "Invoke AddLenderLoanInvestor service";
                var AddLenderLoanInvestorRequest = EscrowRequestFactory.GetAddLenderLoanInvestorRequest(fileId);
                var AddLenderLoanInvestorResponse = EscrowService.AddLenderLoanInvestor(AddLenderLoanInvestorRequest);
                Support.AreEqual("1", AddLenderLoanInvestorResponse.Status.ToString(), "Status");
                Support.AreEqual("Loan Investor has been Added Successfully.", AddLenderLoanInvestorResponse.StatusDescription, "Status Description");

                Reports.TestStep = "Invoke GetRestrictLenderUpdateStatus Service";
                var request = EscrowRequestFactory.GetRestrictLenderUpdateStatusRequest(file, fileRequest.File.NewLoan.LoanNumber);
                var response = EscrowService.GetRestrictLenderUpdateStatus(request);
                Support.AreEqual("1", response.Status.ToString(), "Status");
                Support.AreEqual("Lender Closing Instructions are accepted", response.StatusDescription, "Description");

                Reports.TestStep = "Navigate to New Loan screen";
                FastDriver.NewLoan.Open();

                Reports.TestStep = "Verify Restrict Lender Updates checbox is unchecked";
                Support.AreEqual(false, FastDriver.NewLoan.LoanDetailsRestrictLenderUpdates.IsSelected(), "Restrict Lender Updates check box is unchecked");   
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0007_DuplicateFileSearch()
        {
            Reports.TestDescription = "Verify the web service DuplicteFileSearch (Escrow Service).";
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                var fileSearchResult = new DuplicateFileSearchResponse();
                #endregion

                #region Login to the FAST Application.
                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                #endregion

                #region Invoke the DuplicateFileSearch(escrow) service.
                Reports.TestStep = "Invoke the DuplicateFileSearch(escrow) service.";
                DuplicateFileSearchRequest request = EscrowRequestFactory.GetDuplicateFileSearchRequest();
                fileSearchResult = FileManagementHelpers.GetDuplicateFileSearchResult(request);
                bool result = (fileSearchResult.Status == 1) ? true : false;
                Reports.StatusUpdate("DuplicateFileSearch(escrow) service invoked: " + fileSearchResult.StatusDescription, result);
                #endregion

                #region Navigate to the DuplicateFileSearch page in Fast and enter the criteria for search.
                Reports.TestStep = "Navigate to the DuplicateFileSearch page in Fast and enter the criteria for search.";
                FastDriver.DuplicateFileSearch.Open();
                FastDriver.DuplicateFileSearch.Buyer1Type.FASelectItem("Individual");
                FastDriver.DuplicateFileSearch.WaitForScreenToLoad();
                FastDriver.DuplicateFileSearch.Buyer1FirstName.FASetText("Bart");
                FastDriver.DuplicateFileSearch.Buyer1LastName.FASetText("Simpson");
                FastDriver.DuplicateFileSearch.Buyer2Type.FASelectItem("Husband/Wife");
                FastDriver.DuplicateFileSearch.WaitForScreenToLoad();
                FastDriver.DuplicateFileSearch.Buyer2FirstName.FASetText("Homer");
                FastDriver.DuplicateFileSearch.Buyer2LastName.FASetText("Simpson");
                FastDriver.DuplicateFileSearch.PropertyAddressCity.FASetText("Santa Ana");
                FastDriver.DuplicateFileSearch.PropertyCounty.FASetText("Orange");
                FastDriver.DuplicateFileSearch.PropertyAddressState.FASelectItem("CA");
                FastDriver.DuplicateFileSearch.ClickFindNow();
                #endregion

                #region Verify that UI results with the same criteria is same as web services.
                Reports.TestStep = "Verify that UI results with the same criteria is same as web services.";
                FastDriver.DuplicateFileSearchResults.WaitForScreenToLoad();
                int actCount=FastDriver.DuplicateFileSearchResults.SearchResultsTable.GetRowCount();
                result = fileSearchResult.DuplicateFileInfos.Length.Equals(actCount-1);
                Reports.StatusUpdate("UI verification of the DuplicateFileSearch webservice: " + result.ToString(), result);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally { FastDriver.WebDriver.Quit(); }
        }

        [TestMethod]
        public void REG0008_GetGFEDetails()
        {
            try
            {
                Reports.TestDescription = "Verify GetGFEDetails service";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.formType = FASTWCFHelpers.FastFileService.FormType.HUD;
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a HUD file using web service";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                string fileNum = FileService.GetOrderDetails(fileId).FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(fileNum);

                Reports.TestStep = "Navigate to New Loan screen, click Loan Charges tab";
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.ClickChargesTab();

                Reports.TestStep = "Enter buyer charge and GFE amount for Appraisal fee";
                string chargeDescription = FastDriver.NewLoan.LoanCharges_NewLoanTable.PerformTableAction(2, 1, TableAction.GetInputValue).Message.Clean();
                FastDriver.NewLoan.LoanCharges_NewLoanTable.PerformTableAction(2, 3, TableAction.SetText, "100");
                FastDriver.NewLoan.LoanCharges_NewLoanTable.PerformTableAction(2, 7, TableAction.SetText, "100");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20);

                Reports.TestStep = "Invoke GetGFEDetails method, validate response (WS)";
                var request = EscrowRequestFactory.GetGFEDetailsRequest(fileId);
                var response = FileManagementHelpers.GetGFEDetails(request);

                Reports.TestStep = "Validate charge description and GFE #3 amount in the response";
                Support.AreEqual(chargeDescription, response.GFE_3_Required_Lender_selected_services.GFE_3[0].ChargeDescription.Clean(), "Charge Description");
                Support.AreEqual("100", response.GFE_3_Required_Lender_selected_services.GFE_3[0].GFEAmount.Clean(), "GFE Amount");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally { FastDriver.WebDriver.Quit(); }
        }

        [TestMethod]
        public void REG0009_UpdateGFEDetails()
        {
            try
            {
                Reports.TestDescription = "Verify UpdateGFEDetails service";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.formType = FASTWCFHelpers.FastFileService.FormType.HUD;
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a HUD file using web service";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                string fileNum = FileService.GetOrderDetails(fileId).FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(fileNum);

                Reports.TestStep = "Invoke UpdateGFEDetails method, validate response (WS) [US # 704107]";
                var request = EscrowRequestFactory.GetGFELoanRequest(fileId);
                request.GFE_3_Required_Lender_selected_services = new GFE_3_Required_Lender_selected_services() 
                { 
                    GFE_3 = new  GFERequiredLender[]
                    {
                        new GFERequiredLender()
                        {
                            ChargeDescription = "Appraisal fee",
                            GFEAmount = "200",
                            GFEEntryTypeCdID = 1589,
                            ProcessTypeDescription = "New Loan 1 Lender"
                        }
                    }
                };
                
                //[US # 704107]
                request.GFE_10_Daily_interest_charges = (decimal)0.0;
                request.GFE_10_Daily_interest_charges_Flag = GFEChargeFlags.Zero;
                request.GFE_7_Government_recording_charges = (decimal)0.0;
                request.GFE_8_Transfer_taxes = (decimal)10000;
                var response = FileManagementHelpers.UpdateGFEDetails(request);
                response.Validate();

                // This part is not working, waiting for confirmation from QA: TFS# 911604
                //Reports.TestStep = "Navigate to New Loan screen, click Loan Charges tab";
                //FastDriver.NewLoan.Open();
                //FastDriver.NewLoan.ClickChargesTab();

                //Reports.TestStep = "Validate charge description and GFE #3 amount in the response";
                //Support.AreEqual("Appraisal fee updated", FastDriver.NewLoan.LoanCharges_NewLoanTable.PerformTableAction(2, 1, TableAction.GetInputValue).Message.Clean(), "Charge Description");
                //Support.AreEqual("200", FastDriver.NewLoan.LoanCharges_NewLoanTable.PerformTableAction(2, 7, TableAction.GetInputValue).Message.Clean(), "GFE Amount");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally { FastDriver.WebDriver.Quit(); }
        }

        [TestMethod]
        public void REG0010_GetSDNTrackingSummaryDetails()
        {
            try
            {
                Reports.TestDescription = "Verify GetSDNTrackingSummaryDetails service";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetDetailedCreateFileDefaultRequest();
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a file using web service";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                string fileNum = FileService.GetOrderDetails(fileId).FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(fileNum);

                Reports.TestStep = "Wait for SDN Search to complete";
                FastDriver.SDNTrackingSummary.WaitForSDNSearchComplete(30);

                Reports.TestStep = "Invoke GetSDNTrackingSummaryDetails method, validate response (WS)";
                var request = EscrowRequestFactory.GetSDNSearchRequest(fileId);
                var response = FileManagementHelpers.GetSDNTrackingSummaryDetails(request);
                response.Validate();

                Reports.TestStep = "Navigate to SDN Tracking Summary screen, validate response";
                FastDriver.SDNTrackingSummary.Open();
                Support.AreEqual((FastDriver.SDNTrackingSummary.SDNNoHitTable.GetRowCount() - 1).ToString(), response.NoHit.Length.ToString(), "SDN No Hit Table Row Count");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally { FastDriver.WebDriver.Quit(); }
        }

        [TestMethod]
        [DeploymentItem(@"Common\Support\PDFSigQFormalRep.pdf")]
        public void REG0011_AttachMessage()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                #endregion

                Reports.TestDescription = "Verify AttachMessage() service";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a file with BOA as a new lender using web service";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                var file = FileService.GetOrderDetails(fileId).FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(file);

                Reports.TestStep = "Convert file to byte array";
                var fileName = @"PDFSigQFormalRep.pdf";
                byte[] fileContent = IOHelper.ConvertFileToByteArray(fileName);

                Reports.TestStep = "Invoke UploadWorkQFile service";
                var UploadWQFRequest = EscrowRequestFactory.GetUploadWorkQFileRequest(fileContent);
                var UploadWQFResponse = EscrowService.UploadWorkQFile(UploadWQFRequest);
                UploadWQFResponse.Validate();

                Reports.TestStep = "Navigate to WorkQueue Message Browser";
                FastDriver.TopFrame.ClickQListTab();
                FastDriver.WorkQueueMessagesBrowser.WaitForScreenToLoad();

                Reports.TestStep = "Select a queue with id: 1";
                FastDriver.WorkQueueMessagesBrowser.ForQueue.FASelectItem("TestQueue");
                FastDriver.WorkQueueMessagesBrowser.WaitForScreenToLoad();

                Reports.TestStep = "Get the id from the recently added message";
                int rows = FastDriver.WorkQueueMessagesBrowser.MessageTable.GetRowCount();
                var fName = FastDriver.WorkQueueMessagesBrowser.MessageTable.PerformTableAction(rows, 3, TableAction.GetText).Message;

                var messageId = fName.Split('\\')[1].Split('_')[0];

                Reports.TestStep = "Invoke AttachMessage service";
                var AttachMessageRequest = EscrowRequestFactory.GetAttachMessageRequest(fileId, Convert.ToInt32(messageId));
                var AttachMessageRespnse = EscrowService.AttachMessage(AttachMessageRequest);
                AttachMessageRespnse.Validate();

                Reports.TestStep = "Navigate to Document Repository";
                FastDriver.WebDriver.WaitForActionToComplete(() => {
                    FastDriver.DocumentRepository.Open();

                    return FastDriver.DocumentRepository.DocumentsTable.IsDisplayed();
                }, timeout: 120, idleInterval: 20);

                Reports.TestStep = "Verify Document Repository is filled with data from the web service request.";
                Support.AreEqual(true, FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(1, 4, TableAction.GetText).Message.Contains(AttachMessageRequest.DocumentName + " " + AttachMessageRequest.AdditionalInfo), "Name");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        [TestMethod]
        public void REG0012_GetOrderDetailsByFileIDs()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan();
                #endregion

                Reports.TestDescription = "Verify GetOrderDetailsByFileIDs() service.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Invoke the CreateFile method.";
                int fileid = FastDriver.FACreateFileGetFileId(fileRequest);

                Reports.TestStep = "Invoke the GetOrderDetails method.";
                var file = FileService.GetOrderDetails(fileid);

                Reports.TestStep = "Open file in FAST UI.";
                FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

                Reports.TestStep = "Execute GetOrderDetailsByFileIDs web service";
                int[] fileIDsArray = { fileid };

                var getOrderDetailsByFileIDsResponse = EscrowService.GetOrderDetailsByFileIDs(fileIDsArray);

                Reports.TestStep = "Validate response";
                var matches = getOrderDetailsByFileIDsResponse.ToList().FirstOrDefault(p => p.FileNumber == file.FileNumber);
                Support.AreEqual(true, !(matches == null), "Validating request order details by file id is included in response");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0013_UnlinkSecondOrderSource()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan();
                #endregion

                Reports.TestDescription = "Verify UnlinkSecondOrderSource() service.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Invoke the CreateFile method.";
                int fileid = FastDriver.FACreateFileGetFileId(fileRequest);

                Reports.TestStep = "Invoke the GetOrderDetails method.";
                var file = FileService.GetOrderDetails(fileid);

                Reports.TestStep = "Invoke the UpdateSecondOrderSource method.";
                var updateFileRequest = FileRequestFactory.GetUpdateSecondOrderSourceRequest(file.FileID.Value, appID: 38, Source: "LVIS");
                FileService.UpdateSecondOrderSource(updateFileRequest).Validate();

                Reports.TestStep = "Open file in FAST UI.";
                FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

                Reports.TestStep = "Validate Order Source in File Homepage.";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.OrderSourceExpand.FAClick();
                Support.AreEqual(updateFileRequest.Source, FastDriver.FileHomepage.SecondOrderSource.FAGetText(), "SecondOrderSource");
                Support.AreEqual(updateFileRequest.SecondExternalFileNum, FastDriver.FileHomepage.SecondExternalNumber.FAGetText(), "SecondExternalNumber");

                Reports.TestStep = "Invoke the UnlinkSecondOrderSource method, validate response (WS)";
                var request = EscrowRequestFactory.GetUpdateSecondOrderSourceRequest(file.FileID.Value, 38);
                var response = FileManagementHelpers.UnlinkSecondOrderSource(request);
                response.Validate();

                Reports.TestStep = "Validate Order Source has been removed in File Homepage";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.OrderSourceExpand.FAClick();
                Support.AreEqual(false, FastDriver.FileHomepage.SecondOrderSource.IsDisplayed(), "Second Order Source Displayed");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally { FastDriver.WebDriver.Quit(); }
        }

        [TestMethod, DeploymentItem(@"Common\Support\10 pages.tif")]
        public void REG0014_SplitImageDocument()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan();
                #endregion

                Reports.TestDescription = "Validate SplitImageDocument web method";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file (WS)";
                int fileID = GeneralFileServiceOperationsHelpers.CreateFile();
                string fileNumber = FASTWCFHelpers.FileService.GetOrderDetails(fileID).FileNumber;

                Reports.TestStep = "Upload TIF file to file, validate response (WS)";
                string filePath = Reports.DEPLOYDIR + @"\10 pages.tif";
                DocumentsHelpers.UploadImage2(fileID, "UploadImage2 TIF", ".TIF", 7, filePath).Validate();

                Reports.TestStep = "Navigate to the file";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Get Electronic File ID using GetDocuments (WS)";
                long imageID = (long) FileService.GetDocuments(fileID).Images[0].ImageDocumentID;

                Reports.TestStep = "Invoke SplitImageDocument method, validate response (WS)";
                var request = EscrowRequestFactory.GetSplitImageDocument(imageID, "Test Split Image Document", "3,6");
                FileManagementHelpers.SplitImageDocument(request).Validate();

                Reports.TestStep = "Navigate to Document Repository, validate image file is splitted";
                FastDriver.DocumentRepository.Open();
                Support.AreEqual("Test Split Image Document", FastDriver.DocumentRepository.DocumentsTable.PerformTableAction(9, "Imaged", 4, TableAction.GetText).Message.Clean(), "Split Image Name");

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { FastDriver.WebDriver.Quit(); }
        }

        [TestMethod]
        public void REG0015_UpdateExternalServiceNumber()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan();
                #endregion

                Reports.TestDescription = "Validate UpdateExternalServiceNumber web method";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic file (WS)";
                int fileID = GeneralFileServiceOperationsHelpers.CreateFile();
                string fileNumber = FASTWCFHelpers.FileService.GetOrderDetails(fileID).FileNumber;

                Reports.TestStep = "Invoke UpdateExternalServiceNumber method, validate response (WS)";
                var request = EscrowRequestFactory.GetUpdateExternalServiceNumRequest(fileID, "TO", "012345");
                FileManagementHelpers.UpdateExternalServiceNumber(request).Validate();

                Reports.TestStep = "Invoke GetOrderDetails method, validate ExternalServiceNum (WS)";
                var response = FileService.GetOrderDetails(fileID);

                string externalServiceNum = "";

                foreach (FASTWCFHelpers.FastFileService.Service fileService in response.Services)
                {
                    if (fileService.ServiceTypeObjectCD == "TO")
                    {
                        externalServiceNum = fileService.ExternalServiceNum.Clean();
                        break;
                    }
                }

                Support.AreEqual(request.ExternalServiceNumber, externalServiceNum, "External Service Number");
               
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { FastDriver.WebDriver.Quit(); }
        }

        [TestMethod]
        public void REG0016_UpdateSiteFileStatus()
        {
            try
            {
                Reports.TestDescription = "Validate UpdateSiteFileStatus web method";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan();
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a project file file (WS)";
                int fileID = GeneralFileServiceOperationsHelpers.CreateFile();
                string fileNumber = FASTWCFHelpers.FileService.GetOrderDetails(fileID).FileNumber;

                Reports.TestStep = "Navigate to File Homepage screen, check the Project File checkbox";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20);

                Reports.TestStep = "Invoke UpdateSiteFileStatus method, validate response (WS)";
                var request = EscrowRequestFactory.GetUpdateSFStatus(fileID, 151);
                FileManagementHelpers.UpdateSiteFileStatus(request).Validate();

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { FastDriver.WebDriver.Quit(); }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
