﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastEscrowService;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace WebServices.Escrow
{
    [CodedUITest]
    public class ProrationWS : MasterTestClass
    {
        [TestMethod]
        [Description("Verify create Proation instance using CreateProration web service")]
        public void REG_CreateProration_TAX()
        {
            try
            {
                 Reports.TestDescription = "Verify create Proration - Rent information using CreateProration web service";

                FASTSelenium.Common.FASTHelpers.FAST_Init_File();

                #region Create new Proration - Rent instance with CreateProration()
                Reports.TestStep = "Create new Proration - Rent instance with CreateProration()";
                var index = 1;
                var request = EscrowRequestFactory.GetProrationRequest(FASTSelenium.Common.FASTHelpers.File.FileID, index, ProrationType.TAX);
                var response = EscrowService.CreateProration(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Verify new Proration instance in FAST
                Reports.TestStep = "Verify new Proration instance in FAST";
                FastDriver.ProrationTax.Open();
                FastDriver.ProrationTax.WaitForScreenToLoad();
              //  //*[contains(@id, 'ctl00_btnAircraftMapCell')]
              //  int i = FastDriver.WebDriver.FindElements(By.XPath("//*[contains(@id,'dGridProration_dGridProration')]")).Count;
              //  ISearchContext sc = FastDriver.WebDriver.FindElement(By.XPath("//*[contains(@id,'dGridProration_dGridProration')]"));
              //  int row = FastDriver.ProrationTax.ProrationTaxTable.GetRowCount();
              //int j=  sc.FindElements(By.TagName("tr")).Count;
                FastDriver.ProrationTax.ProrationTaxTable4.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();
                FastDriver.ProrationDetail.WaitForScreenToLoad();
                Support.AreEqual(request.ProrDetailsForCD.CreditSeller.Value.ToString(),FastDriver.ProrationDetail.CreditSeller.Selected.ToString());
                Support.AreEqual(request.ProrDetailsForCD.DayOfClosePaidbySeller.Value.ToString(), FastDriver.ProrationDetail.DayofClosePaidbySeller.Selected.ToString());
                
                Support.AreEqual(((Decimal)request.ProrDetailsForCD.Amount).ToString("N2"), FastDriver.ProrationDetail.Amount.FAGetValue());
                Support.AreEqual(((DateTime)request.ProrDetailsForCD.FromDate).ToDateString(), FastDriver.ProrationDetail.FromDate.FAGetValue());
                Support.AreEqual(((DateTime)request.ProrDetailsForCD.ToDate).ToDateString(), FastDriver.ProrationDetail.ToDate.FAGetValue());
                Support.AreEqual(request.ProrDetailsForCD.FromDateInclusive.Value.ToString(), FastDriver.ProrationDetail.fromInclusive.Selected.ToString());
                Support.AreEqual(request.ProrDetailsForCD.AmountPeriod.ToString(), FastDriver.ProrationDetail.Per.FAGetSelectedItem().ToString());

                Support.AreEqual(((Decimal)request.ProrDetailsForCD.BuyerCharge).ToString("N2"), FastDriver.ProrationDetail.BuyerCharge.FAGetValue());
                Support.AreEqual(((Decimal)request.ProrDetailsForCD.BuyerCredit).ToString("N2"), FastDriver.ProrationDetail.BuyerCredit.FAGetValue());
                Support.AreEqual(((Decimal)request.ProrDetailsForCD.SellerCharge).ToString("N2"), FastDriver.ProrationDetail.SellerCharge.FAGetValue());
                Support.AreEqual(((Decimal)request.ProrDetailsForCD.SellerCredit).ToString("N2"), FastDriver.ProrationDetail.SellerCredit.FAGetValue());
                
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify create Proation instance using CreateProration web service")]
        public void REG_CreateProration_RENT()
        {
            try
            {
                Reports.TestDescription = "Verify create Proration - Rent information using CreateProration web service";

                FASTSelenium.Common.FASTHelpers.FAST_Init_File();

                #region Create new Proration - Rent instance with CreateProration()
                Reports.TestStep = "Create new Proration - Rent instance with CreateProration()";
                var index = 1;
                var request = EscrowRequestFactory.GetProrationRequest(FASTSelenium.Common.FASTHelpers.File.FileID, index, ProrationType.RENT);
                var response = EscrowService.CreateProration(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Verify new Proration instance in FAST
                Reports.TestStep = "Verify new Proration instance in FAST";
                FastDriver.ProrationRent.Open();
                FastDriver.ProrationRent.ProrationTaxTable2.FAClick();
                FastDriver.ProrationRent.Edit.FAClick();
                FastDriver.ProrationDetail.WaitForScreenToLoad();
                Support.AreEqual(request.ProrDetailsForCD.CreditSeller.Value.ToString(), FastDriver.ProrationDetail.CreditSeller.Selected.ToString());
                Support.AreEqual(request.ProrDetailsForCD.DayOfClosePaidbySeller.Value.ToString(), FastDriver.ProrationDetail.DayofClosePaidbySeller.Selected.ToString());

                Support.AreEqual(((Decimal)request.ProrDetailsForCD.Amount).ToString("N2"), FastDriver.ProrationDetail.Amount.FAGetValue());
                Support.AreEqual(((DateTime)request.ProrDetailsForCD.FromDate).ToDateString(), FastDriver.ProrationDetail.FromDate.FAGetValue());
                Support.AreEqual(((DateTime)request.ProrDetailsForCD.ToDate).ToDateString(), FastDriver.ProrationDetail.ToDate.FAGetValue());
                Support.AreEqual(request.ProrDetailsForCD.FromDateInclusive.Value.ToString(), FastDriver.ProrationDetail.fromInclusive.Selected.ToString());
                Support.AreEqual(request.ProrDetailsForCD.AmountPeriod.ToString(), FastDriver.ProrationDetail.Per.FAGetSelectedItem().ToString());

                Support.AreEqual(((Decimal)request.ProrDetailsForCD.BuyerCharge).ToString("N2"), FastDriver.ProrationDetail.BuyerCharge.FAGetValue());
                Support.AreEqual(((Decimal)request.ProrDetailsForCD.BuyerCredit).ToString("N2"), FastDriver.ProrationDetail.BuyerCredit.FAGetValue());
                Support.AreEqual(((Decimal)request.ProrDetailsForCD.SellerCharge).ToString("N2"), FastDriver.ProrationDetail.SellerCharge.FAGetValue());
                Support.AreEqual(((Decimal)request.ProrDetailsForCD.SellerCredit).ToString("N2"), FastDriver.ProrationDetail.SellerCredit.FAGetValue());

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }


        [TestMethod]
        [Description("Verify create Proation instance using CreateProration web service")]
        public void REG_CreateProration_MISCELLANEOUS()
        {
            try
            {
                Reports.TestDescription = "Verify create Proration - Rent information using CreateProration web service";

                FASTSelenium.Common.FASTHelpers.FAST_Init_File();

                #region Create new Proration - Rent instance with CreateProration()
                Reports.TestStep = "Create new Proration - Rent instance with CreateProration()";
                var index = 1;
                var request = EscrowRequestFactory.GetProrationRequest(FASTSelenium.Common.FASTHelpers.File.FileID, index, ProrationType.MISCELLANEOUS);
                var response = EscrowService.CreateProration(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Verify new Proration instance in FAST
                Reports.TestStep = "Verify new Proration instance in FAST";
                FastDriver.ProrationMisc.Open();
                FastDriver.ProrationMisc.ProrationTaxTable2.FAClick();
                FastDriver.ProrationMisc.Edit.FAClick();
                FastDriver.ProrationDetail.WaitForScreenToLoad();
                Support.AreEqual(request.ProrDetailsForCD.CreditSeller.Value.ToString(), FastDriver.ProrationDetail.CreditSeller.Selected.ToString());
                Support.AreEqual(request.ProrDetailsForCD.DayOfClosePaidbySeller.Value.ToString(), FastDriver.ProrationDetail.DayofClosePaidbySeller.Selected.ToString());

                Support.AreEqual(((Decimal)request.ProrDetailsForCD.Amount).ToString("N2"), FastDriver.ProrationDetail.Amount.FAGetValue());
                Support.AreEqual(((DateTime)request.ProrDetailsForCD.FromDate).ToDateString(), FastDriver.ProrationDetail.FromDate.FAGetValue());
                Support.AreEqual(((DateTime)request.ProrDetailsForCD.ToDate).ToDateString(), FastDriver.ProrationDetail.ToDate.FAGetValue());
                Support.AreEqual(request.ProrDetailsForCD.FromDateInclusive.Value.ToString(), FastDriver.ProrationDetail.fromInclusive.Selected.ToString());
                Support.AreEqual(request.ProrDetailsForCD.AmountPeriod.ToString(), FastDriver.ProrationDetail.Per.FAGetSelectedItem().ToString());

                Support.AreEqual(((Decimal)request.ProrDetailsForCD.BuyerCharge).ToString("N2"), FastDriver.ProrationDetail.BuyerCharge.FAGetValue());
                Support.AreEqual(((Decimal)request.ProrDetailsForCD.BuyerCredit).ToString("N2"), FastDriver.ProrationDetail.BuyerCredit.FAGetValue());
                Support.AreEqual(((Decimal)request.ProrDetailsForCD.SellerCharge).ToString("N2"), FastDriver.ProrationDetail.SellerCharge.FAGetValue());
                Support.AreEqual(((Decimal)request.ProrDetailsForCD.SellerCredit).ToString("N2"), FastDriver.ProrationDetail.SellerCredit.FAGetValue());

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify Update Proation instance using CreateProration web service")]
        public void REG_UpdateProration_TAX()
        {
            try
            {
                Reports.TestDescription = "Verify create Proration - Rent information using CreateProration web service";

                FASTSelenium.Common.FASTHelpers.FAST_Init_File();

                #region Create new Proration - Rent instance with CreateProration()
                Reports.TestStep = "Tax updation Proration - Rent instance with CreateProration()";
                var index = 1;
                var request = EscrowRequestFactory.GetProrationRequest(FASTSelenium.Common.FASTHelpers.File.FileID, index, ProrationType.TAX);
                var response = EscrowService.CreateProration(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);

                var UpdateReq = EscrowRequestFactory.UpdateProrationRequest(FASTSelenium.Common.FASTHelpers.File.FileID, index + 3, ProrationType.TAX);
                var UpdateRes = EscrowService.UpdateProration(UpdateReq);
                Support.AreEqual("1", UpdateRes.Status.ToString(), response.StatusDescription);
                #endregion

                #region Verify new Proration instance in FAST
                Reports.TestStep = "Verify new Proration instance in FAST";
                FastDriver.ProrationTax.Open();
                FastDriver.ProrationTax.WaitForScreenToLoad();
                FastDriver.ProrationTax.ProrationTaxTable4.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();
                FastDriver.ProrationDetail.WaitForScreenToLoad();
               
                Support.AreEqual(((DateTime)UpdateReq.ProrDetailsForCD.FromDate).ToDateString(), FastDriver.ProrationDetail.FromDate.FAGetValue());
                Support.AreEqual(((DateTime)UpdateReq.ProrDetailsForCD.ToDate).ToDateString(), FastDriver.ProrationDetail.ToDate.FAGetValue());
                
                Support.AreEqual(((Decimal)UpdateReq.ProrDetailsForCD.BuyerCharge).ToString("N2"), FastDriver.ProrationDetail.BuyerCharge.FAGetValue());
                Support.AreEqual(((Decimal)UpdateReq.ProrDetailsForCD.BuyerCredit).ToString("N2"), FastDriver.ProrationDetail.BuyerCredit.FAGetValue());
                Support.AreEqual(((Decimal)UpdateReq.ProrDetailsForCD.SellerCharge).ToString("N2"), FastDriver.ProrationDetail.SellerCharge.FAGetValue());
                Support.AreEqual(((Decimal)UpdateReq.ProrDetailsForCD.SellerCredit).ToString("N2"), FastDriver.ProrationDetail.SellerCredit.FAGetValue());
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }
        
        [TestMethod]
        [Description("Verify Update Proation instance using CreateProration web service")]
        public void REG_UpdateProration_RENT()
        {
            try
            {
                Reports.TestDescription = "Verify create Proration - Rent information using CreateProration web service";

                FASTSelenium.Common.FASTHelpers.FAST_Init_File();

                #region Create new Proration - Rent instance with CreateProration()
                Reports.TestStep = "Update updation Proration - Rent instance with CreateProration()";
                var index = 1;
                var request = EscrowRequestFactory.GetProrationRequest(FASTSelenium.Common.FASTHelpers.File.FileID, index, ProrationType.RENT);
                var response = EscrowService.CreateProration(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                var UpdateReq = EscrowRequestFactory.UpdateProrationRequest(FASTSelenium.Common.FASTHelpers.File.FileID, index + 1, ProrationType.RENT);
                var UpdateRes = EscrowService.UpdateProration(UpdateReq);
                Support.AreEqual("1", UpdateRes.Status.ToString(), response.StatusDescription);
               
                #endregion

                #region Verify new Proration instance in FAST
                Reports.TestStep = "Verify new Proration instance in FAST";
                FastDriver.ProrationRent.Open();
                FastDriver.ProrationRent.ProrationTaxTable2.FAClick();
                FastDriver.ProrationRent.Edit.FAClick();
                FastDriver.ProrationDetail.WaitForScreenToLoad();
               
                 Support.AreEqual(((DateTime)UpdateReq.ProrDetailsForCD.FromDate).ToDateString(), FastDriver.ProrationDetail.FromDate.FAGetValue());
                Support.AreEqual(((DateTime)UpdateReq.ProrDetailsForCD.ToDate).ToDateString(), FastDriver.ProrationDetail.ToDate.FAGetValue());
              
                Support.AreEqual(((Decimal)UpdateReq.ProrDetailsForCD.BuyerCharge).ToString("N2"), FastDriver.ProrationDetail.BuyerCharge.FAGetValue());
                Support.AreEqual(((Decimal)UpdateReq.ProrDetailsForCD.BuyerCredit).ToString("N2"), FastDriver.ProrationDetail.BuyerCredit.FAGetValue());
                Support.AreEqual(((Decimal)UpdateReq.ProrDetailsForCD.SellerCharge).ToString("N2"), FastDriver.ProrationDetail.SellerCharge.FAGetValue());
                Support.AreEqual(((Decimal)UpdateReq.ProrDetailsForCD.SellerCredit).ToString("N2"), FastDriver.ProrationDetail.SellerCredit.FAGetValue());
               
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }
        
        [TestMethod]
        [Description("Verify Update Proation instance using CreateProration web service")]
        public void REG_UpdateProration_MISCELLANEOUS()
        {
            try
            {
                Reports.TestDescription = "Verify create Proration - Rent information using CreateProration web service";

                FASTSelenium.Common.FASTHelpers.FAST_Init_File();

                #region Update Proration - Rent instance with CreateProration()
                Reports.TestStep = "Update Proration - MISCELLANEOUS instance with CreateProration()";
                var index = 1;
                var request = EscrowRequestFactory.GetProrationRequest(FASTSelenium.Common.FASTHelpers.File.FileID, index, ProrationType.MISCELLANEOUS);
                var response = EscrowService.CreateProration(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                var UpdateReq = EscrowRequestFactory.UpdateProrationRequest(FASTSelenium.Common.FASTHelpers.File.FileID, index+1, ProrationType.MISCELLANEOUS);
                var UpdateRes = EscrowService.UpdateProration(UpdateReq);
                Support.AreEqual("1", UpdateRes.Status.ToString(), response.StatusDescription);
               
                #endregion

                #region Verify new Proration instance in FAST
                Reports.TestStep = "Verify new Proration instance in FAST";
                FastDriver.ProrationMisc.Open();
                FastDriver.ProrationMisc.ProrationTaxTable2.FAClick();
                FastDriver.ProrationMisc.Edit.FAClick();
                FastDriver.ProrationDetail.WaitForScreenToLoad();
              
                Support.AreEqual(((DateTime)UpdateReq.ProrDetailsForCD.FromDate).ToDateString(), FastDriver.ProrationDetail.FromDate.FAGetValue());
                Support.AreEqual(((DateTime)UpdateReq.ProrDetailsForCD.ToDate).ToDateString(), FastDriver.ProrationDetail.ToDate.FAGetValue());
               
                Support.AreEqual(((Decimal)UpdateReq.ProrDetailsForCD.BuyerCharge).ToString("N2"), FastDriver.ProrationDetail.BuyerCharge.FAGetValue());
                Support.AreEqual(((Decimal)UpdateReq.ProrDetailsForCD.BuyerCredit).ToString("N2"), FastDriver.ProrationDetail.BuyerCredit.FAGetValue());
                Support.AreEqual(((Decimal)UpdateReq.ProrDetailsForCD.SellerCharge).ToString("N2"), FastDriver.ProrationDetail.SellerCharge.FAGetValue());
               
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify Get Proation instance using CreateProration web service")]
        public void REG_GetProration_TAX()
        {
            try
            {
                Reports.TestDescription = "Verify Get Proration - Tax information using CreateProration web service";

                FASTSelenium.Common.FASTHelpers.FAST_Init_File();

                #region Create new Proration - Rent instance with CreateProration()
                Reports.TestStep = "Create Get Proration - Tax instance with CreateProration()";
                var index = 1;
                var request = EscrowRequestFactory.GetProrationRequest(FASTSelenium.Common.FASTHelpers.File.FileID, index, ProrationType.TAX);
                var response = EscrowService.CreateProration(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                var GetProrationReq = EscrowRequestFactory.GetServiceFileRequest(FASTSelenium.Common.FASTHelpers.File.FileID);
                var GetProrationRes = EscrowService.GetProrationDetails(GetProrationReq);
                Support.AreEqual("1", GetProrationRes.Status.ToString(), GetProrationRes.StatusDescription);
               
                #endregion

                #region Verify new Proration instance in FAST
                Reports.TestStep = "Verify new Proration instance in FAST";
                FastDriver.ProrationTax.Open();
                FastDriver.ProrationTax.WaitForScreenToLoad();
                FastDriver.ProrationTax.ProrationTaxTable4.FAClick();
                FastDriver.ProrationTax.Edit.FAClick();
                FastDriver.ProrationDetail.WaitForScreenToLoad();
                Support.AreEqual(GetProrationRes.TaxSummaryForCD[3].CreditSeller.Value.ToString(), FastDriver.ProrationDetail.CreditSeller.Selected.ToString());
                Support.AreEqual(GetProrationRes.TaxSummaryForCD[3].DayOfClosePaidbySeller.Value.ToString(), FastDriver.ProrationDetail.DayofClosePaidbySeller.Selected.ToString());

                Support.AreEqual(((Decimal)GetProrationRes.TaxSummaryForCD[3].Amount).ToString("N2"), FastDriver.ProrationDetail.Amount.FAGetValue());
                Support.AreEqual(((DateTime)GetProrationRes.TaxSummaryForCD[3].FromDate).ToDateString(), FastDriver.ProrationDetail.FromDate.FAGetValue());
                Support.AreEqual(((DateTime)GetProrationRes.TaxSummaryForCD[3].ToDate).ToDateString(), FastDriver.ProrationDetail.ToDate.FAGetValue());
                Support.AreEqual(GetProrationRes.TaxSummaryForCD[3].FromDateInclusive.Value.ToString(), FastDriver.ProrationDetail.fromInclusive.Selected.ToString());
                Support.AreEqual(GetProrationRes.TaxSummaryForCD[3].AmountPeriod.ToString(), FastDriver.ProrationDetail.Per.FAGetSelectedItem().ToString());

                Support.AreEqual(((Decimal)GetProrationRes.TaxSummaryForCD[3].BuyerCharge).ToString("N2"), FastDriver.ProrationDetail.BuyerCharge.FAGetValue());
                Support.AreEqual(((Decimal)GetProrationRes.TaxSummaryForCD[3].BuyerCredit).ToString("N2"), FastDriver.ProrationDetail.BuyerCredit.FAGetValue());
                Support.AreEqual(((Decimal)GetProrationRes.TaxSummaryForCD[3].SellerCharge).ToString("N2"), FastDriver.ProrationDetail.SellerCharge.FAGetValue());
                Support.AreEqual(((Decimal)GetProrationRes.TaxSummaryForCD[3].SellerCredit).ToString("N2"), FastDriver.ProrationDetail.SellerCredit.FAGetValue());

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify Get Proation instance using CreateProration web service")]
        public void REG_GetProration_RENT()
        {
            try
            {
                Reports.TestDescription = "Verify Get Proration - Rent information using CreateProration web service";

                FASTSelenium.Common.FASTHelpers.FAST_Init_File();

                #region Create new Proration - Rent instance with CreateProration()
                Reports.TestStep = "Create Get Proration - Rent instance with CreateProration()";
                var index = 1;
                var request = EscrowRequestFactory.GetProrationRequest(FASTSelenium.Common.FASTHelpers.File.FileID, index, ProrationType.RENT);
                var response = EscrowService.CreateProration(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                var GetProrationReq = EscrowRequestFactory.GetServiceFileRequest(FASTSelenium.Common.FASTHelpers.File.FileID);
                var GetProrationRes = EscrowService.GetProrationDetails(GetProrationReq);
                Support.AreEqual("1", GetProrationRes.Status.ToString(), GetProrationRes.StatusDescription);
               
                #endregion

                #region Verify new Proration instance in FAST
                Reports.TestStep = "Verify new Proration instance in FAST";
                FastDriver.ProrationRent.Open();
                FastDriver.ProrationRent.ProrationTaxTable2.FAClick();
                FastDriver.ProrationRent.Edit.FAClick();
                FastDriver.ProrationDetail.WaitForScreenToLoad();
                Support.AreEqual(GetProrationRes.RentSummaryForCD[index].CreditSeller.Value.ToString(), FastDriver.ProrationDetail.CreditSeller.Selected.ToString());
                Support.AreEqual(GetProrationRes.RentSummaryForCD[index].DayOfClosePaidbySeller.Value.ToString(), FastDriver.ProrationDetail.DayofClosePaidbySeller.Selected.ToString());

                Support.AreEqual(((Decimal)GetProrationRes.RentSummaryForCD[index].Amount).ToString("N2"), FastDriver.ProrationDetail.Amount.FAGetValue());
                Support.AreEqual(((DateTime)GetProrationRes.RentSummaryForCD[index].FromDate).ToDateString(), FastDriver.ProrationDetail.FromDate.FAGetValue());
                Support.AreEqual(((DateTime)GetProrationRes.RentSummaryForCD[index].ToDate).ToDateString(), FastDriver.ProrationDetail.ToDate.FAGetValue());
                Support.AreEqual(GetProrationRes.RentSummaryForCD[index].FromDateInclusive.Value.ToString(), FastDriver.ProrationDetail.fromInclusive.Selected.ToString());
                Support.AreEqual(GetProrationRes.RentSummaryForCD[index].AmountPeriod.ToString(), FastDriver.ProrationDetail.Per.FAGetSelectedItem().ToString());

                Support.AreEqual(((Decimal)GetProrationRes.RentSummaryForCD[index].BuyerCharge).ToString("N2"), FastDriver.ProrationDetail.BuyerCharge.FAGetValue());
                Support.AreEqual(((Decimal)GetProrationRes.RentSummaryForCD[index].BuyerCredit).ToString("N2"), FastDriver.ProrationDetail.BuyerCredit.FAGetValue());
                Support.AreEqual(((Decimal)GetProrationRes.RentSummaryForCD[index].SellerCharge).ToString("N2"), FastDriver.ProrationDetail.SellerCharge.FAGetValue());
                Support.AreEqual(((Decimal)GetProrationRes.RentSummaryForCD[index].SellerCredit).ToString("N2"), FastDriver.ProrationDetail.SellerCredit.FAGetValue());

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify Get Proation instance using CreateProration web service")]
        public void REG_GetProration_MISCELLANEOUS()
        {
            try
            {
                Reports.TestDescription = "Verify create Proration - MISCELLANEOUS information using CreateProration web service";

                FASTSelenium.Common.FASTHelpers.FAST_Init_File();

                #region Create new Proration - Rent instance with CreateProration()
                Reports.TestStep = "Create Get Proration - MISCELLANEOUS instance with CreateProration()";
                var index = 1;
                var request = EscrowRequestFactory.GetProrationRequest(FASTSelenium.Common.FASTHelpers.File.FileID, index, ProrationType.MISCELLANEOUS);
                var response = EscrowService.CreateProration(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                var GetProrationReq = EscrowRequestFactory.GetServiceFileRequest(FASTSelenium.Common.FASTHelpers.File.FileID);
                var GetProrationRes = EscrowService.GetProrationDetails(GetProrationReq);
               
                #endregion

                #region Verify new Proration instance in FAST
                Reports.TestStep = "Verify new Proration instance in FAST";
                FastDriver.ProrationMisc.Open();
                FastDriver.ProrationMisc.ProrationTaxTable2.FAClick();
                FastDriver.ProrationMisc.Edit.FAClick();
                FastDriver.ProrationDetail.WaitForScreenToLoad();
                Support.AreEqual(GetProrationRes.MiscellaneousSummaryForCD[index].CreditSeller.Value.ToString(), FastDriver.ProrationDetail.CreditSeller.Selected.ToString());
                Support.AreEqual(GetProrationRes.MiscellaneousSummaryForCD[index].DayOfClosePaidbySeller.Value.ToString(), FastDriver.ProrationDetail.DayofClosePaidbySeller.Selected.ToString());

                Support.AreEqual(((Decimal)GetProrationRes.MiscellaneousSummaryForCD[index].Amount).ToString("N2"), FastDriver.ProrationDetail.Amount.FAGetValue());
                Support.AreEqual(((DateTime)GetProrationRes.MiscellaneousSummaryForCD[index].FromDate).ToDateString(), FastDriver.ProrationDetail.FromDate.FAGetValue());
                Support.AreEqual(((DateTime)GetProrationRes.MiscellaneousSummaryForCD[index].ToDate).ToDateString(), FastDriver.ProrationDetail.ToDate.FAGetValue());
                Support.AreEqual(GetProrationRes.MiscellaneousSummaryForCD[index].FromDateInclusive.Value.ToString(), FastDriver.ProrationDetail.fromInclusive.Selected.ToString());
                Support.AreEqual(GetProrationRes.MiscellaneousSummaryForCD[index].AmountPeriod.ToString(), FastDriver.ProrationDetail.Per.FAGetSelectedItem().ToString());

                Support.AreEqual(((Decimal)GetProrationRes.MiscellaneousSummaryForCD[index].BuyerCharge).ToString("N2"), FastDriver.ProrationDetail.BuyerCharge.FAGetValue());
                Support.AreEqual(((Decimal)GetProrationRes.MiscellaneousSummaryForCD[index].BuyerCredit).ToString("N2"), FastDriver.ProrationDetail.BuyerCredit.FAGetValue());
                Support.AreEqual(((Decimal)GetProrationRes.MiscellaneousSummaryForCD[index].SellerCharge).ToString("N2"), FastDriver.ProrationDetail.SellerCharge.FAGetValue());
                Support.AreEqual(((Decimal)GetProrationRes.MiscellaneousSummaryForCD[index].SellerCredit).ToString("N2"), FastDriver.ProrationDetail.SellerCredit.FAGetValue());

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify Delete Proation instance using CreateProration web service")]
        public void REG_DeleteProration_TAX()
        {
            try
            {
                Reports.TestDescription = "Verify Delete Proration - Rent information using CreateProration web service";

                FASTSelenium.Common.FASTHelpers.FAST_Init_File();

                #region Delete Proration - Rent instance with CreateProration()
                Reports.TestStep = " Delete Proration - Rent instance with CreateProration()";
                var index = 1;
                var request = EscrowRequestFactory.GetProrationRequest(FASTSelenium.Common.FASTHelpers.File.FileID, index, ProrationType.TAX);
                var response = EscrowService.CreateProration(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                request.ProrDetailsForCD.SeqNum = index + 3;
                var DeleteProration = EscrowService.DeleteProration(request);
                Support.AreEqual("1", response.Status.ToString(), DeleteProration.StatusDescription);
               
                #endregion

                #region Verify new Proration instance in FAST
                Reports.TestStep = "Verify new Proration instance in FAST";
                FastDriver.ProrationTax.Open();
                FastDriver.ProrationTax.WaitForScreenToLoad();
                bool tax_proration = FastDriver.ProrationTax.ProrationTaxTable4.Exists();
                Support.AreEqual("False", tax_proration.ToString(),"Bug has locked in TFS_ID:612569");
               
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify Delete Proation instance using CreateProration web service")]
        public void REG_DeleteProration_RENT()
        {
            try
            {
                Reports.TestDescription = "Verify create Proration - Rent information using CreateProration web service";

                FASTSelenium.Common.FASTHelpers.FAST_Init_File();

                #region Delete Proration - Rent instance with CreateProration()
                Reports.TestStep = "Delete Proration - Rent instance with CreateProration()";
                var index = 1;
                var request = EscrowRequestFactory.GetProrationRequest(FASTSelenium.Common.FASTHelpers.File.FileID, index, ProrationType.RENT);
                var response = EscrowService.CreateProration(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                request.ProrDetailsForCD.SeqNum = index + 1;
                var DeleteProration = EscrowService.DeleteProration(request);
                Support.AreEqual("1", response.Status.ToString(), DeleteProration.StatusDescription);

                #endregion

                #region Verify Deleted Proration instance in FAST
                Reports.TestStep = "Verify Deleted Proration instance in FAST";
                FastDriver.ProrationRent.Open();
                FastDriver.ProrationRent.WaitForScreenToLoad();
                bool tax_proration = FastDriver.ProrationRent.ProrationTaxTable2.Exists();
                Support.AreEqual("False", tax_proration.ToString(), "Bug has locked in TFS_ID:612569");

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }
        
        [TestMethod]
        [Description("Verify Delete Proation instance using CreateProration web service")]
        public void REG_DeleteProration_MISCELLANEOUS()
        {
            try
            {
                Reports.TestDescription = "Verify Delete Proration - Rent information using CreateProration web service";

                FASTSelenium.Common.FASTHelpers.FAST_Init_File();

                #region Delete Proration - Rent instance with DeleteProration()
                Reports.TestStep = "DeleteProration - MISCELLANEOUS instance with CreateProration()";
                var index = 1;
                var request = EscrowRequestFactory.GetProrationRequest(FASTSelenium.Common.FASTHelpers.File.FileID, index, ProrationType.MISCELLANEOUS);
                var response = EscrowService.CreateProration(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                request.ProrDetailsForCD.SeqNum = index + 1;
                var DeleteProration = EscrowService.DeleteProration(request);
                Support.AreEqual("1", response.Status.ToString(), DeleteProration.StatusDescription);

                #endregion
                #region Verify Deleted Proration instance in FAST
                Reports.TestStep = "Verify Deleted Proration instance in FAST";
                FastDriver.ProrationMisc.Open();
                FastDriver.ProrationMisc.WaitForScreenToLoad();
                bool tax_proration = FastDriver.ProrationTax.ProrationTaxTable2.Exists();
                Support.AreEqual("False", tax_proration.ToString(), "Bug has locked in TFS_ID:612569");

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }


    }
}
