﻿using FASTSelenium.Common;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using OpenQA.Selenium;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;


namespace WebServices.Escrow
{
    [CodedUITest]
    public class Utility : MasterTestClass
    {
        [TestMethod]
        [Description("Verify create Utility instance using CreateUtility web service")]
        public void Create_Utility_instance()
        {
            try
            {
                Reports.TestDescription = "Verify create Utility instance using CreateUtility web service";

                FASTSelenium.Common.FASTHelpers.FAST_Init_File();

                #region Create a new Utility instance with CreateUtility()
                Reports.TestStep = "Create a new Utility instance with CreateUtility()";
                var UtilityReq = EscrowRequestFactory.GetCreateUtilityRequest(FASTSelenium.Common.FASTHelpers.File.FileID, null);
                var UtilityRes = EscrowService.CreateUtility(UtilityReq);
                Support.AreEqual("1", UtilityRes.Status.ToString(), UtilityRes.StatusDescription);
                #endregion

                #region Verify that the Utility instance in showing in FAST
                Reports.TestStep = "Verify that the Utility instance in showing in FAST";
                FastDriver.UtilityDetail.Open();
                Support.AreEqual("415", FastDriver.UtilityDetail.GabCodeLabel.FAGetText().Trim(), "GabCodeLabel");

                string BuyerCharge = FastDriver.UtilityDetail.UtilityChargesBuyerCharge.FAGetValue();
                 if (BuyerCharge == "1,000,000.00")
                {
                    BuyerCharge = "1000000";
                }
                 Support.AreEqual(UtilityReq.Utility.UtilityCharges.UtilityCDChargesList[0].BuyerCharge.Value.ToString(), BuyerCharge);
                string SellerCharge = FastDriver.UtilityDetail.UtilityChargesSellerCharge.FAGetValue();
                if (SellerCharge == "1,000,000.00")
                {
                    SellerCharge = "1000000";
                }
                Support.AreEqual(UtilityReq.Utility.UtilityCharges.UtilityCDChargesList[0].SellerCharge.Value.ToString(), SellerCharge);
                string prorationamt = null;
                if (UtilityReq.Utility.Proration.Amount.Value.ToString() == "50000")
                {
                    prorationamt = "50,000.00";
                }
                Support.AreEqual(prorationamt, FastDriver.UtilityDetail.ProrationAmount.FAGetValue());
                Support.AreEqual(UtilityReq.Utility.Proration.FromDateInclusive.Value.ToString(), FastDriver.UtilityDetail.fromInclusive.Selected.ToString());
                Support.AreEqual(UtilityReq.Utility.Proration.ToDateInclusive.Value.ToString(), FastDriver.UtilityDetail.toInclusive.Selected.ToString());
                Support.AreEqual(UtilityReq.Utility.Proration.BasedOnDays.Value.ToString(), FastDriver.UtilityDetail.BasedOn.FAGetSelectedItem().ToString());
                Support.AreEqual(UtilityReq.Utility.Proration.AmountPeriod.ToString(), FastDriver.UtilityDetail.Per.FAGetSelectedItem().ToString());

                FastDriver.UtilityDetail.PaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                string atclosingbuyer=null;
                if (UtilityReq.Utility.UtilityCharges.UtilityCDChargesList[0].AtClosingBuyerPaymentMethodTypeID.ToString()=="CHK")
                {
                    atclosingbuyer = "Check";
                }
                Support.AreEqual(atclosingbuyer, FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FAGetSelectedItem().ToString().Replace(" ", ""));
                string atclosingseller = null;
                if (UtilityReq.Utility.UtilityCharges.UtilityCDChargesList[0].AtClosingBuyerPaymentMethodTypeID.ToString() == "CHK")
                {
                    atclosingseller = "Check";
                }
                Support.AreEqual(atclosingseller, FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod.FAGetSelectedItem().ToString().Replace(" ", ""));
                Support.AreEqual(UtilityReq.Utility.UtilityCharges.UtilityCDChargesList[0].PBOthersForBuyerPMTypeCdID.ToString(), FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FAGetSelectedItem().ToString());
                Support.AreEqual(UtilityReq.Utility.UtilityCharges.UtilityCDChargesList[0].PBOthersForSellerPMTypeCdID.ToString(), FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FAGetSelectedItem().ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify Update_Utility_Defaults instance using CreateUtility web service")]
        public void Update_Utility_instance()
        {
            try
            {
                Reports.TestDescription = "Verify create Utility instance using CreateUtility web service";

                FASTSelenium.Common.FASTHelpers.FAST_Init_File();

                #region Create a new Utility instance with CreateUtility()

                Reports.TestStep = "Create  a new Utility instance with CreateUtility()";
                var UtilityReq = EscrowRequestFactory.GetCreateUtilityRequest(FASTSelenium.Common.FASTHelpers.File.FileID, 1);
                var UtilityRes = EscrowService.CreateUtility(UtilityReq);
                Support.AreEqual("1", UtilityRes.Status.ToString(), UtilityRes.StatusDescription);
                Reports.TestStep = "Verify that the Utility instance in showing in FAST";
                FastDriver.UtilityDetail.Open();
                Support.AreEqual("415", FastDriver.UtilityDetail.GabCodeLabel.FAGetText().Trim(), "GabCodeLabel");

                #endregion
                Reports.TestStep = "Update existing Utility instance with UpdateUtility()";
               
                var UpdateUtilityReq = EscrowRequestFactory.GetUpdateUtilityRequest(FASTSelenium.Common.FASTHelpers.File.FileID, 1);
                var UpdateUtilityRes = EscrowService.UpdateUtility(UpdateUtilityReq);
                
                #region Verify that the Utility instance in showing in FAST
                Reports.TestStep = "Verify that the Utility instance in showing in FAST";
                FastDriver.UtilityDetail.Open();
                Support.AreEqual("247", FastDriver.UtilityDetail.GabCodeLabel.FAGetText().Trim(), "GabCodeLabel");

                

                string BuyerCharge = FastDriver.UtilityDetail.UtilityChargesBuyerCharge.FAGetValue();
                if (BuyerCharge == "1,000,000.00")
                {
                    BuyerCharge = "1000000";
                }
                Support.AreEqual(UpdateUtilityReq.Utility.UtilityCharges.UtilityCDChargesList[0].BuyerCharge.Value.ToString(), BuyerCharge);
                string SellerCharge = FastDriver.UtilityDetail.UtilityChargesSellerCharge.FAGetValue();
                if (SellerCharge == "1,000,000.00")
                {
                    SellerCharge = "1000000";
                }
                Support.AreEqual(UpdateUtilityReq.Utility.UtilityCharges.UtilityCDChargesList[0].SellerCharge.Value.ToString(), SellerCharge);
                string prorationamt = null;
                if (UpdateUtilityReq.Utility.Proration.Amount.Value.ToString() == "50000")
                {
                    prorationamt = "50,000.00";
                }
                Support.AreEqual(prorationamt, FastDriver.UtilityDetail.ProrationAmount.FAGetValue());
                Support.AreEqual(UpdateUtilityReq.Utility.Proration.FromDateInclusive.Value.ToString(), FastDriver.UtilityDetail.fromInclusive.Selected.ToString());
                Support.AreEqual(UpdateUtilityReq.Utility.Proration.ToDateInclusive.Value.ToString(), FastDriver.UtilityDetail.toInclusive.Selected.ToString());
                Support.AreEqual(UpdateUtilityReq.Utility.Proration.BasedOnDays.Value.ToString(), FastDriver.UtilityDetail.BasedOn.FAGetSelectedItem().ToString());
                Support.AreEqual(UpdateUtilityReq.Utility.Proration.AmountPeriod.ToString(), FastDriver.UtilityDetail.Per.FAGetSelectedItem().ToString());

                FastDriver.UtilityDetail.PaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                string atclosingbuyer = null;
                if (UpdateUtilityReq.Utility.UtilityCharges.UtilityCDChargesList[0].AtClosingBuyerPaymentMethodTypeID.ToString() == "NoCheck")
                {
                    atclosingbuyer = "NoCheck";
                }
                Support.AreEqual(atclosingbuyer, FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FAGetSelectedItem().ToString().Replace(" ", ""));
                string atclosingseller = null;
                if (UpdateUtilityReq.Utility.UtilityCharges.UtilityCDChargesList[0].AtClosingBuyerPaymentMethodTypeID.ToString() == "NoCheck")
                {
                    atclosingseller = "NoCheck";
                }
                Support.AreEqual(atclosingseller, FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod.FAGetSelectedItem().ToString().Replace(" ", ""));
                Support.AreEqual(UpdateUtilityReq.Utility.UtilityCharges.UtilityCDChargesList[0].PBOthersForBuyerPMTypeCdID.ToString(), FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FAGetSelectedItem().ToString());
                Support.AreEqual(UpdateUtilityReq.Utility.UtilityCharges.UtilityCDChargesList[0].PBOthersForSellerPMTypeCdID.ToString(), FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FAGetSelectedItem().ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify Get_Utility_Defaults instance using CreateUtility web service")]
        public void Get_Utility_Defaults()
        {
            try
            {
                Reports.TestDescription = "Verify create Utility instance using CreateUtility web service";

                FASTSelenium.Common.FASTHelpers.FAST_Init_File();

                #region Create a new Utility instance with CreateUtility()
                Reports.TestStep = "Create and getUtility instance with GetUtilityRequest()";
                var UtilityReq = EscrowRequestFactory.GetCreateUtilityRequest(FASTSelenium.Common.FASTHelpers.File.FileID, null);
                var UtilityRes = EscrowService.CreateUtility(UtilityReq);
                Support.AreEqual("1", UtilityRes.Status.ToString(), UtilityRes.StatusDescription);
                var GetUtilityReq = EscrowRequestFactory.GetUtilityRequest(FASTSelenium.Common.FASTHelpers.File.FileID, 1);
                var GetUtilityDetailsRes = EscrowService.GetUtilityDetails(GetUtilityReq);

                #endregion

                #region Verify that the Utility instance in showing in FAST
                Reports.TestStep = "Verify that the Utility instance in showing in FAST";
                FastDriver.UtilityDetail.Open();
                Support.AreEqual("415", FastDriver.UtilityDetail.GabCodeLabel.FAGetText().Trim(), "GabCodeLabel");

                string BuyerCharge = FastDriver.UtilityDetail.UtilityChargesBuyerCharge.FAGetValue();
                if (BuyerCharge == "1,000,000.00")
                {
                    BuyerCharge = "1000000";
                }
                Support.AreEqual(GetUtilityDetailsRes.UtilityDetails.UtilityCharges.UtilityCDChargesList[0].BuyerCharge.Value.ToString(), BuyerCharge);
                string SellerCharge = FastDriver.UtilityDetail.UtilityChargesSellerCharge.FAGetValue();
                if (SellerCharge == "1,000,000.00")
                {
                    SellerCharge = "1000000";
                }
                Support.AreEqual(GetUtilityDetailsRes.UtilityDetails.UtilityCharges.UtilityCDChargesList[0].SellerCharge.Value.ToString(), SellerCharge);
                string prorationamt = null;
                if (GetUtilityDetailsRes.UtilityDetails.Proration.Amount.Value.ToString() == "50000")
                {
                    prorationamt = "50,000.00";
                }
                Support.AreEqual(prorationamt, FastDriver.UtilityDetail.ProrationAmount.FAGetValue());
                Support.AreEqual(GetUtilityDetailsRes.UtilityDetails.Proration.FromDateInclusive.Value.ToString(), FastDriver.UtilityDetail.fromInclusive.Selected.ToString());
                Support.AreEqual(GetUtilityDetailsRes.UtilityDetails.Proration.ToDateInclusive.Value.ToString(), FastDriver.UtilityDetail.toInclusive.Selected.ToString());
                Support.AreEqual(GetUtilityDetailsRes.UtilityDetails.Proration.BasedOnDays.Value.ToString(), FastDriver.UtilityDetail.BasedOn.FAGetSelectedItem().ToString());
                Support.AreEqual(GetUtilityDetailsRes.UtilityDetails.Proration.AmountPeriod.ToString(), FastDriver.UtilityDetail.Per.FAGetSelectedItem().ToString());

                FastDriver.UtilityDetail.PaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                string atclosingbuyer = null;
                if (GetUtilityDetailsRes.UtilityDetails.UtilityCharges.UtilityCDChargesList[0].AtClosingBuyerPaymentMethodTypeID.ToString() == "CHK")
                {
                    atclosingbuyer = "Check";
                }
                Support.AreEqual(atclosingbuyer, FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FAGetSelectedItem().ToString().Replace(" ", ""));
                string atclosingseller = null;
                if (GetUtilityDetailsRes.UtilityDetails.UtilityCharges.UtilityCDChargesList[0].AtClosingBuyerPaymentMethodTypeID.ToString() == "CHK")
                {
                    atclosingseller = "Check";
                }
                Support.AreEqual(atclosingseller, FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod.FAGetSelectedItem().ToString().Replace(" ", ""));
                Support.AreEqual(GetUtilityDetailsRes.UtilityDetails.UtilityCharges.UtilityCDChargesList[0].PBOthersForBuyerPMTypeCdID.ToString(), FastDriver.PaymentDetailsDlg.BuyerPaidByOthersPaymentMethod.FAGetSelectedItem().ToString());
                Support.AreEqual(GetUtilityDetailsRes.UtilityDetails.UtilityCharges.UtilityCDChargesList[0].PBOthersForSellerPMTypeCdID.ToString(), FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FAGetSelectedItem().ToString());
                FastDriver.DialogBottomFrame.ClickDone();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify Get_Utility_Defaults instance using CreateUtility web service")]
        public void Remove_Utility_Defaults()
        {
            try
            {
                Reports.TestDescription = "Verify Remove Utility instance using CreateUtility web service";

                FASTSelenium.Common.FASTHelpers.FAST_Init_File();

                #region Create a new Utility instance with CreateUtility()
                Reports.TestStep = "Create and remove Utility instance with GetUtilityRequest()";
                var UtilityReq = EscrowRequestFactory.GetCreateUtilityRequest(FASTSelenium.Common.FASTHelpers.File.FileID, null);
                var UtilityRes = EscrowService.CreateUtility(UtilityReq);
                Support.AreEqual("1", UtilityRes.Status.ToString(), UtilityRes.StatusDescription);
                var RemoveUtilityReq = EscrowRequestFactory.GetRemoveUtilityRequest(FASTSelenium.Common.FASTHelpers.File.FileID, 1);
                var RemoveUtilityRes = EscrowService.RemoveUtility(RemoveUtilityReq);
                Support.AreEqual("1", RemoveUtilityRes.Status.ToString(), RemoveUtilityRes.StatusDescription);
                #endregion

                #region Verify utility instance is removed in FAST
                Reports.TestStep = "Verify utility instance is removed in FAST";
                FastDriver.UtilityDetail.Open();
                Support.AreEqual("", FastDriver.UtilityDetail.GabCodeLabel.FAGetText().Trim(), "GabCodeLabel");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Verify create Utility instance using CreateUtility web service")]
        public void GetSummary_Utility_instance()
        {
            try
            {
                Reports.TestDescription = "Verify create Utility instance using CreateUtility web service";

                FASTSelenium.Common.FASTHelpers.FAST_Init_File();

                #region Create a new Utility instance with CreateUtility()
                Reports.TestStep = "Create a new Utility instance with CreateUtility()";
                var UtilityReq = EscrowRequestFactory.GetCreateUtilityRequest(FASTSelenium.Common.FASTHelpers.File.FileID, null);
                var UtilityRes = EscrowService.CreateUtility(UtilityReq);
                Support.AreEqual("1", UtilityRes.Status.ToString(), UtilityRes.StatusDescription);
                UtilityReq = EscrowRequestFactory.GetCreateUtilityRequest(FASTSelenium.Common.FASTHelpers.File.FileID, null);
                UtilityRes = EscrowService.CreateUtility(UtilityReq);
                var UtilitySymmaryReq = EscrowRequestFactory.GetUtilitySymmaryRequest(FASTSelenium.Common.FASTHelpers.File.FileID);
                var UtilitySymmaryRes = EscrowService.GetUtilitySummaryResponse(UtilitySymmaryReq);
                Support.AreEqual("1", UtilitySymmaryRes.Status.ToString(), UtilityRes.StatusDescription);
                #endregion

                #region Verify that the Utility instance in showing in FAST
                Reports.TestStep = "Verify that the Utility instance in showing in FAST";
                FastDriver.LeftNavigation.Navigate<UtilityDetail>("Home>Order Entry>Escrow Charge Processes>Utility");
                FastDriver.UtilitySummary.WaitForScreenToLoad();
                Support.AreEqual(UtilitySymmaryRes.NumberOfRecords.Value.ToString(), (FastDriver.UtilitySummary.SummaryTable.FindElements(By.TagName("tr")).Count-1).ToString());
                
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }


        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
