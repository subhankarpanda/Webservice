﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using FASTSelenium.DataObjects.IIS;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastEscrowService;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using WebServices.Helpers.Escrow;
using WebServices.Helpers.File;

namespace WebServices.Escrow
{
    [CodedUITest]
    public class EscrowTransactionsWS : MasterTestClass
    {
        [TestMethod]
        public void REG0001_CreateDepositOutSideEscrow()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                #endregion

                Reports.TestDescription = "Verify CreateDepositOutSideEscrow() Service";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a HUD file using web service";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                var file = FileService.GetOrderDetails(fileId).FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(file);

                Reports.TestStep = "Invoke GetDepositOutSideEscrow Service";
                var GetDepositOERequest = EscrowRequestFactory.GetDepositOERequest(fileId);
                var GetDepositOEResponse = EscrowService.GetDepositOE(GetDepositOERequest);
                Support.AreEqual("1", GetDepositOEResponse.Status.ToString(), "Status Code");
                Support.AreEqual("Deposit Outside Escrow data Loaded Successfully.", GetDepositOEResponse.StatusDescription, "Status Description");

                Reports.TestStep = "Invoke CreateDepositOutSideEscrow Service";
                var CreateDepositOERequest = EscrowRequestFactory.GetCreateDepositOutSideEscrowRequest(fileId);

                var CreateDepositOEResponse = EscrowService.CreateDepositOutSideEscrow(CreateDepositOERequest);
                CreateDepositOEResponse.Validate();

                Reports.TestStep = "Navigate to Deposit Outside Escrow";
                FastDriver.DepositOutsideEscrow.Open();

                Reports.TestStep = "Verify Deposit Outside Escrow is filled with data from web service request";
                Support.AreEqual(CreateDepositOERequest.CDDepositOESaveRequest.TotalAmount.Value.ToString().FormatAsMoney(), FastDriver.DepositOutsideEscrow.TotalDeposit.FAGetValue(), "Deposit/Amount");
                Support.AreEqual(CreateDepositOERequest.CDDepositOESaveRequest.EarnestDeposits[0].HolderEntityTypeCdID.Value.ToString(), FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_0.FAGetAttribute("value"), "Held By 1 Type");
                Support.AreEqual(CreateDepositOERequest.CDDepositOESaveRequest.EarnestDeposits[0].HolderName.ToString(), FastDriver.DepositOutsideEscrow.EarnerstMoneyName_0.FAGetValue(), "Held By 1 Name");
                Support.AreEqual(CreateDepositOERequest.CDDepositOESaveRequest.EarnestDeposits[0].EarnestAmount.Value.ToString().FormatAsMoney(), FastDriver.DepositOutsideEscrow.EarnerstMoneyAmount_0.FAGetValue(), "Held By 1 Amount");
                Support.AreEqual(CreateDepositOERequest.CDDepositOESaveRequest.EarnestDeposits[1].HolderEntityTypeCdID.Value.ToString(), FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_1.FAGetAttribute("value"), "Held By 2 Type");
                Support.AreEqual(CreateDepositOERequest.CDDepositOESaveRequest.EarnestDeposits[1].HolderName.ToString(), FastDriver.DepositOutsideEscrow.EarnerstMoneyName_1.FAGetValue(), "Held By 2 Name");
                Support.AreEqual(CreateDepositOERequest.CDDepositOESaveRequest.EarnestDeposits[1].EarnestAmount.Value.ToString().FormatAsMoney(), FastDriver.DepositOutsideEscrow.EarnerstMoneyAmount_1.FAGetValue(), "Held By 2 Amount");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0002_AdjustEscrowDeposit()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                #endregion

                Reports.TestDescription = "Verify AdjustEscrowDeposit() Service";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a file using web service";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                var file = FileService.GetOrderDetails(fileId).FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(file);
                
                Reports.TestStep = "Invoke GetDepositInEscrowRequest Service";
                var GetDepositInEscrowRequest = EscrowRequestFactory.GetDepositInEscrowRequest(fileId);
                GetDepositInEscrowRequest.DepositInEscrow.DepositEscrow.BankAcctID = 11715;
                var GetDepositInEscrowResponse = EscrowService.CreateDepositInEscrow(GetDepositInEscrowRequest);
                GetDepositInEscrowResponse.Validate();

                Reports.TestStep = "Invoke GetDepositHistorySummary Service";
                var GetDepositHistorySummaryRequest = EscrowRequestFactory.GetDepositHistorySummaryRequest(fileId);
                var GetDepositHistorySummaryResponse = EscrowService.GetDepositHistorySummary(GetDepositHistorySummaryRequest);
                GetDepositHistorySummaryResponse.Validate();
                var depositId = GetDepositHistorySummaryResponse.DepositActivities[0].DepositID.Value;

                Reports.TestStep = "Invoke AdjustEscrowDeposit Service";
                var AdjustEscrowDepositRequest = EscrowRequestFactory.GetAdjustEscrowDepositRequest(fileId, depositId);
                var AdjustEscrowDepositResponse = EscrowService.AdjustEscrowDeposit(AdjustEscrowDepositRequest);
                AdjustEscrowDepositResponse.Validate();

                Reports.TestStep = "Navigate to Deposit/Receipt History";
                FastDriver.DepositReceiptHistory.Open();

                var oldAmount = GetDepositInEscrowRequest.DepositInEscrow.DepositEscrow.Amount.Value.ToString().FormatAsMoney();
                var correctAmount = AdjustEscrowDepositRequest.DepositAdjustment.CorrectingTransaction.Amount.Value.ToString().FormatAsMoney();

                Reports.TestStep = "Verify Deposit Outside Escrow is filled with data from web service request";
                Support.AreEqual("Adjusted", FastDriver.DepositReceiptHistory.ReceiptsDepositActivityTable.PerformTableAction(6, oldAmount, 1, TableAction.GetText).Message, "Status");
                Support.AreEqual(AdjustEscrowDepositRequest.DepositAdjustment.CorrectingTransaction.Amount.Value.ToString().FormatAsMoney(), FastDriver.DepositReceiptHistory.ReceiptsDepositActivityTable.PerformTableAction(6, correctAmount, 6, TableAction.GetText).Message.Clean(), "New Amount");
                Support.AreEqual(AdjustEscrowDepositRequest.DepositAdjustment.CorrectingTransaction.Description, FastDriver.DepositReceiptHistory.ReceiptsDepositActivityTable.PerformTableAction(6, correctAmount, 8, TableAction.GetText).Message, "Description");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0003_GetDepositHistorySummary()
        {
            try
            {
                Reports.TestDescription = "Verify GetDepositHistorySummary service";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetDetailedCreateFileDefaultRequest();
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a file using web service";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                string fileNum = FileService.GetOrderDetails(fileId).FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(fileNum);

                Reports.TestStep = "Create a deposit in escrow (WS)";
                var GetDepositInEscrowRequest = EscrowRequestFactory.GetDepositInEscrowRequest(fileId);
                var GetDepositInEscrowResponse = EscrowService.CreateDepositInEscrow(GetDepositInEscrowRequest);
                GetDepositInEscrowResponse.Validate();

                Reports.TestStep = "Invoke GetDepositHistorySummary method, validate response (WS)";
                var request = EscrowRequestFactory.GetServiceFileRequest(fileId);
                var response = EscrowTransactionsHelpers.GetDepositHistorySummary(request);
                response.Validate();

                Reports.TestStep = "Navigate to Deposit/Receipt History screen, validate Document # and Amount";
                FastDriver.DepositReceiptHistory.Open();
                Support.AreEqual(response.DepositActivities[0].DepositAmount.ToString().FormatAsMoney(), FastDriver.DepositReceiptHistory.ReceiptsDepositActivityTable.PerformTableAction(1, 6, TableAction.GetText).Message.Clean(), "Deposit Amount");
                Support.AreEqual(response.DepositActivities[0].DocumentNumber, FastDriver.DepositReceiptHistory.ReceiptsDepositActivityTable.PerformTableAction(1, 4, TableAction.GetText).Message.Clean(), "Document Number");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally { FastDriver.WebDriver.Quit(); }
        }

        [TestMethod]
        public void REG0004_GetDepositHistoryViewDetails()
        {
            try
            {
                Reports.TestDescription = "Verify GetDepositHistoryViewDetails service";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetDetailedCreateFileDefaultRequest();
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a file using web service";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                string fileNum = FileService.GetOrderDetails(fileId).FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(fileNum);

                Reports.TestStep = "Create a deposit in escrow (WS)";
                var GetDepositInEscrowRequest = EscrowRequestFactory.GetDepositInEscrowRequest(fileId);
                var GetDepositInEscrowResponse = EscrowService.CreateDepositInEscrow(GetDepositInEscrowRequest);
                GetDepositInEscrowResponse.Validate();
                int depositID = (int) GetDepositInEscrowResponse.DepositInEscrow.DepositEscrow.InEscrowID;

                Reports.TestStep = "Invoke GetDepositHistoryViewDetails method, validate response (WS)";
                var request = EscrowRequestFactory.GetDepositImagesRequest(fileId, depositID);
                var response = EscrowTransactionsHelpers.GetDepositHistoryViewDetails(request);
                response.Validate();

                Reports.TestStep = "Navigate to Deposit/Receipt History screen, validate Receipt # and Amount";
                FastDriver.DepositReceiptHistory.Open();
                Support.AreEqual(response.DepositInEscrow.DepositEscrow.Amount.ToString().FormatAsMoney(), FastDriver.DepositReceiptHistory.ReceiptsDepositActivityTable.PerformTableAction(1, 6, TableAction.GetText).Message.Clean(), "Deposit Amount");
                Support.AreEqual(response.DepositInEscrow.DepositEscrow.ReceiptNumber, FastDriver.DepositReceiptHistory.ReceiptsDepositActivityTable.PerformTableAction(1, 4, TableAction.GetText).Message.Clean(), "Document Number");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally { FastDriver.WebDriver.Quit(); }
        }
        
        [TestMethod]
        public void REG0005_GetDepositList()
        {
            // TFS # 564133
            //try
            //{
            //    Reports.TestDescription = "Verify GetDepositList service";

            //    #region data setup
            //    var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

            //    var fileRequest = FileRequestFactory.GetDetailedCreateFileDefaultRequest();
            //    #endregion

            //    Reports.TestStep = "Log into FAST application.";
            //    FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

            //    Reports.TestStep = "Create a file using web service";
            //    int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
            //    string fileNum = FileService.GetOrderDetails(fileId).FileNumber;
            //    FastDriver.TopFrame.SearchFileByFileNumber(fileNum);

            //    Reports.TestStep = "Create a deposit in escrow (WS)";
            //    var GetDepositInEscrowRequest = EscrowRequestFactory.GetDepositInEscrowRequest(fileId);
            //    var GetDepositInEscrowResponse = EscrowService.CreateDepositInEscrow(GetDepositInEscrowRequest);
            //    GetDepositInEscrowResponse.Validate();
            //    int depositID = (int) GetDepositInEscrowResponse.DepositInEscrow.DepositEscrow.InEscrowID;

            //    Reports.TestStep = "Invoke GetDepositHistoryViewDetails method, validate response (WS)";
            //    var request = EscrowRequestFactory.GetDepositListDetailsRequest(fileId, depositID);
            //    var response = EscrowTransactionsHelpers.GetDepositList(request);
            //    response.Validate();

            //    Reports.TestStep = "Navigate to Deposit/Receipt History screen, validate Receipt # and Amount";
            //    FastDriver.DepositReceiptHistory.Open();
            //    Support.AreEqual(response.DepositInEscrow.DepositEscrow.Amount.ToString().FormatAsMoney(), FastDriver.DepositReceiptHistory.ReceiptsDepositActivityTable.PerformTableAction(1, 6, TableAction.GetText).Message.Clean(), "Deposit Amount");
            //    Support.AreEqual(response.DepositInEscrow.DepositEscrow.ReceiptNumber, FastDriver.DepositReceiptHistory.ReceiptsDepositActivityTable.PerformTableAction(1, 4, TableAction.GetText).Message.Clean(), "Document Number");
            //}
            //catch (Exception ex)
            //{
            //    FailTest(ex.Message);
            //}
            //finally { FastDriver.WebDriver.Quit(); }
        }

        [TestMethod]
        public void REG0006_SaveDepositList()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                #endregion

                Reports.TestDescription = "Verify SaveDepositList() service";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a file using web service";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                var file = FileService.GetOrderDetails(fileId).FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(file);

                Reports.TestStep = "Check if there are any Pending deposit list";
                FastDriver.LeftNavigation.Navigate<DepositList>("Home>Business Unit Processing>Deposit Slip>Deposit List").WaitForScreenToLoad();
                FastDriver.DepositList.FindNow.FAClick();
                FastDriver.DepositList.WaitForScreenToLoad(FastDriver.DepositList.DepositListTable);
                if (FastDriver.DepositList.DepositListTable.StringExistOnTable("Pending"))
                {
                    FastDriver.DepositList.DepositListTable.PerformTableAction(2, "Pending", 2, TableAction.Click);
                    FastDriver.DepositList.Edit.FAClick();
                    FastDriver.DepositList.WaitForScreenToLoad(FastDriver.DepositList.ReceiptsTable); 
                    FastDriver.DepositList.Complete.FAClick();
                    FastDriver.PrintDlg.WaitForScreenToLoad();
                    FastDriver.PrintDlg.ClickCancel();
                }

                Reports.TestStep = "Navigate to Deposit List screen, click New button";
                FastDriver.LeftNavigation.Navigate<DepositList>("Home>Business Unit Processing>Deposit Slip>Deposit List").WaitForScreenToLoad();
                FastDriver.DepositList.New.FAClick();

                Reports.TestStep = "Complete the New deposit list";
                FastDriver.DepositList.WaitForScreenToLoad(FastDriver.DepositList.ReceiptsTable);
                FastDriver.DepositList.DepositListEdit_FindNow.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(true, true, 20, true);
                FastDriver.DepositList.WaitForScreenToLoad(FastDriver.DepositList.ReceiptsTable);
                FastDriver.DepositList.ReceiptsTable.PerformTableAction(1, 1, TableAction.On);
                string fileNumber = FastDriver.DepositList.ReceiptsTable.PerformTableAction(1, 6, TableAction.GetText).Message.Clean();
                string depositFileID = FileService.GetFilesByFileNum(fileNumber, Convert.ToInt32(AutoConfig.SelectedRegionBUID), 1).FileSearchResults[0].FileID.ToString();
                FastDriver.DepositList.Complete.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("Blank Page", false, 20, false);

                Reports.TestStep = "Click Cancel on the Print dialog";
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.ClickCancel();

                Reports.TestStep = "Find the Deposit List ID, using SQL query";
                int depositListID = FASqlHelpers.FindDepositListID(depositFileID);

                Reports.TestStep = "Invoke ReadDepositListDetails method (WS)";
                var request = EscrowRequestFactory.GetReadDepositListDetailsRequest(depositListID, "");
                var response = EscrowService.ReadDepositListDetails(request);

                Reports.TestStep = "Invoke SaveDepositList Service, validate response (WS)";
                var SaveDepositListRequest = EscrowRequestFactory.GetSaveDepositListRequest();
                SaveDepositListRequest.DepositListDetails = new DepositListSaveDetail[]
                {
                    new DepositListSaveDetail()
                    {
                        BankAcctID = response.DepositListDetails[0].BankAcctID,
                        BusinessUnitID = response.DepositListDetails[0].BusinessUnitID,
                        CurrentUserID = 1,
                        DepositListStatusTypecdID = response.DepositListDetails[0].DepositListStatusTypecdID,
                        NumberOfReceipts = 1,
                        UpdatedEmployeeID = 1
                    }
                };
                SaveDepositListRequest.DepositReceipt = new DepositReceipt[]
                {
                    new DepositReceipt()
                    {
                        FileID = response.DepositListDetails[0].DepositReceipts[0].FileID,
                        FileNum = response.DepositListDetails[0].DepositReceipts[0].FileNum,
                        InEscrowID = FASqlHelpers.FindInEscrowID(depositFileID),
                        ReceiptNum = response.DepositListDetails[0].DepositReceipts[0].ReceiptNum,
                        UserSelect = "1"
                    }
                };
                var SaveDepositListResponse = EscrowService.SaveDepositList(SaveDepositListRequest);
                Support.AreEqual("1", SaveDepositListResponse.Status.ToString(), "Operation Status");
                Support.AreEqual("Deposit List operation Success", SaveDepositListResponse.StatusDescription.Clean(), "Operation Status Description");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally { FastDriver.WebDriver.Quit(); }
        }

        [TestMethod]
        public void REG0007_GetExcludedReceipts()
        {
            try
            {
                Reports.TestDescription = "Verify GetExcludedReceipts service";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = FileRequestFactory.GetDetailedCreateFileDefaultRequest();
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a file using web service";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                string fileNum = FileService.GetOrderDetails(fileId).FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(fileNum);

                Reports.TestStep = "Navigate to Excluded Receipts screen, click Find Now";
                FastDriver.ExcludedReceipts.Open();
                string fromDate = FastDriver.ExcludedReceipts.FromDate.FAGetValue();
                string toDate = FastDriver.ExcludedReceipts.ToDate.FAGetValue();
                FastDriver.ExcludedReceipts.FindNow.FAClick();

                Reports.TestStep = "Invoke GetDepositHistorySummary method, validate response (WS)";
                var request = EscrowRequestFactory.GetExcludedReceiptLoadRequest(AutoConfig.SelectedOfficeBUID, fromDate, toDate);
                var response = EscrowTransactionsHelpers.GetExcludedReceipts(request);
                response.Validate();

                Reports.TestStep = "Validate number of records returned";
                Support.AreEqual(FastDriver.ExcludedReceipts.ExcludedReceiptsTable.GetRowCount().ToString(), response.ExcludedReceipts.Length.ToString(), "Number of Record");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally { FastDriver.WebDriver.Quit(); }
        }

        [TestMethod]
        public void REG0008_GetSplitDisbursementDetail()
        {
            try
            {
                Reports.TestDescription = "Verify GetSplitDisbursementDetail service";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = FileRequestFactory.GetDetailedCreateFileDefaultRequest();
                var deposit = new DepositParameters()
                {
                    Amount = 10000.00,
                    TypeofFunds = "Cash",
                    Representing = "Additional Closing Costs",
                    Description = "Sanity Deposit In Escrow",
                    ReceivedFrom = "Buyer",
                    Payor = "Buyer"
                };
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a file using web service";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                string fileNum = FileService.GetOrderDetails(fileId).FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(fileNum);

                Reports.TestStep = "Set default check printer";
                FastDriver.LeftNavigation.Navigate<PrinterConfiguration>(@"Home>Printer Configuration").WaitForScreenToLoad();
                FastDriver.PrinterConfiguration.SetDefaultPrinter();

                Reports.TestStep = "Making a cash deposit";
                FastDriver.DepositInEscrow.Open();
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.PrintDlg.SelectPrinter(@"TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.ClickPrint();
                FastDriver.WebDriver.WaitForDeliveryWindow(FADeliveryMethod.Print, 200);

                Reports.TestStep = "Navigate to Home Warranty screen, enter buyer charge";
                FastDriver.HomeWarrantyDetail.Open();
                FastDriver.HomeWarrantyDetail.FindGABCode("BOA");
                FastDriver.HomeWarrantyDetail.HomeWarrantyChargeDescription.FASetText("Home Warranty");
                FastDriver.HomeWarrantyDetail.HomeWarrantyBuyerCharge.FASetText("100.00" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Active Disbursement Summary screen, perform split disbursement";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(7, "100.00", 7, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Split.FAClick();
                FastDriver.SplitDisbursement.WaitForScreenToLoad();
                FastDriver.SplitDisbursement.SplitDistributionAmount0.FASetText("60.00" + FAKeys.Tab);
                Thread.Sleep(5000);
                FastDriver.SplitDisbursement.SplitDistributionAmount1.FASetText("40.00");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Wait for SDN search to complete";
                FastDriver.SDNTrackingSummary.WaitForSDNSearchComplete(30);

                Reports.TestStep = "Print the first split check";
                PrintCheck("60.00");

                Reports.TestStep = "Get Super DisbursementID (WC)";
                int disbursementID = 0;
                var ressponse1 = FileService.GetDisbursementHistorySummary(fileId, @"fastts\fastqa07");
                
                foreach (DisbursementActivity disburse in ressponse1.DisbursementActivities)
                {
                    if (disburse.SplitIndicator == "M")
                    {
                        disbursementID = (int)disburse.DisbursementID;
                        break;
                    }
                }

                Reports.TestStep = "Invoke GetSplitDisbursementDetail method, validate response (WS)";
                var request = EscrowRequestFactory.GetSplitDisbDetailRequest(fileId, disbursementID);
                var response = EscrowTransactionsHelpers.GetSplitDisbursementDetail(request);
                response.Validate();

                Reports.TestStep = "Validate split amounts";
                Support.AreEqual("60", response.splitDistributions[0].Amount.ToString(), "Check 1 Amount");
                Support.AreEqual("40", response.splitDistributions[1].Amount.ToString(), "Check 2 Amount");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally { FastDriver.WebDriver.Quit(); }
        }

        [TestMethod]
        public void REG0009_GetDisbursementTrackDetails()
        {
            try
            {
                Reports.TestDescription = "Verify GetDisbursementTrackDetails service";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = FileRequestFactory.GetDetailedCreateFileDefaultRequest();
                var deposit = new DepositParameters()
                {
                    Amount = 10000.00,
                    TypeofFunds = "Cash",
                    Representing = "Additional Closing Costs",
                    Description = "Sanity Deposit In Escrow",
                    ReceivedFrom = "Buyer",
                    Payor = "Buyer"
                };
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a file using web service";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                string fileNum = FileService.GetOrderDetails(fileId).FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(fileNum);

                Reports.TestStep = "Set default check printer";
                FastDriver.LeftNavigation.Navigate<PrinterConfiguration>(@"Home>Printer Configuration").WaitForScreenToLoad();
                FastDriver.PrinterConfiguration.SetDefaultPrinter();

                Reports.TestStep = "Making a cash deposit";
                FastDriver.DepositInEscrow.Open();
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.PrintDlg.SelectPrinter(@"TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.ClickPrint();
                FastDriver.WebDriver.WaitForDeliveryWindow(FADeliveryMethod.Print, 200);

                Reports.TestStep = "Navigate to Home Warranty screen, enter buyer charge";
                FastDriver.HomeWarrantyDetail.Open();
                FastDriver.HomeWarrantyDetail.FindGABCode("BOA");
                FastDriver.HomeWarrantyDetail.HomeWarrantyChargeDescription.FASetText("Home Warranty");
                FastDriver.HomeWarrantyDetail.HomeWarrantyBuyerCharge.FASetText("100.00" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Wait for SDN search to complete";
                FastDriver.SDNTrackingSummary.WaitForSDNSearchComplete(30);

                Reports.TestStep = "Print the check";
                PrintCheck("100.00");

                Reports.TestStep = "Get DisbursementID (WC)";
                int disbursementID = 0;
                var ressponse1 = FileService.GetDisbursementHistorySummary(fileId, @"fastts\fastqa07");

                foreach (DisbursementActivity disburse in ressponse1.DisbursementActivities)
                {
                    if (disburse.Status == "Issued")
                    {
                        disbursementID = (int)disburse.DisbursementID;
                        break;
                    }
                }

                Reports.TestStep = "Invoke GetDisbursementTrackDetails method, validate response (WS)";
                var request = EscrowRequestFactory.GetDisbTrackRequest(fileId, disbursementID);
                var response = EscrowTransactionsHelpers.GetDisbursementTrackDetails(request);
                response.Validate();

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally { FastDriver.WebDriver.Quit(); }
        }
        
        [TestMethod]
        public void REG0010_GetDepostOutSideEscrow()
        {
            try
            {
                #region data setup
                int DepCnt = 0;
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                #endregion

                Reports.TestDescription = "Verify GetDepositOutSideEscrow() Service";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a file using web service";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                var file = FileService.GetOrderDetails(fileId).FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(file);

                Reports.TestStep = "Invoke GetDepositOutSideEscrow Service";
                var GetDepositOERequest = EscrowRequestFactory.GetDepositOERequest(fileId);
                var GetDepositOEResponse = EscrowService.GetDepositOE(GetDepositOERequest);
                Support.AreEqual("1", GetDepositOEResponse.Status.ToString(), "Status Code");
                Support.AreEqual("Deposit Outside Escrow data Loaded Successfully.", GetDepositOEResponse.StatusDescription, "Status Description");


                Reports.TestStep = "Invoke CreateDepositOutSideEscrow Service";
                var CreateDepositOERequest = EscrowRequestFactory.GetCreateDepositOutSideEscrowRequest(fileId);

                var CreateDepositOEResponse = EscrowService.CreateDepositOutSideEscrow(CreateDepositOERequest);
                CreateDepositOEResponse.Validate();

                Reports.TestStep = "Invoke GetDepositOutSideEscrow Service";
                var GetDepositOERequest2 = EscrowRequestFactory.GetDepositOERequest(fileId);
                var GetDepositOEResponse2 = EscrowService.GetDepositOE(GetDepositOERequest2);
                Support.AreEqual("1", GetDepositOEResponse.Status.ToString(), "Status Code");
                Support.AreEqual("Deposit Outside Escrow data Loaded Successfully.", GetDepositOEResponse.StatusDescription, "Status Description");


                Reports.TestStep = "Navigate to Deposit Outside Escrow and validate the values wrt to service responce values.";
                FastDriver.DepositOutsideEscrow.Open();
                Support.AreEqual(GetDepositOEResponse2.CDDepositOEResponse.TotalAmount.ToString().FormatAsMoney(), FastDriver.DepositOutsideEscrow.TotalDeposit.FAGetValue(), "Deposit/Amount");
                Support.AreEqual(GetDepositOEResponse2.CDDepositOEResponse.EarnestDeposits[0].HolderEntityTypeCdID.Value.ToString(), FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_0.FAGetAttribute("value"), "Held By 1 Type");
                Support.AreEqual(GetDepositOEResponse2.CDDepositOEResponse.EarnestDeposits[0].HolderName.ToString(), FastDriver.DepositOutsideEscrow.EarnerstMoneyName_0.FAGetValue(), "Held By 1 Name");
                Support.AreEqual(GetDepositOEResponse2.CDDepositOEResponse.EarnestDeposits[0].EarnestAmount.Value.ToString().FormatAsMoney(), FastDriver.DepositOutsideEscrow.EarnerstMoneyAmount_0.FAGetValue(), "Held By 1 Amount");
                Support.AreEqual(GetDepositOEResponse2.CDDepositOEResponse.EarnestDeposits[1].HolderEntityTypeCdID.Value.ToString(), FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_1.FAGetAttribute("value"), "Held By 2 Type");
                Support.AreEqual(GetDepositOEResponse2.CDDepositOEResponse.EarnestDeposits[1].HolderName.ToString(), FastDriver.DepositOutsideEscrow.EarnerstMoneyName_1.FAGetValue(), "Held By 2 Name");
                Support.AreEqual(GetDepositOEResponse2.CDDepositOEResponse.EarnestDeposits[1].EarnestAmount.Value.ToString().FormatAsMoney(), FastDriver.DepositOutsideEscrow.EarnerstMoneyAmount_1.FAGetValue(), "Held By 2 Amount");
                Support.AreEqual(GetDepositOEResponse2.CDDepositOEResponse.DistributionAmount.Value.ToString().FormatAsMoney(), FastDriver.DepositOutsideEscrow.EarnestMoneyDistribution.FAGetText(), "Earnest Money Distribution");
                string HEntityType1 = GetDepositOEResponse2.CDDepositOEResponse.EarnestDeposits[0].HolderEntityTypeCdID.Value.ToString();
                string HEntityType2 = GetDepositOEResponse2.CDDepositOEResponse.EarnestDeposits[1].HolderEntityTypeCdID.Value.ToString();
                for (int i = 0; i < GetDepositOEResponse2.CDDepositOEResponse.EarnestDeposits.Length; i++)
                {
                    string HEId = GetDepositOEResponse2.CDDepositOEResponse.EarnestDeposits[i].HolderEntityTypeCdID.Value.ToString();
                    string HEName = string.Empty;
                    string test = string.Empty;
                    if (HEId == "322")
                        HEName = "Buyer's Attorney";
                    else if (HEId == "323")
                        HEName = "Buyer's Broker";
                    else if (HEId == "317")
                        HEName = "Outside Title Company";
                    else if (HEId == "325")
                        HEName = "Seller's Attorney";
                    else if (HEId == "326")
                        HEName = "Seller's Broker";
                    if (i == 0)
                        Support.AreEqual(HEName, FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_0.FAGetSelectedItem().ToString(), "Held By 1 Type");
                    if (i == 1)
                        Support.AreEqual(HEName, FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_1.FAGetSelectedItem().ToString(), "Held By 2 Type");
                }

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0011_UpdateDepostOutSideEscrow()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                #endregion

                Reports.TestDescription = "Verify UpdateDepositOutSideEscrow() Service";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a file using web service";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                var file = FileService.GetOrderDetails(fileId).FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(file);

                Reports.TestStep = "Invoke GetDepositOutSideEscrow Service";
                var GetDepositOERequest = EscrowRequestFactory.GetDepositOERequest(fileId);
                var GetDepositOEResponse = EscrowService.GetDepositOE(GetDepositOERequest);
                Support.AreEqual("1", GetDepositOEResponse.Status.ToString(), "Status Code");
                Support.AreEqual("Deposit Outside Escrow data Loaded Successfully.", GetDepositOEResponse.StatusDescription, "Status Description");


                Reports.TestStep = "Invoke CreateDepositOutSideEscrow Service";
                var CreateDepositOERequest = EscrowRequestFactory.GetCreateDepositOutSideEscrowRequest(fileId);

                var CreateDepositOEResponse = EscrowService.CreateDepositOutSideEscrow(CreateDepositOERequest);
                CreateDepositOEResponse.Validate();


                Reports.TestStep = "Invoke GetDepositOutSideEscrow Service";
                var GetDepositOERequest2 = EscrowRequestFactory.GetDepositOERequest(fileId);
                var GetDepositOEResponse2 = EscrowService.GetDepositOE(GetDepositOERequest2);
                Support.AreEqual("1", GetDepositOEResponse.Status.ToString(), "Status Code");
                Support.AreEqual("Deposit Outside Escrow data Loaded Successfully.", GetDepositOEResponse.StatusDescription, "Status Description");


                Reports.TestStep = "Navigate to Deposit Outside Escrow and validate the values wrt to service responce values.";
                FastDriver.DepositOutsideEscrow.Open();
                Support.AreEqual(GetDepositOEResponse2.CDDepositOEResponse.TotalAmount.ToString().FormatAsMoney(), FastDriver.DepositOutsideEscrow.TotalDeposit.FAGetValue(), "Deposit/Amount");
                Support.AreEqual(GetDepositOEResponse2.CDDepositOEResponse.EarnestDeposits[0].HolderEntityTypeCdID.Value.ToString(), FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_0.FAGetAttribute("value"), "Held By 1 Type");
                Support.AreEqual(GetDepositOEResponse2.CDDepositOEResponse.EarnestDeposits[0].HolderName.ToString(), FastDriver.DepositOutsideEscrow.EarnerstMoneyName_0.FAGetValue(), "Held By 1 Name");
                Support.AreEqual(GetDepositOEResponse2.CDDepositOEResponse.EarnestDeposits[0].EarnestAmount.Value.ToString().FormatAsMoney(), FastDriver.DepositOutsideEscrow.EarnerstMoneyAmount_0.FAGetValue(), "Held By 1 Amount");
                Support.AreEqual(GetDepositOEResponse2.CDDepositOEResponse.EarnestDeposits[1].HolderEntityTypeCdID.Value.ToString(), FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_1.FAGetAttribute("value"), "Held By 2 Type");
                Support.AreEqual(GetDepositOEResponse2.CDDepositOEResponse.EarnestDeposits[1].HolderName.ToString(), FastDriver.DepositOutsideEscrow.EarnerstMoneyName_1.FAGetValue(), "Held By 2 Name");
                Support.AreEqual(GetDepositOEResponse2.CDDepositOEResponse.EarnestDeposits[1].EarnestAmount.Value.ToString().FormatAsMoney(), FastDriver.DepositOutsideEscrow.EarnerstMoneyAmount_1.FAGetValue(), "Held By 2 Amount");
                Support.AreEqual(GetDepositOEResponse2.CDDepositOEResponse.DistributionAmount.Value.ToString().FormatAsMoney(), FastDriver.DepositOutsideEscrow.EarnestMoneyDistribution.FAGetText(), "Earnest Money Distribution");

                for (int i = 0; i < GetDepositOEResponse2.CDDepositOEResponse.EarnestDeposits.Length; i++)
                {
                    string HEId = GetDepositOEResponse2.CDDepositOEResponse.EarnestDeposits[i].HolderEntityTypeCdID.Value.ToString();
                    string HEName = string.Empty;
                    string test = string.Empty;
                    if (HEId == "322")
                        HEName = "Buyer's Attorney";
                    else if (HEId == "323")
                        HEName = "Buyer's Broker";
                    else if (HEId == "317")
                        HEName = "Outside Title Company";
                    else if (HEId == "325")
                        HEName = "Seller's Attorney";
                    else if (HEId == "326")
                        HEName = "Seller's Broker";
                    if (i == 0)
                        Support.AreEqual(HEName, FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_0.FAGetSelectedItem().ToString(), "Held By 1 Type");
                    if (i == 1)
                        Support.AreEqual(HEName, FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_1.FAGetSelectedItem().ToString(), "Held By 2 Type");
                }

                Reports.TestStep = "Invoke UpdateDepositOutSideEscrow Service";
                var UpdateDepositOERequest = EscrowRequestFactory.UpdateDepositOutSideEscrowRequest(fileId);
                var UpdateDepositOEResponse = EscrowService.UpdateDepositOutSideEscrow(UpdateDepositOERequest);
                UpdateDepositOEResponse.Validate();
                Support.AreEqual("deposit outside escrow save successful", UpdateDepositOEResponse.StatusDescription.ToString().ToLower());

                Reports.TestStep = "Invoke GetDepositOutSideEscrow Service";
                var GetDepositOERequest3 = EscrowRequestFactory.GetDepositOERequest(fileId);
                var GetDepositOEResponse3 = EscrowService.GetDepositOE(GetDepositOERequest2);
                Support.AreEqual("1", GetDepositOEResponse3.Status.ToString(), "Status Code");
                Support.AreEqual("Deposit Outside Escrow data Loaded Successfully.", GetDepositOEResponse.StatusDescription, "Status Description");


                Reports.TestStep = "Navigate to Deposit Outside Escrow and validate the values wrt to Update service responce values.";
                FastDriver.DepositOutsideEscrow.Open();
                Support.AreEqual(GetDepositOEResponse3.CDDepositOEResponse.TotalAmount.ToString().FormatAsMoney(), FastDriver.DepositOutsideEscrow.TotalDeposit.FAGetValue(), "Deposit/Amount");
                Support.AreEqual(GetDepositOEResponse3.CDDepositOEResponse.DistributionAmount.Value.ToString().FormatAsMoney(), FastDriver.DepositOutsideEscrow.EarnestMoneyDistribution.FAGetText(), "Earnest Money Distribution");

                Support.AreEqual(GetDepositOEResponse3.CDDepositOEResponse.EarnestDeposits[0].HolderEntityTypeCdID.Value.ToString(), FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_0.FAGetAttribute("value"), "Held By 1 Type");
                Support.AreEqual(GetDepositOEResponse3.CDDepositOEResponse.EarnestDeposits[0].HolderName.ToString(), FastDriver.DepositOutsideEscrow.EarnerstMoneyName_0.FAGetValue(), "TestName1");
                Support.AreEqual(GetDepositOEResponse3.CDDepositOEResponse.EarnestDeposits[0].EarnestAmount.Value.ToString().FormatAsMoney(), FastDriver.DepositOutsideEscrow.EarnerstMoneyAmount_0.FAGetValue(), "Held By 1 Amount");

                Support.AreEqual(GetDepositOEResponse3.CDDepositOEResponse.EarnestDeposits[1].HolderEntityTypeCdID.Value.ToString(), FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_1.FAGetAttribute("value"), "Held By 2 Type");
                Support.AreEqual(GetDepositOEResponse3.CDDepositOEResponse.EarnestDeposits[1].HolderName.ToString(), FastDriver.DepositOutsideEscrow.EarnerstMoneyName_1.FAGetValue(), "TestName2");
                Support.AreEqual(GetDepositOEResponse3.CDDepositOEResponse.EarnestDeposits[1].EarnestAmount.Value.ToString().FormatAsMoney(), FastDriver.DepositOutsideEscrow.EarnerstMoneyAmount_1.FAGetValue(), "Held By 2 Amount");

                Support.AreEqual(GetDepositOEResponse3.CDDepositOEResponse.EarnestDeposits[2].HolderEntityTypeCdID.Value.ToString(), FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_2.FAGetAttribute("value"), "Held By 3 Type");
                Support.AreEqual(GetDepositOEResponse3.CDDepositOEResponse.EarnestDeposits[2].HolderName.ToString(), FastDriver.DepositOutsideEscrow.EarnerstMoneyName_2.FAGetValue(), "TestName3");
                Support.AreEqual(GetDepositOEResponse3.CDDepositOEResponse.EarnestDeposits[2].EarnestAmount.Value.ToString().FormatAsMoney(), FastDriver.DepositOutsideEscrow.EarnerstMoneyAmount_2.FAGetValue(), "Held By 3 Amount");

                Support.AreEqual(GetDepositOEResponse3.CDDepositOEResponse.EarnestDeposits[3].HolderEntityTypeCdID.Value.ToString(), FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_3.FAGetAttribute("value"), "Held By 4 Type");
                Support.AreEqual(GetDepositOEResponse3.CDDepositOEResponse.EarnestDeposits[3].HolderName.ToString(), FastDriver.DepositOutsideEscrow.EarnerstMoneyName_3.FAGetValue(), "TestName4");
                Support.AreEqual(GetDepositOEResponse3.CDDepositOEResponse.EarnestDeposits[3].EarnestAmount.Value.ToString().FormatAsMoney(), FastDriver.DepositOutsideEscrow.EarnerstMoneyAmount_3.FAGetValue(), "Held By 4 Amount");

                Support.AreEqual(GetDepositOEResponse3.CDDepositOEResponse.EarnestDeposits[4].HolderEntityTypeCdID.Value.ToString(), FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_4.FAGetAttribute("value"), "Held By 5 Type");
                Support.AreEqual(GetDepositOEResponse3.CDDepositOEResponse.EarnestDeposits[4].HolderName.ToString(), FastDriver.DepositOutsideEscrow.EarnerstMoneyName_4.FAGetValue(), "TestName5");
                Support.AreEqual(GetDepositOEResponse3.CDDepositOEResponse.EarnestDeposits[4].EarnestAmount.Value.ToString().FormatAsMoney(), FastDriver.DepositOutsideEscrow.EarnerstMoneyAmount_4.FAGetValue(), "Held By 5 Amount");

                for (int i = 0; i < GetDepositOEResponse3.CDDepositOEResponse.EarnestDeposits.Length; i++)
                {
                    string HEId = GetDepositOEResponse3.CDDepositOEResponse.EarnestDeposits[i].HolderEntityTypeCdID.Value.ToString();
                    string HEName = string.Empty;
                    string test = string.Empty;
                    if (HEId == "322")
                        HEName = "Buyer's Attorney";
                    else if (HEId == "323")
                        HEName = "Buyer's Broker";
                    else if (HEId == "317")
                        HEName = "Outside Title Company";
                    else if (HEId == "325")
                        HEName = "Seller's Attorney";
                    else if (HEId == "326")
                        HEName = "Seller's Broker";
                    if (i == 0)
                        Support.AreEqual(HEName, FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_0.FAGetSelectedItem().ToString(), "Held By 1 Type");
                    else if (i == 1)
                        Support.AreEqual(HEName, FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_1.FAGetSelectedItem().ToString(), "Held By 2 Type");
                    else if (i == 2)
                        Support.AreEqual(HEName, FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_2.FAGetSelectedItem().ToString(), "Held By 3 Type");
                    else if (i == 3)
                        Support.AreEqual(HEName, FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_3.FAGetSelectedItem().ToString(), "Held By 4 Type");
                    else if (i == 4)
                        Support.AreEqual(HEName, FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_4.FAGetSelectedItem().ToString(), "Held By 5 Type");

                }

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0012_UpdateDepostOutSideEscrow_DifferentTotalAndDistributionAmt()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                #endregion

                Reports.TestDescription = "Verify UpdateDepositOutSideEscrow() Service";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a file using web service";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                var file = FileService.GetOrderDetails(fileId).FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(file);

                Reports.TestStep = "Invoke GetDepositOutSideEscrow Service";
                var GetDepositOERequest = EscrowRequestFactory.GetDepositOERequest(fileId);
                var GetDepositOEResponse = EscrowService.GetDepositOE(GetDepositOERequest);
                Support.AreEqual("1", GetDepositOEResponse.Status.ToString(), "Status Code");
                Support.AreEqual("Deposit Outside Escrow data Loaded Successfully.", GetDepositOEResponse.StatusDescription, "Status Description");


                Reports.TestStep = "Invoke CreateDepositOutSideEscrow Service";
                var CreateDepositOERequest = EscrowRequestFactory.GetCreateDepositOutSideEscrowRequest(fileId);

                var CreateDepositOEResponse = EscrowService.CreateDepositOutSideEscrow(CreateDepositOERequest);
                CreateDepositOEResponse.Validate();


                Reports.TestStep = "Invoke GetDepositOutSideEscrow Service";
                var GetDepositOERequest2 = EscrowRequestFactory.GetDepositOERequest(fileId);
                var GetDepositOEResponse2 = EscrowService.GetDepositOE(GetDepositOERequest2);
                Support.AreEqual("1", GetDepositOEResponse.Status.ToString(), "Status Code");
                Support.AreEqual("Deposit Outside Escrow data Loaded Successfully.", GetDepositOEResponse.StatusDescription, "Status Description");


                Reports.TestStep = "Navigate to Deposit Outside Escrow and validate the values wrt to Createservice responce values.";
                FastDriver.DepositOutsideEscrow.Open();
                Support.AreEqual(GetDepositOEResponse2.CDDepositOEResponse.TotalAmount.ToString().FormatAsMoney(), FastDriver.DepositOutsideEscrow.TotalDeposit.FAGetValue(), "Deposit/Amount");
                Support.AreEqual(GetDepositOEResponse2.CDDepositOEResponse.EarnestDeposits[0].HolderEntityTypeCdID.Value.ToString(), FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_0.FAGetAttribute("value"), "Held By 1 Type");
                Support.AreEqual(GetDepositOEResponse2.CDDepositOEResponse.EarnestDeposits[0].HolderName.ToString(), FastDriver.DepositOutsideEscrow.EarnerstMoneyName_0.FAGetValue(), "Held By 1 Name");
                Support.AreEqual(GetDepositOEResponse2.CDDepositOEResponse.EarnestDeposits[0].EarnestAmount.Value.ToString().FormatAsMoney(), FastDriver.DepositOutsideEscrow.EarnerstMoneyAmount_0.FAGetValue(), "Held By 1 Amount");
                Support.AreEqual(GetDepositOEResponse2.CDDepositOEResponse.EarnestDeposits[1].HolderEntityTypeCdID.Value.ToString(), FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_1.FAGetAttribute("value"), "Held By 2 Type");
                Support.AreEqual(GetDepositOEResponse2.CDDepositOEResponse.EarnestDeposits[1].HolderName.ToString(), FastDriver.DepositOutsideEscrow.EarnerstMoneyName_1.FAGetValue(), "Held By 2 Name");
                Support.AreEqual(GetDepositOEResponse2.CDDepositOEResponse.EarnestDeposits[1].EarnestAmount.Value.ToString().FormatAsMoney(), FastDriver.DepositOutsideEscrow.EarnerstMoneyAmount_1.FAGetValue(), "Held By 2 Amount");
                Support.AreEqual(GetDepositOEResponse2.CDDepositOEResponse.DistributionAmount.Value.ToString().FormatAsMoney(), FastDriver.DepositOutsideEscrow.EarnestMoneyDistribution.FAGetText(), "Earnest Money Distribution");

                for (int i = 0; i < GetDepositOEResponse2.CDDepositOEResponse.EarnestDeposits.Length; i++)
                {
                    string HEId = GetDepositOEResponse2.CDDepositOEResponse.EarnestDeposits[i].HolderEntityTypeCdID.Value.ToString();
                    string HEName = string.Empty;
                    string test = string.Empty;
                    if (HEId == "322")
                        HEName = "Buyer's Attorney";
                    else if (HEId == "323")
                        HEName = "Buyer's Broker";
                    else if (HEId == "317")
                        HEName = "Outside Title Company";
                    else if (HEId == "325")
                        HEName = "Seller's Attorney";
                    else if (HEId == "326")
                        HEName = "Seller's Broker";
                    if (i == 0)
                        Support.AreEqual(HEName, FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_0.FAGetSelectedItem().ToString(), "Held By 1 Type");
                    if (i == 1)
                        Support.AreEqual(HEName, FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_1.FAGetSelectedItem().ToString(), "Held By 2 Type");
                }


                
                Reports.TestStep = "Invoke UpdateDepositOutSideEscrow Service";
                var UpdateDepositOERequest = EscrowRequestFactory.UpdateDepositOutSideEscrowRequest(fileId);
                UpdateDepositOERequest.CDDepositOESaveRequest.TotalAmount = UpdateDepositOERequest.CDDepositOESaveRequest.DistributionAmount - 100;
                var UpdateDepositOEResponse = EscrowService.UpdateDepositOutSideEscrow(UpdateDepositOERequest);

                Support.AreEqual("-1", UpdateDepositOEResponse.Status.ToString());
                Support.AreEqual("the distributed amount must equal the deposit / earnest money total.", UpdateDepositOEResponse.StatusDescription.ToString().ToLower());

                Reports.TestStep = "Invoke GetDepositOutSideEscrow Service";
                var GetDepositOERequest3 = EscrowRequestFactory.GetDepositOERequest(fileId);
                var GetDepositOEResponse3 = EscrowService.GetDepositOE(GetDepositOERequest3);
                Support.AreEqual("1", GetDepositOEResponse.Status.ToString(), "Status Code");
                Support.AreEqual("Deposit Outside Escrow data Loaded Successfully.", GetDepositOEResponse.StatusDescription, "Status Description");


                Reports.TestStep = "Navigate to Deposit Outside Escrow and validate that the values are not updated.";
                FastDriver.DepositOutsideEscrow.Open();
                Support.AreEqual(GetDepositOEResponse3.CDDepositOEResponse.TotalAmount.ToString().FormatAsMoney(), FastDriver.DepositOutsideEscrow.TotalDeposit.FAGetValue(), "Deposit/Amount");
                Support.AreEqual(GetDepositOEResponse3.CDDepositOEResponse.EarnestDeposits[0].HolderEntityTypeCdID.Value.ToString(), FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_0.FAGetAttribute("value"), "Held By 1 Type");
                Support.AreEqual(GetDepositOEResponse3.CDDepositOEResponse.EarnestDeposits[0].HolderName.ToString(), FastDriver.DepositOutsideEscrow.EarnerstMoneyName_0.FAGetValue(), "Held By 1 Name");
                Support.AreEqual(GetDepositOEResponse3.CDDepositOEResponse.EarnestDeposits[0].EarnestAmount.Value.ToString().FormatAsMoney(), FastDriver.DepositOutsideEscrow.EarnerstMoneyAmount_0.FAGetValue(), "Held By 1 Amount");
                Support.AreEqual(GetDepositOEResponse3.CDDepositOEResponse.EarnestDeposits[1].HolderEntityTypeCdID.Value.ToString(), FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_1.FAGetAttribute("value"), "Held By 2 Type");
                Support.AreEqual(GetDepositOEResponse3.CDDepositOEResponse.EarnestDeposits[1].HolderName.ToString(), FastDriver.DepositOutsideEscrow.EarnerstMoneyName_1.FAGetValue(), "Held By 2 Name");
                Support.AreEqual(GetDepositOEResponse3.CDDepositOEResponse.EarnestDeposits[1].EarnestAmount.Value.ToString().FormatAsMoney(), FastDriver.DepositOutsideEscrow.EarnerstMoneyAmount_1.FAGetValue(), "Held By 2 Amount");
                Support.AreEqual(GetDepositOEResponse3.CDDepositOEResponse.DistributionAmount.Value.ToString().FormatAsMoney(), FastDriver.DepositOutsideEscrow.EarnestMoneyDistribution.FAGetText(), "Earnest Money Distribution");
                
                for (int i = 0; i < GetDepositOEResponse3.CDDepositOEResponse.EarnestDeposits.Length; i++)
                {
                    string HEId = GetDepositOEResponse3.CDDepositOEResponse.EarnestDeposits[i].HolderEntityTypeCdID.Value.ToString();
                    string HEName = string.Empty;
                    string test = string.Empty;
                    if (HEId == "322")
                        HEName = "Buyer's Attorney";
                    else if (HEId == "323")
                        HEName = "Buyer's Broker";
                    else if (HEId == "317")
                        HEName = "Outside Title Company";
                    else if (HEId == "325")
                        HEName = "Seller's Attorney";
                    else if (HEId == "326")
                        HEName = "Seller's Broker";
                    if (i == 0)
                        Support.AreEqual(HEName, FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_0.FAGetSelectedItem().ToString(), "Held By 1 Type");
                    if (i == 1)
                        Support.AreEqual(HEName, FastDriver.DepositOutsideEscrow.EarnerstMoneyHeldBy_1.FAGetSelectedItem().ToString(), "Held By 2 Type");
                }
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0013_GetDocTypeAndDocNames()
        {
            try
            {
                Reports.TestDescription = "Verify GetDocTypeAndDocNames service";

                Reports.TestStep = "Invoke GetDocTypeAndDocNames method, validate response (WS)";
                var request = EscrowRequestFactory.GetDocumentTypeRequest();
                var response = EscrowTransactionsHelpers.GetDocTypeAndDocNames(request);
                response.Validate();

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally {  }
        }

        [TestMethod]
        public void REG0014_SetCalculationFees()
        {
            try
            {
                Reports.TestDescription = "Verify SetCalculationFees service";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = FileRequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.formType = FASTWCFHelpers.FastFileService.FormType.HUD;
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a file using web service";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                string fileNum = FileService.GetOrderDetails(fileId).FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(fileNum);

                Reports.TestStep = "Invoke SetCalculationFees method, validate response (WS)";
                var request = EscrowRequestFactory.GetUpdateFeesCalculationRequest(fileId);
                request.RecordingFees = new RecordingFee[]
                {
                    new RecordingFee()
                    {
                        ConsiderationAmount = 50,
                        PageCount = 5,
                        eFACCOpertion = FACCOpertion.Create,
                        Costs = new RecordingCost[]
                        {
                            new RecordingCost()
                            {
                                RecordingDocumentDescr = "Test",
                                RecordingDocumentID = 410,
                                ChargeToCdID = 55,
                                FeeID = 32255,
                                IsOTC =  false,
                                OverrideAmount = 10,
                                OverrideTypeCDID = 1
                            }
                        }
                    }
                };
                var response = EscrowTransactionsHelpers.SetCalculationFees(request);
                response.Validate();

                Reports.TestStep = "Navigate to Fee Entry screen, validate recording fee amount";
                FastDriver.FileFees.Open();
                Support.AreEqual("$10.00", FastDriver.FileFees.TotalRecordingFees.FAGetText().Clean(), "Total Charge");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally { FastDriver.WebDriver.Quit(); }
        }


        [TestMethod]
        public void REG0015_GetEscrowFileBalanceSummary()
        {
            try
            {
                Reports.TestDescription = "Verify GetDepositOutSideEscrow() Service";

                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                #endregion

                #region Login
                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                #endregion

                #region Create file using WCF
                Reports.TestStep = "Create a file using web service";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                var file = FileService.GetOrderDetails(fileId).FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(file);
                #endregion

                #region Deposit in Escrow
                Reports.TestStep = "Invoke CreateDepositInEscrow Service";
                var CreateDepositInEscrowRequest = EscrowRequestFactory.GetDepositInEscrowRequest(fileId);
                CreateDepositInEscrowRequest.DepositInEscrow.DepositEscrow.Amount = 100;
                CreateDepositInEscrowRequest.DepositInEscrow.DepositEscrow.ReceivedFrom = "Other";
                CreateDepositInEscrowRequest.DepositInEscrow.DepositEscrow.IssueDate = DateTime.Now.ToPST();
                CreateDepositInEscrowRequest.DepositInEscrow.DepositEscrow.TypeFunds = "Cash";
                CreateDepositInEscrowRequest.DepositInEscrow.DepositEscrow.TransactionDate = DateTime.Now.ToPST();
                CreateDepositInEscrowRequest.DepositInEscrow.DepositEscrow.Representing = "Additional Closing Costs";

                var CreateDepositInEscrowResponse = EscrowService.CreateDepositInEscrow(CreateDepositInEscrowRequest);
                CreateDepositInEscrowResponse.Validate();
                #endregion

                #region Create Survey
                Reports.TestStep = "Invoke CreateSurvey method";
                var surveyRequest = EscrowRequestFactory.GetSurveyRequest(fileId, 1, "BOA");
                EscrowService.CreateSurvey(surveyRequest).Validate();
                #endregion

                #region Enter Fees
                Reports.TestStep = "Enter first fee in Title and escrow.";
                FastDriver.FileFees.Open();
                FastDriver.FileFees.AddFirstMatchingTitleAndScrowFee("New Home Rate (Title Only)");
                FastDriver.FileFees.WaitForScreenToLoad();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 4, TableAction.SetText, "1.99");
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, "New Home Rate (Title Only)", 7, TableAction.SetText, "2.99");
                FastDriver.BottomFrame.Done();
                #endregion

                #region Set an instance for Lease Details with charge amount entered
                Reports.TestStep = "Set an instance for Lease Details with charge amount entered.";
                FastDriver.LeaseDetail.Open();
                FastDriver.LeaseDetail.FindGABcode("HUDLEASE03");
                FastDriver.LeaseDetail.BuyerCharge.FASetText("0.8");
                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();

                #endregion

                #region Validate Active Disbursement and Issue Check
                Reports.TestStep = "Validate that active disbursement screen is loaded.";
                FastDriver.ActiveDisbursementSummary.Open();

                Reports.TestStep = "To Issue the check us the Print button in Active Disbursement Summary.";
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(3, "Check", 1, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Print.FAClick();


                Reports.TestStep = "Click on Deliver.";
                FastDriver.PrintChecks.WaitForScreenToLoad(FastDriver.PrintChecks.Deliver);
                FastDriver.PrintChecks.Deliver.FAClick();

                if (FastDriver.WebDriver.WaitForAlertToExist(10) && FastDriver.WebDriver.HandleDialogMessage().Contains("No printer"))
                {
                    Support.Fail("Printer is not configured");
                }
                Reports.TestStep = "Print the checks.";

                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.Printers.FASelectItemBySendingKeys("TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.ClickPrint();

                Reports.TestStep = "Check if Password Confirmation dialog appears and blocks the execution.";
                try
                {
                    FastDriver.PasswordConfirmationDlg.WaitForScreenToLoad();
                    FastDriver.PasswordConfirmationDlg.SwitchToDialogContentFrame();
                    FastDriver.PasswordConfirmationDlg.ReasonForLoss.FASelectItemByIndex(1);
                    FastDriver.PasswordConfirmationDlg.LossExplanation.FASetText("LossExplanation");

                    if (FastDriver.PasswordConfirmationDlg.LossPassword.IsDisplayed())
                        FastDriver.PasswordConfirmationDlg.LossPassword.FASetText(AutoConfig.CheckPrintingPassword);

                    Reports.TestStep = "Click on Done in PasswordConfirmationDlg.";
                    FastDriver.PasswordConfirmationDlg.SwitchToDialogBottomFrame();
                    FastDriver.DialogBottomFrame.ClickDone();
                }
                catch (Exception err)
                {
                    Reports.StatusUpdate("Password Confirmation dialog/alert hasn't appeared or some other exception has occurred ! :" + err.Message, true);
                }
                FastDriver.WebDriver.WaitForDeliveryWindow("Print", 200);

                #endregion

                #region Deposit in Escrow
                Reports.TestStep = "Invoke CreateDepositInEscrow Service for anotehr deposit.";
                var CreateDepositInEscrowRequest2 = EscrowRequestFactory.GetDepositInEscrowRequest(fileId);
                CreateDepositInEscrowRequest2.DepositInEscrow.DepositEscrow.Amount = 10000000;
                CreateDepositInEscrowRequest2.DepositInEscrow.DepositEscrow.ReceivedFrom = "Buyer";
                CreateDepositInEscrowRequest2.DepositInEscrow.DepositEscrow.DepositorTypeCdID = 113;
                CreateDepositInEscrowRequest2.DepositInEscrow.DepositEscrow.IssueDate = DateTime.Now.ToPST();
                CreateDepositInEscrowRequest2.DepositInEscrow.DepositEscrow.TypeFunds = "Cash";
                CreateDepositInEscrowRequest2.DepositInEscrow.DepositEscrow.TransactionDate = DateTime.Now.ToPST();
                CreateDepositInEscrowRequest2.DepositInEscrow.DepositEscrow.Representing = "Additional Closing Costs";
                CreateDepositInEscrowRequest2.DepositInEscrow.DepositEscrow.CreditTo = "Buyer";
                CreateDepositInEscrowRequest2.DepositInEscrow.DepositEscrow.CreditToTypeCdID = 113;

                var CreateDepositInEscrowResponse2 = EscrowService.CreateDepositInEscrow(CreateDepositInEscrowRequest2);
                CreateDepositInEscrowResponse2.Validate();
                #endregion

                #region Invoke GetFileBalanceSummary() service and validate the details w.r.t UI.
                var FBSreq = EscrowRequestFactory.GetFileBalanceSummaryRequest(fileId);
                var FBSres = EscrowService.GetFileBalanceSummary(FBSreq);
                FBSres.Validate();

                Reports.TestStep = "Validate the details from service with UI values.";
                FastDriver.EscrowFileBalanceSummary.Open();

                Reports.TestStep = "Validate File balance Summary Details.";
                Support.AreEqual(FBSres.DepositAndDisbursementSummary.DisbursementSummaryTotals.NetTotalDisbursements.ToString().FormatAsMoney().Trim(), FastDriver.EscrowFileBalanceSummary.NetTotalDisbursements.FAGetText().ToString().Trim(), "NetTotalDisbursements");
                Support.AreEqual(FBSres.FileBalanceSummary.FileBalanceSummaryActualAndPosted.NetTotalDeposits.ToString().FormatAsMoney().Trim(), FastDriver.EscrowFileBalanceSummary.FileBalanceSummaryActOrProjNetTotalDeposits.FAGetText().ToString().Trim(), "FileBalanceSummaryActOrProjNetTotalDeposits"); // net total deposit
                Support.AreEqual(FBSres.FileBalanceSummary.CurrentFunds.NetTotalDeposits.ToString().FormatAsMoney().Trim(), FastDriver.EscrowFileBalanceSummary.NetDeposit.FAGetText().ToString(), "NetDeposit");
                Support.AreEqual(FBSres.FileBalanceSummary.FileBalanceSummaryActualAndPosted.FileBalance.ToString().FormatAsMoney().Trim(), FastDriver.EscrowFileBalanceSummary.FileBalance.FAGetText().ToString().Trim(), "FileBalance");
                Support.AreEqual(FBSres.FileBalanceSummary.CurrentFunds.CurrentAvailableFunds.ToString().FormatAsMoney().Trim(), FastDriver.EscrowFileBalanceSummary.CurrentAvailableFunds.FAGetText().ToString().Trim(), "CurrentAvailableFunds");
                Support.AreEqual(FBSres.FileBalanceSummary.FileBalanceSummaryActualAndPosted.BuyerFundsHeld.ToString().FormatAsMoney().Trim(), FastDriver.EscrowFileBalanceSummary.BuyerFundsHeld.FAGetText().ToString().Trim(), "BuyerFundsHeld");
                Support.AreEqual(FBSres.FileBalanceSummary.FileBalanceSummaryActualAndPosted.SellerFundsHeld.ToString().FormatAsMoney().Trim(), FastDriver.EscrowFileBalanceSummary.SellerFundsHeld.FAGetText().ToString().Trim(), "SellerFundsHeld");
                Support.AreEqual(FBSres.FileBalanceSummary.FileBalanceSummaryProjected.BuyersFundsDue.ToString().FormatAsMoney().Trim(), FastDriver.EscrowFileBalanceSummary.BuyerFundsDue1.FAGetText().ToString().Trim(), "BuyerFundsDue1");
                Support.AreEqual(FBSres.FileBalanceSummary.FileBalanceSummaryProjected.SellersFundsDue.ToString().FormatAsMoney().Trim(), FastDriver.EscrowFileBalanceSummary.SellerFundsDueAmount.FAGetText().ToString().Trim(), "SellerFundsDueAmount");

                if (FBSres.FileBalanceSummary.BuyerAndSellerAmounts.BuyerFundsDue.ToString().FormatAsMoney().Trim() == "0.00")
                    Support.AreEqual("", FastDriver.EscrowFileBalanceSummary.BuyerFundsDue.FAGetText().ToString().Trim(), "BuyerFundsDue");
                else
                    Support.AreEqual(FBSres.FileBalanceSummary.BuyerAndSellerAmounts.BuyerFundsDue.ToString().FormatAsMoney().Trim(), FastDriver.EscrowFileBalanceSummary.BuyerFundsDue.FAGetText().ToString().Trim(), "BuyerFundsDue");

                if (FBSres.FileBalanceSummary.BuyerAndSellerAmounts.SellerFundsDue.ToString().FormatAsMoney().Trim() == "0.00")
                    Support.AreEqual("", FastDriver.EscrowFileBalanceSummary.SellerFundsDue.FAGetText().ToString().Trim(), "SellerFundsDue");
                else
                    Support.AreEqual(FBSres.FileBalanceSummary.BuyerAndSellerAmounts.SellerFundsDue.ToString().FormatAsMoney().Trim(), FastDriver.EscrowFileBalanceSummary.SellerFundsDue.FAGetText().ToString().Trim(), "SellerFundsDue");


                if (FBSres.FileBalanceSummary.BuyerAndSellerAmounts.BuyerNetCheck.ToString().FormatAsMoney().Trim() == "0.00")
                    Support.AreEqual("", FastDriver.EscrowFileBalanceSummary.BuyerNetCheck.FAGetText().ToString().Trim());
                else
                    Support.AreEqual(FBSres.FileBalanceSummary.BuyerAndSellerAmounts.BuyerNetCheck.ToString().FormatAsMoney().Trim(), FastDriver.EscrowFileBalanceSummary.BuyerNetCheck.FAGetText().ToString().Trim());

                if (FBSres.FileBalanceSummary.BuyerAndSellerAmounts.SellerNetCheck.ToString().FormatAsMoney().Trim() == "0.00")
                    Support.AreEqual("", FastDriver.EscrowFileBalanceSummary.SellerNetCheck.FAGetText().ToString().Trim());
                else
                    Support.AreEqual(FBSres.FileBalanceSummary.BuyerAndSellerAmounts.SellerNetCheck.ToString().FormatAsMoney().Trim(), FastDriver.EscrowFileBalanceSummary.SellerNetCheck.FAGetText().ToString().Trim());

                Reports.TestStep = "Validate Loan Proceeds Summary Details.";
                Support.AreEqual(FBSres.LoanProceedsSummary[0].LoanAmounts.ToString().Trim(), FastDriver.EscrowFileBalanceSummary.LoanAmount.FAGetText().ToString().Trim());
                Support.AreEqual(FBSres.LoanProceedsSummary[0].ProjectedLoanFunding.ToString().Trim(), FastDriver.EscrowFileBalanceSummary.ProjectedLoanFunding.FAGetText().ToString().Trim());

                if (FBSres.LoanProceedsSummary[0].Recvd.ToString() == "0")
                    Support.AreEqual(FastDriver.EscrowFileBalanceSummary.Recieved.IsSelected().ToString(), "False");

                Reports.TestStep = "Validate Deposit/Disbursement Summary Details.";
                Support.AreEqual(FBSres.DepositAndDisbursementSummary.DepositToEscrowSummaryTotals.InitialDeposits.ToString().FormatAsMoney().Trim(), FastDriver.EscrowFileBalanceSummary.InitialDeposits.FAGetText().ToString().Trim());
                Support.AreEqual(FBSres.DepositAndDisbursementSummary.DepositToEscrowSummaryTotals.DepositsOutsideEscrow.ToString().FormatAsMoney().Trim(), FastDriver.EscrowFileBalanceSummary.DepositOutsideEscrow.FAGetText().ToString().Trim());
                Support.AreEqual(FBSres.DepositAndDisbursementSummary.DisbursementSummaryTotals.IssuedChecks.ToString().FormatAsMoney().Trim(), FastDriver.EscrowFileBalanceSummary.IssuedChecks.FAGetText().ToString().Trim());
                Support.AreEqual(FBSres.DepositAndDisbursementSummary.DisbursementSummaryTotals.IssuedWires.ToString().FormatAsMoney().Trim(), FastDriver.EscrowFileBalanceSummary.IssuedWires.FAGetText().ToString().Trim());
                Support.AreEqual(FBSres.DepositAndDisbursementSummary.DisbursementSummaryTotals.IssuedFeeTransfer.ToString().FormatAsMoney().Trim(), FastDriver.EscrowFileBalanceSummary.IssuedFeeTransfer.FAGetText().ToString().Trim());
                Support.AreEqual(FBSres.DepositAndDisbursementSummary.DisbursementSummaryTotals.IssuedIBADisbursements.ToString().FormatAsMoney().Trim(), FastDriver.EscrowFileBalanceSummary.IssuedIBADisbursements.FAGetText().ToString().Trim());
                Support.AreEqual(FBSres.DepositAndDisbursementSummary.DisbursementSummaryTotals.TotalIssued.ToString().FormatAsMoney().Trim(), FastDriver.EscrowFileBalanceSummary.TotalIssuedAmount.FAGetText().ToString().Trim());
                Support.AreEqual(FBSres.DepositAndDisbursementSummary.DisbursementSummaryTotals.NetAdjustments.ToString().FormatAsMoney().Trim(), FastDriver.EscrowFileBalanceSummary.NetAdjustments.FAGetText().ToString().Trim());


                Support.AreEqual(FBSres.DepositAndDisbursementSummary.DisbursementSummaryTotals.NetIssued.ToString().FormatAsMoney().Trim(), FastDriver.EscrowFileBalanceSummary.DisbursementSummaryTotalNetIssued.FAGetText().ToString().Trim());
                Support.AreEqual(FBSres.DepositAndDisbursementSummary.DisbursementSummaryTotals.TotalActualIssuedCharges.ToString().FormatAsMoney().Trim(), FastDriver.EscrowFileBalanceSummary.DisbursementSummaryTotalActualIssuedCharges.FAGetText().ToString().Trim());
                Support.AreEqual(FBSres.DepositAndDisbursementSummary.DisbursementSummaryTotals.HeldChecks.ToString().FormatAsMoney().Trim(), FastDriver.EscrowFileBalanceSummary.DisbursementSummaryTotalHeldCheckAmount.FAGetText().ToString().Trim());
                Support.AreEqual(FBSres.DepositAndDisbursementSummary.DisbursementSummaryTotals.HeldFeeTransfer.ToString().FormatAsMoney().Trim(), FastDriver.EscrowFileBalanceSummary.DisbursementSummaryTotalHeldFeeTransferAmount.FAGetText().ToString().Trim());
                Support.AreEqual(FBSres.DepositAndDisbursementSummary.DisbursementSummaryTotals.CreatedDisbursement.ToString().FormatAsMoney().Trim(), FastDriver.EscrowFileBalanceSummary.DisbursementSummaryTotalCreatedIssueAmount.FAGetText().ToString().Trim());
                Support.AreEqual(FBSres.DepositAndDisbursementSummary.DisbursementSummaryTotals.PendingIssue.ToString().FormatAsMoney().Trim(), FastDriver.EscrowFileBalanceSummary.DisbursementSummaryTotalPendingIssueAmount.FAGetText().ToString().Trim());
                // User Story 700091:GetFileBalanceSummary()-Formatting issue in one if the fields: Validate if DisbursementsPendingAndHeld  is formatted correctly.
                Support.AreEqual(FBSres.DepositAndDisbursementSummary.DisbursementSummaryTotals.DisbursementsPendingAndHeld.ToString().FormatAsMoney().Trim(), FastDriver.EscrowFileBalanceSummary.DisbursementSummaryTotalPendingHeld.FAGetText().ToString().Trim());
                Support.AreEqual(FBSres.DepositAndDisbursementSummary.DisbursementSummaryTotals.NetTotalDisbursements.ToString().FormatAsMoney().Trim(), FastDriver.EscrowFileBalanceSummary.DisbursementSummaryTotalNetTotalDisbursement.FAGetText().ToString().Trim());
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        [TestMethod]
        public void REG0016_SaveEditDisbursementDetails()
        {
            try
            {
                Reports.TestDescription = "Verify SaveEditDisbursementDetails service";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = FileRequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan();
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a file using web service";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                string fileNum = FileService.GetOrderDetails(fileId).FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(fileNum);

                Reports.TestStep = "Navigate to Home Warranty screen, enter buyer charge";
                FastDriver.HomeWarrantyDetail.Open();
                FastDriver.HomeWarrantyDetail.FindGABCode("BOA");
                FastDriver.HomeWarrantyDetail.HomeWarrantyChargeDescription.FASetText("Home Warranty");
                FastDriver.HomeWarrantyDetail.HomeWarrantyBuyerCharge.FASetText("100.00" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Get the disbursement details (WC)";
                var ressponse1 = FileService.GetActiveDisbursementSummaryDetails(fileId);
                int disActivityID = (int) ressponse1.Disbursements[0].DisbursementID;
                int bankAccSelValue = (int) ressponse1.Disbursements[0].EditDisbursement.DisbursementDetails.BankAccSelValue;
                int disbTypeIDSelectedValue = (int) ressponse1.Disbursements[0].EditDisbursement.DisbursementDetails.DisbTypeIdSelectedValue;
                int fileBusinessPartyID = (int) ressponse1.Disbursements[0].EditDisbursement.DisbursementDetails.FileBusinessPartyID;
                int fileProcessId = (int) ressponse1.Disbursements[0].EditDisbursement.DisbursementDetails.FileProcessID;

                Reports.TestStep = "Invoke SaveEditDisbursementDetails method, validate response (WS)";
                var request = EscrowRequestFactory.GetEditDisbursementRequest(fileId);
                request.DisbActivityID = disActivityID;
                request.EditDisbursementDetails = new EditDisbursementDetails()
                {
                    BankAccSelValue = bankAccSelValue,
                    DisbTypeIDSelectedValue = disbTypeIDSelectedValue,
                    FileBusinessPartyID = fileBusinessPartyID,
                    ManualCheckReason = "Test from WCF",
                    FileProcessId = fileProcessId
                };
                var response = EscrowTransactionsHelpers.SaveEditDisbursementDetails(request);
                response.Validate();

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally { FastDriver.WebDriver.Quit(); }
        }


        [TestMethod]
        public void REG0017_SearchDepositList()
        {
            try
            {
                Reports.TestDescription = "Verify SearchDepositList() Service";

                #region data setup

                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                #endregion

                #region Login
                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                #endregion

                #region Create file using WCF
                Reports.TestStep = "Create a file using web service";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                var file = FileService.GetOrderDetails(fileId).FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(file);
                #endregion

                Reports.TestStep = "Invoke SearchDepositListService.";
                var SearchDepositReq = EscrowRequestFactory.SearchDepositListRequest();
                var SearchDepositRes = EscrowService.SearchDepositList(SearchDepositReq);

                string BankAcctId = SearchDepositReq.BankAccount.ToString();

                Reports.TestStep = "Navigate to Deposit List.";
                FastDriver.LeftNavigation.Navigate<DepositList>("Home>Business Unit Processing>Deposit Slip>Deposit List");
                FastDriver.DepositList.WaitForScreenToLoad(FastDriver.DepositList.SearchDate);
                FastDriver.DepositList.SearchDate.FASetText(DateTime.UtcNow.ToDateString());
                FastDriver.DepositList.BankAccounts.FASelectItem("All Accounts");
                FastDriver.DepositList.WaitForScreenToLoad(FastDriver.DepositList.SearchDate);
                FastDriver.DepositList.FindNow.FAClick();
                FastDriver.DepositList.WaitForScreenToLoad(FastDriver.DepositList.DepositListTable);

                Reports.TestStep = "Validate the Search Deposit Response details.";
                Support.AreEqual(BankAcctId, SearchDepositRes.DepositIDs[0].PrimaryBankAcct.ToString(), "BankAccount");
                Support.AreEqual("Automation Bank", SearchDepositRes.DepositBankAccnt[0].BankName.ToString(), "Account Name");
                Support.AreEqual(BankAcctId, SearchDepositRes.DpstSearchResponse[1].BankID.ToString(), "BankAccount");
                for (int i = 1; i < 4; i++)
                {
                    int DepositListNum = FastDriver.DepositList.VerifyDepositListNumDisplayedInTable(SearchDepositRes.DpstSearchResponse[i].DepositListNum);
                    string DepositListNumber = SearchDepositRes.DpstSearchResponse[i].DepositListNum.ToString();
                    if (DepositListNum >= 1)
                    {
                        string AmountUI = FastDriver.DepositList.DepositListTable.PerformTableAction(1, DepositListNumber, 3, TableAction.GetText).Message.Clean();
                        string StatusUI = FastDriver.DepositList.DepositListTable.PerformTableAction(1, DepositListNumber, 2, TableAction.GetText).Message.Clean();
                        Support.AreEqual(AmountUI, SearchDepositRes.DpstSearchResponse[i].DepositTotal.ToString().FormatAsMoney().Trim());
                        Support.AreEqual(BankAcctId, SearchDepositRes.DpstSearchResponse[i].BankID);
                        Support.AreEqual(StatusUI, SearchDepositRes.DpstSearchResponse[i].Status.ToString().Trim());
                    }
                }

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0018_UpdateDisbursementTrackDetails()
        {
            try
            {
                Reports.TestDescription = "Verify UpdateDisbursementTrackDetails service";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = FileRequestFactory.GetDetailedCreateFileDefaultRequest();
                var deposit = new DepositParameters()
                {
                    Amount = 10000.00,
                    TypeofFunds = "Cash",
                    Representing = "Additional Closing Costs",
                    Description = "Sanity Deposit In Escrow",
                    ReceivedFrom = "Buyer",
                    Payor = "Buyer"
                };
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a file using web service";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                string fileNum = FileService.GetOrderDetails(fileId).FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(fileNum);

                Reports.TestStep = "Set default check printer";
                FastDriver.LeftNavigation.Navigate<PrinterConfiguration>(@"Home>Printer Configuration").WaitForScreenToLoad();
                FastDriver.PrinterConfiguration.SetDefaultPrinter();

                Reports.TestStep = "Making a cash deposit";
                FastDriver.DepositInEscrow.Open();
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.PrintDlg.SelectPrinter(@"TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.ClickPrint();
                FastDriver.WebDriver.WaitForDeliveryWindow(FADeliveryMethod.Print, 200);

                Reports.TestStep = "Navigate to Home Warranty screen, enter buyer charge";
                FastDriver.HomeWarrantyDetail.Open();
                FastDriver.HomeWarrantyDetail.FindGABCode("BOA");
                FastDriver.HomeWarrantyDetail.HomeWarrantyChargeDescription.FASetText("Home Warranty");
                FastDriver.HomeWarrantyDetail.HomeWarrantyBuyerCharge.FASetText("100.00" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Wait for SDN search to complete";
                FastDriver.SDNTrackingSummary.WaitForSDNSearchComplete(30);

                Reports.TestStep = "Print the check";
                PrintCheck("100.00");

                Reports.TestStep = "Get DisbursementID (WC)";
                int disbursementID = 0;
                var ressponse1 = FileService.GetDisbursementHistorySummary(fileId, @"fastts\fastqa07");

                foreach (DisbursementActivity disburse in ressponse1.DisbursementActivities)
                {
                    if (disburse.Status == "Issued")
                    {
                        disbursementID = (int)disburse.DisbursementID;
                        break;
                    }
                }

                Reports.TestStep = "Invoke UpdateDisbursementTrackDetails method, validate response (WS)";
                var request = EscrowRequestFactory.GetUpdateDisbTrackRequest(fileId, disbursementID);
                request.TrackDetail = "Test from web service";
                EscrowTransactionsHelpers.UpdateDisbursementTrackDetails(request).Validate();

                Reports.TestStep = "Navigate to Active Disbursement Screen, validate track info details";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(1, "Issued", 1, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Track.FAClick();
                FastDriver.TrackDlg.WaitForScreenToLoad();
                Support.AreEqual(request.TrackDetail, FastDriver.TrackDlg.TrackInfo.FAGetText().Clean(), "Track Info");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally { FastDriver.WebDriver.Quit(); }
        }

        [TestMethod]
        public void REG0019_UpdateSplitDisbursement()
        {
            try
            {
                Reports.TestDescription = "Verify UpdateSplitDisbursement service";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = FileRequestFactory.GetDetailedCreateFileDefaultRequest();
                var deposit = new DepositParameters()
                {
                    Amount = 10000.00,
                    TypeofFunds = "Cash",
                    Representing = "Additional Closing Costs",
                    Description = "Sanity Deposit In Escrow",
                    ReceivedFrom = "Buyer",
                    Payor = "Buyer"
                };
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a file using web service";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                string fileNum = FileService.GetOrderDetails(fileId).FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(fileNum);

                Reports.TestStep = "Set default check printer";
                FastDriver.LeftNavigation.Navigate<PrinterConfiguration>(@"Home>Printer Configuration").WaitForScreenToLoad();
                FastDriver.PrinterConfiguration.SetDefaultPrinter();

                Reports.TestStep = "Making a cash deposit";
                FastDriver.DepositInEscrow.Open();
                FastDriver.DepositInEscrow.Deposit(deposit);
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.PrintDlg.SelectPrinter(@"TEXT_FILE_PRINTER");
                FastDriver.PrintDlg.ClickPrint();
                FastDriver.WebDriver.WaitForDeliveryWindow(FADeliveryMethod.Print, 200);

                Reports.TestStep = "Navigate to Home Warranty screen, enter buyer charge";
                FastDriver.HomeWarrantyDetail.Open();
                FastDriver.HomeWarrantyDetail.FindGABCode("BOA");
                FastDriver.HomeWarrantyDetail.HomeWarrantyChargeDescription.FASetText("Home Warranty");
                FastDriver.HomeWarrantyDetail.HomeWarrantyBuyerCharge.FASetText("100.00" + FAKeys.Tab);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Navigate to Active Disbursement Summary screen, perform split disbursement";
                FastDriver.ActiveDisbursementSummary.Open();
                FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(7, "100.00", 7, TableAction.Click);
                FastDriver.ActiveDisbursementSummary.Split.FAClick();
                FastDriver.SplitDisbursement.WaitForScreenToLoad();
                FastDriver.SplitDisbursement.SplitDistributionAmount0.FASetText("60.00" + FAKeys.Tab);
                Thread.Sleep(5000);
                FastDriver.SplitDisbursement.SplitDistributionAmount1.FASetText("40.00");
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20);
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Get Super DisbursementID (WC)";
                int superDisbursementID = 0;
                var ressponse1 = FileService.GetActiveDisbursementSummaryDetails(fileId);

                foreach (FASTWCFHelpers.FastFileService.Disbursement disburse in ressponse1.Disbursements)
                {
                    if (disburse.SplitIndicator == "M")
                    {
                        superDisbursementID = (int)disburse.DisbursementID;
                        break;
                    }
                }

                Reports.TestStep = "Invoke UpdateSplitDisbursement method, validate response (WS)";
                var request = EscrowRequestFactory.GetUpdateSplitDisbRequest(fileId, superDisbursementID);
                request.splitDistributions = new SplitDistribution[]
                {
                    new SplitDistribution()
                    {
                        Percentage = 70,
                        DisburseAs =  "Check",
                        DisbursementMethodTypeCdID = 384,
                        SuperDisbursementId = superDisbursementID,
                        DisbursementID = superDisbursementID + 1,
                        PayeeName = "Payee Number 1"
                    },
                    new SplitDistribution()
                    {
                        Percentage = 30,
                        DisburseAs =  "Check",
                        DisbursementMethodTypeCdID = 384,
                        SuperDisbursementId = superDisbursementID,
                        DisbursementID = superDisbursementID + 2,
                        PayeeName = "Payee Number 2"
                    }
                };
                EscrowTransactionsHelpers.UpdateSplitDisbursement(request).Validate();

                Reports.TestStep = "Navigate to Active Disbursement screen, validate amounts";
                FastDriver.ActiveDisbursementSummary.Open();
                Support.AreEqual("70.00", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(7, "70.00", 7, TableAction.GetText).Message.Clean(), "Check 1");
                Support.AreEqual("30.00", FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction(7, "30.00", 7, TableAction.GetText).Message.Clean(), "Check 2");
                
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally { FastDriver.WebDriver.Quit(); }
        }

        [TestMethod]
        public void REG0020_GetDepositImages()
        {
            try
            {
                Reports.TestDescription = "Verify GetDepositImages service";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetDetailedCreateFileDefaultRequest();
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a file using web service";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                string fileNum = FileService.GetOrderDetails(fileId).FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(fileNum);

                Reports.TestStep = "Create a deposit in escrow (WS)";
                var GetDepositInEscrowRequest = EscrowRequestFactory.GetDepositInEscrowRequest(fileId);
                var GetDepositInEscrowResponse = EscrowService.CreateDepositInEscrow(GetDepositInEscrowRequest);
                GetDepositInEscrowResponse.Validate();
                int depositID = (int)GetDepositInEscrowResponse.DepositInEscrow.DepositEscrow.InEscrowID;

                Reports.TestStep = "Invoke GetDepositImages method, validate response (WS)";
                var request = EscrowRequestFactory.GetDepositImagesRequest(fileId, depositID);
                var response = EscrowTransactionsHelpers.GetDepositImages(request);
                //Can't fully automate this test case as the check image is coming from trust bank, just validate the expected response
                Support.AreEqual("Image is not Applicable for Non TrustBank Deposits", response.StatusDescription.Clean(), "Status Description");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally { FastDriver.WebDriver.Quit(); }
        }

        #region private methods
        private void PrintCheck(string amount)
        {
            FastDriver.ActiveDisbursementSummary.Open();
            FastDriver.ActiveDisbursementSummary.Disbursements.PerformTableAction("Amount", amount, "Status", TableAction.Click);
            FastDriver.ActiveDisbursementSummary.Print.FAClick();
            FastDriver.PrintChecks.WaitForScreenToLoad();
            FastDriver.PrintChecks.Deliver.FAClick();
            FastDriver.PrintDlg.WaitForScreenToLoad();
            FastDriver.PrintDlg.Printers.FASelectItemBySendingKeys("TEXT_FILE_PRINTER");
            FastDriver.PrintDlg.ClickPrint();
            FastDriver.WebDriver.WaitForDeliveryWindow(FADeliveryMethod.Print, 200);
        }

        #endregion

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
