﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastEscrowService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;
using WebServices.Helpers.Escrow;


namespace WebServices.Escrow
{
    [CodedUITest]
    public class NewLoanWS : MasterTestClass
    {
        [TestMethod]
        public void REG0001_CreateNewLoan()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan();
                #endregion

                Reports.TestDescription = "Verify CreateNewLoan() service.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                int fileid = FastDriver.FACreateFileGetFileId(fileRequest);
                var file = FileService.GetOrderDetails(fileid);
                FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

                var newloanRequest = EscrowRequestFactory.GetNewLoanCreateRequest(file.FileID.ToString(), seqNum: 1);
                newloanRequest.EmployeeID = 1;
                newloanRequest.LoanDetails.LoanDates.FundingDate = DateTime.Now.ToPST();
                newloanRequest.LoanDetails.LoanDates.RescissionBeginDate = DateTime.Now.ToPST();
                newloanRequest.LoanDetails.LoanDates.RescissionEnds = DateTime.Now.ToPST().AddDays(5);
                newloanRequest.LoanDetails.LoanDates.SigningDate = DateTime.Now.ToPST();
                if (AutoConfig.UseCDFormType) newloanRequest.LoanCharges.CDInterestCalculationSummary.InterestCalculation.From = DateTime.Now.ToPST();
                else newloanRequest.LoanCharges.InterestCalculationSummary.InterestCalculation.From = DateTime.Now.ToPST();
                if (AutoConfig.UseCDFormType) newloanRequest.LoanCharges.CDInterestCalculationSummary.InterestCalculation.To = DateTime.Now.ToPST().AddDays(6);
                else newloanRequest.LoanCharges.InterestCalculationSummary.InterestCalculation.To = DateTime.Now.ToPST().AddDays(6);
                if (AutoConfig.UseCDFormType) newloanRequest.LoanCharges.CDNewLoanCharges[0].SeqNum = 1;
                else newloanRequest.LoanCharges.NewLoanCharges[0].SeqNum = 1;

                Reports.TestStep = "Invoke CreateNewLoan service";
                EscrowService.CreateNewLoan(newloanRequest).Validate();

                Reports.TestStep = "Identifying form type";
                Reports.StatusUpdate("Form type is " + AutoConfig.FormType, true);

                Reports.TestStep = "Navigate to New Loan";
                FastDriver.LeftNavigation.Navigate<NewLoanSummary>("Home>Order Entry>New Loan").WaitForScreenToLoad(FastDriver.NewLoanSummary.LoanSummaryTable);
                FastDriver.NewLoanSummary.LoanSummaryTable.PerformTableAction("Loan Amount", "1,000.01", "Loan Amount", TableAction.DoubleClick);
                FastDriver.NewLoan.WaitForScreenToLoad();

                var interestCalculationDetails = AutoConfig.UseCDFormType ? newloanRequest.LoanCharges.CDInterestCalculationSummary.InterestCalculation : newloanRequest.LoanCharges.InterestCalculationSummary.InterestCalculation;
                var newLoanDetails = newloanRequest.LoanDetails;
                var newLoanCharges = newloanRequest.LoanCharges.CDNewLoanCharges ?? null;
                var principalBalanceCharges = newloanRequest.LoanCharges.CDPrincipalBalanceCharges ?? null;
                var brokerFee = newloanRequest.MortgageBroker.CDBrokerFee ?? null;
                var mortgageBrokerCharge = newloanRequest.MortgageBroker.CDMortgageBrokerCharges ?? null;
                var impoundData = !AutoConfig.UseCDFormType ? newloanRequest.LoanCharges.ImpoundCharges.Impounds[0] : null;
                var mortgageYieldData = newloanRequest.MortgageBroker.YieldSpreadPremium ?? null;

                Reports.TestStep = "Verify New Loan screen is filled with data from the web service request.";
                Support.AreEqual(newLoanDetails.LoanDates.FundingDate.Value.ToDateString(), FastDriver.NewLoan.LoanDetailsFundingDate.FAGetValue(), "FundingDate");
                //Support.AreEqual(NewLoanDetails.LoanDates.SigningDate.Value.ToFASTDateString(), FastDriver.NewLoan.LoanDetailsSigningDate.FAGetValue(), "SigningDate");
                Support.AreEqual(newLoanDetails.LoanDates.RescissionDays.Value.ToString(), FastDriver.NewLoan.LoanDetailsDays.FAGetValue(), "RescissionDays");
                Support.AreEqual(newLoanDetails.LoanDates.RescissionEnds.Value.ToDateString(), FastDriver.NewLoan.LoanDetailsEnds.FAGetValue(), "RescissionEnds");
                Support.AreEqual(newLoanDetails.LoanDates.RescissionBeginDate.Value.ToDateString(), FastDriver.NewLoan.LoanDetailsRescissionPeriodBegins.FAGetValue(), "RescissionBeginDate");
                Support.AreEqual(newLoanDetails.LoanAmount.ToString().FormatAsMoney(), FastDriver.NewLoan.LoanDetailsLoanAmount.FAGetValue().FormatAsMoney(), "LoanAmount");
                Support.AreEqual(newLoanDetails.MortgageInsuranceCaseNumber, FastDriver.NewLoan.LoanDetailsMortgageInsCase.FAGetValue(), "MortgageInsuranceCaseNumber");
                Support.AreEqual(newLoanDetails.LoanNumber, FastDriver.NewLoan.LoanDetailsLoanNumber.FAGetValue(), "LoanNumber");

                Reports.TestStep = "Click Loan Charges";
                FastDriver.NewLoan.LoanChargesTab.FAClick();
                FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                if (AutoConfig.UseCDFormType && principalBalanceCharges.Description != null)
                {
                    Reports.TestStep = "Verify Principal Balance Charges";
                    Support.AreEqual(principalBalanceCharges.Description.ToString(), FastDriver.NewLoan.LoanChargesPrincipalBalanceChargesdescription.FAGetValue(), "Description");
                }

                Reports.TestStep = "Verify Interest Calculation Summary";
                Support.AreEqual(interestCalculationDetails.PerDiemAmount.ToString().FormatAsMoney(), FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FAGetValue().FormatAsMoney(), "PerDiemAmount");
                Support.AreEqual(interestCalculationDetails.From.Value.ToDateString(), FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FAGetValue(), "From");
                Support.AreEqual(interestCalculationDetails.To.Value.ToDateString(), FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FAGetValue(), "To");
                Support.AreEqual(interestCalculationDetails.ToInclusive.Value, FastDriver.NewLoan.LoanChargesInterestCalculationInclusiveTo.IsSelected(), "ToInclusive");
                Support.AreEqual(interestCalculationDetails.FromInclusive.Value, FastDriver.NewLoan.LoanChargesInterestCalculationInclusiveFrom.IsSelected(), "FromInclusive");
                Support.AreEqual(interestCalculationDetails.BasedOnDays.ToString(), FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FAGetSelectedItem(), "BasedOnDays");

                if (AutoConfig.UseCDFormType)
                {
                    Reports.TestStep = "Verify New Loan Charges";
                    FastDriver.NewLoan.LoanCharges_NewLoanTable.PerformTableAction("Description", newLoanCharges[0].Description, "Description", TableAction.DoubleClick);
                    ServiceHelper.ValidatePaymentAndGetCheckAMount(newLoanCharges[0]);
                    FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                    if (newLoanCharges[0].Description != null)
                        Support.AreEqual(newLoanCharges[0].Description.ToString(), FastDriver.NewLoan.LoanChargesNewLoanChargesDescription1.FAGetValue(), "Description");
                    if (newLoanCharges[0].BuyerCharge != null)
                        Support.AreEqual(newLoanCharges[0].BuyerCharge.ToString().FormatAsMoney(), FastDriver.NewLoan.LoanChargesNewLoanChargesBuyerCharge1.FAGetValue().FormatAsMoney(), "BuyerCharge");
                    if (newLoanCharges[0].SellerCharge != null)
                        Support.AreEqual(newLoanCharges[0].SellerCharge.ToString().FormatAsMoney(), FastDriver.NewLoan.LoanChargesNewLoanChargesSellerCharge1.FAGetValue().FormatAsMoney(), "SellerCharge");

                    Reports.TestStep = "Navigate to Mortgage Broker";
                    FastDriver.NewLoan.MortgageBrokerTab.FAClick();
                    FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();

                    Reports.TestStep = "Verify the Mortgage Broker Fee";
                    Support.AreEqual(brokerFee.Description.ToString(), FastDriver.NewLoan.MortgageYieldSpreadPremiumdescription.FAGetValue(), "Description");
                    Support.AreEqual(brokerFee.FileCharge.ToString().FormatAsMoney(), FastDriver.NewLoan.MortgageYieldSpreadPremiumAmount.FAGetValue().FormatAsMoney(), "FileCharge");

                    Reports.TestStep = "Verify the Mortgage Broker Charges";
                    if (mortgageBrokerCharge[0].Description != null)
                        Support.AreEqual(mortgageBrokerCharge[0].Description.ToString(), FastDriver.NewLoan.MBChargesDescription0.FAGetValue(), "Description");
                    if (mortgageBrokerCharge[0].BuyerCharge != null)
                        Support.AreEqual(mortgageBrokerCharge[0].BuyerCharge.ToString().FormatAsMoney(), FastDriver.NewLoan.MortgageGFE_3MortgageBrokerChargesBuyerCharge.FAGetValue().FormatAsMoney(), "BuyerCharge");
                    if (mortgageBrokerCharge[0].SellerCharge != null)
                        Support.AreEqual(mortgageBrokerCharge[0].SellerCharge.ToString().FormatAsMoney(), FastDriver.NewLoan.MortgageGFE_3MortgageBrokerChargesSellerCharge.FAGetValue().FormatAsMoney(), "SellerCharge");
                }
                else
                {
                    Reports.TestStep = "Verify New Loan Impound Charges";
                    impoundData.PaymentDetails.BuyerCharge = impoundData.Months * impoundData.MonthlyCharge;
                    if (FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustment_GFEAmount.IsEnabled())
                        Support.AreEqual(newloanRequest.LoanCharges.ImpoundCharges.GFEAmount.ToString().FormatAsMoney(), FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustment_GFEAmount.FAGetValue(), "GFEAmount");
                    Support.AreEqual(impoundData.PaymentDetails.BuyerCharge.ToString().FormatAsMoney(), FastDriver.NewLoan.LoanCharges_InitialDepositBuyerChargeAmount.FAGetText(), "GFEAmount");
                    Support.AreEqual(impoundData.Months.ToString(), FastDriver.NewLoan.LoanChargesImpoundsTable.PerformTableAction("Description", impoundData.PaymentDetails.Description, "Months", TableAction.GetInputValue).Message, "Impound Months");
                    Support.AreEqual(impoundData.MonthlyCharge.ToString().FormatAsMoney(), FastDriver.NewLoan.LoanChargesImpoundsTable.PerformTableAction("Description", impoundData.PaymentDetails.Description, "Monthly Charge", TableAction.GetInputValue).Message, "Impound Monthly Charge");
                    Support.AreEqual(impoundData.PaymentDetails.BuyerCharge.ToString().FormatAsMoney(), FastDriver.NewLoan.LoanChargesImpoundsTable.PerformTableAction("Description", impoundData.PaymentDetails.Description, "Buyer Charge", TableAction.GetInputValue).Message, "Impound Buyer Charge");

                    Reports.TestStep = "Navigate to Mortgage Broker";
                    FastDriver.NewLoan.MortgageBrokerTab.FAClick();
                    FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();

                    Reports.TestStep = "Verify New Loan Mortgage Broker";
                    Support.AreEqual(mortgageYieldData.Description, FastDriver.NewLoan.MortgageYieldSpreadPremiumdescription.FAGetValue(), "MortgageYieldSpreadPremiumDescription");
                    Support.AreEqual(mortgageYieldData.FileCharge.ToString().FormatAsMoney(), FastDriver.NewLoan.MortgageYieldSpreadPremiumAmount.FAGetValue(), "MortgageYieldSpreadPremiumAmount");
                }
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        public void REG0002_UpdateNewLoan()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetDetailedCreateFileDefaultRequest();
                #endregion

                Reports.TestDescription = "Verify UpdateNewLoan() service";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                int fileid = FastDriver.FACreateFileGetFileId(fileRequest);
                var file = FileService.GetOrderDetails(fileid);
                FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

                Reports.TestStep = "Invoke GetNewLoanDetails service";
                var getNewLoanDetailsResponse = EscrowService.GetNewLoanDetails(EscrowRequestFactory.GetNewLoanDetailsRequest(file.FileID.Value, 1));
                Support.AreEqual("1", getNewLoanDetailsResponse.Status.ToString(), getNewLoanDetailsResponse.StatusDescription);

                if (AutoConfig.UseCDFormType)
                {
                    #region CD Validations
                    int orgChargeAdhocCount = getNewLoanDetailsResponse.LoanCharges.CDOriginationCharges.Length;
                    int loanChargeAdhocCount = getNewLoanDetailsResponse.LoanCharges.CDNewLoanCharges.Length;
                    int principalReductionAdhocCount = getNewLoanDetailsResponse.LoanCharges.CDPrincipalReductionOrConstructionHoldBack.Length;

                    var newloanRequest = EscrowRequestFactory.GetNewLoanUpdateRequest(file.FileID.ToString(), seqNum: 1);
                    newloanRequest.EmployeeID = 1;
                    newloanRequest.SeqNum = 1;
                    newloanRequest.LoanDetails.LoanDates.FundingDate = DateTime.Now.ToPST();
                    newloanRequest.LoanDetails.LoanDates.RescissionBeginDate = DateTime.Now.ToPST();
                    newloanRequest.LoanDetails.LoanDates.RescissionEnds = DateTime.Now.ToPST().AddDays(5);
                    newloanRequest.LoanDetails.LoanDates.SigningDate = DateTime.Now.ToPST();
                    newloanRequest.LoanCharges.CDInterestCalculationSummary.InterestCalculation.From = DateTime.Now.ToPST();
                    newloanRequest.LoanCharges.CDInterestCalculationSummary.InterestCalculation.To = DateTime.Now.ToPST().AddDays(6);
                    //Give adhoc seq num from get 
                    newloanRequest.LoanCharges.CDImpoundCharges.Impounds[1].SeqNum = getNewLoanDetailsResponse.LoanCharges.CDImpoundCharges.Impounds.Length;
                    newloanRequest.LoanCharges.CDNewLoanCharges[1].SeqNum = loanChargeAdhocCount;
                    newloanRequest.LoanCharges.CDPrincipalReductionOrConstructionHoldBack[1].SeqNum = principalReductionAdhocCount;
                    newloanRequest.LoanCharges.CDOriginationCharges[1].SeqNum = orgChargeAdhocCount;

                    Reports.TestStep = "Invoke UpdateNewLoan method";
                    var response = EscrowService.UpdateNewLoan(newloanRequest);
                    Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);

                    var cdImpoundData = newloanRequest.LoanCharges.CDImpoundCharges.Impounds;
                    var cdInterestCalDetails = newloanRequest.LoanCharges.CDInterestCalculationSummary.InterestCalculation;
                    var cdInterestChargeDetails = newloanRequest.LoanCharges.CDInterestCalculationSummary.CDChargePaymentDetails;
                    var cdNewLoanDetails = newloanRequest.LoanDetails;
                    var cdCreditOrChargePoints = newloanRequest.LoanCharges.CDCreditOrChargePoints;
                    var cdFutureRecordingFeesCollectedByLender = newloanRequest.LoanCharges.CDFutureRecordingFeesCollectedByLender;
                    var cdLenderCredits = newloanRequest.LoanCharges.CDLenderCredits;
                    var cdNewLoanCharges = newloanRequest.LoanCharges.CDNewLoanCharges;
                    var cdPrincipalReductionOrConstruction = newloanRequest.LoanCharges.CDPrincipalReductionOrConstructionHoldBack;
                    var cdOriginationCharges = newloanRequest.LoanCharges.CDOriginationCharges;
                    var cdPrincipalBalanceCharges = newloanRequest.LoanCharges.CDPrincipalBalanceCharges;
                    var cdBrokerFee = newloanRequest.MortgageBroker.CDBrokerFee;
                    var cdMortgageBrokerCharge = newloanRequest.MortgageBroker.CDMortgageBrokerCharges;
                    var cdFutureRecordingFeescollectedbyMB = newloanRequest.MortgageBroker.CDFutureRecordingFeescollectedbyMB;
                    var cdLenderCreditsMB = newloanRequest.MortgageBroker.CDLenderCredits;

                    Reports.TestStep = "Navigate to New Loan";
                    FastDriver.NewLoan.Open();
                    FastDriver.NewLoan.LoanDetailsTab.FAClick();
                    FastDriver.NewLoan.WaitForScreenToLoad();
                                        
                    Reports.TestStep = "Validate New Loan information";
                    Support.AreEqual(cdNewLoanDetails.LoanDates.FundingDate.Value.ToDateString(), FastDriver.NewLoan.LoanDetailsFundingDate.FAGetValue(), "FundingDate");
                    Support.AreEqual(cdNewLoanDetails.LoanDates.SigningDate.Value.ToDateString(), FastDriver.NewLoan.LoanDetailsSigningDate.FAGetValue(), "SigningDate");
                    Support.AreEqual(cdNewLoanDetails.LoanDates.RescissionDays.ToString(), FastDriver.NewLoan.LoanDetailsDays.FAGetValue(), "RescissionDays");
                    Support.AreEqual(cdNewLoanDetails.LoanDates.RescissionEnds.Value.ToDateString(), FastDriver.NewLoan.LoanDetailsEnds.FAGetValue(), "RescissionEnds");
                    Support.AreEqual(cdNewLoanDetails.LoanDates.RescissionBeginDate.Value.ToDateString(), FastDriver.NewLoan.LoanDetailsRescissionPeriodBegins.FAGetValue(), "RescissionBeginDate");
                    Support.AreEqual(cdNewLoanDetails.LoanAmount.Value.ToString().FormatAsMoney(), FastDriver.NewLoan.LoanDetailsLoanAmount.FAGetValue().FormatAsMoney(), "LoanAmount");
                    Support.AreEqual(cdNewLoanDetails.MortgageInsuranceCaseNumber.ToString(), FastDriver.NewLoan.LoanDetailsMortgageInsCase.FAGetValue(), "MortgageInsuranceCaseNumber");
                    Support.AreEqual(cdNewLoanDetails.LoanNumber.ToString(), FastDriver.NewLoan.LoanDetailsLoanNumber.FAGetValue(), "LoanNumber");

                    Reports.TestStep = "Open New Loan Charges";
                    FastDriver.NewLoan.LoanChargesTab.FAClick();
                    FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                    Reports.TestStep = "Validate CD impound data 1";
                    FastDriver.NewLoan.LoanChargesImpoundsTable.PerformTableAction("Months", cdImpoundData[0].Months.ToString(), "Months", TableAction.DoubleClick);
                    ServiceHelper.ValidatePaymentAndGetCheckAMount(cdImpoundData[0]);

                    Reports.TestStep = "Validate CD impound data 2";
                    FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                    FastDriver.NewLoan.LoanChargesImpoundsTable.PerformTableAction("Description", cdImpoundData[1].Description.ToString(), "Months", TableAction.DoubleClick);
                    ServiceHelper.ValidatePaymentAndGetCheckAMount(cdImpoundData[1]);

                    Reports.TestStep = "Validate New Loan monthly charges";
                    FastDriver.NewLoan.WaitForLoanChargesTabToLoad();
                    Support.AreEqual(cdImpoundData[0].MonthlyCharge.ToString().FormatAsMoney(), FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustment_MonthlyCharge.FAGetValue().FormatAsMoney(), "MonthlyCharge");
                    Support.AreEqual(cdImpoundData[0].Months.ToString(), FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustment_Months1.FAGetValue(), "Months");

                    Reports.TestStep = "Validate New Loan Principal Balance charges";
                    if (cdPrincipalBalanceCharges.Description != null)
                        Support.AreEqual(cdPrincipalBalanceCharges.Description.ToString(), FastDriver.NewLoan.LoanChargesPrincipalBalanceChargesdescription.FAGetValue(), "Principal Balance Description");
                    if (cdPrincipalBalanceCharges.BuyerCredit != null)
                        Support.AreEqual(cdPrincipalBalanceCharges.BuyerCredit.ToString().FormatAsMoney(), FastDriver.NewLoan.LoanChargesPrincipalBalanceChargesBuyercredit.FAGetValue().FormatAsMoney(), "Principal Balance BuyerCredit");
                    if (cdPrincipalBalanceCharges.SellerCharge != null)
                        Support.AreEqual(cdPrincipalBalanceCharges.SellerCharge.ToString().FormatAsMoney(), FastDriver.NewLoan.LoanChargesPrincipalBalanceChargesSellercharge.FAGetValue().FormatAsMoney(), "Principal Balance SellerCharge");

                    Reports.TestStep = "Verify Interest Calculation Summary ";
                    Support.AreEqual(cdInterestCalDetails.PerDiemAmount.ToString().FormatAsMoney(), FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FAGetValue().FormatAsMoney(), "PerDiemAmount");
                    Support.AreEqual(cdInterestCalDetails.From.Value.ToDateString(), FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FAGetValue(), "From");
                    Support.AreEqual(cdInterestCalDetails.To.Value.ToDateString(), FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FAGetValue(), "To");
                    Support.AreEqual(cdInterestCalDetails.ToInclusive.ToString(), FastDriver.NewLoan.LoanChargesInterestCalculationInclusiveTo.IsSelected().ToString(), "ToInclusive");
                    Support.AreEqual(cdInterestCalDetails.FromInclusive.ToString(), FastDriver.NewLoan.LoanChargesInterestCalculationInclusiveFrom.IsSelected().ToString(), "FromInclusive");
                    Support.AreEqual(cdInterestCalDetails.BasedOnDays.ToString(), FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FAGetSelectedItem().ToString(), "BasedOnDays");

                    Reports.TestStep = "Verify Loan Charges details 1";
                    FastDriver.NewLoan.LoanCharges_NewLoanTable.PerformTableAction(2, 2, TableAction.DoubleClick);
                    ServiceHelper.ValidatePaymentAndGetCheckAMount(cdNewLoanCharges[0]);
                    FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                    Reports.TestStep = "Verify Loan Charges details 2";
                    FastDriver.NewLoan.LoanCharges_NewLoanTable.PerformTableAction("Description", cdNewLoanCharges[1].Description.ToString(), "Description", TableAction.DoubleClick);
                    ServiceHelper.ValidatePaymentAndGetCheckAMount(cdNewLoanCharges[1]);
                    FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                    Reports.TestStep = "Validate New Loan charges";
                    if (cdNewLoanCharges[0].Description != null)
                        Support.AreEqual(cdNewLoanCharges[0].Description, FastDriver.NewLoan.LoanChargesNewLoanChargesDescription1.FAGetValue(), "Description");
                    if (cdNewLoanCharges[0].BuyerCharge != null)
                        Support.AreEqual(cdNewLoanCharges[0].BuyerCharge.ToString().FormatAsMoney(), FastDriver.NewLoan.LoanChargesNewLoanChargesBuyerCharge1.FAGetValue().FormatAsMoney(), "BuyerCharge");
                    if (cdNewLoanCharges[0].SellerCharge != null)
                        Support.AreEqual(cdNewLoanCharges[0].SellerCharge.ToString().FormatAsMoney(), FastDriver.NewLoan.LoanChargesNewLoanChargesSellerCharge1.FAGetValue().FormatAsMoney(), "SellerCharge");

                    Reports.TestStep = "Verify the Origination Charges details 1";
                    FastDriver.NewLoan.LoanChargesOriginationChargeTable.PerformTableAction(2, 2, TableAction.DoubleClick);
                    ServiceHelper.ValidatePaymentAndGetCheckAMount(cdOriginationCharges[0]);
                    FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                    Reports.TestStep = "Verify the Origination Charges details 2";
                    FastDriver.NewLoan.LoanChargesOriginationChargeTable.PerformTableAction("Description", cdOriginationCharges[1].Description.ToString(), "Description", TableAction.DoubleClick);
                    ServiceHelper.ValidatePaymentAndGetCheckAMount(cdOriginationCharges[1]);
                    FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                    Reports.TestStep = "Verify the Origination Charges";
                    if (cdOriginationCharges[0].Description != null)
                        Support.AreEqual(cdOriginationCharges[0].Description, FastDriver.NewLoan.LoanChargesOriginationChargeDescription.FAGetValue(), "Description");
                    if (cdOriginationCharges[0].BuyerCharge != null)
                        Support.AreEqual(cdOriginationCharges[0].BuyerCharge.ToString().FormatAsMoney(), FastDriver.NewLoan.LoanChargesOriginationChargebuyercharge.FAGetValue().FormatAsMoney(), "BuyerCharge");
                    if (cdOriginationCharges[0].SellerCharge != null)
                        Support.AreEqual(cdOriginationCharges[0].SellerCharge.ToString().FormatAsMoney(), FastDriver.NewLoan.LoanChargesOriginationChargeSellercharge.FAGetValue().FormatAsMoney(), "SellerCharge");

                    Reports.TestStep = "Verify Principal Reduction or Construction payment details";
                    FastDriver.NewLoan.LoanChargesPrincipalReductiontable.PerformTableAction(2, 2, TableAction.DoubleClick);
                    ServiceHelper.ValidatePaymentAndGetCheckAMount(cdPrincipalReductionOrConstruction[0]);
                    FastDriver.NewLoan.WaitForLoanChargesTabToLoad();

                    Reports.TestStep = "Verify Principal Reduction or Construction charges";
                    if (cdPrincipalReductionOrConstruction[0].Description != null)
                        Support.AreEqual(cdPrincipalReductionOrConstruction[0].Description.ToString(), FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_Description.FAGetValue(), "Description");
                    if (cdPrincipalReductionOrConstruction[0].BuyerCharge != null)
                        Support.AreEqual(cdPrincipalReductionOrConstruction[0].BuyerCharge.ToString().FormatAsMoney(), FastDriver.NewLoan.LoanChargesPrincipalreduction_Payment_BuyerCharge.FAGetValue().FormatAsMoney(), "BuyerCharge");
                    if (cdPrincipalReductionOrConstruction[0].SellerCharge != null)
                        Support.AreEqual(cdPrincipalReductionOrConstruction[0].SellerCharge.ToString().FormatAsMoney(), FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_SellerCharge.FAGetValue().FormatAsMoney(), "SellerCharge");

                    Reports.TestStep = "Verify the CD CreditOrChargePoints ";
                    Support.AreEqual(cdCreditOrChargePoints.IRSDiscountPoints.ToString().FormatAsMoney(), FastDriver.NewLoan.CreditChargeIRSPoints.FAGetValue().FormatAsMoney(), "IRSDiscountPoints");

                    Reports.TestStep = "Open the Mortgage Broker tab ";
                    FastDriver.NewLoan.MortgageBrokerTab.FAClick();
                    FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();

                    Reports.TestStep = "Verify the Mortgage Broker Fee";
                    Support.AreEqual(cdBrokerFee.Description.ToString(), FastDriver.NewLoan.MortgageYieldSpreadPremiumdescription.FAGetValue(), "Description");
                    Support.AreEqual(cdBrokerFee.FileCharge.ToString(), FastDriver.NewLoan.MortgageYieldSpreadPremiumAmount.FAGetValue(), "FileCharge");

                    Reports.TestStep = "Verify the Mortgage Broker Charges payment details";
                    FastDriver.NewLoan.MortgageBrokerChargesTable.PerformTableAction(2, 2, TableAction.DoubleClick);
                    ServiceHelper.ValidatePaymentAndGetCheckAMount(cdMortgageBrokerCharge[0]);

                    Reports.TestStep = "Verify the Mortgage Broker Charges details";
                    FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();
                    if (cdMortgageBrokerCharge[0].Description != null)
                        Support.AreEqual(cdMortgageBrokerCharge[0].Description.ToString(), FastDriver.NewLoan.MBChargesDescription0.FAGetValue(), "Description");
                    if (cdMortgageBrokerCharge[0].BuyerCharge != null)
                        Support.AreEqual(cdMortgageBrokerCharge[0].BuyerCharge.ToString().FormatAsMoney(), FastDriver.NewLoan.MortgageGFE_3MortgageBrokerChargesBuyerCharge.FAGetValue().FormatAsMoney(), "BuyerCharge");
                    if (cdMortgageBrokerCharge[0].SellerCharge != null)
                        Support.AreEqual(cdMortgageBrokerCharge[0].SellerCharge.ToString().FormatAsMoney(), FastDriver.NewLoan.MortgageGFE_3MortgageBrokerChargesSellerCharge.FAGetValue().FormatAsMoney(), "SellerCharge");

                    Reports.TestStep = "Verify the Mortgage - Lender Credits";
                    FastDriver.NewLoan.Mortgage_LenderCreditTable.PerformTableAction(2, 2, TableAction.DoubleClick);
                    ServiceHelper.ValidatePaymentAndGetCheckAMount(cdLenderCreditsMB[0]);
                    FastDriver.NewLoan.WaitForMortgageBrokerTabToLoad();
                    Support.AreEqual(cdLenderCreditsMB[0].BuyerCredit.ToString().FormatAsMoney(), FastDriver.NewLoan.MortgageBrokerLenderCreditBuyerCredit.FAGetValue().FormatAsMoney(), "BuyerCredit");
                    #endregion
                }
                else
                {
                    int gfe3SeqNum = getNewLoanDetailsResponse.LoanCharges.GFE3LoanCharges[0].PaymentDetail.SeqNum.Value;
                    int gfe3AdhocCount = getNewLoanDetailsResponse.LoanCharges.GFE3LoanCharges.Length - 1;
                    int gfe6AdhocCount = getNewLoanDetailsResponse.LoanCharges.GFE6LoanCharges.Length - 1;
                    int gfe3SeqNumAdhoc = getNewLoanDetailsResponse.LoanCharges.GFE3LoanCharges[gfe3AdhocCount].PaymentDetail.SeqNum.Value;
                    int gfe6SeqNum = getNewLoanDetailsResponse.LoanCharges.GFE6LoanCharges[0].PaymentDetail.SeqNum.Value;
                    int gfe6SeqNumAdhoc = getNewLoanDetailsResponse.LoanCharges.GFE6LoanCharges[gfe6AdhocCount].PaymentDetail.SeqNum.Value;
                    int impoundAdhocCount = getNewLoanDetailsResponse.LoanCharges.ImpoundCharges.Impounds.Length - 1;

                    var newloanRequest = EscrowRequestFactory.GetNewLoanUpdateRequest(file.FileID.ToString(), seqNum: 1);
                    newloanRequest.EmployeeID = 1;
                    newloanRequest.SeqNum = 1;
                    newloanRequest.LoanDetails.LoanDates.FundingDate = DateTime.Now.ToPST();
                    newloanRequest.LoanDetails.LoanDates.RescissionBeginDate = DateTime.Now.ToPST();
                    newloanRequest.LoanDetails.LoanDates.RescissionEnds = DateTime.Now.ToPST().AddDays(5);
                    newloanRequest.LoanDetails.LoanDates.SigningDate = DateTime.Now.ToPST();
                    newloanRequest.LoanCharges.CDInterestCalculationSummary.InterestCalculation.From = DateTime.Now.ToPST();
                    newloanRequest.LoanCharges.CDInterestCalculationSummary.InterestCalculation.To = DateTime.Now.ToPST().AddDays(6);
                    //Give adhoc seq num from get 
                    newloanRequest.LoanCharges.GFE3LoanCharges[0].PaymentDetail.SeqNum = gfe3SeqNum;
                    newloanRequest.LoanCharges.GFE3LoanCharges[1].PaymentDetail.SeqNum = gfe3SeqNumAdhoc;
                    newloanRequest.LoanCharges.GFE6LoanCharges[0].PaymentDetail.SeqNum = gfe6SeqNum;
                    newloanRequest.LoanCharges.GFE6LoanCharges[1].PaymentDetail.SeqNum = gfe6SeqNumAdhoc;
                    //QC@ClosingInformation 
                    newloanRequest.QCClosingInformation = new QCClosing
                    {
                        AppraisedValue = 0,
                        GovtProgramID = 0,
                        LoanInterestTypeID = 0,
                        OccupancyTypeID = 0,
                        TransactionTypeID = 0,
                        SourceofFundsID = 0,
                        InvestorID = 0,
                        SpecialInvestorProductID = 0,
                        SecondaryLienInformationID = 0
                    };

                    Reports.TestStep = "Invoke UpdateNewLoan method";
                    newloanRequest.LoanCharges.InterestCalculationSummary.InterestCalculation.From = DateTime.Now.ToPST();
                    newloanRequest.LoanCharges.InterestCalculationSummary.InterestCalculation.To = DateTime.Now.ToPST();
                    var response = EscrowService.UpdateNewLoan(newloanRequest);
                    response.Validate();

                    Reports.TestStep = "Navigate to New Loan screen";
                    FastDriver.NewLoan.Open();
                    var GFE3Data = newloanRequest.LoanCharges.GFE3LoanCharges[0].PaymentDetail;
                    var GFE3DataAdhoc = newloanRequest.LoanCharges.GFE3LoanCharges[1].PaymentDetail;
                    var GFE6Data = newloanRequest.LoanCharges.GFE6LoanCharges[0].PaymentDetail;
                    var GFE6DataAdhoc = newloanRequest.LoanCharges.GFE6LoanCharges[1].PaymentDetail;
                    var impoundData = newloanRequest.LoanCharges.ImpoundCharges.Impounds[0];
                    var interestCalDetails = newloanRequest.LoanCharges.InterestCalculationSummary.InterestCalculation;
                    var newLoanDetails = newloanRequest.LoanDetails;
                    var mortgageYieldData = newloanRequest.MortgageBroker.YieldSpreadPremium;

                    Reports.TestStep = "Validate loan basic amounts";
                    FastDriver.NewLoan.LoanDetailsLoantype.FAClick();
                    Support.AreEqual(newLoanDetails.LoanAmount.ToString().FormatAsMoney(), FastDriver.NewLoan.LoanDetailsLoanAmount.FAGetValue(), "LoanDetailsLoanAmount");
                    Support.AreEqual(newLoanDetails.LiabilityAmount.ToString().FormatAsMoney(), FastDriver.NewLoan.LoanDetailsLoanLiability.FAGetValue(), "LoanDetailsLoanLiability");
                    Support.AreEqual(newLoanDetails.MortgageInsuranceCaseNumber, FastDriver.NewLoan.LoanDetailsMortgageInsCase.FAGetValue(), "LoanDetailsMortgageInsCase");

                    Reports.TestStep = "Validate loan dates";
                    Support.AreEqual(newLoanDetails.LoanDates.FundingDate.Value.ToDateString(), FastDriver.NewLoan.LoanDetailsFundingDate.FAGetValue(), "LoanDetailsFundingDate");
                    Support.AreEqual(newLoanDetails.LoanDates.SigningDate.Value.ToDateString(), FastDriver.NewLoan.LoanDetailsSigningDate.FAGetValue(), "LoanDetailsSigningDate");
                    Support.AreEqual(newLoanDetails.LoanDates.RescissionDays.ToString(), FastDriver.NewLoan.LoanDetailsDays.FAGetValue(), "LoanDetailsDays");
                    Support.AreEqual(newLoanDetails.LoanDates.RescissionEnds.Value.ToDateString(), FastDriver.NewLoan.LoanDetailsEnds.FAGetValue(), "LoanDetailsEnds");
                    Support.AreEqual(newLoanDetails.LoanDates.RescissionBeginDate.Value.ToDateString(), FastDriver.NewLoan.LoanDetailsRescissionPeriodBegins.FAGetValue(), "LoanDetailsRescissionPeriodBegins");

                    Reports.TestStep = "Go to Loan Charges tab";
                    FastDriver.NewLoan.ClickChargesTab();

                    Reports.TestStep = "Validate loan GFE charges";
                    Support.AreEqual(GFE3Data.BuyerCharge.ToString().FormatAsMoney(), FastDriver.NewLoan.LoanChargesGFE_3NewLoanChargesBuyerCharge.FAGetValue(), "LoanChargesGFE_3NewLoanChargesBuyerCharge");
                    Support.AreEqual(GFE3Data.SellerCharge.ToString().FormatAsMoney(), FastDriver.NewLoan.LoanChargesGFE_3NewLoanChargesSellerCharge.FAGetValue(), "LoanChargesGFE_3NewLoanChargesSellerCharge");
                    string val = FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction("Description", GFE3DataAdhoc.Description, "Buyer Charge", TableAction.GetInputValue).Message;
                    Support.AreEqual(GFE3DataAdhoc.BuyerCharge.ToString().FormatAsMoney(), val, "Buyer Charge");
                    val = FastDriver.NewLoan.NewLoanChargesTable.PerformTableAction("Description", GFE3DataAdhoc.Description, "Seller Charge", TableAction.GetInputValue).Message;
                    Support.AreEqual(GFE3DataAdhoc.SellerCharge.ToString().FormatAsMoney(), val, "Seller Charge");
                    
                    Support.AreEqual(GFE6Data.BuyerCharge.ToString().FormatAsMoney(), FastDriver.NewLoan.LoanChargesGFE_6NewLoanCharges_BuyerCharge.FAGetValue(), "LoanChargesGFE_6NewLoanCharges_BuyerCharge");
                    Support.AreEqual(GFE6Data.SellerCharge.ToString().FormatAsMoney(), FastDriver.NewLoan.LoanChargesGFE_6NewLoanCharges_SellerCharge.FAGetValue(), "LoanChargesGFE_6NewLoanCharges_SellerCharge");
                    val = FastDriver.NewLoan.LoanCharges_LenderCreditTable.PerformTableAction("Description", GFE6DataAdhoc.Description, "Buyer Charge", TableAction.GetInputValue).Message;
                    Support.AreEqual(GFE6DataAdhoc.BuyerCharge.ToString().FormatAsMoney(), val, "Buyer Charge");
                    val = FastDriver.NewLoan.LoanCharges_LenderCreditTable.PerformTableAction("Description", GFE6DataAdhoc.Description, "Seller Charge", TableAction.GetInputValue).Message;
                    Support.AreEqual(GFE6DataAdhoc.SellerCharge.ToString().FormatAsMoney(), val, "Seller Charge");

                    Reports.TestStep = "Validate loan charges interest calculation";
                    Support.AreEqual(newloanRequest.LoanCharges.OriginationCharges.GFEAmount.ToString().FormatAsMoney(), FastDriver.NewLoan.LoanChargesOriginationChargeGFEAmount.FAGetValue(), "LoanChargesOriginationChargeGFEAmount");
                    Support.AreEqual(interestCalDetails.PerDiemAmount.ToString().FormatAsMoney(decimalPlaces: 6), FastDriver.NewLoan.LoanChargesInterestCalculationPerDiemAmount.FAGetValue(), "LoanChargesInterestCalculationPerDiemAmount");
                    Support.AreEqual(interestCalDetails.From.Value.ToDateString(), FastDriver.NewLoan.LoanChargesInterestCalculationFromDate.FAGetValue(), "LoanChargesInterestCalculationFromDate");
                    Support.AreEqual(interestCalDetails.To.Value.ToDateString(), FastDriver.NewLoan.LoanChargesInterestCalculationToDate.FAGetValue(), "LoanChargesInterestCalculationToDate");
                    Support.AreEqual(interestCalDetails.ToInclusive.Value, FastDriver.NewLoan.LoanChargesInterestCalculationInclusiveTo.IsSelected(), "LoanChargesInterestCalculationInclusiveTo");
                    Support.AreEqual(interestCalDetails.FromInclusive.Value, FastDriver.NewLoan.LoanChargesInterestCalculationInclusiveFrom.IsSelected(), "LoanChargesInterestCalculationInclusiveFrom");
                    Support.AreEqual(interestCalDetails.BasedOnDays.ToString(), FastDriver.NewLoan.LoanChargesInterestCalculationBasedOn.FAGetSelectedItem(), "LoanChargesInterestCalculationBasedOn");

                    Reports.TestStep = "Validate loan charges impound data";
                    impoundData.PaymentDetails.BuyerCharge = impoundData.Months * impoundData.MonthlyCharge;
                    Support.AreEqual(newloanRequest.LoanCharges.ImpoundCharges.GFEAmount.ToString().FormatAsMoney(), FastDriver.NewLoan.LoanChargesAggregateAccountingAdjustment_GFEAmount.FAGetValue(), "LoanChargesAggregateAccountingAdjustment_GFEAmount");
                    Support.AreEqual(impoundData.PaymentDetails.BuyerCharge.ToString().FormatAsMoney(), FastDriver.NewLoan.LoanCharges_InitialDepositBuyerChargeAmount.FAGetText(), "LoanCharges_InitialDepositBuyerChargeAmount");
                    val = FastDriver.NewLoan.LoanChargesImpoundsTable.PerformTableAction("Description", impoundData.PaymentDetails.Description, "Months", TableAction.GetInputValue).Message;
                    Support.AreEqual(impoundData.Months.ToString(), val, "Months");
                    val = FastDriver.NewLoan.LoanChargesImpoundsTable.PerformTableAction("Description", impoundData.PaymentDetails.Description, "Monthly Charge", TableAction.GetInputValue).Message;
                    Support.AreEqual(impoundData.MonthlyCharge.ToString().FormatAsMoney(), val, "Monthly Charge");
                    val = FastDriver.NewLoan.LoanChargesImpoundsTable.PerformTableAction("Description", impoundData.PaymentDetails.Description, "Buyer Charge", TableAction.GetInputValue).Message;
                    Support.AreEqual(impoundData.PaymentDetails.BuyerCharge.ToString().FormatAsMoney(), val, "Buyer Charge");

                    Reports.TestStep = "Go to Mortgage Broker tab";
                    FastDriver.NewLoan.ClickMortgageBrokerTab();

                    Reports.TestStep = "Validate Mortgage Broker Yield Spread Premium";
                    Support.AreEqual(mortgageYieldData.Description, FastDriver.NewLoan.MortgageYieldSpreadPremiumdescription.FAGetValue(), "MortgageYieldSpreadPremiumdescription");
                    Support.AreEqual(mortgageYieldData.FileCharge.ToString().FormatAsMoney(), FastDriver.NewLoan.MortgageYieldSpreadPremiumAmount.FAGetValue(), "MortgageYieldSpreadPremiumAmount");
                }
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        public void REG0003_RemoveMortgageBrokerThirdPartyPayee()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetDetailedCreateFileDefaultRequest();
                #endregion

                Reports.TestDescription = "Verify RemoveMortgageBrokerThirdPartyPayee() service.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                int fileid = FastDriver.FACreateFileGetFileId(fileRequest);
                var file = FileService.GetOrderDetails(fileid);
                FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

                Reports.TestStep = "Invoke GetNewLoanDetails service";
                var getNewLoanDetailsResponse = FileService.GetNewLoanDetails(fileid, seqNum: 1);
                Support.AreEqual("1", getNewLoanDetailsResponse.Status.ToString(), getNewLoanDetailsResponse.StatusDescription);
                int orgChargeAdhocCount = getNewLoanDetailsResponse.LoanCharges.CDOriginationCharges.Length;
                int loanChargeAdhocCount = getNewLoanDetailsResponse.LoanCharges.CDNewLoanCharges.Length;
                int principalReductionAdhocCount = getNewLoanDetailsResponse.LoanCharges.CDPrincipalReductionOrConstructionHoldBack.Length;

                var newloanRequest = FileRequestFactory.GetNewLoanUpdateRequest(fileid.ToString(), seqNum: 1);
                newloanRequest.EmployeeID = 1;
                newloanRequest.SeqNum = 1;
                newloanRequest.LoanDetails.LoanDates.FundingDate = DateTime.Now.ToPST();
                newloanRequest.LoanDetails.LoanDates.RescissionBeginDate = DateTime.Now.ToPST();
                newloanRequest.LoanDetails.LoanDates.RescissionEnds = DateTime.Now.ToPST().AddDays(5);
                newloanRequest.LoanDetails.LoanDates.SigningDate = DateTime.Now.ToPST();
                newloanRequest.LoanCharges.CDInterestCalculationSummary.InterestCalculation.From = DateTime.Now.ToPST();
                newloanRequest.LoanCharges.CDInterestCalculationSummary.InterestCalculation.To = DateTime.Now.ToPST().AddDays(6);
                //Give adhoc seq num from get 
                newloanRequest.LoanCharges.CDImpoundCharges.Impounds[1].SeqNum = getNewLoanDetailsResponse.LoanCharges.CDImpoundCharges.Impounds.Length;
                newloanRequest.LoanCharges.CDNewLoanCharges[1].SeqNum = loanChargeAdhocCount;
                newloanRequest.LoanCharges.CDPrincipalReductionOrConstructionHoldBack[1].SeqNum = principalReductionAdhocCount;
                newloanRequest.LoanCharges.CDOriginationCharges[1].SeqNum = orgChargeAdhocCount;

                Reports.TestStep = "Invoke UpdateNewLoan method";
                var updateNewLoanResponse = FileService.UpdateNewLoan(newloanRequest);
                Support.AreEqual("1", updateNewLoanResponse.Status.ToString(), updateNewLoanResponse.StatusDescription);

                Reports.TestStep = "Invoke GetNewLoanDetails service.";
                getNewLoanDetailsResponse = FileService.GetNewLoanDetails(fileid, seqNum: 1);
                Support.AreEqual("1", getNewLoanDetailsResponse.Status.ToString(), getNewLoanDetailsResponse.StatusDescription);

                Reports.TestStep = "Invoke NewLoanMBPayChargesAssociation method";
                var newLoanPayChargesAssociationRequest = FileRequestFactory.GetNewLoanPayChargeAssociationRequest(fileid, seqNum: 1,
                    charge: null, fileBusParty: null);

                #region newLoanPayChargesAssociationRequest params
                newLoanPayChargesAssociationRequest.ChargeDetails = new FASTWCFHelpers.FastFileService.NewLoanDisbursementCharge[2];
                newLoanPayChargesAssociationRequest.PayeeInformation = new FASTWCFHelpers.FastFileService.NewLoanDisbursementPayeeInformation[2];

                newLoanPayChargesAssociationRequest.ChargeDetails[0] = new FASTWCFHelpers.FastFileService.NewLoanDisbursementCharge
                {
                    IsSelected = false,
                    ChargeId = getNewLoanDetailsResponse.MortgageBroker.CDPayCharges.DisbursementCharges[1].ChargeID,
                    FileBusinessPartyId = getNewLoanDetailsResponse.MortgageBroker.CDPayCharges.DisbursementCharges[1].FileBusinessPartyID,
                };
                newLoanPayChargesAssociationRequest.ChargeDetails[1] = new FASTWCFHelpers.FastFileService.NewLoanDisbursementCharge
                {
                    IsSelected = true,
                    ChargeId = getNewLoanDetailsResponse.MortgageBroker.CDPayCharges.DisbursementCharges[2].ChargeID,
                    AddressBookEntryId = AdminService.GetGABAddressBookEntryId("boa")
                };
                newLoanPayChargesAssociationRequest.PayeeInformation[0] = new FASTWCFHelpers.FastFileService.NewLoanDisbursementPayeeInformation
                {
                    eOperationType = FASTWCFHelpers.FastFileService.OperationType.Update,
                    FileBusinessParty = new FASTWCFHelpers.FastFileService.FileBusinessParty()
                    {
                        FileBusinessPartyID = getNewLoanDetailsResponse.MortgageBroker.CDPayCharges.DisbursementCharges[1].FileBusinessPartyID,
                    }
                };
                newLoanPayChargesAssociationRequest.PayeeInformation[1] = new FASTWCFHelpers.FastFileService.NewLoanDisbursementPayeeInformation
                {
                    eOperationType = FASTWCFHelpers.FastFileService.OperationType.Create,
                    FileBusinessParty = new FASTWCFHelpers.FastFileService.FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("boa")
                    }
                };
                #endregion

                Reports.TestStep = "Invoke NewLoanMBPayChargesAssociation method";
                var newLoanMBPayChargesAssociationResponse = FileService.NewLoanMBPayChargesAssociation(newLoanPayChargesAssociationRequest);
                Support.AreEqual("1", newLoanMBPayChargesAssociationResponse.Status.ToString(), newLoanMBPayChargesAssociationResponse.StatusDescription);

                Reports.TestStep = "Invoke GetNewLoanDetails service.";
                getNewLoanDetailsResponse = FileService.GetNewLoanDetails(fileid, seqNum: 1);
                Support.AreEqual("1", getNewLoanDetailsResponse.Status.ToString(), getNewLoanDetailsResponse.StatusDescription);
                string payeeName1 = getNewLoanDetailsResponse.MortgageBroker.CDPayCharges.DisbursementCharges[1].PayeeName;
                string payeeName2 = getNewLoanDetailsResponse.MortgageBroker.CDPayCharges.DisbursementCharges[2].PayeeName;

                Reports.TestStep = "Invoke NewLoanPayChargesAssociation method";
                newLoanPayChargesAssociationRequest = FileRequestFactory.GetNewLoanPayChargeAssociationRequest(fileid, seqNum: 1,
                    charge: null, fileBusParty: null);

                #region newLoanPayChargesAssociationRequest params
                newLoanPayChargesAssociationRequest.ChargeDetails = new FASTWCFHelpers.FastFileService.NewLoanDisbursementCharge[1];
                newLoanPayChargesAssociationRequest.PayeeInformation = new FASTWCFHelpers.FastFileService.NewLoanDisbursementPayeeInformation[1];

                newLoanPayChargesAssociationRequest.ChargeDetails[0] = new FASTWCFHelpers.FastFileService.NewLoanDisbursementCharge
                {
                    IsSelected = false,
                    ChargeId = getNewLoanDetailsResponse.MortgageBroker.CDPayCharges.DisbursementCharges[2].ChargeID,
                    FileBusinessPartyId = getNewLoanDetailsResponse.MortgageBroker.CDPayCharges.PayeeInformation[1].FileBusinessPartyID,
                };
                newLoanPayChargesAssociationRequest.PayeeInformation[0] = new FASTWCFHelpers.FastFileService.NewLoanDisbursementPayeeInformation
                {
                    eOperationType = FASTWCFHelpers.FastFileService.OperationType.Update,
                    FileBusinessParty = new FASTWCFHelpers.FastFileService.FileBusinessParty()
                    {
                        FileBusinessPartyID = getNewLoanDetailsResponse.MortgageBroker.CDPayCharges.PayeeInformation[1].FileBusinessPartyID
                    }
                };
                #endregion

                Reports.TestStep = "Invoke NewLoanMBPayChargesAssociation method";
                newLoanMBPayChargesAssociationResponse = FileService.NewLoanMBPayChargesAssociation(newLoanPayChargesAssociationRequest);
                Support.AreEqual("1", newLoanMBPayChargesAssociationResponse.Status.ToString(), newLoanMBPayChargesAssociationResponse.StatusDescription);

                Reports.TestStep = "Invoke RemoveMortgageBrokerThirdPartyPayee service.";
                var request = EscrowRequestFactory.GetRemoveThirdPartyPayeeRequest(fileid, 1, getNewLoanDetailsResponse.MortgageBroker.CDPayCharges.DisbursementCharges[2].FileBusinessPartyID.Value);
                var response = EscrowChargeProcessesHelpers.RemoveMortgageBrokerThirdPartyPayee(request);

                Reports.TestStep = "Navigate to New Loan screen in FAST UI.";
                FastDriver.NewLoan.Open();

                Reports.TestStep = "Go to New Loan Mortgage Broker tab.";
                FastDriver.NewLoan.ClickMortgageBrokerTab();

                Reports.TestStep = "Validate New Loan Mortgage Broker is removed.";
                FastDriver.NewLoan.MortgagePayCharges.FAClick();
                FastDriver.NewLoanDisbursements.WaitForScreenToLoad();
                Support.AreEqual(false, FastDriver.NewLoanDisbursements.PayeeName2.IsDisplayed(), "PayeeName2 IsDisplayed");
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        public void REG0004_RemoveLenderThirdPartyPayee()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetDetailedCreateFileDefaultRequest();
                #endregion

                Reports.TestDescription = "Verify RemoveLenderThirdPartyPayee() service.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                int fileid = FastDriver.FACreateFileGetFileId(fileRequest);
                var file = FileService.GetOrderDetails(fileid);
                FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

                Reports.TestStep = "Invoke GetNewLoanDetails service";
                var getNewLoanDetailsResponse = FileService.GetNewLoanDetails(fileid, seqNum: 1);
                Support.AreEqual("1", getNewLoanDetailsResponse.Status.ToString(), getNewLoanDetailsResponse.StatusDescription);
                int orgChargeAdhocCount = getNewLoanDetailsResponse.LoanCharges.CDOriginationCharges.Length;
                int loanChargeAdhocCount = getNewLoanDetailsResponse.LoanCharges.CDNewLoanCharges.Length;
                int principalReductionAdhocCount = getNewLoanDetailsResponse.LoanCharges.CDPrincipalReductionOrConstructionHoldBack.Length;

                var newloanRequest = FileRequestFactory.GetNewLoanUpdateRequest(fileid.ToString(), seqNum: 1);
                newloanRequest.EmployeeID = 1;
                newloanRequest.SeqNum = 1;
                newloanRequest.LoanDetails.LoanDates.FundingDate = DateTime.Now.ToPST();
                newloanRequest.LoanDetails.LoanDates.RescissionBeginDate = DateTime.Now.ToPST();
                newloanRequest.LoanDetails.LoanDates.RescissionEnds = DateTime.Now.ToPST().AddDays(5);
                newloanRequest.LoanDetails.LoanDates.SigningDate = DateTime.Now.ToPST();
                newloanRequest.LoanCharges.CDInterestCalculationSummary.InterestCalculation.From = DateTime.Now.ToPST();
                newloanRequest.LoanCharges.CDInterestCalculationSummary.InterestCalculation.To = DateTime.Now.ToPST().AddDays(6);
                //Give adhoc seq num from get 
                newloanRequest.LoanCharges.CDImpoundCharges.Impounds[1].SeqNum = getNewLoanDetailsResponse.LoanCharges.CDImpoundCharges.Impounds.Length;
                newloanRequest.LoanCharges.CDNewLoanCharges[1].SeqNum = loanChargeAdhocCount;
                newloanRequest.LoanCharges.CDPrincipalReductionOrConstructionHoldBack[1].SeqNum = principalReductionAdhocCount;
                newloanRequest.LoanCharges.CDOriginationCharges[1].SeqNum = orgChargeAdhocCount;

                Reports.TestStep = "Invoke UpdateNewLoan method";
                var updateNewLoanResponse = FileService.UpdateNewLoan(newloanRequest);
                Support.AreEqual("1", updateNewLoanResponse.Status.ToString(), updateNewLoanResponse.StatusDescription);

                Reports.TestStep = "Invoke GetNewLoanDetails service.";
                getNewLoanDetailsResponse = FileService.GetNewLoanDetails(fileid, seqNum: 1);
                Support.AreEqual("1", getNewLoanDetailsResponse.Status.ToString(), getNewLoanDetailsResponse.StatusDescription);

                Reports.TestStep = "Invoke NewLoanPayChargesAssociation method";
                var newLoanPayChargesAssociationRequest = FileRequestFactory.GetNewLoanPayChargeAssociationRequest(fileid, seqNum: 1,
                    charge: null, fileBusParty: null);

                #region newLoanPayChargesAssociationRequest params
                newLoanPayChargesAssociationRequest.ChargeDetails = new FASTWCFHelpers.FastFileService.NewLoanDisbursementCharge[2];
                newLoanPayChargesAssociationRequest.PayeeInformation = new FASTWCFHelpers.FastFileService.NewLoanDisbursementPayeeInformation[2];

                newLoanPayChargesAssociationRequest.ChargeDetails[0] = new FASTWCFHelpers.FastFileService.NewLoanDisbursementCharge
                {
                    IsSelected = true,
                    ChargeId = getNewLoanDetailsResponse.LoanCharges.CDPayCharges.DisbursementCharges[1].ChargeID,
                    FileBusinessPartyId = getNewLoanDetailsResponse.LoanCharges.CDPayCharges.DisbursementCharges[1].FileBusinessPartyID,
                };
                newLoanPayChargesAssociationRequest.ChargeDetails[1] = new FASTWCFHelpers.FastFileService.NewLoanDisbursementCharge
                {
                    IsSelected = true,
                    ChargeId = getNewLoanDetailsResponse.LoanCharges.CDPayCharges.DisbursementCharges[2].ChargeID,
                    AddressBookEntryId = AdminService.GetGABAddressBookEntryId("boa")
                };
                newLoanPayChargesAssociationRequest.PayeeInformation[0] = new FASTWCFHelpers.FastFileService.NewLoanDisbursementPayeeInformation
                {
                    eOperationType = FASTWCFHelpers.FastFileService.OperationType.Update,
                    FileBusinessParty = new FASTWCFHelpers.FastFileService.FileBusinessParty()
                    {
                        FileBusinessPartyID = getNewLoanDetailsResponse.LoanCharges.CDPayCharges.DisbursementCharges[1].FileBusinessPartyID,
                    }
                };
                newLoanPayChargesAssociationRequest.PayeeInformation[1] = new FASTWCFHelpers.FastFileService.NewLoanDisbursementPayeeInformation
                {
                    eOperationType = FASTWCFHelpers.FastFileService.OperationType.Create,
                    FileBusinessParty = new FASTWCFHelpers.FastFileService.FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("boa")
                    }
                };
                #endregion

                Reports.TestStep = "Invoke NewLoanPayChargesAssociation method";
                var newLoanPayChargesAssociationResponse = FileService.NewLoanPayChargesAssociation(newLoanPayChargesAssociationRequest);
                Support.AreEqual("1", newLoanPayChargesAssociationResponse.Status.ToString(), newLoanPayChargesAssociationResponse.StatusDescription);

                Reports.TestStep = "Invoke GetNewLoanDetails service.";
                getNewLoanDetailsResponse = FileService.GetNewLoanDetails(fileid, seqNum: 1);
                Support.AreEqual("1", getNewLoanDetailsResponse.Status.ToString(), getNewLoanDetailsResponse.StatusDescription);

                Reports.TestStep = "Invoke NewLoanPayChargesAssociation method";
                newLoanPayChargesAssociationRequest = FileRequestFactory.GetNewLoanPayChargeAssociationRequest(fileid, seqNum: 1,
                    charge: null, fileBusParty: null);

                #region newLoanPayChargesAssociationRequest params
                newLoanPayChargesAssociationRequest.ChargeDetails = new FASTWCFHelpers.FastFileService.NewLoanDisbursementCharge[1];
                newLoanPayChargesAssociationRequest.PayeeInformation = new FASTWCFHelpers.FastFileService.NewLoanDisbursementPayeeInformation[1];

                newLoanPayChargesAssociationRequest.ChargeDetails[0] = new FASTWCFHelpers.FastFileService.NewLoanDisbursementCharge
                {
                    IsSelected = false,
                    ChargeId = getNewLoanDetailsResponse.LoanCharges.CDPayCharges.DisbursementCharges[2].ChargeID,
                    FileBusinessPartyId = getNewLoanDetailsResponse.LoanCharges.CDPayCharges.DisbursementCharges[1].FileBusinessPartyID,
                };
                newLoanPayChargesAssociationRequest.PayeeInformation[0] = new FASTWCFHelpers.FastFileService.NewLoanDisbursementPayeeInformation
                {
                    eOperationType = FASTWCFHelpers.FastFileService.OperationType.Update,
                    FileBusinessParty = new FASTWCFHelpers.FastFileService.FileBusinessParty()
                    {
                        FileBusinessPartyID = getNewLoanDetailsResponse.LoanCharges.CDPayCharges.DisbursementCharges[1].FileBusinessPartyID
                    }
                };
                #endregion

                Reports.TestStep = "Invoke NewLoanPayChargesAssociation method";
                newLoanPayChargesAssociationResponse = FileService.NewLoanPayChargesAssociation(newLoanPayChargesAssociationRequest);
                Support.AreEqual("1", newLoanPayChargesAssociationResponse.Status.ToString(), newLoanPayChargesAssociationResponse.StatusDescription);

                Reports.TestStep = "Invoke RemoveLenderThirdPartyPayee service.";
                var removeLenderThirdPartyPayeeRequest = EscrowRequestFactory.GetRemoveThirdPartyPayeeRequest(fileid, 1, getNewLoanDetailsResponse.LoanCharges.CDPayCharges.PayeeInformation[1].FileBusinessPartyID.Value);
                var removeLenderThirdPartyPayeeResponse = EscrowChargeProcessesHelpers.RemoveLenderThirdPartyPayee(removeLenderThirdPartyPayeeRequest);
                Support.AreEqual("1", removeLenderThirdPartyPayeeResponse.Status.ToString(), removeLenderThirdPartyPayeeResponse.StatusDescription);

                Reports.TestStep = "Navigate to New Loan screen in FAST UI.";
                FastDriver.NewLoan.Open();

                Reports.TestStep = "Go to New Loan charges tab.";
                FastDriver.NewLoan.ClickChargesTab();

                Reports.TestStep = "Verify 3rd party payee got removed.";
                FastDriver.NewLoan.LoanChargesPayCharges.FAClick();
                FastDriver.NewLoanDisbursements.WaitForScreenToLoad();
                Support.AreEqual(false, FastDriver.NewLoanDisbursements.PayeeName2.IsDisplayed(), "PayeeName2 IsDisplayed");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }

        [TestMethod]
        public void REG0006_NewLoanPayChargesAssociation()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetDetailedCreateFileDefaultRequest();
                #endregion

                Reports.TestDescription = "Verify NewLoanPayChargesAssociation() service.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                int fileid = FastDriver.FACreateFileGetFileId(fileRequest);
                var file = FileService.GetOrderDetails(fileid);
                FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

                Reports.TestStep = "Invoke GetNewLoanDetails service";
                var getNewLoanDetailsResponse = EscrowService.GetNewLoanDetails(EscrowRequestFactory.GetNewLoanDetailsRequest(file.FileID.Value, 1));
                Support.AreEqual("1", getNewLoanDetailsResponse.Status.ToString(), getNewLoanDetailsResponse.StatusDescription);
                int orgChargeAdhocCount = getNewLoanDetailsResponse.LoanCharges.CDOriginationCharges.Length;
                int loanChargeAdhocCount = getNewLoanDetailsResponse.LoanCharges.CDNewLoanCharges.Length;
                int principalReductionAdhocCount = getNewLoanDetailsResponse.LoanCharges.CDPrincipalReductionOrConstructionHoldBack.Length;

                var newloanRequest = EscrowRequestFactory.GetNewLoanUpdateRequest(fileid.ToString(), seqNum: 1);
                newloanRequest.EmployeeID = 1;
                newloanRequest.SeqNum = 1;
                newloanRequest.LoanDetails.LoanDates.FundingDate = DateTime.Now.ToPST();
                newloanRequest.LoanDetails.LoanDates.RescissionBeginDate = DateTime.Now.ToPST();
                newloanRequest.LoanDetails.LoanDates.RescissionEnds = DateTime.Now.ToPST().AddDays(5);
                newloanRequest.LoanDetails.LoanDates.SigningDate = DateTime.Now.ToPST();
                newloanRequest.LoanCharges.CDInterestCalculationSummary.InterestCalculation.From = DateTime.Now.ToPST();
                newloanRequest.LoanCharges.CDInterestCalculationSummary.InterestCalculation.To = DateTime.Now.ToPST().AddDays(6);
                //Give adhoc seq num from get 
                newloanRequest.LoanCharges.CDImpoundCharges.Impounds[1].SeqNum = getNewLoanDetailsResponse.LoanCharges.CDImpoundCharges.Impounds.Length;
                newloanRequest.LoanCharges.CDNewLoanCharges[1].SeqNum = loanChargeAdhocCount;
                newloanRequest.LoanCharges.CDPrincipalReductionOrConstructionHoldBack[1].SeqNum = principalReductionAdhocCount;
                newloanRequest.LoanCharges.CDOriginationCharges[1].SeqNum = orgChargeAdhocCount;

                Reports.TestStep = "Invoke UpdateNewLoan method";
                var updateNewLoanResponse = EscrowService.UpdateNewLoan(newloanRequest);
                Support.AreEqual("1", updateNewLoanResponse.Status.ToString(), updateNewLoanResponse.StatusDescription);

                Reports.TestStep = "Invoke GetNewLoanDetails service.";
                getNewLoanDetailsResponse = EscrowService.GetNewLoanDetails(EscrowRequestFactory.GetNewLoanDetailsRequest(file.FileID.Value, 1));
                Support.AreEqual("1", getNewLoanDetailsResponse.Status.ToString(), getNewLoanDetailsResponse.StatusDescription);

                Reports.TestStep = "Invoke NewLoanPayChargesAssociation method";
                var newLoanPayChargesAssociationRequest = EscrowRequestFactory.GetNewLoanPayChargeAssociationRequest(fileid, seqNum: 1,
                    charge: null, fileBusParty: null);

                #region newLoanPayChargesAssociationRequest params
                newLoanPayChargesAssociationRequest.ChargeDetails = new NewLoanDisbursementCharge[2];
                newLoanPayChargesAssociationRequest.PayeeInformation = new NewLoanDisbursementPayeeInformation[2];

                newLoanPayChargesAssociationRequest.ChargeDetails[0] = new NewLoanDisbursementCharge
                {
                    IsSelected = true,
                    ChargeId = getNewLoanDetailsResponse.LoanCharges.CDPayCharges.DisbursementCharges[1].ChargeID,
                    FileBusinessPartyId = getNewLoanDetailsResponse.LoanCharges.CDPayCharges.DisbursementCharges[1].FileBusinessPartyID,
                };
                newLoanPayChargesAssociationRequest.ChargeDetails[1] = new NewLoanDisbursementCharge
                {
                    IsSelected = true,
                    ChargeId = getNewLoanDetailsResponse.LoanCharges.CDPayCharges.DisbursementCharges[2].ChargeID,
                    AddressBookEntryId = AdminService.GetGABAddressBookEntryId("boa")
                };
                newLoanPayChargesAssociationRequest.PayeeInformation[0] = new NewLoanDisbursementPayeeInformation
                {
                    eOperationType = OperationType.Update,
                    FileBusinessParty = new FileBusinessParty()
                    {
                        FileBusinessPartyID = getNewLoanDetailsResponse.LoanCharges.CDPayCharges.DisbursementCharges[1].FileBusinessPartyID,
                    }
                };
                newLoanPayChargesAssociationRequest.PayeeInformation[1] = new NewLoanDisbursementPayeeInformation
                {
                    eOperationType = OperationType.Create,
                    FileBusinessParty = new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("boa")
                    }
                };
                #endregion

                Reports.TestStep = "Invoke NewLoanPayChargesAssociation method";
                var newLoanPayChargesAssociationResponse = EscrowService.NewLoanPayChargesAssociation(newLoanPayChargesAssociationRequest);
                Support.AreEqual("1", newLoanPayChargesAssociationResponse.Status.ToString(), newLoanPayChargesAssociationResponse.StatusDescription);

                Reports.TestStep = "Invoke GetNewLoanDetails service.";
                getNewLoanDetailsResponse = EscrowService.GetNewLoanDetails(EscrowRequestFactory.GetNewLoanDetailsRequest(file.FileID.Value, 1));
                Support.AreEqual("1", getNewLoanDetailsResponse.Status.ToString(), getNewLoanDetailsResponse.StatusDescription);
                string descriptionCharge = getNewLoanDetailsResponse.LoanCharges.CDPayCharges.DisbursementCharges[1].Description;
                string descriptionCharge2 = getNewLoanDetailsResponse.LoanCharges.CDPayCharges.DisbursementCharges[2].Description;
                string payeeName1 = getNewLoanDetailsResponse.LoanCharges.CDPayCharges.DisbursementCharges[1].PayeeName;
                string payeeName2 = getNewLoanDetailsResponse.LoanCharges.CDPayCharges.DisbursementCharges[2].PayeeName;

                Reports.TestStep = "Navigate to New Loan screen in FAST UI.";
                FastDriver.NewLoan.Open();

                Reports.TestStep = "Go to New Loan charges tab.";
                FastDriver.NewLoan.ClickChargesTab();

                Reports.TestStep = "Validate New Loan New Loan charges fields.";
                FastDriver.NewLoan.LoanChargesPayCharges.FAClick();
                FastDriver.NewLoanDisbursements.WaitForScreenToLoad();
                Support.AreEqual(payeeName1, FastDriver.NewLoanDisbursements.PayeeName1.FAGetText().Clean(), "PayeeName1");
                FastDriver.NewLoanDisbursements.PayeeName1.FAClick();
                Playback.Wait(500);
                Support.AreEqual(true, FastDriver.NewLoanDisbursements.Charges2.IsEnabled(), "Charges2 IsEnabled");
                Support.AreEqual(true, FastDriver.NewLoanDisbursements.Charges2.IsSelected(), "Charges2 IsSelected");
                Support.AreEqual(payeeName2, FastDriver.NewLoanDisbursements.PayeeName2.FAGetText().Clean(), "PayeeName2");
                FastDriver.NewLoanDisbursements.PayeeName2.FAClick();
                Playback.Wait(500);
                var charge2 = FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction("Payee Name", payeeName2, "Sel", TableAction.GetElementFromTableCell, "input").Element;
                Support.AreEqual(true, charge2.IsEnabled(), "Charges2 IsEnabled");
                Support.AreEqual(true, charge2.IsSelected(), "Charges2 IsSelected");

                Reports.TestStep = "Validate New Loan Details fields after removing loan.";
                getNewLoanDetailsResponse = EscrowService.GetNewLoanDetails(EscrowRequestFactory.GetNewLoanDetailsRequest(file.FileID.Value, 1));
                Support.AreEqual("1", getNewLoanDetailsResponse.Status.ToString(), getNewLoanDetailsResponse.StatusDescription);

                Reports.TestStep = "Invoke NewLoanPayChargesAssociation method";
                newLoanPayChargesAssociationRequest = EscrowRequestFactory.GetNewLoanPayChargeAssociationRequest(fileid, seqNum: 1,
                    charge: null, fileBusParty: null);

                #region newLoanPayChargesAssociationRequest params
                newLoanPayChargesAssociationRequest.ChargeDetails = new NewLoanDisbursementCharge[1];
                newLoanPayChargesAssociationRequest.PayeeInformation = new NewLoanDisbursementPayeeInformation[1];

                newLoanPayChargesAssociationRequest.ChargeDetails[0] = new NewLoanDisbursementCharge
                {
                    IsSelected = false,
                    ChargeId = getNewLoanDetailsResponse.LoanCharges.CDPayCharges.DisbursementCharges[2].ChargeID,
                    FileBusinessPartyId = getNewLoanDetailsResponse.LoanCharges.CDPayCharges.DisbursementCharges[1].FileBusinessPartyID,
                };
                newLoanPayChargesAssociationRequest.PayeeInformation[0] = new NewLoanDisbursementPayeeInformation
                {
                    eOperationType = OperationType.Update,
                    FileBusinessParty = new FileBusinessParty()
                    {
                        FileBusinessPartyID = getNewLoanDetailsResponse.LoanCharges.CDPayCharges.DisbursementCharges[1].FileBusinessPartyID
                    }
                };
                #endregion

                Reports.TestStep = "Invoke NewLoanPayChargesAssociation method";
                newLoanPayChargesAssociationResponse = EscrowService.NewLoanPayChargesAssociation(newLoanPayChargesAssociationRequest);
                Support.AreEqual("1", newLoanPayChargesAssociationResponse.Status.ToString(), newLoanPayChargesAssociationResponse.StatusDescription);

                Reports.TestStep = "Navigate to New Loan screen in FAST UI.";
                FastDriver.NewLoan.Open();

                Reports.TestStep = "Go to New Loan charges tab.";
                FastDriver.NewLoan.ClickChargesTab();

                Reports.TestStep = "Validate New Loan New Loan charges fields.";
                FastDriver.NewLoan.LoanChargesPayCharges.FAClick();
                FastDriver.NewLoanDisbursements.WaitForScreenToLoad();
                Support.AreEqual(payeeName2, FastDriver.NewLoanDisbursements.PayeeName2.FAGetText().Clean(), "PayeeName2");
                FastDriver.NewLoanDisbursements.PayeeName2.FAClick();
                Playback.Wait(500);
                charge2 = FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction("Payee Name", payeeName2, "Sel", TableAction.GetElementFromTableCell, "input").Element;
                Support.AreEqual(true, charge2.IsEnabled(), "Charges2 IsEnabled");
                Support.AreEqual(false, charge2.IsSelected(), "Charges2 IsSelected");
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        public void REG0008_NewLoanMBPayChargesAssociation()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetDetailedCreateFileDefaultRequest();
                #endregion

                Reports.TestDescription = "Verify NewLoanMBPayChargesAssociation() service.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                int fileid = FastDriver.FACreateFileGetFileId(fileRequest);
                var file = FileService.GetOrderDetails(fileid);
                FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

                Reports.TestStep = "Invoke GetNewLoanDetails service";
                var getNewLoanDetailsResponse = EscrowService.GetNewLoanDetails(EscrowRequestFactory.GetNewLoanDetailsRequest(file.FileID.Value, 1));
                Support.AreEqual("1", getNewLoanDetailsResponse.Status.ToString(), getNewLoanDetailsResponse.StatusDescription);
                int orgChargeAdhocCount = getNewLoanDetailsResponse.LoanCharges.CDOriginationCharges.Length;
                int loanChargeAdhocCount = getNewLoanDetailsResponse.LoanCharges.CDNewLoanCharges.Length;
                int principalReductionAdhocCount = getNewLoanDetailsResponse.LoanCharges.CDPrincipalReductionOrConstructionHoldBack.Length;

                var newloanRequest = EscrowRequestFactory.GetNewLoanUpdateRequest(fileid.ToString(), seqNum: 1);
                newloanRequest.EmployeeID = 1;
                newloanRequest.SeqNum = 1;
                newloanRequest.LoanDetails.LoanDates.FundingDate = DateTime.Now.ToPST();
                newloanRequest.LoanDetails.LoanDates.RescissionBeginDate = DateTime.Now.ToPST();
                newloanRequest.LoanDetails.LoanDates.RescissionEnds = DateTime.Now.ToPST().AddDays(5);
                newloanRequest.LoanDetails.LoanDates.SigningDate = DateTime.Now.ToPST();
                newloanRequest.LoanCharges.CDInterestCalculationSummary.InterestCalculation.From = DateTime.Now.ToPST();
                newloanRequest.LoanCharges.CDInterestCalculationSummary.InterestCalculation.To = DateTime.Now.ToPST().AddDays(6);
                //Give adhoc seq num from get 
                newloanRequest.LoanCharges.CDImpoundCharges.Impounds[1].SeqNum = getNewLoanDetailsResponse.LoanCharges.CDImpoundCharges.Impounds.Length;
                newloanRequest.LoanCharges.CDNewLoanCharges[1].SeqNum = loanChargeAdhocCount;
                newloanRequest.LoanCharges.CDPrincipalReductionOrConstructionHoldBack[1].SeqNum = principalReductionAdhocCount;
                newloanRequest.LoanCharges.CDOriginationCharges[1].SeqNum = orgChargeAdhocCount;

                Reports.TestStep = "Invoke UpdateNewLoan method";
                var updateNewLoanResponse = EscrowService.UpdateNewLoan(newloanRequest);
                Support.AreEqual("1", updateNewLoanResponse.Status.ToString(), updateNewLoanResponse.StatusDescription);

                Reports.TestStep = "Invoke GetNewLoanDetails service.";
                getNewLoanDetailsResponse = EscrowService.GetNewLoanDetails(EscrowRequestFactory.GetNewLoanDetailsRequest(file.FileID.Value, 1));
                Support.AreEqual("1", getNewLoanDetailsResponse.Status.ToString(), getNewLoanDetailsResponse.StatusDescription);

                Reports.TestStep = "Invoke NewLoanMBPayChargesAssociation method";
                var newLoanPayChargesAssociationRequest = EscrowRequestFactory.GetNewLoanPayChargeAssociationRequest(fileid, seqNum: 1,
                    charge: null, fileBusParty: null);

                #region newLoanPayChargesAssociationRequest params
                newLoanPayChargesAssociationRequest.ChargeDetails = new NewLoanDisbursementCharge[2];
                newLoanPayChargesAssociationRequest.PayeeInformation = new NewLoanDisbursementPayeeInformation[2];

                newLoanPayChargesAssociationRequest.ChargeDetails[0] = new NewLoanDisbursementCharge
                {
                    IsSelected = false,
                    ChargeId = getNewLoanDetailsResponse.MortgageBroker.CDPayCharges.DisbursementCharges[1].ChargeID,
                    FileBusinessPartyId = getNewLoanDetailsResponse.MortgageBroker.CDPayCharges.DisbursementCharges[1].FileBusinessPartyID,
                };
                newLoanPayChargesAssociationRequest.ChargeDetails[1] = new NewLoanDisbursementCharge
                {
                    IsSelected = true,
                    ChargeId = getNewLoanDetailsResponse.MortgageBroker.CDPayCharges.DisbursementCharges[2].ChargeID,
                    AddressBookEntryId = AdminService.GetGABAddressBookEntryId("boa")
                };
                newLoanPayChargesAssociationRequest.PayeeInformation[0] = new NewLoanDisbursementPayeeInformation
                {
                    eOperationType = OperationType.Update,
                    FileBusinessParty = new FileBusinessParty()
                    {
                        FileBusinessPartyID = getNewLoanDetailsResponse.MortgageBroker.CDPayCharges.DisbursementCharges[1].FileBusinessPartyID,
                    }
                };
                newLoanPayChargesAssociationRequest.PayeeInformation[1] = new NewLoanDisbursementPayeeInformation
                {
                    eOperationType = OperationType.Create,
                    FileBusinessParty = new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("boa")
                    }
                };
                #endregion

                Reports.TestStep = "Invoke NewLoanMBPayChargesAssociation method";
                var newLoanMBPayChargesAssociationResponse = EscrowService.NewLoanMBPayChargesAssociation(newLoanPayChargesAssociationRequest);
                Support.AreEqual("1", newLoanMBPayChargesAssociationResponse.Status.ToString(), newLoanMBPayChargesAssociationResponse.StatusDescription);

                Reports.TestStep = "Navigate to New Loan screen in FAST UI.";
                FastDriver.NewLoan.Open();

                Reports.TestStep = "Go to New Loan Mortgage Broker tab.";
                FastDriver.NewLoan.ClickMortgageBrokerTab();

                Reports.TestStep = "Invoke GetNewLoanDetails service.";
                getNewLoanDetailsResponse = EscrowService.GetNewLoanDetails(EscrowRequestFactory.GetNewLoanDetailsRequest(file.FileID.Value, 1));
                Support.AreEqual("1", getNewLoanDetailsResponse.Status.ToString(), getNewLoanDetailsResponse.StatusDescription);
                string payeeName1 = getNewLoanDetailsResponse.MortgageBroker.CDPayCharges.DisbursementCharges[1].PayeeName;
                string payeeName2 = getNewLoanDetailsResponse.MortgageBroker.CDPayCharges.DisbursementCharges[2].PayeeName;

                Reports.TestStep = "Validate New Loan Mortgage Broker fields.";
                FastDriver.NewLoan.MortgagePayCharges.FAClick();
                FastDriver.NewLoanDisbursements.WaitForScreenToLoad();
                Support.AreEqual(payeeName1, FastDriver.NewLoanDisbursements.PayeeName1.FAGetText().Clean(), "PayeeName1");
                FastDriver.NewLoanDisbursements.PayeeName1.FAClick();
                Playback.Wait(500);
                Support.AreEqual(true, FastDriver.NewLoanDisbursements.Charges2.IsEnabled(), "Charges2 IsEnabled");
                Support.AreEqual(false, FastDriver.NewLoanDisbursements.Charges2.IsSelected(), "Charges2 IsSelected");
                Support.AreEqual(payeeName2, FastDriver.NewLoanDisbursements.PayeeName2.FAGetText().Clean(), "PayeeName2");
                FastDriver.NewLoanDisbursements.PayeeName2.FAClick();
                Playback.Wait(500);
                string charge3Name = FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction("Payee Name", payeeName2, "Description", TableAction.GetText).Message.Clean();
                var charge3 = FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction("Description", charge3Name, "Sel", TableAction.GetElementFromTableCell, "input").Element;
                Support.AreEqual(true, charge3.IsEnabled(), "Charges3 IsEnabled");
                Support.AreEqual(true, charge3.IsSelected(), "Charges3 IsSelected");

                Reports.TestStep = "Invoke NewLoanPayChargesAssociation method";
                newLoanPayChargesAssociationRequest = EscrowRequestFactory.GetNewLoanPayChargeAssociationRequest(fileid, seqNum: 1,
                    charge: null, fileBusParty: null);

                #region newLoanPayChargesAssociationRequest params
                newLoanPayChargesAssociationRequest.ChargeDetails = new NewLoanDisbursementCharge[1];
                newLoanPayChargesAssociationRequest.PayeeInformation = new NewLoanDisbursementPayeeInformation[1];

                newLoanPayChargesAssociationRequest.ChargeDetails[0] = new NewLoanDisbursementCharge
                {
                    IsSelected = false,
                    ChargeId = getNewLoanDetailsResponse.MortgageBroker.CDPayCharges.DisbursementCharges[2].ChargeID,
                    FileBusinessPartyId = getNewLoanDetailsResponse.MortgageBroker.CDPayCharges.PayeeInformation[1].FileBusinessPartyID,
                };
                newLoanPayChargesAssociationRequest.PayeeInformation[0] = new NewLoanDisbursementPayeeInformation
                {
                    eOperationType = OperationType.Update,
                    FileBusinessParty = new FileBusinessParty()
                    {
                        FileBusinessPartyID = getNewLoanDetailsResponse.MortgageBroker.CDPayCharges.PayeeInformation[1].FileBusinessPartyID
                    }
                };
                #endregion

                Reports.TestStep = "Invoke NewLoanMBPayChargesAssociation method";
                newLoanMBPayChargesAssociationResponse = EscrowService.NewLoanMBPayChargesAssociation(newLoanPayChargesAssociationRequest);
                Support.AreEqual("1", newLoanMBPayChargesAssociationResponse.Status.ToString(), newLoanMBPayChargesAssociationResponse.StatusDescription);

                Reports.TestStep = "Navigate to New Loan screen in FAST UI.";
                FastDriver.NewLoan.Open();

                Reports.TestStep = "Go to New Loan Mortgage Broker tab.";
                FastDriver.NewLoan.ClickMortgageBrokerTab();

                Reports.TestStep = "Validate New Loan Mortgage Broker fields.";
                FastDriver.NewLoan.MortgagePayCharges.FAClick();
                FastDriver.NewLoanDisbursements.WaitForScreenToLoad();
                Support.AreEqual(payeeName2, FastDriver.NewLoanDisbursements.PayeeName2.FAGetText().Clean(), "PayeeName2");
                FastDriver.NewLoanDisbursements.PayeeName2.FAClick();
                Playback.Wait(500);
                charge3 = FastDriver.NewLoanDisbursements.DisbursementChargesTable.PerformTableAction("Description", charge3Name, "Sel", TableAction.GetElementFromTableCell, "input").Element;
                Support.AreEqual(true, charge3.IsEnabled(), "Charges3 IsEnabled");
                Support.AreEqual(false, charge3.IsSelected(), "Charges3 IsSelected");
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

    }
}