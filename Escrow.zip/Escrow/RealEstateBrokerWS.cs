﻿using FASTSelenium.Common;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using FASTWCFHelpers.FastEscrowService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;
using FASTSelenium.DataObjects;
using FASTWCFHelpers;

namespace WebServices.Escrow
{[CodedUITest]
    public class RealEstateBrokerWS : MasterTestClass
    {
        [TestMethod]
        [Description("Verify CreateRealEstateAgentBroker() service functionality")]
        public void REG_CreateREBroker_Other()
        {
            try
            {
                Reports.TestStep = "Verify PayoffLoanPayChargesAssociation() service";
                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FASTHelpers.FAST_Login_IIS();
                #endregion

                #region WCF Create File and open in FAST
                Reports.TestStep = "Create a basic file";
                FASTHelpers.FAST_WCF_File_IIS(GAB: "508", GABRole: FASTWCFHelpers.FastFileService.AdditionalRoleType.None, isTO: true, isEO: true, SPAmt: (decimal)1000000, loanAmt: (decimal)1000);
                #endregion

                Reports.TestStep = "Invoke CreatePayOffLoan service";
                var CreateREBSellerReq = EscrowRequestFactory.GetDefaultRequestForRealEstateBrokerAgentCD(FASTHelpers.File.FileID, FASTWCFHelpers.FastEscrowService.RealEstateBrokerType.OTHER);
                var CreateREBSellerRes = FASTWCFHelpers.EscrowService.CreateRealEstateBroker(CreateREBSellerReq);
                Support.AreEqual("1", CreateREBSellerRes.Status.ToString(), CreateREBSellerRes.StatusDescription);
                //
                Reports.TestStep = "Get REB details";
                var Request = EscrowRequestFactory.GetServiceFileRequest(FASTHelpers.File.FileID);
                var REBDetails = FASTWCFHelpers.EscrowService.GetRealStateBroker(Request);
                //
                Reports.TestStep = "Navigate to Real Estate Broker screen in FAST UI";
                ValidateREBDetailsOnUI(REBDetails,RealEstateBrokerType.OTHER);               
            }
            catch(Exception ex)
            {
                FailTest(ex.Message);
            }
        }
//

        [TestMethod]
        [Description("Verify GetRealEstateBroker() functionality")]
        public void REG_GetRealEstateBroker()
        {
            try
            {
                Reports.TestDescription = "Verify GetRealEstateBroker() operation.";
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = FileRequestFactory.GetDetailedCreateFileDefaultRequest();
                #endregion

                #region Login and Create File
                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a file using web service";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                string fileNum = FileService.GetOrderDetails(fileId).FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(fileNum);
                #endregion

                Reports.TestStep = "Invoke UpdateREBroker service.";
                var UpdateREBreq = EscrowRequestFactory.UpdateRequestForRealEstateBroker(fileId, RealEstateBrokerType.BUYER);
                var UpdateREBres = FASTWCFHelpers.EscrowService.UpdateRealEstateBroker(UpdateREBreq);
                Support.AreEqual("1", UpdateREBres.Status.ToString(), UpdateREBres.StatusDescription);

                Reports.TestStep = "Get REB details";
                var Request = EscrowRequestFactory.GetServiceFileRequest(fileId);
                var REBDetails = FASTWCFHelpers.EscrowService.GetRealStateBroker(Request);

                Reports.TestStep = "Validate the details from GetRealStateBroker service.";
                ValidateREBDetailsOnUIForUpdate(REBDetails, "BUYERBROKER");
            }

            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        //
        [TestMethod]
        [Description("Verify REG_UpdateRealEstateBroker_Buyer() functionality")]
        public void REG_UpdateRealEstateBroker_Buyer()
        {
            try
            {
                Reports.TestDescription = "Verify UpdateRealEstateBroker operation for Buyer broker type.";
                UpdateREBroker("BUYER");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("Verify REG_UpdateRealEstateBroker_Seller() functionality")]
        public void REG_UpdateRealEstateBroker_Seller()
        {
            try
            {
                Reports.TestDescription = "Verify UpdateRealEstateBroker operation for Seller broker type.";
                UpdateREBroker("SELLER");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("Verify REG_UpdateRealEstateBroker_Other() functionality")]
        public void REG_UpdateRealEstateBroker_Other()
        {
            try
            {
                Reports.TestDescription = "Verify UpdateRealEstateBroker operation for Other broker type.";
                UpdateREBroker("OTHER");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("Verify REG_RemoveRealEstateBroker_Buyer() functionality")]
        public void REG_RemoveRealEstateBroker_Buyer()
        {
            try
            {
                Reports.TestDescription = "Verify RemoveRealEstateBroker operation for Other broker type.";
                RemoveREBroker("BUYER");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("Verify REG_RemoveRealEstateBroker_Seller() functionality")]
        public void REG_RemoveRealEstateBroker_Seller()
        {
            try
            {
                Reports.TestDescription = "Verify RemoveRealEstateBroker operation for Seller broker type.";
                RemoveREBroker("SELLER");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        [Description("Verify REG_RemoveRealEstateBroker_Other() functionality")]
        public void REG_RemoveRealEstateBroker_Other()
        {
            try
            {
                Reports.TestDescription = "Verify RemoveRealEstateBroker operation for Other broker type.";
                RemoveREBroker("OTHER");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #region PrivateMethods
        private void ValidateREBDetailsOnUI(RealEstateBrokerResponse REBDetails, RealEstateBrokerType REBType)
        {
            try
            {
                RealEstateBrokerDetails tempREBDetails = new RealEstateBrokerDetails();
                FastDriver.RealEstateBrokerAgentSummary.EditAgentBroker(REBType.ToString());
                switch (REBType)
                {
                    case RealEstateBrokerType.OTHER:
                        tempREBDetails = REBDetails.OtherBroker[0];
                        break;
                    case RealEstateBrokerType.BUYER:
                        tempREBDetails = REBDetails.BuyerBroker;
                        break;
                    case RealEstateBrokerType.SELLER:
                        tempREBDetails = REBDetails.SellerBroker;
                        break;
                }
                int? AddrBookEntryID=FASTWCFHelpers.AdminService.GetGABAddressBookEntryId(FastDriver.RealEstateBrokerAgent.IDCode.FAGetText());
                Support.AreEqual(tempREBDetails.REBrokerInformation.FBP.AddrBookEntryID.ToString(), AddrBookEntryID.ToString());
                Support.AreEqual(tempREBDetails.CommissionSummary.CommissionAmount.ToString() + ".00", FastDriver.RealEstateBrokerAgent.CommissionAmount.FAGetValue());
                Support.AreEqual(tempREBDetails.CommissionSummary.CreditBuyerBrokerFlag.ToString(), FastDriver.RealEstateBrokerAgent.CreditBuyerBroker.IsSelected().ToString());
                Support.AreEqual(tempREBDetails.CommissionSummary.CreditBuyerBrokerAmt.ToString() + ".00", FastDriver.RealEstateBrokerAgent.CreditBuyerBrokerAmt.FAGetValue().ToString());
                Support.AreEqual(tempREBDetails.CommissionSummary.CreditSellerBrokerFlag.ToString(), FastDriver.RealEstateBrokerAgent.CreditSellerBroker.IsSelected().ToString());
                Support.AreEqual(tempREBDetails.CommissionSummary.CreditSellerBrokerAmt.ToString() + ".00", FastDriver.RealEstateBrokerAgent.CreditSellerBrokerAmt.FAGetValue().ToString());
                //
                Support.AreEqual(tempREBDetails.CDCommissionChargeAmount.Description, FastDriver.RealEstateBrokerAgent.CommisionChargeTable.PerformTableAction(2, 1, TableAction.GetInputValue).Message.ToString());
                Support.AreEqual(tempREBDetails.CDCommissionChargeAmount.BuyerCharge.ToString() + ".00", FastDriver.RealEstateBrokerAgent.CommisionChargeTable.PerformTableAction(2, 3, TableAction.GetInputValue).Message.ToString());
                Support.AreEqual(tempREBDetails.CDCommissionChargeAmount.SellerCharge.ToString() + ".00", FastDriver.RealEstateBrokerAgent.CommisionChargeTable.PerformTableAction(2, 4, TableAction.GetInputValue).Message.ToString());
                //
                Support.AreEqual(tempREBDetails.CDREBrokerCharges[0].Description.ToString(), FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesTable.PerformTableAction(2, 1, TableAction.GetInputValue).Message.ToString());
                Support.AreEqual(tempREBDetails.CDREBrokerCharges[0].BuyerCharge.ToString() + ".00", FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesTable.PerformTableAction(2, 3, TableAction.GetInputValue).Message.ToString());
                Support.AreEqual(tempREBDetails.CDREBrokerCharges[0].SellerCharge.ToString() + ".00", FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesTable.PerformTableAction(2, 4, TableAction.GetInputValue).Message.ToString());
                //
                int? BrokerDisbtGABAddrBookEntryID = FASTWCFHelpers.AdminService.GetGABAddressBookEntryId(FastDriver.RealEstateBrokerAgent.BrokerDisbursementGABCodeLabel.FAGetText());
                Support.AreEqual(tempREBDetails.DisbSummaryFBP[0].FBP.AddrBookEntryID.ToString(),BrokerDisbtGABAddrBookEntryID.ToString());
                Support.AreEqual(tempREBDetails.DisbSummaryFBP[0].CheckAmount.ToString() + ".00", FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsCheckAmount.FAGetValue());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void ValidateREBDetailsOnUIForUpdate(RealEstateBrokerResponse REBDetails, string REBType)
        {
            try
            {
                RealEstateBrokerDetails tempREBDetails = new RealEstateBrokerDetails();
                FastDriver.RealEstateBrokerAgentSummary.EditAgentBroker(REBType);
                switch (REBType)
                {
                    case "OTHER":
                        tempREBDetails = REBDetails.OtherBroker[0];
                        break;
                    case "BUYERBROKER":
                        tempREBDetails = REBDetails.BuyerBroker;
                        break;
                    case "SELLERBROKER":
                        tempREBDetails = REBDetails.SellerBroker;
                        break;
                }
                int? AddrBookEntryID = FASTWCFHelpers.AdminService.GetGABAddressBookEntryId(FastDriver.RealEstateBrokerAgent.IDCode.FAGetText());
                Support.AreEqual(tempREBDetails.REBrokerInformation.FBP.AddrBookEntryID.ToString(), AddrBookEntryID.ToString());
                Support.AreEqual(tempREBDetails.CommissionSummary.CommissionAmount.ToString() + ".00", FastDriver.RealEstateBrokerAgent.CommissionAmount.FAGetValue());
                Support.AreEqual(tempREBDetails.CommissionSummary.CreditBuyerBrokerFlag.ToString(), FastDriver.RealEstateBrokerAgent.CreditBuyerBroker.IsSelected().ToString());
                Support.AreEqual(tempREBDetails.CommissionSummary.CreditBuyerBrokerAmt.ToString() + ".00", FastDriver.RealEstateBrokerAgent.CreditBuyerBrokerAmt.FAGetValue().ToString());
                Support.AreEqual(tempREBDetails.CommissionSummary.CreditSellerBrokerFlag.ToString(), FastDriver.RealEstateBrokerAgent.CreditSellerBroker.IsSelected().ToString());
                Support.AreEqual(tempREBDetails.CommissionSummary.CreditSellerBrokerAmt.ToString() + ".00", FastDriver.RealEstateBrokerAgent.CreditSellerBrokerAmt.FAGetValue().ToString());
                //
                Support.AreEqual(tempREBDetails.CDCommissionChargeAmount.Description, FastDriver.RealEstateBrokerAgent.CommisionChargeTable.PerformTableAction(2, 1, TableAction.GetInputValue).Message.ToString());
                Support.AreEqual(tempREBDetails.CDCommissionChargeAmount.BuyerCharge.ToString() + ".00", FastDriver.RealEstateBrokerAgent.CommisionChargeTable.PerformTableAction(2, 3, TableAction.GetInputValue).Message.ToString());
                Support.AreEqual(tempREBDetails.CDCommissionChargeAmount.SellerCharge.ToString() + ".00", FastDriver.RealEstateBrokerAgent.CommisionChargeTable.PerformTableAction(2, 4, TableAction.GetInputValue).Message.ToString());
                //
                Support.AreEqual(tempREBDetails.CDREBrokerCharges[0].Description.ToString(), FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesTable.PerformTableAction(2, 1, TableAction.GetInputValue).Message.ToString());
                Support.AreEqual(tempREBDetails.CDREBrokerCharges[0].BuyerCharge.ToString() + ".00", FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesTable.PerformTableAction(2, 3, TableAction.GetInputValue).Message.ToString());
                Support.AreEqual(tempREBDetails.CDREBrokerCharges[0].SellerCharge.ToString() + ".00", FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesTable.PerformTableAction(2, 4, TableAction.GetInputValue).Message.ToString());
                //
                int? BrokerDisbtGABAddrBookEntryID = FASTWCFHelpers.AdminService.GetGABAddressBookEntryId(FastDriver.RealEstateBrokerAgent.BrokerDisbursementGABCodeLabel.FAGetText());
                Support.AreEqual(tempREBDetails.DisbSummaryFBP[0].FBP.AddrBookEntryID.ToString(), BrokerDisbtGABAddrBookEntryID.ToString());
                Support.AreEqual(tempREBDetails.DisbSummaryFBP[0].CheckAmount.ToString() + ".00", FastDriver.RealEstateBrokerAgent.RealEstateBrokerDisbursementsCheckAmount.FAGetValue());
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void ValidateREBDetailsOnUIAfterRemoval(RealEstateBrokerResponse REBDetails, string REBType)
        {
            try
            {
                RealEstateBrokerDetails tempREBDetails = new RealEstateBrokerDetails();
                FastDriver.RealEstateBrokerAgentSummary.EditAgentBroker(REBType);
                switch (REBType)
                {
                    case "OTHER":
                        tempREBDetails = REBDetails.OtherBroker[0];
                        break;
                    case "BUYERBROKER":
                        tempREBDetails = REBDetails.BuyerBroker;
                        break;
                    case "SELLERBROKER":
                        tempREBDetails = REBDetails.SellerBroker;
                        break;
                }
                Support.AreEqual(tempREBDetails.CommissionSummary.CommissionAmount.ToString() + ".00", FastDriver.RealEstateBrokerAgent.CommissionAmount.FAGetValue());
                Support.AreEqual(tempREBDetails.CommissionSummary.CreditBuyerBrokerFlag.ToString(), FastDriver.RealEstateBrokerAgent.CreditBuyerBroker.IsSelected().ToString());
                Support.AreEqual(tempREBDetails.CommissionSummary.CreditBuyerBrokerAmt.ToString() + ".00", FastDriver.RealEstateBrokerAgent.CreditBuyerBrokerAmt.FAGetValue().ToString());
                Support.AreEqual(tempREBDetails.CommissionSummary.CreditSellerBrokerFlag.ToString(), FastDriver.RealEstateBrokerAgent.CreditSellerBroker.IsSelected().ToString());
                Support.AreEqual(tempREBDetails.CommissionSummary.CreditSellerBrokerAmt.ToString() + ".00", FastDriver.RealEstateBrokerAgent.CreditBuyerBrokerAmt.FAGetValue().ToString());

                Support.AreEqual("0.00", FastDriver.RealEstateBrokerAgent.SellerCommissionAmt.FAGetText());
                Support.AreEqual("0.00", FastDriver.RealEstateBrokerAgent.OtherBrokerCommisionAmt.FAGetText());
                Support.AreEqual("0.00", FastDriver.RealEstateBrokerAgent.BuyerBrokerCommisionAmt.FAGetText());
                Support.AreEqual("", FastDriver.RealEstateBrokerAgent.CommisionChargeAmountBuyerCharge.FAGetValue());
                Support.AreEqual("", FastDriver.RealEstateBrokerAgent.CommisionChargeAmountSellerCharge.FAGetValue());
                Support.AreEqual("", FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesDescription.FAGetValue());
                Support.AreEqual("", FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesBuyerCharge.FAGetValue());
                Support.AreEqual("", FastDriver.RealEstateBrokerAgent.RealEstateBrokerChargesSellerCharge.FAGetValue());
                Support.AreEqual("0.00", FastDriver.RealEstateBrokerAgent.BrokerChargesAmt.FAGetText());

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        private void UpdateREBroker(string brokerType)
        {
            // Reports.TestStep = "Verify UpdateRealEstateBroker service ";
            #region data setup
            var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
            var fileRequest = FileRequestFactory.GetDetailedCreateFileDefaultRequest();
            #endregion

            #region Login and Create File
            Reports.TestStep = "Log into FAST application.";
            FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

            Reports.TestStep = "Create a file using web service";
            int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
            string fileNum = FileService.GetOrderDetails(fileId).FileNumber;
            FastDriver.TopFrame.SearchFileByFileNumber(fileNum);
            #endregion
            if (brokerType == "OTHER")
            {
                Reports.TestStep = "Create Other RE Broker instance.";
                var CreateREBSellerReq = EscrowRequestFactory.GetDefaultRequestForRealEstateBrokerAgentCD(fileId, RealEstateBrokerType.OTHER);
                var CreateREBSellerRes = FASTWCFHelpers.EscrowService.CreateRealEstateBroker(CreateREBSellerReq);
                Support.AreEqual("1", CreateREBSellerRes.Status.ToString(), CreateREBSellerRes.StatusDescription);
            }

            Reports.TestStep = "Invoke UpdateREBroker service.";
            if (brokerType.ToUpper() == "BUYER")
            {
                var UpdateREBreq = EscrowRequestFactory.UpdateRequestForRealEstateBroker(fileId, RealEstateBrokerType.BUYER);
                var UpdateREBres = FASTWCFHelpers.EscrowService.UpdateRealEstateBroker(UpdateREBreq);
                Support.AreEqual("1", UpdateREBres.Status.ToString(), UpdateREBres.StatusDescription);
            }
            if (brokerType.ToUpper() == "SELLER")
            {
                var UpdateREBreq = EscrowRequestFactory.UpdateRequestForRealEstateBroker(fileId, RealEstateBrokerType.SELLER);
                var UpdateREBres = FASTWCFHelpers.EscrowService.UpdateRealEstateBroker(UpdateREBreq);
                Support.AreEqual("1", UpdateREBres.Status.ToString(), UpdateREBres.StatusDescription);
            }
            if (brokerType.ToUpper() == "OTHER")
            {
                var UpdateREBreq = EscrowRequestFactory.UpdateRequestForRealEstateBroker(fileId, RealEstateBrokerType.OTHER);
                var UpdateREBres = FASTWCFHelpers.EscrowService.UpdateRealEstateBroker(UpdateREBreq);
                Support.AreEqual("1", UpdateREBres.Status.ToString(), UpdateREBres.StatusDescription);
            }

            Reports.TestStep = "Get REB details";
            var Request = EscrowRequestFactory.GetServiceFileRequest(fileId);
            var REBDetails = FASTWCFHelpers.EscrowService.GetRealStateBroker(Request);

            if (brokerType.ToUpper() == "BUYER")
            {
                Reports.TestStep = "Validate the details for Buyer broker update.";
                ValidateREBDetailsOnUIForUpdate(REBDetails, "BUYERBROKER");
            }
            if (brokerType.ToUpper() == "SELLER")
            {
                Reports.TestStep = "Validate the details for Seller broker update.";
                ValidateREBDetailsOnUIForUpdate(REBDetails, "SELLERBROKER");
            }
            if (brokerType.ToUpper() == "OTHER")
            {
                Reports.TestStep = "Validate the details for Other broker update.";
                ValidateREBDetailsOnUIForUpdate(REBDetails, "OTHER");
            }
        }


        private void RemoveREBroker(string brokerType)
        {
            // Reports.TestStep = "Verify UpdateRealEstateBroker service ";
            #region data setup
            var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
            var fileRequest = FileRequestFactory.GetDetailedCreateFileDefaultRequest();
            #endregion

            #region Login and Create File
            Reports.TestStep = "Log into FAST application.";
            FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

            Reports.TestStep = "Create a file using web service";
            int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
            string fileNum = FileService.GetOrderDetails(fileId).FileNumber;
            FastDriver.TopFrame.SearchFileByFileNumber(fileNum);
            #endregion
            if (brokerType == "OTHER")
            {
                Reports.TestStep = "Create Other RE Broker instance.";
                var CreateREBSellerReq = EscrowRequestFactory.GetDefaultRequestForRealEstateBrokerAgentCD(fileId, RealEstateBrokerType.OTHER);
                var CreateREBSellerRes = FASTWCFHelpers.EscrowService.CreateRealEstateBroker(CreateREBSellerReq);
                Support.AreEqual("1", CreateREBSellerRes.Status.ToString(), CreateREBSellerRes.StatusDescription);
            }


            if (brokerType.ToUpper() == "BUYER")
            {
                var UpdateREBreq = EscrowRequestFactory.UpdateRequestForRealEstateBroker(fileId, RealEstateBrokerType.BUYER);
                var UpdateREBres = FASTWCFHelpers.EscrowService.UpdateRealEstateBroker(UpdateREBreq);
                Support.AreEqual("1", UpdateREBres.Status.ToString(), UpdateREBres.StatusDescription);
            }
            if (brokerType.ToUpper() == "SELLER")
            {
                var UpdateREBreq = EscrowRequestFactory.UpdateRequestForRealEstateBroker(fileId, RealEstateBrokerType.SELLER);
                var UpdateREBres = FASTWCFHelpers.EscrowService.UpdateRealEstateBroker(UpdateREBreq);
                Support.AreEqual("1", UpdateREBres.Status.ToString(), UpdateREBres.StatusDescription);
            }
            if (brokerType.ToUpper() == "OTHER")
            {
                var UpdateREBreq = EscrowRequestFactory.UpdateRequestForRealEstateBroker(fileId, RealEstateBrokerType.OTHER);
                var UpdateREBres = FASTWCFHelpers.EscrowService.UpdateRealEstateBroker(UpdateREBreq);
                Support.AreEqual("1", UpdateREBres.Status.ToString(), UpdateREBres.StatusDescription);
            }

            Reports.TestStep = "Get REB details";
            var Request = EscrowRequestFactory.GetServiceFileRequest(fileId);
            var REBDetails = FASTWCFHelpers.EscrowService.GetRealStateBroker(Request);

            if (brokerType.ToUpper() == "BUYER")
            {
                Reports.TestStep = "Validate the details for Buyer broker update.";
                ValidateREBDetailsOnUIForUpdate(REBDetails, "BUYERBROKER");
            }
            if (brokerType.ToUpper() == "SELLER")
            {
                Reports.TestStep = "Validate the details for Seller broker update.";
                ValidateREBDetailsOnUIForUpdate(REBDetails, "SELLERBROKER");
            }
            if (brokerType.ToUpper() == "OTHER")
            {
                Reports.TestStep = "Validate the details for Other broker update.";
                ValidateREBDetailsOnUIForUpdate(REBDetails, "OTHER");
            }

            Reports.TestStep = "Invoke RemoveREBroker service.";
            if (brokerType.ToUpper() == "BUYER")
            {
                var RemoveREBreq = EscrowRequestFactory.RemoveRequestForRealEstateBroker(fileId, RealEstateBrokerType.BUYER);
                var RemoveREBres = FASTWCFHelpers.EscrowService.RemoveRealEstateBroker(RemoveREBreq);
                Support.AreEqual("1", RemoveREBres.Status.ToString(), RemoveREBres.StatusDescription);
            }
            if (brokerType.ToUpper() == "SELLER")
            {
                var RemoveREBreq = EscrowRequestFactory.RemoveRequestForRealEstateBroker(fileId, RealEstateBrokerType.SELLER);
                var RemoveREBres = FASTWCFHelpers.EscrowService.RemoveRealEstateBroker(RemoveREBreq);
                Support.AreEqual("1", RemoveREBres.Status.ToString(), RemoveREBres.StatusDescription);
            }
            if (brokerType.ToUpper() == "OTHER")
            {
                var RemoveREBreq = EscrowRequestFactory.RemoveRequestForRealEstateBroker(fileId, RealEstateBrokerType.OTHER);
                var RemoveREBres = FASTWCFHelpers.EscrowService.RemoveRealEstateBroker(RemoveREBreq);
                Support.AreEqual("1", RemoveREBres.Status.ToString(), RemoveREBres.StatusDescription);
            }

            Reports.TestStep = "Get REB details";
            var Request2 = EscrowRequestFactory.GetServiceFileRequest(fileId);
            var REBDetails2 = FASTWCFHelpers.EscrowService.GetRealStateBroker(Request);

            if (brokerType.ToUpper() == "BUYER")
            {
                Reports.TestStep = "Validate the details for Buyer broker update.";
                ValidateREBDetailsOnUIAfterRemoval(REBDetails2, "BUYERBROKER");
            }
            if (brokerType.ToUpper() == "SELLER")
            {
                Reports.TestStep = "Validate the details for Seller broker update.";
                ValidateREBDetailsOnUIAfterRemoval(REBDetails2, "SELLERBROKER");
            }
            if (brokerType.ToUpper() == "OTHER")
            {
                Reports.TestStep = "Validate the details for Other broker update.";
                ValidateREBDetailsOnUIAfterRemoval(REBDetails2, "OTHER");
            }
        }
        #endregion
    }

}
