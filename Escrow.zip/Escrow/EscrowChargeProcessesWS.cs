﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastEscrowService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Threading;
using WebServices.Helpers.Escrow;
using WebServices.Helpers.File;

namespace WebServices.Escrow
{
    [CodedUITest]
    public class EscrowChargeProcessesWS : MasterTestClass
    {
        [TestMethod]
        public void REG0001_GetInspectionRepairSepticSummary()
        {
            try
            {
                Reports.TestDescription = "Verify GetInspectionRepairSepticSummary service";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetDetailedCreateFileDefaultRequest();
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a file using web service";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                string fileNum = FileService.GetOrderDetails(fileId).FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(fileNum);

                Reports.TestStep = "Create an Inspection Repair Septic (WS)";
                var inspectionRepairSepticRequest = EscrowRequestFactory.GetIRSRequest(fileId, 1);
                EscrowChargeProcessesHelpers.CreateInspectionRepairSeptic(inspectionRepairSepticRequest);

                Reports.TestStep = "Invoke GetInspectionRepairSepticSummary method, validate response (WS)";
                var request = EscrowRequestFactory.GetIRSSRequest(fileId);
                var response = EscrowChargeProcessesHelpers.GetInspectionRepairSepticSummary(request);
                Support.AreEqual("1", response.NumberOfRecords.ToString(), "Number Of Records");
                Support.AreEqual("1", response.Status.ToString(), "Operation Status");
                Support.AreEqual("Inspection Repair Septic Summary operation completed", response.StatusDescription, "Operation Status Description");

                Reports.TestStep = "Navigate to Septic screen, validate BusOrgName";
                FastDriver.InspectionRepairSeptic.Open();
                Support.AreEqual(response.InspectionRepairSummary[0].BusOrgName, FastDriver.InspectionRepairSeptic.INSP_Septic_LenderName.FAGetText().Clean(), "Bus Org Name");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally { FastDriver.WebDriver.Quit(); }
        }

        [TestMethod]
        public void REG0002_GetNewLoanDetails()
        {
            try
            {
                Reports.TestDescription = "Verify GetNewLoanDetails service";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetDetailedCreateFileDefaultRequest();
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a file using web service";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                string fileNum = FileService.GetOrderDetails(fileId).FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(fileNum);

                Reports.TestStep = "Invoke GetNewLoanDetails method, validate response (WS)";
                var request = EscrowRequestFactory.GetNewLoanDetailsRequest(fileId, 1);
                var response = EscrowChargeProcessesHelpers.GetNewLoanDetails(request);
                Support.AreEqual("1", response.Status.ToString(), "Operation Status");
                Support.AreEqual("Successful", response.StatusDescription, "Operation Status Description");

                Reports.TestStep = "Navigate to New Loan screen, validate ID Code and lender name";
                FastDriver.NewLoan.Open();
                Support.AreEqual(response.LoanDetails.LenderInformation.IDCode, FastDriver.NewLoan.LoanDetailsGabcodeLabel.FAGetText().Clean(), "GAB Code");
                Support.AreEqual(response.LoanDetails.LenderInformation.Name, FastDriver.NewLoan.LenderName.FAGetText().Clean(), "Lender Name");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally { FastDriver.WebDriver.Quit(); }
        }

        [TestMethod]
        public void REG0003_CreateHomeOwnerAssociation()
        {
            try
            {
                Reports.TestDescription = "Validate the CreateHomeOwnerAssociation (Escrow) web service.";

                #region Create a New file using the webservice.
                Reports.TestStep = "Create a New file using the webservice.";
                int fileID = GeneralFileServiceOperationsHelpers.CreateFile(FileRequestFactory.GetDetailedCreateFileDefaultRequest());
                string fileNumber = FASTWCFHelpers.FileService.GetOrderDetails(fileID).FileNumber;
                #endregion

                #region Create a Home Owner association instance with charges for the created file using webservices.
                Reports.TestStep = "Create a Home Owner association instance with charges for the created file using webservices.";
                OperationResponse response = EscrowChargeProcessesHelpers.GetHomeOwnerInstanceCreated(fileID, 1);
                OperationResponseExtensions.Validate(response);
                #endregion

                #region Login to file Side and verify that homeownerassociation instance is created.
                Reports.TestStep = "Login to the file side.";
                Login();

                Reports.TestStep = "Navigate to the file";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to the Event log and verify for create home owner association log.";
                FastDriver.EventTrackingLog.Open();
                Support.AreEqual(response.StatusDescription, FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Create Homeowner Association]", 5, TableAction.GetText).Message, "Verify the HOA instace is created in UI.");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally { FastDriver.WebDriver.Quit(); }
        }

        [TestMethod]
        public void REG0004_GetHomeOwnerAssociationDetails()
        {
            try
            {
                Reports.TestDescription = "Validate the GetHomeOwnerAssociationDetails (Escrow) web service.";

                #region Create a New file using the webservice.
                Reports.TestStep = "Create a New file using the webservice.";
                int fileID = GeneralFileServiceOperationsHelpers.CreateFile(FileRequestFactory.GetDetailedCreateFileDefaultRequest());
                string fileNumber = FASTWCFHelpers.FileService.GetOrderDetails(fileID).FileNumber;
                #endregion

                #region Create a Home Owner association instance with charges for the created file using webservices.
                Reports.TestStep = "Create a Home Owner association instance with charges for the created file using webservices.";
                var response = EscrowChargeProcessesHelpers.GetHomeOwnerInstanceCreated(fileID, 1);
                OperationResponseExtensions.Validate(response);
                #endregion

                #region Inovke the GetHomeOwnerAssociationDetails web service.
                Reports.TestStep = "Inovke the GetHomeOwnerAssociationDetails web service.";
                var response1 = new HomeownerAssociationResponse();
                response1 = EscrowChargeProcessesHelpers.GetHomeOwnerAssociationDetails(fileID);
                OperationResponseExtensions.Validate(response1);
                #endregion

                #region Login to file Side and verify that homeownerassociation instance is created.
                Reports.TestStep = "Login to the file side.";
                Login();

                Reports.TestStep = "Navigate to the file";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to the Event log and verify for create home owner association log.";
                FastDriver.EventTrackingLog.Open();
                Support.AreEqual(response.StatusDescription, FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Create Homeowner Association]", 5, TableAction.GetText).Message, "Verify the HOA instace is created in UI.");
                #endregion

                #region Navigate to the Home Owner association page and verify the details with UI.
                Reports.TestStep = "Navigate to the HomeOwnerAssociation Page.";
                FastDriver.HomeownerAssociation.Open();
                ServiceHelper.CompareWithUI(FastDriver.HomeownerAssociation.IDCodeText, "value", response1.HOASummary[0].HOAInformation.HOAFileBusinessParty.IDCode);
                ServiceHelper.CompareWithUI(FastDriver.HomeownerAssociation.AmountDues, "value", response1.HOASummary[0].AssocDues.Dues.ToString(), true, true);
                ServiceHelper.CompareWithUI(FastDriver.HomeownerAssociation.Per, "selecteditem", response1.HOASummary[0].AssocDues.eDuesPeriod.ToString());

                Reports.TestStep = "Verify the values of association charges table.";
                FastDriver.HomeownerAssociation.AssociationChargesTable.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.HomeownerAssociation.AssociationChargePaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                ServiceHelper.CompareWithUI(FastDriver.PaymentDetailsDlg.Description, "value", response1.HOASummary[0].AssocCharges.AssociationChargesListForCD[0].Description, true, true);
                ServiceHelper.CompareWithUI(FastDriver.PaymentDetailsDlg.BuyerCharge, "value", response1.HOASummary[0].AssocCharges.AssociationChargesListForCD[0].BuyerCharge.ToString(), true, false);
                ServiceHelper.CompareWithUI(FastDriver.PaymentDetailsDlg.SellerCharge, "value", response1.HOASummary[0].AssocCharges.AssociationChargesListForCD[0].SellerCharge.ToString(), true, false);
                string paymentMethod = (response1.HOASummary[0].AssocCharges.AssociationChargesListForCD[0].AtClosingBuyerPaymentMethodTypeID.ToString() == "CHK" ? "Check" : null);
                ServiceHelper.CompareWithUI(FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod, "selecteditem", paymentMethod);
                paymentMethod = (response1.HOASummary[0].AssocCharges.AssociationChargesListForCD[0].AtClosingSellerPaymentMethodTypeID.ToString() == "CHK" ? "Check" : null);
                ServiceHelper.CompareWithUI(FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod, "selecteditem", paymentMethod);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Verify the values of management company charges table.";
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.ManagementCompanyChargesTable.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.HomeownerAssociation.ManagementCompanyPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                ServiceHelper.CompareWithUI(FastDriver.PaymentDetailsDlg.Description, "value", response1.HOASummary[0].MgmtCompanyCharges.MgmtCompanyChargesListForCD[0].Description, true, false);
                ServiceHelper.CompareWithUI(FastDriver.PaymentDetailsDlg.BuyerCharge, "value", response1.HOASummary[0].MgmtCompanyCharges.MgmtCompanyChargesListForCD[0].BuyerCharge.ToString(), true, false);
                ServiceHelper.CompareWithUI(FastDriver.PaymentDetailsDlg.SellerCharge, "value", response1.HOASummary[0].MgmtCompanyCharges.MgmtCompanyChargesListForCD[0].SellerCharge.ToString(), true, false);
                paymentMethod = (response1.HOASummary[0].MgmtCompanyCharges.MgmtCompanyChargesListForCD[0].AtClosingBuyerPaymentMethodTypeID.ToString() == "CHK" ? "Check" : null);
                ServiceHelper.CompareWithUI(FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod, "selecteditem", paymentMethod);
                paymentMethod = (response1.HOASummary[0].MgmtCompanyCharges.MgmtCompanyChargesListForCD[0].AtClosingSellerPaymentMethodTypeID.ToString() == "CHK" ? "Check" : null);
                ServiceHelper.CompareWithUI(FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod, "selecteditem", paymentMethod);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Verify the values of HOA lein payoff table.";
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.HOALienPayoffTable.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.HomeownerAssociation.ProrationPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                ServiceHelper.CompareWithUI(FastDriver.PaymentDetailsDlg.Description, "value", response1.HOASummary[0].HOALienPayoff.HOALienPayoffListForCD[0].Description, true, false);
                ServiceHelper.CompareWithUI(FastDriver.PaymentDetailsDlg.BuyerCharge, "value", response1.HOASummary[0].HOALienPayoff.HOALienPayoffListForCD[0].BuyerCharge.ToString(), true, false);
                ServiceHelper.CompareWithUI(FastDriver.PaymentDetailsDlg.SellerCharge, "value", response1.HOASummary[0].HOALienPayoff.HOALienPayoffListForCD[0].SellerCharge.ToString(), true, false);
                paymentMethod = (response1.HOASummary[0].HOALienPayoff.HOALienPayoffListForCD[0].AtClosingBuyerPaymentMethodTypeID.ToString() == "CHK" ? "Check" : null);
                ServiceHelper.CompareWithUI(FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod, "selecteditem", paymentMethod);
                paymentMethod = (response1.HOASummary[0].HOALienPayoff.HOALienPayoffListForCD[0].AtClosingSellerPaymentMethodTypeID.ToString() == "CHK" ? "Check" : null);
                ServiceHelper.CompareWithUI(FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod, "selecteditem", paymentMethod);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Verify the values of Home owner proration.";
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                ServiceHelper.CompareWithUI(FastDriver.HomeownerAssociation.CreditSeller, "Checked", response1.HOASummary[0].Proration.CreditSeller.ToString());
                ServiceHelper.CompareWithUI(FastDriver.HomeownerAssociation.ProrationAmount, "value", response1.HOASummary[0].Proration.Amount.ToString(), true, true);
                ServiceHelper.CompareWithUI(FastDriver.HomeownerAssociation.FromDate, "value", ((DateTime)response1.HOASummary[0].Proration.FromDate).ToDateString());
                ServiceHelper.CompareWithUI(FastDriver.HomeownerAssociation.ToDate, "value", ((DateTime)response1.HOASummary[0].Proration.ToDate).ToDateString());
                ServiceHelper.CompareWithUI(FastDriver.HomeownerAssociation.BasedOn, "selecteditem", response1.HOASummary[0].Proration.BasedOnDays.ToString());

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally { FastDriver.WebDriver.Quit(); }
        }

        [TestMethod]
        public void REG0005_GetPropertyTaxCheckDetails()
        {
            try
            {
                Reports.TestDescription = "Verify GetPropertyTaxCheckDetails service";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetDetailedCreateFileDefaultRequest();
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a file using web service";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                string fileNum = FileService.GetOrderDetails(fileId).FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(fileNum);

                Reports.TestStep = "Create an Property Tax Check instance (WS)";
                var propertyTaxCheckRequest = EscrowRequestFactory.GetPropertyTaxCheckRequest(fileId, 1, "BOA");
                EscrowChargeProcessesHelpers.CreatePropertyTaxCheck(propertyTaxCheckRequest);

                Reports.TestStep = "Invoke GetPropertyTaxCheckDetails method, validate response (WS)";
                var response = EscrowChargeProcessesHelpers.GetPropertyTaxCheckDetails(fileId);
                Support.AreEqual("1", response.Status.ToString(), "Operation Status");
                Support.AreEqual("PropertTaxCheck Details operation is successful.", response.StatusDescription, "Operation Status Description");

                Reports.TestStep = "Navigate to Property Tax Check screen, validate IDCode";
                FastDriver.PropertyTaxCheck.Open();
                Support.AreEqual(response.PropTaxCheckSummary[0].FileBusinessParty.IDCode, FastDriver.PropertyTaxCheck.GABcodeLabel.FAGetText().Clean(), "ID Code");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally { FastDriver.WebDriver.Quit(); }
        }

        [TestMethod]
        public void REG0006_GetSurveyDetails()
        {
            try
            {
                Reports.TestDescription = "Verify GetSurveyDetails service";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetDetailedCreateFileDefaultRequest();
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a file using web service";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                string fileNum = FileService.GetOrderDetails(fileId).FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(fileNum);

                Reports.TestStep = "Create a Survey instance (WS)";
                var surveyRequest = EscrowRequestFactory.GetSurveyRequest(fileId, 1, "BOA");
                EscrowChargeProcessesHelpers.CreateSurvey(surveyRequest);

                Reports.TestStep = "Navigate to Survey screen, enter buyer & seller charge";
                FastDriver.SurveyDetail.Open();
                FastDriver.SurveyDetail.SurveyChargesTable.PerformTableAction(2, 3, TableAction.SetText, "100.00");
                FastDriver.SurveyDetail.SurveyChargesTable.PerformTableAction(2, 4, TableAction.SetText, "200.00");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Invoke GetSurveyDetails method, validate response (WS)";
                var request = EscrowRequestFactory.GetServiceFileRequest(fileId);
                var response = EscrowChargeProcessesHelpers.GetSurveyDetails(request);
                Support.AreEqual("1", response.Status.ToString(), "Operation Status");
                Support.AreEqual("GetSurveyDetails operation is successful for CD file.", response.StatusDescription, "Operation Status Description");

                Reports.TestStep = "Navigate to Survey screen, validate check amount and ID Code";
                Support.AreEqual("300", response.SurveySummary[0].CheckAmount.ToString(), "Check Amount");
                Support.AreEqual("BOA", response.SurveySummary[0].SurveyFileBusinessParty.IDCode, "ID code");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally { FastDriver.WebDriver.Quit(); }
        }

        [TestMethod]
        public void REG0007_UpdateHomeOwnerAssociationDetails()
        {
            try
            {
                Reports.TestDescription = "Validate the GetHomeOwnerAssociationDetails (Escrow) web service.";

                #region Create a New file using the webservice.
                Reports.TestStep = "Create a New file using the webservice.";
                int fileID = GeneralFileServiceOperationsHelpers.CreateFile(FileRequestFactory.GetDetailedCreateFileDefaultRequest());
                string fileNumber = FASTWCFHelpers.FileService.GetOrderDetails(fileID).FileNumber;
                #endregion

                #region Create a Home Owner association instance with charges for the created file using webservices.
                Reports.TestStep = "Create a Home Owner association instance with charges for the created file using webservices.";
                var response = EscrowChargeProcessesHelpers.GetHomeOwnerInstanceCreated(fileID, 1);
                OperationResponseExtensions.Validate(response);
                #endregion

                #region Get the Previous request for HOA creation and update it.
                Reports.TestStep = "Get the Previous request for HOA creation through the WS, and update it.";
                HomeownerAssociationRequest request = EscrowRequestFactory.GetHomeownerAssociationRequest(fileID, 1);
                request.oHOADetails.HOAInformation.HOAFileBusinessParty.AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247");
                request.oHOADetails.AssocDues.Dues = 2300.01m;
                request.oHOADetails.AssocDues.eDuesPeriod = DuePeriod.DAY;
                request.oHOADetails.AssocCharges.AssociationChargesListForCD[0].Description = "Association charge Desc changed";
                request.oHOADetails.AssocCharges.AssociationChargesListForCD[0].BuyerCharge = 100.01m;
                request.oHOADetails.AssocCharges.AssociationChargesListForCD[0].SellerCharge = 100.02m;
                request.oHOADetails.MgmtCompanyCharges.MgmtCompanyChargesListForCD[0].Description = "MgmtCompanycharge desc changed";
                request.oHOADetails.MgmtCompanyCharges.MgmtCompanyChargesListForCD[0].BuyerCharge = 200.01m;
                request.oHOADetails.MgmtCompanyCharges.MgmtCompanyChargesListForCD[0].SellerCharge = 200.02m;
                request.oHOADetails.HOALienPayoff.HOALienPayoffListForCD[0].Description = "HOA lein payoff changed";
                request.oHOADetails.HOALienPayoff.HOALienPayoffListForCD[0].BuyerCharge = 300.01m;
                request.oHOADetails.HOALienPayoff.HOALienPayoffListForCD[0].SellerCharge = 300.02m;
                #endregion

                #region Inovke the UpdateHomeOwnerAssociationDetails web service.
                Reports.TestStep = "Inovke the UpdateHomeOwnerAssociationDetails web service.";
                var response1 = EscrowChargeProcessesHelpers.UpdateHomeOwnerAssociationDetails(request);
                OperationResponseExtensions.Validate(response1);
                #endregion

                #region Get the updated details of homeowner association instance details through webservice.
                Reports.TestStep = "Get the updated details of homeowner association instance details through webservice";
                var response2 = new HomeownerAssociationResponse();
                response2 = EscrowChargeProcessesHelpers.GetHomeOwnerAssociationDetails(fileID);
                #endregion

                #region Login to file Side and verify that homeownerassociation instance is created.
                Reports.TestStep = "Login to the file side.";
                Login();

                Reports.TestStep = "Navigate to the file";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to the Event log and verify for create home owner association log.";
                FastDriver.EventTrackingLog.Open();
                Support.AreEqual(response.StatusDescription, FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Create Homeowner Association]", 5, TableAction.GetText).Message, "Verify the HOA instace is created in UI.");
                Support.AreEqual(response1.StatusDescription.Replace(" ", string.Empty), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Update Homeowner Association]", 5, TableAction.GetText).Message.Replace(" ", string.Empty), "Verify the HOA instace is updated in UI.");
                #endregion

                #region Navigate to the Home Owner association page and verify the details in FAST.
                Reports.TestStep = "Navigate to the HomeOwnerAssociation Page.";
                FastDriver.HomeownerAssociation.Open();
                ServiceHelper.CompareWithUI(FastDriver.HomeownerAssociation.IDCodeText, "value", response2.HOASummary[0].HOAInformation.HOAFileBusinessParty.IDCode);
                ServiceHelper.CompareWithUI(FastDriver.HomeownerAssociation.AmountDues, "value", response2.HOASummary[0].AssocDues.Dues.ToString(), true, true);
                ServiceHelper.CompareWithUI(FastDriver.HomeownerAssociation.Per, "selecteditem", response2.HOASummary[0].AssocDues.eDuesPeriod.ToString());

                Reports.TestStep = "Verify the values of association charges table.";
                FastDriver.HomeownerAssociation.AssociationChargesTable.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.HomeownerAssociation.AssociationChargePaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                ServiceHelper.CompareWithUI(FastDriver.PaymentDetailsDlg.Description, "value", response2.HOASummary[0].AssocCharges.AssociationChargesListForCD[0].Description, true, true);
                ServiceHelper.CompareWithUI(FastDriver.PaymentDetailsDlg.BuyerCharge, "value", response2.HOASummary[0].AssocCharges.AssociationChargesListForCD[0].BuyerCharge.ToString(), true, false);
                ServiceHelper.CompareWithUI(FastDriver.PaymentDetailsDlg.SellerCharge, "value", response2.HOASummary[0].AssocCharges.AssociationChargesListForCD[0].SellerCharge.ToString(), true, false);
                string paymentMethod = (response2.HOASummary[0].AssocCharges.AssociationChargesListForCD[0].AtClosingBuyerPaymentMethodTypeID.ToString() == "CHK" ? "Check" : null);
                ServiceHelper.CompareWithUI(FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod, "selecteditem", paymentMethod);
                paymentMethod = (response2.HOASummary[0].AssocCharges.AssociationChargesListForCD[0].AtClosingSellerPaymentMethodTypeID.ToString() == "CHK" ? "Check" : null);
                ServiceHelper.CompareWithUI(FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod, "selecteditem", paymentMethod);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Verify the values of management company charges table.";
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.ManagementCompanyChargesTable.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.HomeownerAssociation.ManagementCompanyPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                ServiceHelper.CompareWithUI(FastDriver.PaymentDetailsDlg.Description, "value", response2.HOASummary[0].MgmtCompanyCharges.MgmtCompanyChargesListForCD[0].Description, true, false);
                ServiceHelper.CompareWithUI(FastDriver.PaymentDetailsDlg.BuyerCharge, "value", response2.HOASummary[0].MgmtCompanyCharges.MgmtCompanyChargesListForCD[0].BuyerCharge.ToString(), true, false);
                ServiceHelper.CompareWithUI(FastDriver.PaymentDetailsDlg.SellerCharge, "value", response2.HOASummary[0].MgmtCompanyCharges.MgmtCompanyChargesListForCD[0].SellerCharge.ToString(), true, false);
                paymentMethod = (response2.HOASummary[0].MgmtCompanyCharges.MgmtCompanyChargesListForCD[0].AtClosingBuyerPaymentMethodTypeID.ToString() == "CHK" ? "Check" : null);
                ServiceHelper.CompareWithUI(FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod, "selecteditem", paymentMethod);
                paymentMethod = (response2.HOASummary[0].MgmtCompanyCharges.MgmtCompanyChargesListForCD[0].AtClosingSellerPaymentMethodTypeID.ToString() == "CHK" ? "Check" : null);
                ServiceHelper.CompareWithUI(FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod, "selecteditem", paymentMethod);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Verify the values of HOA lein payoff table.";
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                FastDriver.HomeownerAssociation.HOALienPayoffTable.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.HomeownerAssociation.ProrationPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                ServiceHelper.CompareWithUI(FastDriver.PaymentDetailsDlg.Description, "value", response2.HOASummary[0].HOALienPayoff.HOALienPayoffListForCD[0].Description, true, false);
                ServiceHelper.CompareWithUI(FastDriver.PaymentDetailsDlg.BuyerCharge, "value", response2.HOASummary[0].HOALienPayoff.HOALienPayoffListForCD[0].BuyerCharge.ToString(), true, false);
                ServiceHelper.CompareWithUI(FastDriver.PaymentDetailsDlg.SellerCharge, "value", response2.HOASummary[0].HOALienPayoff.HOALienPayoffListForCD[0].SellerCharge.ToString(), true, false);
                paymentMethod = (response2.HOASummary[0].HOALienPayoff.HOALienPayoffListForCD[0].AtClosingBuyerPaymentMethodTypeID.ToString() == "CHK" ? "Check" : null);
                ServiceHelper.CompareWithUI(FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod, "selecteditem", paymentMethod);
                paymentMethod = (response2.HOASummary[0].HOALienPayoff.HOALienPayoffListForCD[0].AtClosingSellerPaymentMethodTypeID.ToString() == "CHK" ? "Check" : null);
                ServiceHelper.CompareWithUI(FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod, "selecteditem", paymentMethod);
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Verify the values of Home owner proration.";
                FastDriver.HomeownerAssociation.WaitForScreenToLoad();
                ServiceHelper.CompareWithUI(FastDriver.HomeownerAssociation.CreditSeller, "Checked", response2.HOASummary[0].Proration.CreditSeller.ToString());
                ServiceHelper.CompareWithUI(FastDriver.HomeownerAssociation.ProrationAmount, "value", response2.HOASummary[0].Proration.Amount.ToString(), true, true);
                ServiceHelper.CompareWithUI(FastDriver.HomeownerAssociation.FromDate, "value", ((DateTime)response2.HOASummary[0].Proration.FromDate).ToDateString());
                ServiceHelper.CompareWithUI(FastDriver.HomeownerAssociation.ToDate, "value", ((DateTime)response2.HOASummary[0].Proration.ToDate).ToDateString());
                ServiceHelper.CompareWithUI(FastDriver.HomeownerAssociation.BasedOn, "selecteditem", response2.HOASummary[0].Proration.BasedOnDays.ToString());

                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally { FastDriver.WebDriver.Quit(); }
        }

        [TestMethod]
        public void REG0008_CreateDepositInEscrow()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                #endregion

                Reports.TestDescription = "Verify CreateDepositInEscrow() Service";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a file using web service";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                var file = FileService.GetOrderDetails(fileId).FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(file);

                Reports.TestStep = "Invoke CreateDepositInEscrow Service";
                var CreateDepositInEscrowRequest = EscrowRequestFactory.GetDepositInEscrowRequest(fileId);
                CreateDepositInEscrowRequest.DepositInEscrow.DepositEscrow.ReceivedFrom = "Other";
                CreateDepositInEscrowRequest.DepositInEscrow.DepositEscrow.IssueDate = DateTime.Now.ToPST();
                CreateDepositInEscrowRequest.DepositInEscrow.DepositEscrow.TypeFunds = "Cash";
                CreateDepositInEscrowRequest.DepositInEscrow.DepositEscrow.TransactionDate = DateTime.Now.ToPST();
                CreateDepositInEscrowRequest.DepositInEscrow.DepositEscrow.Representing = "Additional Closing Costs";

                var CreateDepositInEscrowResponse = EscrowService.CreateDepositInEscrow(CreateDepositInEscrowRequest);
                CreateDepositInEscrowResponse.Validate();

                Reports.TestStep = "Navigate to Deposit/Receipt History screen and select the added deposit";
                FastDriver.DepositReceiptHistory.Open();
                FastDriver.DepositReceiptHistory.ReceiptsDepositActivityTable.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.DepositReceiptHistory.ViewDetails.FAClick();
                FastDriver.DepositInEscrow.WaitForScreenToLoad(FastDriver.DepositInEscrow.Amount);

                Reports.TestStep = "Verify Deposit In Escrow is filled with data from web service request";
                Support.AreEqual(CreateDepositInEscrowRequest.DepositInEscrow.DepositEscrow.Amount.Value.ToString().FormatAsMoney(), FastDriver.DepositInEscrow.Amount.FAGetValue(), "Amount");
                Support.AreEqual(CreateDepositInEscrowRequest.DepositInEscrow.DepositEscrow.ReceiptNumber.ToString(), FastDriver.DepositInEscrow.ReceiptNo.FAGetValue(), "Receipt No");
                Support.AreEqual(CreateDepositInEscrowRequest.DepositInEscrow.DepositEscrow.ReceivedFrom.ToString(), FastDriver.DepositInEscrow.ReceivedFrom.FAGetSelectedItem(), "Received From");
                Support.AreEqual(CreateDepositInEscrowRequest.DepositInEscrow.DepositEscrow.IssueDate.Value.ToDateString(), FastDriver.DepositInEscrow.IssueDte.FAGetValue(), "Issue Date");
                Support.AreEqual(CreateDepositInEscrowRequest.DepositInEscrow.DepositEscrow.TypeFunds.ToString(), FastDriver.DepositInEscrow.TypeofFunds.FAGetSelectedItem(), "Type Funds");
                Support.AreEqual(CreateDepositInEscrowRequest.DepositInEscrow.DepositEscrow.Representing.ToString(), FastDriver.DepositInEscrow.Representing.FAGetSelectedItem(), "Representing");
                Support.AreEqual(true, FastDriver.DepositInEscrow.CredittoOther.IsSelected(), "For Credit to: Other is selected");
                Support.AreEqual(CreateDepositInEscrowRequest.DepositInEscrow.DepositEscrow.ManualReceiptReason.ToString(), FastDriver.DepositInEscrow.ManualReceiptReason.FAGetText(), "Manual Receipt Reason");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0009_RemoveInspectionRepairPest()
        {
            try
            {
                Reports.TestDescription = "Verify RemoveInspectionRepairPest service";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetDetailedCreateFileDefaultRequest();
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a file using web service";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                string fileNum = FileService.GetOrderDetails(fileId).FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(fileNum);

                Reports.TestStep = "Create a Inspection Repair Pest instance (WS)";
                var pestRequest = EscrowRequestFactory.GetInspectionRepairPestRequest(fileId, 1, "BOA");
                EscrowChargeProcessesHelpers.CreateInspectionRepairPest(pestRequest);

                Reports.TestStep = "Navigate to Pest screen, validate GAB Code";
                FastDriver.InspectionRepairPest.Open();
                Support.AreEqual("BOA", FastDriver.InspectionRepairPest.LabelIDCode.FAGetText(), "GAB Code");

                Reports.TestStep = "Invoke RemoveInspectionRepairPest method, validate response (WS)";
                var request = EscrowRequestFactory.GetInspectionRepairPestRequest(fileId, 1);
                var response = EscrowChargeProcessesHelpers.RemoveInspectionRepairPest(request);
                Support.AreEqual("1", response.Status.ToString(), "Operation Status");
                Support.AreEqual("InspectionRepair Pest with SeqNum : 1 Removed successfully.", response.StatusDescription, "Operation Status Description");

                Reports.TestStep = "Navigate to Pest screen, validate GAB Code is now blank";
                FastDriver.InspectionRepairPest.Open();
                Support.AreEqual("", FastDriver.InspectionRepairPest.LabelIDCode.FAGetText().Clean(), "GAB Code");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally { FastDriver.WebDriver.Quit(); }
        }

        [TestMethod]
        public void REG0010_RemoveInspectionRepairSeptic()
        {
            try
            {
                Reports.TestDescription = "Verify RemoveInspectionRepairSeptic service";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetDetailedCreateFileDefaultRequest();
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a file using web service";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                string fileNum = FileService.GetOrderDetails(fileId).FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(fileNum);

                Reports.TestStep = "Create a Inspection Repair Septic instance (WS)";
                var septicRequest = EscrowRequestFactory.GetInspectionRepairSepticRequest(fileId, 1, "BOA");
                EscrowChargeProcessesHelpers.CreateInspectionRepairSeptic(septicRequest);

                Reports.TestStep = "Navigate to Septic screen, validate GAB Code";
                FastDriver.InspectionRepairSeptic.Open();
                Support.AreEqual("BOA", FastDriver.InspectionRepairSeptic.GABcodeLabel.FAGetText(), "GAB Code");

                Reports.TestStep = "Invoke RemoveInspectionRepairSeptic method, validate response (WS)";
                var request = EscrowRequestFactory.GetIRSRemoveRequest(fileId, 1);
                var response = EscrowChargeProcessesHelpers.RemoveInspectionRepairSeptic(request);
                Support.AreEqual("1", response.Status.ToString(), "Operation Status");
                Support.AreEqual("InspectionRepair Septic with SeqNum : 1 Removed successfully.", response.StatusDescription, "Operation Status Description");

                Reports.TestStep = "Navigate to Pest screen, validate GAB Code is now blank";
                FastDriver.InspectionRepairSeptic.Open();
                Support.AreEqual("", FastDriver.InspectionRepairSeptic.GABcodeLabel.FAGetText().Clean(), "GAB Code");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally { FastDriver.WebDriver.Quit(); }
        }

        [TestMethod]
        public void REG0011_RemoveMortgageBrokerInformation()
        {
            try
            {
                Reports.TestDescription = "Verify RemoveMortgageBrokerInformation service";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetDetailedCreateFileDefaultRequest();
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a file using web service";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                string fileNum = FileService.GetOrderDetails(fileId).FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(fileNum);

                Reports.TestStep = "Navigate to New Loan | Mortgage Broker screen, add a Mortgage Broker";
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.ClickMortgageBrokerTab();
                FastDriver.NewLoan.MortgageFindGAB("BOA");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20);
                Thread.Sleep(5000);

                Reports.TestStep = "Invoke RemoveMortgageBrokerInformation method, validate response (WS)";
                var request = EscrowRequestFactory.GetRemoveNewLoanRequest(fileId, 1);
                var response = EscrowChargeProcessesHelpers.RemoveMortgageBrokerInformation(request);
                Support.AreEqual("1", response.Status.ToString(), "Operation Status");
                Support.AreEqual("Mortagage Broker Business Party is Removed Successfully.(Sequence No : 1)", response.StatusDescription, "Operation Status Description");

                Reports.TestStep = "Navigate to New Loan | Mortgage Broker screen, validate mortage broker is now blank";
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.ClickMortgageBrokerTab();
                Support.AreEqual("", FastDriver.NewLoan.MortgageBrokerGABlabel.FAGetText().Clean(), "GAB Code");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally { FastDriver.WebDriver.Quit(); }
        }

        [TestMethod]
        public void REG0012_RemoveHomeOwnerAssociation()
        {
            Reports.TestDescription = "Validate the RemoveHomeOwnerAssociation web service.";
            try
            {
                #region Create a New file using the webservice.
                Reports.TestStep = "Create a New file using the webservice.";
                int fileID = GeneralFileServiceOperationsHelpers.CreateFile(FileRequestFactory.GetDetailedCreateFileDefaultRequest());
                string fileNumber = FASTWCFHelpers.FileService.GetOrderDetails(fileID).FileNumber;
                #endregion

                #region Create a Home Owner association instance with charges for the created file using webservices.
                Reports.TestStep = "Create a Home Owner association instance with charges for the created file using webservices.";
                OperationResponse response = EscrowChargeProcessesHelpers.GetHomeOwnerInstanceCreated(fileID, 1);
                OperationResponseExtensions.Validate(response);
                #endregion

                #region Login to file Side and verify that homeownerassociation instance is created.
                Reports.TestStep = "Login to the file side.";
                Login();

                Reports.TestStep = "Navigate to the file";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to the Event log and verify for create home owner association log.";
                FastDriver.EventTrackingLog.Open();
                Support.AreEqual(response.StatusDescription, FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Create Homeowner Association]", 5, TableAction.GetText).Message, "Verify the HOA instace is created in UI.");
                #endregion

                #region Invoke the Remove Homeowner webservice.
                Reports.TestStep = "Invoke the removehomeownerassociation webservice.";
                response = EscrowChargeProcessesHelpers.RemoveHomeOwnerAssociation(fileID, 1);
                OperationResponseExtensions.Validate(response);
                #endregion

                #region Verify that created instace of homeownerassociation is deleted in FAST.
                Reports.TestStep = "Verify that Created instance of HomeOwnerAssociation is deleted in FAST.";
                FastDriver.EventTrackingLog.Open();
                Support.AreEqual(response.StatusDescription, FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Remove Homeowner Association]", 5, TableAction.GetText).Message, "Verify the HOA instace is deleted in UI.");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally { FastDriver.WebDriver.Quit(); }
        }

        [TestMethod]
        public void REG0013_CreateInspectionRepairOthers()
        {
            Reports.TestDescription = "Validate the CreateInspectionRepairOthers web service.";
            try
            {
                #region Create a New file using the webservice.
                Reports.TestStep = "Create a New file using the webservice.";
                int fileID = GeneralFileServiceOperationsHelpers.CreateFile(FileRequestFactory.GetDetailedCreateFileDefaultRequest());
                string fileNumber = FASTWCFHelpers.FileService.GetOrderDetails(fileID).FileNumber;
                #endregion

                #region Create a inspection repair other instance for the file using WS.
                Reports.TestStep = "Create a inspection repair other instance for the file using WS.";
                var response = EscrowChargeProcessesHelpers.GetInspectionRepairOthersCreated(fileID, 1);
                OperationResponseExtensions.Validate(response);
                #endregion

                #region Login to file Side and verify that InspectionRepairOthers instance is created at FAST.
                Reports.TestStep = "Login to the file side.";
                Login();

                Reports.TestStep = "Navigate to the file";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to the Event log and verify for create home owner association log.";
                FastDriver.EventTrackingLog.Open();
                Support.AreEqual(response.StatusDescription, FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Create Inspection Repair]", 5, TableAction.GetText).Message, "Verify the HOA instace is created in UI.");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally { FastDriver.WebDriver.Quit(); }
        }

        [TestMethod]
        public void REG0014_GetInspectionRepairOthersDetails()
        {
            Reports.TestDescription = "Validate the GetInspectionRepairOthersDetails web service.";
            try
            {
                #region Create a New file using the webservice.
                Reports.TestStep = "Create a New file using the webservice.";
                int fileID = GeneralFileServiceOperationsHelpers.CreateFile(FileRequestFactory.GetDetailedCreateFileDefaultRequest());
                string fileNumber = FASTWCFHelpers.FileService.GetOrderDetails(fileID).FileNumber;
                #endregion

                #region Create a inspection repair other instance for the file using WS.
                Reports.TestStep = "Create a inspection repair other instance for the file using WS.";
                var response = EscrowChargeProcessesHelpers.GetInspectionRepairOthersCreated(fileID, 1);
                OperationResponseExtensions.Validate(response);
                #endregion

                #region Invoke the GetInspectionRepairOthersDetails ws and get the details of created inspection repair.
                Reports.TestStep = "Invoke the GetInspectionRepairOthersDetails ws and get the details of created inspection repair.";
                InspectionRepairResponse response1 = EscrowChargeProcessesHelpers.GetInspectionRepairOthersDetails(fileID);
                OperationResponseExtensions.Validate(response1);
                #endregion

                #region Login to file Side and verify that InspectionRepairOthers instance is created at FAST.
                Reports.TestStep = "Login to the file side.";
                Login();

                Reports.TestStep = "Navigate to the file";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to the Event log and verify for create home owner association log.";
                FastDriver.EventTrackingLog.Open();
                Support.AreEqual(response.StatusDescription, FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Create Inspection Repair]", 5, TableAction.GetText).Message, "Verify the inspection repair for others instace is created in UI.");
                #endregion

                #region Validate the response by WS in FAST.
                Reports.TestStep = "Validating the response got by webservice in FAST.";
                FastDriver.InspectionRepairOther.Open();
                ServiceHelper.CompareWithUI(FastDriver.InspectionRepairOther.GABcodeLabel, "value", response1.InspectionRepairList[0].FileBusinessParty.IDCode);
                ServiceHelper.CompareWithUI(FastDriver.InspectionRepairOther.FurnishedBy, "selecteditem", response1.InspectionRepairList[0].ReportInfo.FurnishedType.ToString());
                ServiceHelper.CompareWithUI(FastDriver.InspectionRepairOther.WithinDays, "value", response1.InspectionRepairList[0].ReportInfo.Within.ToString());
                ServiceHelper.CompareWithUI(FastDriver.InspectionRepairOther.CompleteDate, "Value", ((DateTime)response1.InspectionRepairList[0].ReportInfo.CompletionDate).ToDateString());
                ServiceHelper.CompareWithUI(FastDriver.InspectionRepairOther.ReportDate, "Value", ((DateTime)response1.InspectionRepairList[0].ReportInfo.ReportDate).ToDateString());

                Reports.TestStep = "Verify the values of inspection repair charges table. ";
                FastDriver.InspectionRepairOther.InspectionRepairChargesTable.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.InspectionRepairOther.PaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                ServiceHelper.CompareWithUI(FastDriver.PaymentDetailsDlg.Description, "value", response1.InspectionRepairList[0].CDChargeList[0].Description);

                ServiceHelper.CompareWithUI(FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue().Replace("$", string.Empty), String.Format("{0:0,0.00}", response1.InspectionRepairList[0].CDChargeList[0].PBBuyerAtClosing));
                ServiceHelper.CompareWithUI(FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FAGetValue().Replace("$", string.Empty), String.Format("{0:0,0.00}", response1.InspectionRepairList[0].CDChargeList[0].PBBuyerBeforeClosing));
                ServiceHelper.CompareWithUI(FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FAGetValue().Replace("$", string.Empty), response1.InspectionRepairList[0].CDChargeList[0].PBOthersForBuyer.ToString());
                string paymentMethod = response1.InspectionRepairList[0].CDChargeList[0].AtClosingBuyerPaymentMethodTypeID.ToString() == "CHK" ? "Check" : null;
                ServiceHelper.CompareWithUI(FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod, "selecteditem", paymentMethod);

                ServiceHelper.CompareWithUI(FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FAGetValue().Replace("$", string.Empty), String.Format("{0:0,0.00}", response1.InspectionRepairList[0].CDChargeList[0].PBSellerAtClosing));
                ServiceHelper.CompareWithUI(FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FAGetValue().Replace("$", string.Empty), String.Format("{0:0,0.00}", response1.InspectionRepairList[0].CDChargeList[0].PBSellerBeforeClosing));
                ServiceHelper.CompareWithUI(FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FAGetValue().Replace("$", string.Empty), response1.InspectionRepairList[0].CDChargeList[0].PBOthersForSeller.ToString());
                paymentMethod = response1.InspectionRepairList[0].CDChargeList[0].AtClosingSellerPaymentMethodTypeID.ToString() == "CHK" ? "Check" : null;
                ServiceHelper.CompareWithUI(FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod, "selecteditem", paymentMethod);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally { FastDriver.WebDriver.Quit(); }
        }

        [TestMethod]
        public void REG0015_ReadDepositListDetails()
        {
            //Bug Number: 564133
            //try
            //{
            //    Reports.TestDescription = "Verify ReadDepositListDetails() service";

            //    #region data setup
            //    var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
            //    var fileRequest = FileRequestFactory.GetDetailedCreateFileDefaultRequest();
            //    #endregion

            //    Reports.TestStep = "Log into FAST application.";
            //    FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

            //    Reports.TestStep = "Create a file using web service";
            //    int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
            //    string fileNum = FileService.GetOrderDetails(fileId).FileNumber;
            //    FastDriver.TopFrame.SearchFileByFileNumber(fileNum);

            //    Reports.TestStep = "Invoke GetDepositInEscrowRequest Service";
            //    var GetDepositInEscrowRequest = EscrowRequestFactory.GetDepositInEscrowRequest(fileId);
            //    GetDepositInEscrowRequest.DepositInEscrow.DepositEscrow.BankAcctID = 11715;

            //    var GetDepositInEscrowResponse = EscrowService.CreateDepositInEscrow(GetDepositInEscrowRequest);
            //    GetDepositInEscrowResponse.Validate();

            //    var DepositBankAccID = GetDepositInEscrowRequest.DepositInEscrow.DepositEscrow.BankAcctID.Value.ToString();

            //    Reports.TestStep = "Navigate to Deposit List and search for the deposit created";
            //    FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.DepositList>("Home>Business Unit Processing>Deposit Slip>Deposit List");
            //    FastDriver.DepositList.WaitForScreenToLoad();

            //    Reports.TestStep = "Search for the deposit's bank account, select it and click on New button";
            //    FastDriver.DepositList.BankAccounts.FASelectItemByIndex(6);
            //    FastDriver.DepositList.FindNow.FAClick();
            //    FastDriver.DepositList.WaitForScreenToLoad(FastDriver.DepositList.New);
            //    FastDriver.DepositList.New.FAClick();
            //    FastDriver.DepositList.WaitForScreenToLoad(FastDriver.DepositList.DepositListEdit_FindNow);

            //    Reports.TestStep = "Click on Find Now and Select the Created Deposit";
            //    FastDriver.DepositList.DepositListEdit_FindNow.FAClick();
            //    FastDriver.DepositList.WaitForScreenToLoad(FastDriver.DepositList.ReceiptsTable);
            //    FastDriver.DepositList.ReceiptsTable.PerformTableAction(6, fileNum, 1, TableAction.On);

            //    FastDriver.DepositList.Complete.FAClick();
            //    FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 20);
            //    FastDriver.PrintDlg.WaitForScreenToLoad();
            //    FastDriver.PrintDlg.ClickCancel();
            //    FastDriver.BottomFrame.Done();

            //    Reports.TestStep = "Search for the Deposit's bank account and get the deposit list id";
            //    FastDriver.DepositList.WaitForScreenToLoad(FastDriver.DepositList.BankAccounts);
            //    FastDriver.DepositList.BankAccounts.FASelectItemByIndex(6);

            //    FastDriver.DepositList.FindNow.FAClick();
            //    FastDriver.DepositList.WaitForScreenToLoad(FastDriver.DepositList.DepositListTable);
            //    var DepositListID = FastDriver.DepositList.DepositListTable.PerformTableAction(2, 1, TableAction.GetText).Message;

            //    Reports.TestStep = "Invoke ReadDepositListDetails Service";
            //    var ReadDepositListDetailsRequest = EscrowRequestFactory.ReadDepositListDetailsRequest(Convert.ToInt32(DepositListID), DepositBankAccID); //failing here
            //    var ReadDepositListDetailsResponse = EscrowService.ReadDepositListDetails(ReadDepositListDetailsRequest);
            //    ReadDepositListDetailsResponse.Validate();

            //    Reports.TestStep = "Navigate to Deposit/Receipt History screen and select the added deposit";
            //    FastDriver.DepositReceiptHistory.Open();
            //    FastDriver.DepositReceiptHistory.ReceiptsDepositActivityTable.PerformTableAction(1, 1, TableAction.Click);
            //    FastDriver.DepositReceiptHistory.ViewDetails.FAClick();
            //    FastDriver.DepositInEscrow.WaitForScreenToLoad(FastDriver.DepositInEscrow.Amount);

            //    Reports.TestStep = "Verify Deposit is filled with data from web service request";
            //}
            //catch (Exception ex)
            //{
            //    FailTest(ex.Message);
            //}
            //finally { FastDriver.WebDriver.Quit(); }
        }

        [TestMethod]
        public void REG0016_RemovePropertyTaxCheck()
        {
            try
            {
                Reports.TestDescription = "Verify RemovePropertyTaxCheck service";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetDetailedCreateFileDefaultRequest();
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a file using web service";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                string fileNum = FileService.GetOrderDetails(fileId).FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(fileNum);

                Reports.TestStep = "Create a Property Tax Check instance (WS)";
                var propertyTaxCheckRequest = EscrowRequestFactory.GetPropertyTaxCheckRequest(fileId, 1, "BOA");
                EscrowChargeProcessesHelpers.CreatePropertyTaxCheck(propertyTaxCheckRequest);

                Reports.TestStep = "Navigate to Property Tax Check screen, validate GAB Code";
                FastDriver.PropertyTaxCheck.Open();
                Support.AreEqual("BOA", FastDriver.PropertyTaxCheck.GABcodeLabel.FAGetText().Clean(), "GAB Code");

                Reports.TestStep = "Invoke RemovePropertyTaxCheck method, validate response (WS)";
                var request = EscrowRequestFactory.GetPropertyTaxCheckRequest(fileId, 1);
                var response = EscrowChargeProcessesHelpers.RemovePropertyTaxCheck(request);
                Support.AreEqual("1", response.Status.ToString(), "Operation Status");
                Support.AreEqual("PropertyTaxCheck with Sequence No : 1 Removed successfully.", response.StatusDescription, "Operation Status Description");

                Reports.TestStep = "Navigate to Property Tax Check screen, validate mortage broker is now blank";
                FastDriver.PropertyTaxCheck.Open();
                Support.AreEqual("", FastDriver.PropertyTaxCheck.GABcodeLabel.FAGetText().Clean(), "GAB Code");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally { FastDriver.WebDriver.Quit(); }
        }

        [TestMethod]
        public void REG0017_CreateHoldFunds()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                #endregion

                Reports.TestDescription = "Verify CreateHoldFunds() Service";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a file using web service";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                var file = FileService.GetOrderDetails(fileId).FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(file);

                Reports.TestStep = "Invoke CreateHoldFuns Service";
                var CreateHoldFundsRequest = EscrowRequestFactory.GetCreateHoldFundsRequest(fileId, seqNum: 1);
                CreateHoldFundsRequest.HoldFunds.Date = DateTime.Now.ToPST().ToDateString();
                CreateHoldFundsRequest.HoldFunds.ReleaseDaysOn = DateTime.Now.AddDays(CreateHoldFundsRequest.HoldFunds.ReleaseIn.Value).ToPST().ToDateString();

                var CreateHoldFundsResponse = EscrowService.CreateHoldFunds(CreateHoldFundsRequest);
                CreateHoldFundsResponse.Validate();

                var releaseDaysOn = DateTime.Now.ToPST().AddDays(CreateHoldFundsRequest.HoldFunds.ReleaseIn.Value);

                Reports.TestStep = "Navigate to Hold Funds";
                FastDriver.HoldFunds.Open();

                Reports.TestStep = "Verify Hold Funds has been filled with the data from the web service";
                Support.AreEqual(CreateHoldFundsRequest.HoldFunds.Reason.ToString(), FastDriver.HoldFunds.Reason.FAGetValue(), "Reason");
                Support.AreEqual(CreateHoldFundsRequest.HoldFunds.SellerCharge.Value.ToString().FormatAsMoney(), FastDriver.HoldFunds.SellerCharge.FAGetValue(), "Seller Charge");
                Support.AreEqual(CreateHoldFundsRequest.HoldFunds.Date, FastDriver.HoldFunds.Date.FAGetValue(), "Date");
                Support.AreEqual(CreateHoldFundsRequest.HoldFunds.ReleaseIn.Value.ToString(), FastDriver.HoldFunds.ReleaseinDays.FAGetValue(), "Release In");
                Support.AreEqual(releaseDaysOn.ToDateString(), FastDriver.HoldFunds.DateDaysOn.FAGetValue(), "Release Days On");
                Support.AreEqual(CreateHoldFundsRequest.HoldFundsDisbursement[0].HoldFundsDisbursementChargeList[0].SellerCharge.Value.ToString().FormatAsMoney(), FastDriver.HoldFunds.HoldFundTable.PerformTableAction(2, 6, TableAction.GetText).Message.Clean(), "Check Amt. 1");
                Support.AreEqual(CreateHoldFundsRequest.HoldFundsDisbursement[1].HoldFundsDisbursementChargeList[0].SellerCharge.Value.ToString().FormatAsMoney(), FastDriver.HoldFunds.HoldFundTable.PerformTableAction(3, 6, TableAction.GetText).Message.Clean(), "Check Amt. 2");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0018_CreateSurvey()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan();
                #endregion

                Reports.TestDescription = "Verify CreateSurvey() service.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                int fileid = FastDriver.FACreateFileGetFileId(fileRequest);
                var file = FileService.GetOrderDetails(fileid);
                FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

                Reports.TestStep = "Invoke CreateSurvey method";
                var surveyRequest = EscrowRequestFactory.GetSurveyRequest(file.FileID.Value, 1, "BOA");
                EscrowService.CreateSurvey(surveyRequest).Validate();

                Reports.TestStep = "Navigate to Survey screen, validate GAB Code";
                FastDriver.SurveyDetail.Open();
                Support.AreEqual("BOA", FastDriver.SurveyDetail.IDcodeLabel.FAGetText().Clean(), "ID Code");
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        public void REG0019_CreatePropertyTaxCheck()
        {
            try
            {
                Reports.TestDescription = "Verify RemovePropertyTaxCheck service";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetDetailedCreateFileDefaultRequest();
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a file using web service";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                string fileNum = FileService.GetOrderDetails(fileId).FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(fileNum);

                Reports.TestStep = "Create a Property Tax Check instance (WS)";
                var propertyTaxCheckRequest = EscrowRequestFactory.GetPropertyTaxCheckRequest(fileId, 1, "BOA");
                EscrowService.CreatePropertyTaxCheck(propertyTaxCheckRequest);

                Reports.TestStep = "Navigate to Property Tax Check screen, validate GAB Code";
                FastDriver.PropertyTaxCheck.Open();
                Support.AreEqual("BOA", FastDriver.PropertyTaxCheck.GABcodeLabel.FAGetText().Clean(), "GAB Code");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally { FastDriver.WebDriver.Quit(); }
        }

        [TestMethod]
        public void REG0020_RemoveSurvey()
        {
            try
            {
                Reports.TestDescription = "Verify RemoveSurvey service";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetDetailedCreateFileDefaultRequest();
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a file using web service";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                string fileNum = FileService.GetOrderDetails(fileId).FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(fileNum);

                Reports.TestStep = "Create a Survey instance (WS)";
                var surveyRequest = EscrowRequestFactory.GetSurveyRequest(fileId, 1, "BOA");
                EscrowChargeProcessesHelpers.CreateSurvey(surveyRequest);

                Reports.TestStep = "Navigate to Survey screen, validate GAB Code";
                FastDriver.SurveyDetail.Open();
                Support.AreEqual("BOA", FastDriver.SurveyDetail.IDcodeLabel.FAGetText().Clean(), "ID Code");

                Reports.TestStep = "Invoke RemoveSurvey method, validate response (WS)";
                var request = EscrowRequestFactory.GetSurveyRequest(fileId, 1, "BOA");
                var response = EscrowChargeProcessesHelpers.RemoveSurvey(request);
                Support.AreEqual("1", response.Status.ToString(), "Operation Status");
                Support.AreEqual("Survey with Sequence No : 1 Removed successfully.", response.StatusDescription, "Operation Status Description");

                Reports.TestStep = "Navigate to Survey screen, validate ID Code is now blank";
                FastDriver.SurveyDetail.Open();
                Support.AreEqual("", FastDriver.SurveyDetail.IDcodeLabel.FAGetText().Clean(), "ID Code");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally { FastDriver.WebDriver.Quit(); }
        }

        [TestMethod]
        public void REG0021_UpdateHoldFunds()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                #endregion

                Reports.TestDescription = "Verify UpdateHoldFunds() Service";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a file using web service";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                var file = FileService.GetOrderDetails(fileId).FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(file);

                Reports.TestStep = "Create first Hold Funds instance (WS)";
                var CreateHoldFundsRequest = EscrowRequestFactory.GetCreateHoldFundsRequest(fileId, seqNum: 1);
                CreateHoldFundsRequest.HoldFunds.Date = DateTime.Now.ToPST().ToDateString();
                CreateHoldFundsRequest.HoldFunds.ReleaseDaysOn = DateTime.Now.AddDays(CreateHoldFundsRequest.HoldFunds.ReleaseIn.Value).ToPST().ToDateString();
                var CreateHoldFundsResponse = EscrowService.CreateHoldFunds(CreateHoldFundsRequest);
                CreateHoldFundsResponse.Validate();

                Reports.TestStep = "Create second Hold Funds instance (WS) [US # 700156]";
                CreateHoldFundsRequest = EscrowRequestFactory.GetCreateHoldFundsRequest(fileId, seqNum: 2);
                CreateHoldFundsRequest.HoldFunds.Date = DateTime.Now.ToPST().ToDateString();
                CreateHoldFundsRequest.HoldFunds.ReleaseDaysOn = DateTime.Now.AddDays(CreateHoldFundsRequest.HoldFunds.ReleaseIn.Value).ToPST().ToDateString();
                EscrowService.CreateHoldFunds(CreateHoldFundsRequest).Validate();

                Reports.TestStep = "Invoke UpdateHoldFunds Service on the first Hold Funds instance, validate response (WS) [US # 700156]";
                var request = EscrowRequestFactory.GetCreateHoldFundsRequest(fileId, 1);
                request.HoldFunds.SellerCharge = 80000;
                request.HoldFunds.Reason = "Update from WCF";
                request.HoldFundsDisbursement[0].HoldFundsFileBusinessParty.AddrBookEntryID = AdminService.GetGABAddressBookEntryId("1256", Convert.ToInt32(AutoConfig.SelectedRegionBUID));
                request.HoldFundsDisbursement[0].HoldFundsFileBusinessParty.RegionID = Convert.ToInt32(AutoConfig.SelectedRegionBUID);
                var response = EscrowChargeProcessesHelpers.UpdateHoldFunds(request);
                response.Validate();

                Reports.TestStep = "Navigate to Hold Funds screen, validate Seller Charge amount has changed [US # 700156]";
                FastDriver.HoldFundsSummary.Open();
                FastDriver.HoldFundsSummary.SummaryTable.PerformTableAction(1, "1", 1, TableAction.DoubleClick);
                FastDriver.HoldFunds.WaitForScreenToLoad();
                Support.AreEqual("80,000.00", FastDriver.HoldFunds.SellerCharge.FAGetValue().Clean(), "Seller Charge Amount");

                Reports.TestStep = "Navigate to Hold Funds screen, validate the second Hold Funds instance remains unchanged [US # 700156]";
                FastDriver.HoldFundsSummary.Open();
                FastDriver.HoldFundsSummary.SummaryTable.PerformTableAction(1, "2", 1, TableAction.DoubleClick);
                FastDriver.HoldFunds.WaitForScreenToLoad();
                Support.AreEqual("50,000.00", FastDriver.HoldFunds.SellerCharge.FAGetValue().Clean(), "Seller Charge Amount");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally { FastDriver.WebDriver.Quit(); }
        }

        [TestMethod]
        public void REG0022_UpdateInspectionRepairOtherDetails()
        {
            Reports.TestDescription = "Validate the UpdateInspectionRepairOthersDetails web service.";
            try
            {
                #region Create a New file using the webservice.
                Reports.TestStep = "Create a New file using the webservice.";
                int fileID = GeneralFileServiceOperationsHelpers.CreateFile(FileRequestFactory.GetDetailedCreateFileDefaultRequest());
                string fileNumber = FASTWCFHelpers.FileService.GetOrderDetails(fileID).FileNumber;
                #endregion

                #region Create a inspection repair other instance for the file using WS.
                Reports.TestStep = "Create a inspection repair other instance for the file using WS.";
                var response = EscrowChargeProcessesHelpers.GetInspectionRepairOthersCreated(fileID, 1);
                OperationResponseExtensions.Validate(response);
                #endregion

                #region Get the request for inspection repair and update it.
                Reports.TestStep = "Get the request for inspection repair and update it.";
                InspectionRepairRequest request = EscrowRequestFactory.GetIRORequest(fileID, 1);
                request.oInspectionRepairDetails.FileBusinessParty.AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247");
                request.oInspectionRepairDetails.ReportInfo.FurnishedType = FurnishedType.Buyer;
                request.oInspectionRepairDetails.ReportInfo.Within = 30;
                request.oInspectionRepairDetails.ReportInfo.ReportDate = DateTime.Now;
                request.oInspectionRepairDetails.ReportInfo.CompletionDate = DateTime.Now.AddDays(5);

                request.oInspectionRepairDetails.CDChargeList[0].Description = "Second IRO charge Added.";
                request.oInspectionRepairDetails.CDChargeList[0].PBBuyerAtClosing = 100.01m;
                request.oInspectionRepairDetails.CDChargeList[0].PBBuyerBeforeClosing = 100.02m;
                request.oInspectionRepairDetails.CDChargeList[0].PBOthersForBuyer = 100.03m;
                request.oInspectionRepairDetails.CDChargeList[0].PBSellerAtClosing = 200.01m;
                request.oInspectionRepairDetails.CDChargeList[0].PBSellerBeforeClosing = 200.02m;
                request.oInspectionRepairDetails.CDChargeList[0].PBOthersForSeller = 200.03m;

                #endregion

                #region Invoke the updateinspectionrepairothers webservices with update request and validate the response.
                Reports.TestStep = "Invoke the updateinspectionrepairothers webservices with update request and validate the response.";
                response = EscrowChargeProcessesHelpers.UpdateInspectionRepairOthers(request);
                OperationResponseExtensions.Validate(response);
                #endregion

                #region Get the updated details of inspection repair for other type using webservices.
                Reports.TestStep = "Get the updated details of inspection repair for other type using webservices.";
                InspectionRepairResponse response1 = EscrowChargeProcessesHelpers.GetInspectionRepairOthersDetails(fileID);
                OperationResponseExtensions.Validate(response1);
                #endregion

                #region Login to file Side and verify that InspectionRepairOthers instance is created at FAST.
                Reports.TestStep = "Login to the file side.";
                Login();

                Reports.TestStep = "Navigate to the file";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to the Event log and verify for create home owner association log.";
                FastDriver.EventTrackingLog.Open();
                Support.AreEqual(response.StatusDescription.Replace(" ", string.Empty), FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Update Inspection Repair]", 5, TableAction.GetText).Message.Replace(" ", string.Empty), "Verify the inspection repair for others instace is updated in UI.");
                #endregion

                #region Validate the response by WS in FAST.
                Reports.TestStep = "Validating the response got by webservice in FAST.";
                FastDriver.InspectionRepairOther.Open();
                ServiceHelper.CompareWithUI(FastDriver.InspectionRepairOther.GABcodeLabel, "value", response1.InspectionRepairList[0].FileBusinessParty.IDCode);
                ServiceHelper.CompareWithUI(FastDriver.InspectionRepairOther.FurnishedBy, "selecteditem", response1.InspectionRepairList[0].ReportInfo.FurnishedType.ToString());
                ServiceHelper.CompareWithUI(FastDriver.InspectionRepairOther.WithinDays, "value", response1.InspectionRepairList[0].ReportInfo.Within.ToString());
                ServiceHelper.CompareWithUI(FastDriver.InspectionRepairOther.CompleteDate, "Value", ((DateTime)response1.InspectionRepairList[0].ReportInfo.CompletionDate).ToDateString());
                ServiceHelper.CompareWithUI(FastDriver.InspectionRepairOther.ReportDate, "Value", ((DateTime)response1.InspectionRepairList[0].ReportInfo.ReportDate).ToDateString());

                Reports.TestStep = "Verify the values of inspection repair charges table. ";
                FastDriver.InspectionRepairOther.InspectionRepairChargesTable.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.InspectionRepairOther.PaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                ServiceHelper.CompareWithUI(FastDriver.PaymentDetailsDlg.Description, "value", response1.InspectionRepairList[0].CDChargeList[0].Description);

                ServiceHelper.CompareWithUI(FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FAGetValue().Replace("$", string.Empty), String.Format("{0:0,0.00}", response1.InspectionRepairList[0].CDChargeList[0].PBBuyerAtClosing));
                ServiceHelper.CompareWithUI(FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FAGetValue().Replace("$", string.Empty), String.Format("{0:0,0.00}", response1.InspectionRepairList[0].CDChargeList[0].PBBuyerBeforeClosing));
                ServiceHelper.CompareWithUI(FastDriver.PaymentDetailsDlg.PaidbyBuyerOthers.FAGetValue().Replace("$", string.Empty), response1.InspectionRepairList[0].CDChargeList[0].PBOthersForBuyer.ToString());
                string paymentMethod = response1.InspectionRepairList[0].CDChargeList[0].AtClosingBuyerPaymentMethodTypeID.ToString() == "CHK" ? "Check" : null;
                ServiceHelper.CompareWithUI(FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod, "selecteditem", paymentMethod);

                ServiceHelper.CompareWithUI(FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FAGetValue().Replace("$", string.Empty), String.Format("{0:0,0.00}", response1.InspectionRepairList[0].CDChargeList[0].PBSellerAtClosing));
                ServiceHelper.CompareWithUI(FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FAGetValue().Replace("$", string.Empty), String.Format("{0:0,0.00}", response1.InspectionRepairList[0].CDChargeList[0].PBSellerBeforeClosing));
                ServiceHelper.CompareWithUI(FastDriver.PaymentDetailsDlg.PaidbySellerOthers.FAGetValue().Replace("$", string.Empty), response1.InspectionRepairList[0].CDChargeList[0].PBOthersForSeller.ToString());
                paymentMethod = response1.InspectionRepairList[0].CDChargeList[0].AtClosingSellerPaymentMethodTypeID.ToString() == "CHK" ? "Check" : null;
                ServiceHelper.CompareWithUI(FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod, "selecteditem", paymentMethod);
                FastDriver.DialogBottomFrame.ClickDone();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally { FastDriver.WebDriver.Quit(); }
        }

        [TestMethod]
        public void REG0023_RemoveInspectionRepairOthers()
        {
            Reports.TestDescription = "Validate the RemoveInspectionRepairOthers web service.";
            try
            {
                #region Create a New file using the webservice.
                Reports.TestStep = "Create a New file using the webservice.";
                int fileID = GeneralFileServiceOperationsHelpers.CreateFile(FileRequestFactory.GetDetailedCreateFileDefaultRequest());
                string fileNumber = FASTWCFHelpers.FileService.GetOrderDetails(fileID).FileNumber;
                #endregion

                #region Create a inspection repair other instance for the file using WS.
                Reports.TestStep = "Create a inspection repair other instance for the file using WS.";
                var responseCreate = EscrowChargeProcessesHelpers.GetInspectionRepairOthersCreated(fileID, 1);
                OperationResponseExtensions.Validate(responseCreate);
                #endregion

                #region Invoke the webservice for the create inspection repair for others.
                Reports.TestStep = "Invoke the webservice for the create inspection repair for others.";
                var responseRemove = EscrowChargeProcessesHelpers.RemoveInspectionRepairOther(fileID, 1);
                OperationResponseExtensions.Validate(responseRemove);
                #endregion

                #region Login to file Side and verify that InspectionRepairOthers instance is removed at FAST.
                Reports.TestStep = "Login to the file side.";
                Login();

                Reports.TestStep = "Navigate to the file";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to the Event log and verify for create Inspection repair other instance log.";
                FastDriver.EventTrackingLog.Open();
                Support.AreEqual(responseCreate.StatusDescription, FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Create Inspection Repair]", 5, TableAction.GetText).Message, "Verify the HOA instace is created in UI.");
                Reports.TestStep = "verify for Remove  Inspection repair other instance log.";
                Support.AreEqual(responseRemove.StatusDescription, FastDriver.EventTrackingLog.EventTable.PerformTableAction(1, "[Remove Inspection Repair]", 5, TableAction.GetText).Message, "Verify the HOA instace is Removed in UI.");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally { FastDriver.WebDriver.Quit(); }
        }

        [TestMethod]
        public void REG0024_UpdateInspectionRepairPest()
        {
            try
            {
                Reports.TestDescription = "Verify UpdateInspectionRepairPest service";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetDetailedCreateFileDefaultRequest();
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a file using web service";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                string fileNum = FileService.GetOrderDetails(fileId).FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(fileNum);

                Reports.TestStep = "Create a Inspection Repair Pest instance (WS)";
                var pestRequest = EscrowRequestFactory.GetInspectionRepairPestRequest(fileId, 1, "BOA");
                EscrowChargeProcessesHelpers.CreateInspectionRepairPest(pestRequest);

                Reports.TestStep = "Navigate to Pest screen, validate GAB Code";
                FastDriver.InspectionRepairPest.Open();
                Support.AreEqual("BOA", FastDriver.InspectionRepairPest.LabelIDCode.FAGetText(), "GAB Code");

                Reports.TestStep = "Invoke UpdateInspectionRepairPest method, validate response (WS)";
                var request = EscrowRequestFactory.GetInspectionRepairPestRequest(fileId, 1, "1256");
                var response = EscrowChargeProcessesHelpers.UpdateInspectionRepairPest(request);
                Support.AreEqual("1", response.Status.ToString(), "Operation Status");
                Support.AreEqual("Inspection Repair Pest with Sequence No: 1 Updated successfully", response.StatusDescription.Clean(), "Operation Status Description");

                Reports.TestStep = "Navigate to Pest screen, validate GAB Code is now changed";
                FastDriver.InspectionRepairPest.Open();
                Support.AreEqual("1256", FastDriver.InspectionRepairPest.LabelIDCode.FAGetText().Clean(), "GAB Code");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally { FastDriver.WebDriver.Quit(); }
        }

        [TestMethod]
        public void REG0025_AddLenderLoanInvestor()
        {
            try
            {
                Reports.TestDescription = "Verify AddLenderLoanInvestor service";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.File.NewLoan.FileBusinessParty.AddrBookEntryID = AdminService.GetGABAddressBookEntryId("BOA", Convert.ToInt32(AutoConfig.SelectedRegionBUID));
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a file with BOA as a new lender using web service";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                string fileNum = FileService.GetOrderDetails(fileId).FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(fileNum);

                Reports.TestStep = "Invoke AddLenderLoanInvestor service";
                var AddLenderLoanInvestorRequest = EscrowRequestFactory.GetAddLenderLoanInvestorRequest(fileId);
                var AddLenderLoanInvestorResponse = EscrowService.AddLenderLoanInvestor(AddLenderLoanInvestorRequest);
                Support.AreEqual("1", AddLenderLoanInvestorResponse.Status.ToString(), "Status");
                Support.AreEqual("Loan Investor has been Added Successfully.", AddLenderLoanInvestorResponse.StatusDescription, "Status Description");

                Reports.TestStep = "Navigate to New Loan screen, click Loan Investors button";
                FastDriver.NewLoan.Open();
                FastDriver.NewLoan.LoanInvestors.FAClick();
                FastDriver.LoanInvestors.WaitForScreenToLoad();

                Reports.TestStep = "Validate Loan Investor is added";
                Support.AreEqual("1256", FastDriver.LoanInvestors.LoanInvestorSummmaryTable.PerformTableAction(2, 1, TableAction.GetText).Message.Clean(), "Loan Investor Addr Book ID");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0026_UpdateInspectionRepairSeptic()
        {
            try
            {
                Reports.TestDescription = "Verify UpdateInspectionRepairSeptic service";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetDetailedCreateFileDefaultRequest();
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a file using web service";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                string fileNum = FileService.GetOrderDetails(fileId).FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(fileNum);

                Reports.TestStep = "Create a Inspection Repair Septic instance (WS)";
                var septicRequest = EscrowRequestFactory.GetInspectionRepairSepticRequest(fileId, 1, "BOA");
                EscrowChargeProcessesHelpers.CreateInspectionRepairSeptic(septicRequest);

                Reports.TestStep = "Navigate to Septic screen, validate GAB Code";
                FastDriver.InspectionRepairSeptic.Open();
                Support.AreEqual("BOA", FastDriver.InspectionRepairSeptic.GABcodeLabel.FAGetText(), "GAB Code");

                Reports.TestStep = "Invoke UpdateInspectionRepairSeptic method, validate response (WS)";
                var request = EscrowRequestFactory.GetInspectionRepairSepticRequest(fileId, 1, "1256");
                var response = EscrowChargeProcessesHelpers.UpdateInspectionRepairSeptic(request);
                Support.AreEqual("1", response.Status.ToString(), "Operation Status");
                Support.AreEqual("Inspection Repair Septic with Sequence No: 1 Updated successfully", response.StatusDescription.Clean(), "Operation Status Description");

                Reports.TestStep = "Navigate to Septic screen, validate GAB Code has changed";
                FastDriver.InspectionRepairSeptic.Open();
                Support.AreEqual("1256", FastDriver.InspectionRepairSeptic.GABcodeLabel.FAGetText().Clean(), "GAB Code");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally { FastDriver.WebDriver.Quit(); }
        }

        [TestMethod]
        public void REG0027_UpdatePropertyTaxCheck()
        {
            try
            {
                Reports.TestDescription = "Verify UpdatePropertyTaxCheck service";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetDetailedCreateFileDefaultRequest();
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a file using web service";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                string fileNum = FileService.GetOrderDetails(fileId).FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(fileNum);

                Reports.TestStep = "Create a Property Tax Check instance (WS)";
                var propertyTaxCheckRequest = EscrowRequestFactory.GetPropertyTaxCheckRequest(fileId, 1, "BOA");
                EscrowChargeProcessesHelpers.CreatePropertyTaxCheck(propertyTaxCheckRequest);

                Reports.TestStep = "Navigate to Property Tax Check screen, validate GAB Code";
                FastDriver.PropertyTaxCheck.Open();
                Support.AreEqual("BOA", FastDriver.PropertyTaxCheck.GABcodeLabel.FAGetText().Clean(), "GAB Code");

                Reports.TestStep = "Invoke UpdatePropertyTaxCheck method, validate response (WS)";
                var request = EscrowRequestFactory.GetPropertyTaxCheckRequest(fileId, 1, "1256");
                var response = EscrowChargeProcessesHelpers.UpdatePropertyTaxCheck(request);
                Support.AreEqual("1", response.Status.ToString(), "Operation Status");
                Support.AreEqual("PropertyTax Created with Sequence No: 1 Updated successfully", response.StatusDescription.Clean(), "Operation Status Description");

                Reports.TestStep = "Navigate to Property Tax Check screen, validate GAB code has changed";
                FastDriver.PropertyTaxCheck.Open();
                Support.AreEqual("1256", FastDriver.PropertyTaxCheck.GABcodeLabel.FAGetText().Clean(), "GAB Code");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally { FastDriver.WebDriver.Quit(); }
        }

        [TestMethod]
        public void REG0028_UpdateSurvey()
        {
            try
            {
                Reports.TestDescription = "Verify UpdateSurvey service";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetDetailedCreateFileDefaultRequest();
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a file using web service";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                string fileNum = FileService.GetOrderDetails(fileId).FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(fileNum);

                Reports.TestStep = "Create a Survey instance (WS)";
                var surveyRequest = EscrowRequestFactory.GetSurveyRequest(fileId, 1, "BOA");
                EscrowChargeProcessesHelpers.CreateSurvey(surveyRequest);

                Reports.TestStep = "Navigate to Survey screen, validate GAB Code";
                FastDriver.SurveyDetail.Open();
                Support.AreEqual("BOA", FastDriver.SurveyDetail.IDcodeLabel.FAGetText().Clean(), "ID Code");

                Reports.TestStep = "Invoke UpdateSurvey method, validate response (WS)";
                var request = EscrowRequestFactory.GetSurveyRequest(fileId, 1, "1256");
                var response = EscrowChargeProcessesHelpers.UpdateSurvey(request);
                Support.AreEqual("1", response.Status.ToString(), "Operation Status");
                Support.AreEqual("Survey with Sequence No: 1 Updated successfully", response.StatusDescription.Clean(), "Operation Status Description");

                Reports.TestStep = "Navigate to Survey screen, validate ID Code is now blank";
                FastDriver.SurveyDetail.Open();
                Support.AreEqual("1256", FastDriver.SurveyDetail.IDcodeLabel.FAGetText().Clean(), "ID Code");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally { FastDriver.WebDriver.Quit(); }
        }

        [TestMethod]
        public void REG0029_CreateProration()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan();
                #endregion

                Reports.TestDescription = "Verify CreateProration() service.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                int fileid = FastDriver.FACreateFileGetFileId(fileRequest);
                var file = FileService.GetOrderDetails(fileid);
                FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

                Reports.TestStep = "Add Proration TAX using CreateProration method";
                var createProrationRequest = EscrowRequestFactory.GetProrationRequest(file.FileID, 1, ProrationType.TAX);
                EscrowService.CreateProration(createProrationRequest).Validate();

                Reports.TestStep = "Add Proration RENT using CreateProration method";
                EscrowService.CreateProration(EscrowRequestFactory.GetProrationRequest(file.FileID, 1, ProrationType.RENT)).Validate();

                Reports.TestStep = "Add Proration MISCELLANEOUS using CreateProration method";
                EscrowService.CreateProration(EscrowRequestFactory.GetProrationRequest(file.FileID, 1, ProrationType.MISCELLANEOUS)).Validate();

                Reports.TestStep = "Navigate to Proration Tax screen and open proration details";
                FastDriver.ProrationTax.Open();
                FastDriver.ProrationTax.ProrationTaxTable4.FADoubleClick();
                FastDriver.ProrationDetail.WaitForScreenToLoad();
                Support.AreEqual(createProrationRequest.ProrDetailsForCD.CreditSeller.Value, FastDriver.ProrationDetail.CreditSeller.IsSelected(), "CreditSeller");
                Support.AreEqual(createProrationRequest.ProrDetailsForCD.DayOfClosePaidbySeller.Value, FastDriver.ProrationDetail.DayofClosePaidbySeller.IsSelected(), "DayOfClosePaidbySeller");
                Support.AreEqual(createProrationRequest.ProrDetailsForCD.Amount.ToString().FormatAsMoney(), FastDriver.ProrationDetail.Amount.FAGetValue(), "Amount");
                Support.AreEqual(createProrationRequest.ProrDetailsForCD.AmountPeriod.ToString(), FastDriver.ProrationDetail.Per.FAGetSelectedItem(), "AmountPeriod");
                Support.AreEqual(createProrationRequest.ProrDetailsForCD.FromDate.Value.ToDateString(), FastDriver.ProrationDetail.FromDate.FAGetValue(), "FromDate");
                Support.AreEqual(createProrationRequest.ProrDetailsForCD.ToDate.Value.ToDateString(), FastDriver.ProrationDetail.ToDate.FAGetValue(), "ToDate");
                Support.AreEqual(createProrationRequest.ProrDetailsForCD.Description, FastDriver.ProrationDetail.Description.FAGetValue(), "Description");
                Support.AreEqual(createProrationRequest.ProrDetailsForCD.BuyerCharge.ToString().FormatAsMoney(), FastDriver.ProrationDetail.BuyerCharge.FAGetValue(), "BuyerCharge");
                Support.AreEqual(createProrationRequest.ProrDetailsForCD.SellerCharge.ToString().FormatAsMoney(), FastDriver.ProrationDetail.SellerCharge.FAGetValue(), "SellerCharge");

                Reports.TestStep = "Navigate to Proration Rent screen and open proration details";
                FastDriver.ProrationRent.Open();
                FastDriver.ProrationRent.ProrationTaxTable2.FADoubleClick();
                FastDriver.ProrationDetail.WaitForScreenToLoad();
                Support.AreEqual(createProrationRequest.ProrDetailsForCD.CreditSeller.Value, FastDriver.ProrationDetail.CreditSeller.IsSelected(), "CreditSeller");
                Support.AreEqual(createProrationRequest.ProrDetailsForCD.DayOfClosePaidbySeller.Value, FastDriver.ProrationDetail.DayofClosePaidbySeller.IsSelected(), "DayOfClosePaidbySeller");
                Support.AreEqual(createProrationRequest.ProrDetailsForCD.Amount.ToString().FormatAsMoney(), FastDriver.ProrationDetail.Amount.FAGetValue(), "Amount");
                Support.AreEqual(createProrationRequest.ProrDetailsForCD.AmountPeriod.ToString(), FastDriver.ProrationDetail.Per.FAGetSelectedItem(), "AmountPeriod");
                Support.AreEqual(createProrationRequest.ProrDetailsForCD.FromDate.Value.ToDateString(), FastDriver.ProrationDetail.FromDate.FAGetValue(), "FromDate");
                Support.AreEqual(createProrationRequest.ProrDetailsForCD.ToDate.Value.ToDateString(), FastDriver.ProrationDetail.ToDate.FAGetValue(), "ToDate");
                Support.AreEqual(createProrationRequest.ProrDetailsForCD.Description, FastDriver.ProrationDetail.Description.FAGetValue(), "Description");
                Support.AreEqual(createProrationRequest.ProrDetailsForCD.BuyerCharge.ToString().FormatAsMoney(), FastDriver.ProrationDetail.BuyerCharge.FAGetValue(), "BuyerCharge");
                Support.AreEqual(createProrationRequest.ProrDetailsForCD.SellerCharge.ToString().FormatAsMoney(), FastDriver.ProrationDetail.SellerCharge.FAGetValue(), "SellerCharge");

                Reports.TestStep = "Navigate to Proration Misc screen and open proration details";
                FastDriver.ProrationMisc.Open();
                FastDriver.ProrationMisc.ProrationTaxTable2.FADoubleClick();
                FastDriver.ProrationDetail.WaitForScreenToLoad();
                Support.AreEqual(createProrationRequest.ProrDetailsForCD.CreditSeller.Value, FastDriver.ProrationDetail.CreditSeller.IsSelected(), "CreditSeller");
                Support.AreEqual(createProrationRequest.ProrDetailsForCD.DayOfClosePaidbySeller.Value, FastDriver.ProrationDetail.DayofClosePaidbySeller.IsSelected(), "DayOfClosePaidbySeller");
                Support.AreEqual(createProrationRequest.ProrDetailsForCD.Amount.ToString().FormatAsMoney(), FastDriver.ProrationDetail.Amount.FAGetValue(), "Amount");
                Support.AreEqual(createProrationRequest.ProrDetailsForCD.AmountPeriod.ToString(), FastDriver.ProrationDetail.Per.FAGetSelectedItem(), "AmountPeriod");
                Support.AreEqual(createProrationRequest.ProrDetailsForCD.FromDate.Value.ToDateString(), FastDriver.ProrationDetail.FromDate.FAGetValue(), "FromDate");
                Support.AreEqual(createProrationRequest.ProrDetailsForCD.ToDate.Value.ToDateString(), FastDriver.ProrationDetail.ToDate.FAGetValue(), "ToDate");
                Support.AreEqual(createProrationRequest.ProrDetailsForCD.Description, FastDriver.ProrationDetail.Description.FAGetValue(), "Description");
                Support.AreEqual(createProrationRequest.ProrDetailsForCD.BuyerCharge.ToString().FormatAsMoney(), FastDriver.ProrationDetail.BuyerCharge.FAGetValue(), "BuyerCharge");
                Support.AreEqual(createProrationRequest.ProrDetailsForCD.SellerCharge.ToString().FormatAsMoney(), FastDriver.ProrationDetail.SellerCharge.FAGetValue(), "SellerCharge");
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        public void REG0030_GetHUDEscrowCharges()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan();
                #endregion

                Reports.TestDescription = "Verify GetHUDEscrowCharges() service.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                if (!AutoConfig.UseCDFormType)
                {
                    Reports.TestStep = "Create File using web service.";
                    int fileid = FastDriver.FACreateFileGetFileId(fileRequest);
                    var file = FileService.GetOrderDetails(fileid);
                    FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

                    Reports.TestStep = "PROVIDE THE HOME OWNER ASSOCIATION GAB";
                    FastDriver.HomeownerAssociation.Open();
                    FastDriver.HomeownerAssociation.FindGABCode("328");

                    Reports.TestStep = "PROVIDE THE HOME OWNER ASSOCIATION GAB";
                    FastDriver.HomeownerAssociation.AssociationChargeBuyerCharge.FASetText("100");
                    FastDriver.HomeownerAssociation.AssociationChargeSellerCharge.FASetText("200");
                    string chargeDescription = FastDriver.HomeownerAssociation.AssociationChargeDescription.FAGetValue();
                    FastDriver.BottomFrame.Done();

                    Reports.TestStep = "Verify GetHUDEscrowCharges Service Response";
                    var hudEscrowChargesresponse = EscrowService.GetHUDEscrowCharges(EscrowRequestFactory.GetHUDEscrowChargeRequest(file.FileID.Value,
                        new Filter { FilterResponseType = eFilterEscrowResponseType.CHARGE, FilterSection = eFilterSection.ALL }));
                    //hudEscrowChargesresponse.Validate(); //can't call this method because the response is not standard to other FAST methods

                    Support.AreEqual("100", hudEscrowChargesresponse.Charges[0].ChargeData.BuyerChargeAmount.ToString(), "BuyerChargeAmount");
                    Support.AreEqual("200", hudEscrowChargesresponse.Charges[4].ChargeData.SellerChargeAmount.ToString(), "SellerChargeAmount");
                }
                else
                {
                    Reports.TestStep = "Scenario only applicable for HUD.";
                    Reports.StatusUpdate("This test scenario only applicable for HUD", true);
                }
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        public void REG0031_GetHud1LineNumberDetails()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan();
                #endregion

                Reports.TestDescription = "Verify GetHud1LineNumberDetails() service.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                if (!AutoConfig.UseCDFormType)
                {
                    Reports.TestStep = "Create File using web service.";
                    int fileid = FastDriver.FACreateFileGetFileId(fileRequest);
                    var file = FileService.GetOrderDetails(fileid);
                    FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

                    Reports.TestStep = "Navigate to New Loan screen";
                    FastDriver.NewLoan.Open();
                    FastDriver.NewLoan.FindGABCode("508");

                    Reports.TestStep = "Open to Loan Charges screen";
                    FastDriver.NewLoan.ClickChargesTab();
                    FastDriver.NewLoan.LoanChargesGFE_3NewLoanChargesBuyerCredit.FASetText("10.10");
                    FastDriver.NewLoan.LenderCreditsIcon.FAClick();
                    FastDriver.NewLoan.LoanChargesGFE_6NewLoanCharges_BuyerCredit.FASetText("10.10");
                    FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_Expand.FAClick();
                    FastDriver.NewLoan.LoanChargesPrincipalreduction_Constructionholdback_BuyerCredit.FASetText("10.10");
                    FastDriver.BottomFrame.Done();
                    Playback.Wait(10 * 1000);

                    Reports.TestStep = "Invoke GetHud1LineNumberDetails Service Response";
                    var hud1LineNumberDetailsResponse = EscrowService.GetHud1LineNumberDetails(EscrowRequestFactory.GetServiceFileRequest(file.FileID));
                    hud1LineNumberDetailsResponse.Validate();
                    var chargeList = hud1LineNumberDetailsResponse.Hud1LineNumbers204Plus.NewLoan2AndMoreChargeList[0].HUD1ChargeList;

                    Reports.TestStep = "Navigate to Assign Charges to HUD-1 Line Numbers";
                    FastDriver.AssignChargestoHUD1LineNumbers.Open();
                    FastDriver.AssignChargestoHUD1LineNumbers.Expand204Section.FAClick();

                    Reports.TestStep = "Verify GetHud1LineNumberDetails Service Response";
                    Support.AreEqual(hud1LineNumberDetailsResponse.Hud1LineNumbers204Plus.NewLoan2AndMoreChargeList[0].GroupHeader, FastDriver.AssignChargestoHUD1LineNumbers.Section204PlusTable.PerformTableAction(2, 2, TableAction.GetText).Message, "GroupHeader");

                    Reports.TestStep = "Verify Section 204+";
                    for (int i = 0; i < chargeList.Length; i++)
                    {
                        Support.AreEqual(chargeList[i].Description, FastDriver.AssignChargestoHUD1LineNumbers.Section204PlusTable.PerformTableAction(i + 3, 2, TableAction.GetText).Message, "Charge Description");
                    }
                }
                else
                {
                    Reports.TestStep = "Scenario only applicable for HUD.";
                    Reports.StatusUpdate("This test scenario only applicable for HUD", true);
                }
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        public void REG0032_UpdateHud1LineNumbers()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan();
                #endregion

                Reports.TestDescription = "Verify UpdateHud1LineNumbers() service.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                if (!AutoConfig.UseCDFormType)
                {
                    Reports.TestStep = "Create File using web service.";
                    int fileid = FastDriver.FACreateFileGetFileId(fileRequest);
                    var file = FileService.GetOrderDetails(fileid);
                    FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

                    Reports.TestStep = "Navigate to Payoff Loan Screen to Enter Some Charges";
                    FastDriver.PayoffLoanDetails.Open();

                    Reports.TestStep = "Provide The PayOff Loan GAB";
                    FastDriver.PayoffLoanDetails.FindGABCode("328");

                    Reports.TestStep = "Open to Loan Charges screen";
                    FastDriver.PayoffLoanDetails.ClickChargesTab();
                    List<string> chargeDescriptions = new List<string>();
                    chargeDescriptions.Add(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction(2, 1, TableAction.GetInputValue).Message);
                    FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction(2, 3, TableAction.SetText, "100");
                    FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction(2, 4, TableAction.SetText, "10");
                    FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction(2, 5, TableAction.SetText, "100");
                    FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction(2, 6, TableAction.SetText, "10");
                    chargeDescriptions.Add(FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction(3, 1, TableAction.GetInputValue).Message);
                    FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction(3, 3, TableAction.SetText, "50");
                    FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction(3, 4, TableAction.SetText, "5");
                    FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction(3, 5, TableAction.SetText, "50");
                    FastDriver.PayoffLoanCharges.PayoffLoanChargesTable.PerformTableAction(3, 6, TableAction.SetText, "5");
                    FastDriver.BottomFrame.Done();
                    Playback.Wait(10 * 1000);

                    Reports.TestStep = "Invoke GetHud1LineNumberDetails Service Response";
                    var hud1LineNumberDetailsResponse = EscrowService.GetHud1LineNumberDetails(EscrowRequestFactory.GetServiceFileRequest(file.FileID));
                    hud1LineNumberDetailsResponse.Validate();
                    var hud1_104plus = hud1LineNumberDetailsResponse.Hud1LineNumbers104Plus;

                    Reports.TestStep = "Validate charge descriptions";
                    for (int i = 0; i < hud1_104plus.PayOffLoanChargeList[0].HUD1ChargeList.Length; i++)
                    {
                        Support.AreEqual(chargeDescriptions[i], hud1_104plus.PayOffLoanChargeList[0].HUD1ChargeList[i].Description, "Payoff Loan Charge Description");
                    }

                    #region Request data setup
                    hud1_104plus.PayOffLoanChargeList[0].DisplayOrderNum = 1;
                    hud1_104plus.PayOffLoanChargeList[0].HUD1ChargeList[0].ChargeProcessTypeCdID = 370;
                    hud1_104plus.PayOffLoanChargeList[0].HUD1ChargeList[0].DisplayOrderNum = 0;
                    hud1_104plus.PayOffLoanChargeList[0].HUD1ChargeList[0].HudLineNumber = 104;
                    hud1_104plus.PayOffLoanChargeList[0].HUD1ChargeList[0].SeqNum = 1;
                    hud1_104plus.PayOffLoanChargeList[0].HUD1ChargeList[1].ChargeProcessTypeCdID = 370;
                    hud1_104plus.PayOffLoanChargeList[0].HUD1ChargeList[1].HudLineNumber = 104;
                    hud1_104plus.PayOffLoanChargeList[0].HUD1ChargeList[1].SeqNum = 1;
                    hud1_104plus.PayOffLoanChargeList[0].HUDLineNum = 105;
                    hud1_104plus.PayOffLoanChargeList[0].SeqNum = 1;
                    hud1_104plus.PropertyTaxCheckChargeList = new GroupChargeSet
                    {
                        HUDLineNum = 104,
                        SeqNum = 1,
                        HUD1ChargeList = new Hud1ChargeSet[]
                        {
                            new Hud1ChargeSet
                            {
                                ChargeProcessTypeCdID = 373,
                                DisplayOrderNum = 0,
                                HudLineNumber = 104,
                                SeqNum = 1
                            }
                        }
                    };

                    var charges = new Hud1Charges
                    {
                        Hud1LineNumbers104Plus = hud1_104plus
                    };
                    #endregion

                    Reports.TestStep = "Add a Property Tax Check instance";
                    FastDriver.PropertyTaxCheck.Open();
                    FastDriver.PropertyTaxCheck.FindGABCode("BOA");
                    FastDriver.PropertyTaxCheck.PropertyTaxesBuyerCharge_1.FASetText("10.00");
                    FastDriver.BottomFrame.Done();
                    FastDriver.PropertyTaxCheck.WaitForScreenToLoad();
                    Thread.Sleep(10000);

                    Reports.TestStep = "Invoke UpdateHud1LineNumber Service Response";
                    var updateHud1LineNumberResponse = EscrowService.UpdateHud1LineNumbers(EscrowRequestFactory.GetHud1LineNumberRequest(file.FileID.Value, charges));
                    updateHud1LineNumberResponse.Validate();

                    Reports.TestStep = "Navigate to Assign Charges to HUD-1 Line Numbers";
                    FastDriver.AssignChargestoHUD1LineNumbers.Open();
                    FastDriver.AssignChargestoHUD1LineNumbers.Expand104Section.FAClick();

                    Reports.TestStep = "Verify Section 104+";
                    Support.AreEqual("104", FastDriver.AssignChargestoHUD1LineNumbers.Section104PlusTable.PerformTableAction(2, "Property Tax Check", 1, TableAction.GetInputValue).Message.Clean(), "Property Tax Check HUD1 Line Number");
                    Support.AreEqual("105", FastDriver.AssignChargestoHUD1LineNumbers.Section104PlusTable.PerformTableAction(2, "Payoff Loan 1 Charges", 1, TableAction.GetInputValue).Message.Clean(), "Payoff Loan 1 Charges HUD1 Line Number");
                    
                }
                else
                {
                    Reports.TestStep = "Scenario only applicable for HUD.";
                    Reports.StatusUpdate("This test scenario only applicable for HUD", true);
                }
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { FastDriver.WebDriver.Quit(); }
        }

        [TestMethod]
        public void REG0033_DeleteOutsideTitleCompany()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan();
                #endregion

                Reports.TestDescription = "Verify DeleteOutsideTitleCompany() service.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                int fileid = FastDriver.FACreateFileGetFileId(fileRequest);
                var file = FileService.GetOrderDetails(fileid);
                FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

                Reports.TestStep = "Create Outside Title Company Instance";
                FastDriver.OutsideTitleCompanyDetail.Open();
                FastDriver.OutsideTitleCompanyDetail.FindGAB("508");

                Reports.TestStep = "Add Title Services charges";
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(2, 3, TableAction.SetText, "10");
                FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(2, 5, TableAction.SetText, "1");

                Reports.TestStep = "Add Lenders Policy And Endorsements charges";
                FastDriver.OutsideTitleCompanyDetail.LendersPolicyAndEndorsementsTable.PerformTableAction(2, 3, TableAction.SetText, "50");
                FastDriver.OutsideTitleCompanyDetail.LendersPolicyAndEndorsementsTable.PerformTableAction(2, 5, TableAction.SetText, "5");

                Reports.TestStep = "Add Owner Policy And Endorsements charges";
                FastDriver.OutsideTitleCompanyDetail.OwnerPolicyAndEndorsementsTable.PerformTableAction(2, 3, TableAction.SetText, "30");
                FastDriver.OutsideTitleCompanyDetail.OwnerPolicyAndEndorsementsTable.PerformTableAction(2, 5, TableAction.SetText, "3");

                Reports.TestStep = "Add Recording Fees & Transfer Taxes charges";
                FastDriver.OutsideTitleCompanyDetail.RecFeesAndTTaxTable.PerformTableAction(2, 3, TableAction.SetText, "20");
                FastDriver.OutsideTitleCompanyDetail.RecFeesAndTTaxTable.PerformTableAction(2, 4, TableAction.SetText, "2");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Validate Outside Title Company is created";
                FastDriver.OutsideTitleCompanyDetail.Open();
                FastDriver.OutsideTitleCompanyDetail.WaitForScreenToLoad();
                Support.AreEqual("508", FastDriver.OutsideTitleCompanyDetail.IDCode.FAGetText(), "IDCode label");

                Reports.TestStep = "Invoke DeleteOutsideTitleCompany Service Response";
                EscrowService.DeleteOutsideTitleCompany(EscrowRequestFactory.GetDeleteOutsideTitleCompanyRequest(file.FileID.Value, 1)).Validate();

                Reports.TestStep = "Validate Outside Title Company instance is deleted";
                FastDriver.OutsideTitleCompanyDetail.Open();
                Support.AreEqual("", FastDriver.OutsideTitleCompanyDetail.IDCode.FAGetText().Clean(), "IDCode label");

                Reports.TestStep = "Validate Title Services charges";
                Support.AreEqual("", FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(2, 3, TableAction.GetInputValue).Message);
                Support.AreEqual("", FastDriver.OutsideTitleCompanyDetail.TitleServicesTable.PerformTableAction(2, 5, TableAction.GetInputValue).Message);

                Reports.TestStep = "Validate Lenders Policy And Endorsements charges";
                Support.AreEqual("", FastDriver.OutsideTitleCompanyDetail.LendersPolicyAndEndorsementsTable.PerformTableAction(2, 3, TableAction.GetInputValue).Message);
                Support.AreEqual("", FastDriver.OutsideTitleCompanyDetail.LendersPolicyAndEndorsementsTable.PerformTableAction(2, 5, TableAction.GetInputValue).Message);

                Reports.TestStep = "Validate Owner Policy And Endorsements charges";
                Support.AreEqual("", FastDriver.OutsideTitleCompanyDetail.OwnerPolicyAndEndorsementsTable.PerformTableAction(2, 3, TableAction.GetInputValue).Message);
                Support.AreEqual("", FastDriver.OutsideTitleCompanyDetail.OwnerPolicyAndEndorsementsTable.PerformTableAction(2, 5, TableAction.GetInputValue).Message);

                Reports.TestStep = "Validate Recording Fees & Transfer Taxes charges";
                Support.AreEqual("", FastDriver.OutsideTitleCompanyDetail.RecFeesAndTTaxTable.PerformTableAction(2, 3, TableAction.GetInputValue).Message);
                Support.AreEqual("", FastDriver.OutsideTitleCompanyDetail.RecFeesAndTTaxTable.PerformTableAction(2, 4, TableAction.GetInputValue).Message);
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        public void REG0034_DeleteOutsideEscrowCompany()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan();
                #endregion

                Reports.TestDescription = "Verify DeleteOutsideEscrowCompany() service.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                var file = FileService.GetOrderDetails(fileId);
                FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

                Reports.TestStep = "Create Outside Escrow Company Instance (WS)";
                var request1 = EscrowRequestFactory.GetOECRequest(fileId, 1, "BOA");
                var response1 = EscrowChargeProcessesHelpers.CreateOutsideEscrowCompany(request1);

                Reports.TestStep = "Validate Outside Escrow Company is created";
                FastDriver.OutsideEscrowCompanyDetail.Open();
                Support.AreEqual("BOA", FastDriver.OutsideEscrowCompanyDetail.GABcodeLabel.FAGetText().Clean(), "ID Code");

                Reports.TestStep = "Invoke DeleteOutsideEscrowCompany web method, validate response (WS)";
                var request = EscrowRequestFactory.GetOECRequest(fileId, 1, "BOA");
                var response = EscrowChargeProcessesHelpers.DeleteOutsideEscrowCompany(request);
                response.Validate();

                Reports.TestStep = "Validate Outside Escrow Company instance is deleted";
                FastDriver.OutsideEscrowCompanyDetail.Open();
                Support.AreEqual("", FastDriver.OutsideEscrowCompanyDetail.GABcodeLabel.FAGetText().Clean(), "ID Code");
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { FastDriver.WebDriver.Quit(); }
        }

        [TestMethod]
        public void REG0035_GetHoldFundsSummary()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan();
                #endregion

                Reports.TestDescription = "Verify GetHoldFundsSummary() service.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                var file = FileService.GetOrderDetails(fileId);
                FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

                Reports.TestStep = "Create Two Hold Funds Instances (WS)";
                var request1 = EscrowRequestFactory.GetHoldFundsSaveRequest(fileId, 1, "BOA");
                var response1 = EscrowChargeProcessesHelpers.CreateHoldFunds(request1);
                response1.Validate();
                var response2 = EscrowChargeProcessesHelpers.CreateHoldFunds(request1);
                response2.Validate();

                Reports.TestStep = "Invoke GetHoldFundsSummary web method, validate response (WS)";
                var request = EscrowRequestFactory.GetHoldFundsSummaryRequest(fileId);
                var response = EscrowChargeProcessesHelpers.GetHoldFundsSummary(request);
                response.Validate();

                Reports.TestStep = "Validate Hold Funds screen, validate response";
                FastDriver.HoldFundsSummary.Open();
                Support.AreEqual((FastDriver.HoldFundsSummary.SummaryTable.GetRowCount() - 1).ToString(), response.TotalNumberofRecords.ToString().Clean(), "Number of Records");
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { FastDriver.WebDriver.Quit(); }
        }

        [TestMethod]
        public void REG0036_GetHoldFundsDetails()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan();
                #endregion

                Reports.TestDescription = "Verify GetHoldFundsDetails() service.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                var file = FileService.GetOrderDetails(fileId);
                FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

                Reports.TestStep = "Create a Hold Funds Instance (WS)";
                var request1 = EscrowRequestFactory.GetHoldFundsSaveRequest(fileId, 1, "BOA");
                var response1 = EscrowChargeProcessesHelpers.CreateHoldFunds(request1);
                response1.Validate();

                Reports.TestStep = "Invoke GetHoldFundsDetails web method, validate response (WS)";
                var request = EscrowRequestFactory.GetGetHoldFundsRequest(fileId, 1);
                var response = EscrowChargeProcessesHelpers.GetHoldFundsDetails(request);
                response.Validate();

                Reports.TestStep = "Validate Hold Funds screen, validate response";
                FastDriver.HoldFunds.Open();
                FastDriver.HoldFunds.HoldFundTable.PerformTableAction(2, 1, TableAction.Click);
                Support.AreEqual("BOA", response.HoldFundsDisbursement[0].HoldFundsFileBusinessParty.IDCode.Clean(), "GAB Code");
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { FastDriver.WebDriver.Quit(); }
        }

        [TestMethod]
        public void REG0037_RemoveHoldFunds()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan();
                #endregion

                Reports.TestDescription = "Verify RemoveHoldFunds() service.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                var file = FileService.GetOrderDetails(fileId);
                FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

                Reports.TestStep = "Create a Hold Funds Instance (WS)";
                var request1 = EscrowRequestFactory.GetHoldFundsSaveRequest(fileId, 1, "BOA");
                var response1 = EscrowChargeProcessesHelpers.CreateHoldFunds(request1);
                response1.Validate();

                Reports.TestStep = "Navigate Hold Funds screen, validate GAB Code";
                FastDriver.HoldFunds.Open();
                FastDriver.HoldFunds.HoldFundTable.PerformTableAction(2, 1, TableAction.Click);
                Support.AreEqual("BOA", FastDriver.HoldFunds.GABCode.FAGetText().Clean(), "GAB Code");

                Reports.TestStep = "Invoke RemoveHoldFunds web method, validate response (WS)";
                var request = EscrowRequestFactory.GetHoldFundsRemoveRequest(fileId, 1);
                var response = EscrowChargeProcessesHelpers.RemoveHoldFunds(request);
                response.Validate();

                Reports.TestStep = "Navigate Hold Funds screen, validate Hold Funds instance has been removed";
                FastDriver.HoldFunds.Open();
                Support.AreEqual("1", FastDriver.HoldFunds.HoldFundTable.GetRowCount().ToString(), "Hold Fund Table");
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { FastDriver.WebDriver.Quit(); }
        }

        [TestMethod]
        public void REG0038_CreateInspectionRepairPest()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan();
                #endregion

                Reports.TestDescription = "Verify CreateInspectionRepairPest() service.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                var file = FileService.GetOrderDetails(FastDriver.FACreateFileGetFileId(fileRequest));
                FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

                Reports.TestStep = "Create Inspection Repair Pest Instance";
                var inspectionRepairRequest = EscrowRequestFactory.GetInspectionRepairPestRequest(file.FileID, 1, "boa", DateTime.Now.ToPST());
                EscrowService.CreateInspectionRepairPest(inspectionRepairRequest).Validate();

                var chargeList = inspectionRepairRequest.oInspectionRepairDetails.CDChargeList;

                Reports.TestStep = "Open Inspection Repair Pest Screen";
                FastDriver.InspectionRepairPest.Open();

                Reports.TestStep = "Validate Inspection Repair Pest Charges";
                Support.AreEqual(chargeList[0].Description, FastDriver.InspectionRepairPest.description.FAGetValue(), "description");
                Support.AreEqual(chargeList[0].BuyerCharge.ToString().FormatAsMoney(), FastDriver.InspectionRepairPest.BuyerCharge.FAGetValue(), "BuyerCharge");
                Support.AreEqual(chargeList[0].SellerCharge.ToString().FormatAsMoney(), FastDriver.InspectionRepairPest.SellerCharge.FAGetValue(), "SellerCharge");
                Support.AreEqual(chargeList[1].Description, FastDriver.InspectionRepairPest.description1.FAGetValue(), "description1");
                Support.AreEqual(chargeList[1].BuyerCharge.ToString().FormatAsMoney(), FastDriver.InspectionRepairPest.buyerCharge1.FAGetValue(), "buyerCharge1");
                Support.AreEqual(chargeList[1].SellerCharge.ToString().FormatAsMoney(), FastDriver.InspectionRepairPest.SellerCharge1.FAGetValue(), "SellerCharge1");

                Reports.TestStep = "Validate Inspection Repair Pest Dates";
                Support.AreEqual(inspectionRepairRequest.oInspectionRepairDetails.ReportInfo.FurnishedType.ToString(), FastDriver.InspectionRepairPest.FurnishedBy.FAGetSelectedItem(), "FurnishedBy");
                Support.AreEqual(inspectionRepairRequest.oInspectionRepairDetails.ReportInfo.Within.ToString(), FastDriver.InspectionRepairPest.WithinDays.FAGetValue(), "WithinDays");
                Support.AreEqual(inspectionRepairRequest.oInspectionRepairDetails.ReportInfo.DateOrdered.Value.ToDateString(), FastDriver.InspectionRepairPest.OrderDate.FAGetValue(), "OrderDate");
                Support.AreEqual(inspectionRepairRequest.oInspectionRepairDetails.ReportInfo.DueDate.Value.ToDateString(), FastDriver.InspectionRepairPest.DueDate.FAGetValue(), "DueDate");
                Support.AreEqual(inspectionRepairRequest.oInspectionRepairDetails.ReportInfo.FollowUpDate.Value.ToDateString(), FastDriver.InspectionRepairPest.FollowUpDate.FAGetValue(), "FollowUpDate");
                Support.AreEqual(inspectionRepairRequest.oInspectionRepairDetails.ReportInfo.CompletionDate.Value.ToDateString(), FastDriver.InspectionRepairPest.CompleteDate.FAGetValue(), "CompleteDate");
                Support.AreEqual(inspectionRepairRequest.oInspectionRepairDetails.ReportInfo.ReportDate.Value.ToDateString(), FastDriver.InspectionRepairPest.ReportDate.FAGetValue(), "ReportDate");

                Reports.TestStep = "Validate payment Details 1";
                FastDriver.InspectionRepairPest.description.FADoubleClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                Support.AreEqual(chargeList[0].BuyerCharge.ToString().FormatAsMoney(true), FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue(), "BuyerCharge");
                Support.AreEqual("Check", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FAGetSelectedItem(), "PaidbyBuyerAtClosingPaymentMethod");
                Support.AreEqual(chargeList[0].SellerCharge.ToString().FormatAsMoney(true), FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue(), "SellerCharge");
                Support.AreEqual("Check", FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod.FAGetSelectedItem(), "PaidbySellerAtClosingPaymentMethod");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.InspectionRepairPest.WaitForScreenToLoad();

                Reports.TestStep = "Validate payment Details 2";
                FastDriver.InspectionRepairPest.WaitForScreenToLoad();
                FastDriver.InspectionRepairPest.description1.FADoubleClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                Support.AreEqual(chargeList[1].BuyerCharge.ToString().FormatAsMoney(true), FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue(), "BuyerCharge");
                Support.AreEqual("Check", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FAGetSelectedItem(), "PaidbyBuyerAtClosingPaymentMethod");
                Support.AreEqual(chargeList[1].SellerCharge.ToString().FormatAsMoney(true), FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue(), "SellerCharge");
                Support.AreEqual("Check", FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod.FAGetSelectedItem(), "PaidbySellerAtClosingPaymentMethod");
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Click Done";
                FastDriver.InspectionRepairPest.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        public void REG0039_CreateInspectionRepairSeptic()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan();
                #endregion

                Reports.TestDescription = "Verify CreateInspectionRepairSeptic() service.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                var file = FileService.GetOrderDetails(FastDriver.FACreateFileGetFileId(fileRequest));
                FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

                Reports.TestStep = "Create Inspection Repair Septic Instance";
                var inspectionRepairRequest = EscrowRequestFactory.GetInspectionRepairSepticRequest(file.FileID, 1, "boa", DateTime.Now.ToPST());
                EscrowService.CreateInspectionRepairSeptic(inspectionRepairRequest).Validate();

                var chargeList = inspectionRepairRequest.oInspectionRepairDetails.CDChargeList;

                Reports.TestStep = "Open Inspection Repair Septic Screen";
                FastDriver.InspectionRepairSeptic.Open();

                Reports.TestStep = "Validate Inspection Repair Septic Charges";
                Support.AreEqual(chargeList[0].Description, FastDriver.InspectionRepairSeptic.description.FAGetValue(), "description");
                Support.AreEqual(chargeList[0].BuyerCharge.ToString().FormatAsMoney(), FastDriver.InspectionRepairSeptic.BuyerCharge.FAGetValue(), "BuyerCharge");
                Support.AreEqual(chargeList[0].SellerCharge.ToString().FormatAsMoney(), FastDriver.InspectionRepairSeptic.SellerCharge.FAGetValue(), "SellerCharge");

                Reports.TestStep = "Validate Inspection Repair Septic Dates";
                Support.AreEqual(inspectionRepairRequest.oInspectionRepairDetails.ReportInfo.FurnishedType.ToString(), FastDriver.InspectionRepairSeptic.FurnishedBy.FAGetSelectedItem(), "FurnishedBy");
                Support.AreEqual(inspectionRepairRequest.oInspectionRepairDetails.ReportInfo.Within.ToString(), FastDriver.InspectionRepairSeptic.WithinDays.FAGetValue(), "WithinDays");
                Support.AreEqual(inspectionRepairRequest.oInspectionRepairDetails.ReportInfo.DateOrdered.Value.ToDateString(), FastDriver.InspectionRepairSeptic.OrderDate.FAGetValue(), "OrderDate");
                Support.AreEqual(inspectionRepairRequest.oInspectionRepairDetails.ReportInfo.DueDate.Value.ToDateString(), FastDriver.InspectionRepairSeptic.DueDate.FAGetValue(), "DueDate");
                Support.AreEqual(inspectionRepairRequest.oInspectionRepairDetails.ReportInfo.FollowUpDate.Value.ToDateString(), FastDriver.InspectionRepairSeptic.FollowUpDate.FAGetValue(), "FollowUpDate");
                Support.AreEqual(inspectionRepairRequest.oInspectionRepairDetails.ReportInfo.CompletionDate.Value.ToDateString(), FastDriver.InspectionRepairSeptic.CompleteDate.FAGetValue(), "CompleteDate");
                Support.AreEqual(inspectionRepairRequest.oInspectionRepairDetails.ReportInfo.ReportDate.Value.ToDateString(), FastDriver.InspectionRepairSeptic.ReportDate.FAGetValue(), "ReportDate");

                Reports.TestStep = "Click Done";
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        public void REG0040_GetInspectionRepairPestDetails()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan();
                #endregion

                Reports.TestDescription = "Verify CreateInspectionRepairPest() service.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                var file = FileService.GetOrderDetails(FastDriver.FACreateFileGetFileId(fileRequest));
                FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

                Reports.TestStep = "Create Inspection Repair Pest Instance";
                EscrowService.CreateInspectionRepairPest(EscrowRequestFactory.GetInspectionRepairPestRequest(file.FileID, 1, "boa", DateTime.Now.ToPST())).Validate();

                Reports.TestStep = "Open Inspection Repair Pest Screen";
                FastDriver.InspectionRepairPest.Open();

                Reports.TestStep = "Invoke Inspection Repair Pest Instance";
                var inspectionRepairDetails = EscrowService.GetInspectionRepairPestDetails(EscrowRequestFactory.GetIRPestDetailsRequest(file.FileID, 1));
                inspectionRepairDetails.Validate();

                Reports.TestStep = "Validate Inspection Repair Pest Charges";
                Support.AreEqual(inspectionRepairDetails.InspectionRepairCharges.CdChargesList[0].Description, FastDriver.InspectionRepairPest.description.FAGetValue(), "description");
                Support.AreEqual(inspectionRepairDetails.InspectionRepairCharges.CdChargesList[0].BuyerCharge.ToString().FormatAsMoney(), FastDriver.InspectionRepairPest.BuyerCharge.FAGetValue(), "BuyerCharge");
                Support.AreEqual(inspectionRepairDetails.InspectionRepairCharges.CdChargesList[0].SellerCharge.ToString().FormatAsMoney(), FastDriver.InspectionRepairPest.SellerCharge.FAGetValue(), "SellerCharge");
                Support.AreEqual(inspectionRepairDetails.InspectionRepairCharges.CdChargesList[1].Description, FastDriver.InspectionRepairPest.description1.FAGetValue(), "description1");
                Support.AreEqual(inspectionRepairDetails.InspectionRepairCharges.CdChargesList[1].BuyerCharge.ToString().FormatAsMoney(), FastDriver.InspectionRepairPest.buyerCharge1.FAGetValue(), "buyerCharge1");
                Support.AreEqual(inspectionRepairDetails.InspectionRepairCharges.CdChargesList[1].SellerCharge.ToString().FormatAsMoney(), FastDriver.InspectionRepairPest.SellerCharge1.FAGetValue(), "SellerCharge1");

                Reports.TestStep = "Validate Inspection Repair Pest Dates";
                Support.AreEqual(inspectionRepairDetails.ReportInfo.FurnishedType.ToString(), FastDriver.InspectionRepairPest.FurnishedBy.FAGetSelectedItem(), "FurnishedBy");
                Support.AreEqual(inspectionRepairDetails.ReportInfo.Within.ToString(), FastDriver.InspectionRepairPest.WithinDays.FAGetValue(), "WithinDays");
                Support.AreEqual(inspectionRepairDetails.ReportInfo.DateOrdered.Value.ToDateString(), FastDriver.InspectionRepairPest.OrderDate.FAGetValue(), "OrderDate");
                Support.AreEqual(inspectionRepairDetails.ReportInfo.DueDate.Value.ToDateString(), FastDriver.InspectionRepairPest.DueDate.FAGetValue(), "DueDate");
                Support.AreEqual(inspectionRepairDetails.ReportInfo.FollowUpDate.Value.ToDateString(), FastDriver.InspectionRepairPest.FollowUpDate.FAGetValue(), "FollowUpDate");
                Support.AreEqual(inspectionRepairDetails.ReportInfo.CompletionDate.Value.ToDateString(), FastDriver.InspectionRepairPest.CompleteDate.FAGetValue(), "CompleteDate");
                Support.AreEqual(inspectionRepairDetails.ReportInfo.ReportDate.Value.ToDateString(), FastDriver.InspectionRepairPest.ReportDate.FAGetValue(), "ReportDate");

                Reports.TestStep = "Validate payment Details 1";
                FastDriver.InspectionRepairPest.description.FADoubleClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                Support.AreEqual(inspectionRepairDetails.InspectionRepairCharges.CdChargesList[0].BuyerCharge.ToString().FormatAsMoney(true), FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue(), "BuyerCharge");
                Support.AreEqual("Check", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FAGetSelectedItem(), "PaidbyBuyerAtClosingPaymentMethod");
                Support.AreEqual(inspectionRepairDetails.InspectionRepairCharges.CdChargesList[0].SellerCharge.ToString().FormatAsMoney(true), FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue(), "SellerCharge");
                Support.AreEqual("Check", FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod.FAGetSelectedItem(), "PaidbySellerAtClosingPaymentMethod");
                FastDriver.DialogBottomFrame.ClickDone();
                FastDriver.InspectionRepairPest.WaitForScreenToLoad();

                Reports.TestStep = "Validate payment Details 2";
                FastDriver.InspectionRepairPest.WaitForScreenToLoad();
                FastDriver.InspectionRepairPest.description1.FADoubleClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                Support.AreEqual(inspectionRepairDetails.InspectionRepairCharges.CdChargesList[1].BuyerCharge.ToString().FormatAsMoney(true), FastDriver.PaymentDetailsDlg.BuyerCharge.FAGetValue(), "BuyerCharge");
                Support.AreEqual("Check", FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosingPaymentMethod.FAGetSelectedItem(), "PaidbyBuyerAtClosingPaymentMethod");
                Support.AreEqual(inspectionRepairDetails.InspectionRepairCharges.CdChargesList[1].SellerCharge.ToString().FormatAsMoney(true), FastDriver.PaymentDetailsDlg.SellerCharge.FAGetValue(), "SellerCharge");
                Support.AreEqual("Check", FastDriver.PaymentDetailsDlg.PaidbySellerAtClosingPaymentMethod.FAGetSelectedItem(), "PaidbySellerAtClosingPaymentMethod");
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Click Done";
                FastDriver.InspectionRepairPest.WaitForScreenToLoad();
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        public void REG0041_GetInspectionRepairSepticDetails()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan();
                #endregion

                Reports.TestDescription = "Verify GetInspectionRepairSepticDetails() service.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                var file = FileService.GetOrderDetails(FastDriver.FACreateFileGetFileId(fileRequest));
                FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

                Reports.TestStep = "Create Inspection Repair Septic Instance";
                EscrowService.CreateInspectionRepairSeptic(EscrowRequestFactory.GetInspectionRepairSepticRequest(file.FileID, 1, "boa", DateTime.Now.ToPST())).Validate();

                Reports.TestStep = "Open Inspection Repair Septic Screen";
                FastDriver.InspectionRepairSeptic.Open();

                Reports.TestStep = "Invoke Inspection Repair Pest Instance";
                var inspectionRepairDetails = EscrowService.GetInspectionRepairSepticDetails(EscrowRequestFactory.GetIRSepticDetailsRequest(file.FileID, 1));
                inspectionRepairDetails.Validate();

                Reports.TestStep = "Validate Inspection Repair Septic Charges";
                Support.AreEqual(inspectionRepairDetails.InspectionRepairCharges.CdChargesList[0].Description, FastDriver.InspectionRepairSeptic.description.FAGetValue(), "description");
                Support.AreEqual(inspectionRepairDetails.InspectionRepairCharges.CdChargesList[0].BuyerCharge.ToString().FormatAsMoney(), FastDriver.InspectionRepairSeptic.BuyerCharge.FAGetValue(), "BuyerCharge");
                Support.AreEqual(inspectionRepairDetails.InspectionRepairCharges.CdChargesList[0].SellerCharge.ToString().FormatAsMoney(), FastDriver.InspectionRepairSeptic.SellerCharge.FAGetValue(), "SellerCharge");

                Reports.TestStep = "Validate Inspection Repair Septic Dates";
                Support.AreEqual(inspectionRepairDetails.ReportInfo.FurnishedType.ToString(), FastDriver.InspectionRepairSeptic.FurnishedBy.FAGetSelectedItem(), "FurnishedBy");
                Support.AreEqual(inspectionRepairDetails.ReportInfo.Within.ToString(), FastDriver.InspectionRepairSeptic.WithinDays.FAGetValue(), "WithinDays");
                Support.AreEqual(inspectionRepairDetails.ReportInfo.DateOrdered.Value.ToDateString(), FastDriver.InspectionRepairSeptic.OrderDate.FAGetValue(), "OrderDate");
                Support.AreEqual(inspectionRepairDetails.ReportInfo.DueDate.Value.ToDateString(), FastDriver.InspectionRepairSeptic.DueDate.FAGetValue(), "DueDate");
                Support.AreEqual(inspectionRepairDetails.ReportInfo.FollowUpDate.Value.ToDateString(), FastDriver.InspectionRepairSeptic.FollowUpDate.FAGetValue(), "FollowUpDate");
                Support.AreEqual(inspectionRepairDetails.ReportInfo.CompletionDate.Value.ToDateString(), FastDriver.InspectionRepairSeptic.CompleteDate.FAGetValue(), "CompleteDate");
                Support.AreEqual(inspectionRepairDetails.ReportInfo.ReportDate.Value.ToDateString(), FastDriver.InspectionRepairSeptic.ReportDate.FAGetValue(), "ReportDate");

                Reports.TestStep = "Click Done";
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        public void REG0042_GetInspectionRepairPestSummary()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan();
                #endregion

                Reports.TestDescription = "Verify GetInspectionRepairPestSummary() service.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                var file = FileService.GetOrderDetails(FastDriver.FACreateFileGetFileId(fileRequest));
                FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

                Reports.TestStep = "Create Inspection Repair Pest Instance";
                EscrowService.CreateInspectionRepairPest(EscrowRequestFactory.GetInspectionRepairPestRequest(file.FileID, 1, "boa", DateTime.Now.ToPST())).Validate();
                EscrowService.CreateInspectionRepairPest(EscrowRequestFactory.GetInspectionRepairPestRequest(file.FileID, 1, "247", DateTime.Now.ToPST())).Validate();

                Reports.TestStep = "Open Inspection Repair Pest Screen";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.InspectionRepairSummary>("Home>Order Entry>Escrow Charge Processes>Inspection Repair>Pest").WaitForScreenToLoad();

                Reports.TestStep = "Invoke Inspection Repair Pest Instance";
                var inspectionRepairSummary = EscrowService.GetInspectionRepairPestSummary(EscrowRequestFactory.GetIRPSRequest(file.FileID));
                inspectionRepairSummary.Validate();

                Reports.TestStep = "Validate instance count";
                Support.AreEqual(inspectionRepairSummary.InspectionRepairSummary.Length.ToString(), FastDriver.InspectionRepairSummary.InstanceCount.FAGetText().Split(':')[1], "Instance count");
                Support.AreEqual(inspectionRepairSummary.InspectionRepairSummary.Length.ToString(), (FastDriver.InspectionRepairSummary.SummaryTable.GetRowCount() - 1).ToString(), "Row count");

                Reports.TestStep = "Validate GAB Codes";
                string message = FastDriver.InspectionRepairSummary.SummaryTable.PerformTableAction(2, 2, TableAction.GetText).Message;
                Support.AreEqual(inspectionRepairSummary.InspectionRepairSummary[0].BusOrgName, message, "GAB Name");
                message = FastDriver.InspectionRepairSummary.SummaryTable.PerformTableAction(3, 2, TableAction.GetText).Message;
                Support.AreEqual(inspectionRepairSummary.InspectionRepairSummary[1].BusOrgName, message, "GAB Name");
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        public void REG0043_GetPayOffLoanDetails_US729637()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                #endregion

                Reports.TestDescription = "Verify GetOrderDetails() and GetPayOffLoanDetails() services are returning correct LEAmount/Rounded LEAmount";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a file using Web Service";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);

                Reports.TestStep = "Invoke CreatePayOffLoan service";
                var createPayOffRequest = EscrowRequestFactory.GetDefaultPayoffLoanRequestWithCharge(fileId.ToString());//
                var createPayOffResponse = EscrowService.CreatePayoffLoan(createPayOffRequest);
                createPayOffResponse.Validate();

                Reports.TestStep = "Invoke GetOrderDetails service";
                var file = FileService.GetOrderDetails(fileId);

                Reports.TestStep = "Invoke GetPayOffLoanDetails service";
                var getPayOffRequest = EscrowRequestFactory.GetGetPayoffLoanRequest(fileId);
                var getPayOffResponse = EscrowService.GetPayoffLoanDetails(getPayOffRequest);
                getPayOffResponse.Validate();

                Reports.TestStep = "Open the file in FAST UI";
                FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

                Reports.TestStep = "Navigate to Payoff Loan screen";
                FastDriver.PayoffLoanDetails.Open();

                Reports.TestStep = "Click on Charges tab";
                FastDriver.PayoffLoanDetails.ClickChargesTab();

                Reports.TestStep = "Click on Payment Details under Payoff Loan Charges section";
                FastDriver.PayoffLoanCharges.PayoffLoanChargesPaymentDetails.FAClick();
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad(FastDriver.PaymentDetailsDlg.LoanEstimateUnrounded);

                Reports.TestStep = "Validate data on the screen with the response from Web service [US729637]";
                Support.AreEqual(file.PayOffLoan[0].CDLoanCharges.LEAmount.Value.ToString().FormatAsMoney(), FastDriver.PaymentDetailsDlg.LoanEstimateUnrounded.FAGetValue().Remove(0, 1), "LEAmount on GetOrderDetails response");
                Support.AreEqual(file.PayOffLoan[0].CDLoanCharges.RoundedLEAmount.Value.ToString().FormatAsMoney(), FastDriver.PaymentDetailsDlg.LoanEstimateRounded.FAGetValue().Remove(0, 1), "Rounded LEAmount on GetOrderDetails response");
                Support.AreEqual(getPayOffResponse.PayOffLoanSummary[0].CDLoanCharges.LEAmount.Value.ToString().FormatAsMoney(), FastDriver.PaymentDetailsDlg.LoanEstimateUnrounded.FAGetValue().Remove(0, 1), "LEAmount on GetPayOffLoan response");
                Support.AreEqual(getPayOffResponse.PayOffLoanSummary[0].CDLoanCharges.RoundedLEAmount.Value.ToString().FormatAsMoney(), FastDriver.PaymentDetailsDlg.LoanEstimateRounded.FAGetValue().Remove(0, 1), "Rounded LEAmount on GetPayOffLoan response");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        [TestMethod]
        public void REG0044_UpdateDepositInEscrow()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                #endregion

                Reports.TestDescription = "Verify UpdateDepositInEscrow() Service";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a file using web service";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                var file = FileService.GetOrderDetails(fileId).FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(file);

                Reports.TestStep = "Invoke CreateDepositInEscrow Service";
                var CreateDepositInEscrowRequest = EscrowRequestFactory.GetDepositInEscrowRequest(fileId);
                CreateDepositInEscrowRequest.DepositInEscrow.DepositEscrow.ReceivedFrom = "Other";
                CreateDepositInEscrowRequest.DepositInEscrow.DepositEscrow.IssueDate = DateTime.Now.ToPST();
                CreateDepositInEscrowRequest.DepositInEscrow.DepositEscrow.TypeFunds = "Cash";
                CreateDepositInEscrowRequest.DepositInEscrow.DepositEscrow.TransactionDate = DateTime.Now.ToPST();
                CreateDepositInEscrowRequest.DepositInEscrow.DepositEscrow.Representing = "Additional Closing Costs";

                var CreateDepositInEscrowResponse = EscrowService.CreateDepositInEscrow(CreateDepositInEscrowRequest);
                CreateDepositInEscrowResponse.Validate();

                Reports.TestStep = "Navigate to Deposit/Receipt History screen and select the added deposit";
                FastDriver.DepositReceiptHistory.Open();
                FastDriver.DepositReceiptHistory.ReceiptsDepositActivityTable.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.DepositReceiptHistory.ViewDetails.FAClick();
                FastDriver.DepositInEscrow.WaitForScreenToLoad(FastDriver.DepositInEscrow.Amount);

                Reports.TestStep = "Verify Deposit In Escrow is filled with data from web service request";
                Support.AreEqual(CreateDepositInEscrowRequest.DepositInEscrow.DepositEscrow.Amount.Value.ToString().FormatAsMoney(), FastDriver.DepositInEscrow.Amount.FAGetValue(), "Amount");
                Support.AreEqual(CreateDepositInEscrowRequest.DepositInEscrow.DepositEscrow.ReceiptNumber.ToString(), FastDriver.DepositInEscrow.ReceiptNo.FAGetValue(), "Receipt No");
                Support.AreEqual(CreateDepositInEscrowRequest.DepositInEscrow.DepositEscrow.ReceivedFrom.ToString(), FastDriver.DepositInEscrow.ReceivedFrom.FAGetSelectedItem(), "Received From");
                Support.AreEqual(CreateDepositInEscrowRequest.DepositInEscrow.DepositEscrow.IssueDate.Value.ToDateString(), FastDriver.DepositInEscrow.IssueDte.FAGetValue(), "Issue Date");
                Support.AreEqual(CreateDepositInEscrowRequest.DepositInEscrow.DepositEscrow.TypeFunds.ToString(), FastDriver.DepositInEscrow.TypeofFunds.FAGetSelectedItem(), "Type Funds");
                Support.AreEqual(CreateDepositInEscrowRequest.DepositInEscrow.DepositEscrow.Representing.ToString(), FastDriver.DepositInEscrow.Representing.FAGetSelectedItem(), "Representing");
                Support.AreEqual(true, FastDriver.DepositInEscrow.CredittoOther.IsSelected(), "For Credit to: Other is selected");
                Support.AreEqual(CreateDepositInEscrowRequest.DepositInEscrow.DepositEscrow.ManualReceiptReason.ToString(), FastDriver.DepositInEscrow.ManualReceiptReason.FAGetText(), "Manual Receipt Reason");

                Reports.TestStep = "Invoke UpdateDepositInEscrow Service";
                int escrowId = Convert.ToInt32(CreateDepositInEscrowResponse.DepositInEscrow.DepositEscrow.InEscrowID.Value.ToString());
                var UpdateDepositInEscrowRequest = EscrowRequestFactory.UpdateDepositInEscrowRequest(fileId, escrowId);
                UpdateDepositInEscrowRequest.DepositInEscrow.DepositEscrow.ReceivedFrom = "Other";
                UpdateDepositInEscrowRequest.DepositInEscrow.DepositEscrow.IssueDate = DateTime.Now.ToPST();
                UpdateDepositInEscrowRequest.DepositInEscrow.DepositEscrow.TypeFunds = "Cash";
                UpdateDepositInEscrowRequest.DepositInEscrow.DepositEscrow.TransactionDate = DateTime.Now.ToPST();
                UpdateDepositInEscrowRequest.DepositInEscrow.DepositEscrow.Representing = "Additional Closing Costs";

                var UpdateDepositInEscrowResponse = EscrowService.UpdateDepositInEscrow(UpdateDepositInEscrowRequest);
                UpdateDepositInEscrowResponse.Validate();

                Reports.TestStep = "Navigate to Deposit/Receipt History screen and select the added deposit";
                FastDriver.DepositReceiptHistory.Open();
                FastDriver.DepositReceiptHistory.ReceiptsDepositActivityTable.PerformTableAction(1, 1, TableAction.Click);
                FastDriver.DepositReceiptHistory.ViewDetails.FAClick();
                FastDriver.DepositInEscrow.WaitForScreenToLoad(FastDriver.DepositInEscrow.Amount);

                Reports.TestStep = "Verify Deposit In Escrow is filled with data from create deposit in escrow web service request";
                Support.AreEqual(CreateDepositInEscrowRequest.DepositInEscrow.DepositEscrow.Amount.Value.ToString().FormatAsMoney(), FastDriver.DepositInEscrow.Amount.FAGetValue(), "Amount");
                Support.AreEqual(CreateDepositInEscrowRequest.DepositInEscrow.DepositEscrow.ReceiptNumber.ToString(), FastDriver.DepositInEscrow.ReceiptNo.FAGetValue(), "Receipt No");
                Support.AreEqual(CreateDepositInEscrowRequest.DepositInEscrow.DepositEscrow.ReceivedFrom.ToString(), FastDriver.DepositInEscrow.ReceivedFrom.FAGetSelectedItem(), "Received From");
                Support.AreEqual(CreateDepositInEscrowRequest.DepositInEscrow.DepositEscrow.IssueDate.Value.ToDateString(), FastDriver.DepositInEscrow.IssueDte.FAGetValue(), "Issue Date");
                Support.AreEqual(CreateDepositInEscrowRequest.DepositInEscrow.DepositEscrow.TypeFunds.ToString(), FastDriver.DepositInEscrow.TypeofFunds.FAGetSelectedItem(), "Type Funds");
                Support.AreEqual(CreateDepositInEscrowRequest.DepositInEscrow.DepositEscrow.Representing.ToString(), FastDriver.DepositInEscrow.Representing.FAGetSelectedItem(), "Representing");
                Support.AreEqual(CreateDepositInEscrowRequest.DepositInEscrow.DepositEscrow.ManualReceiptReason.ToString(), FastDriver.DepositInEscrow.ManualReceiptReason.FAGetText(), "Manual Receipt Reason");

                Reports.TestStep = "Verify CredittoSeller in Deposit In Escrow is filled with data from update deposit in escrow web service request";
                Support.AreEqual(true, FastDriver.DepositInEscrow.CredittoSeller.IsSelected(), "For Credit to: Seller is selected");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        #region Private Methods
        private void Login(string url = null)
        {
            var credentials = new Credentials()
            {
                UserName = AutoConfig.UserName,
                Password = AutoConfig.UserPassword
            };

            FASTLogin.Login(url ?? AutoConfig.FASTHomeURL, credentials, true);
        }
        #endregion
    }
}
