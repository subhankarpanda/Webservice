﻿using FASTSelenium.Common;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Reflection;
using FASTWCFHelpers;
using OpenQA.Selenium.Support.UI;
using FASTSelenium.DataObjects;



namespace WebServices.File
{
    [CodedUITest]
    public class FeeEntryWS : MasterTestClass
    {
        bool isProductadded = false;
        public static int serviceFileFeeId = 0;
        string feeDescriotion_titleEscrow = "";
        string feeDescriotion_fee = "";
        public static decimal splitPayeePercentage = 0.0M;
        public static decimal splitStatePercentage1 = 50.0M;
        public static decimal splitStatePercentage2 = 25.0M;
        public static string ActualState = "";


        /// <summary>
        /// Author : Yusuf
        /// Date : 18-02-2016
        /// Test method to perform Fee Entry delivery.
        /// </summary>
        [TestMethod]
        public void REG_FeeEntryDelivery()
        {
            Reports.TestDescription = "Verify FeeEntryDelivery operation";
            try
            {
                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                // FAST_Login_IIS();
                // Reports.TestStep = "Log into FAST application.";
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                #endregion

                Reports.TestStep = "Create a file using WCF and get the fileId.";
                int fileID = CreateFile();

                var fileFeeDeliveryRequest = CreateFileFeeDeliveryRequest(fileID);
                var response = ServiceFactory.GetFileService().FeeEntryDelivery(fileFeeDeliveryRequest);


                Reports.TestStep = "Verify the Service Response";
                Reports.StatusUpdate("Is status == 1 in the response ?", Convert.ToInt16(response.Status).Equals(1));
                Reports.StatusUpdate("Is the status description as expected in the response ?", response.StatusDescription.ToLower().ToString().Contains("preview successfull"));

                //Assert.IsTrue(ServiceHelper.GetStatusOnReport(Convert.ToInt16(feeEntryDeliveryResponse.Status).Equals(1), "The status is 1 in the response"));
                //Assert.IsTrue(ServiceHelper.GetStatusOnReport(feeEntryDeliveryResponse.StatusDescription.ToLower().ToString().Contains("preview successfull"), "The status description is as expected in the response"));
                //Playback.Wait(60000);

                Reports.TestStep = "Navigate to Terms/Dates/Status screen in FAST";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>(@"Home>Order Entry>Event/Tracking Log").WaitForScreenToLoad();

                FastDriver.EventTrackingLog.EventCategory.FASelectItem("Doc Delivery");
                Playback.Wait(5000);

                ServiceHelper.ContainsUIVal(FastDriver.EventTrackingLog.Comments, "value", "Delivery Method: Print Preview", true);
                ServiceHelper.ContainsUIVal(FastDriver.EventTrackingLog.StartDate, "value", DateTime.Now.ToString("MM/dd/yyyy"));
                ServiceHelper.ContainsUIVal(FastDriver.EventTrackingLog.EventName, "value", "Print Preview");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        /// <summary>
        /// Author : Yusuf
        /// Date : 18-02-2016 to 29-02-2016
        /// Test method to perform Fee Entry delivery.
        /// </summary>

        [TestMethod]
        public void REG_GetFeeEntryDetails()
        {
            Reports.TestDescription = "Verify GetFeeEntryDetails operation.";
            try
            {
                string buyerChargeEscrow = "10.02";
                string buyerChargeTitle = "20.02";
                string buyerChargeFeeTax = "40.02";
                string buyerChargeRecording = "10.02";
                string sellerChargeEscrow = "20.01";
                string sellerChargeTitle = "30.01";
                string sellerChargeFeeTax = "50.01";
                string sellerChargeRecording = "10.01";
                var FeeDesc1 = string.Empty;

                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                // FAST_Login_IIS();
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                #endregion

                Reports.TestStep = "Create a file using WCF and get the fileId.";
                int fileID = CreateFile();

                if (!AddFeeEscrowTitle("Escrow Fee", buyerChargeEscrow, sellerChargeEscrow))
                {
                    Reports.StatusUpdate("Could not add the fee type : Escrow Fee !", false);
                }
                ///FindAndClickLink("Title and Escrow");
                if (!AddFeeEscrowTitle("Title - Endorsement Fee", buyerChargeTitle, sellerChargeTitle))
                {
                    Reports.StatusUpdate("Could not add the fee type : Title - Endorsement Fee !", false);
                }

                //FindAndClickLink("Title and Escrow");
                //Playback.Wait(3000);
                if (!AddFeeTax("Recording and Tax", buyerChargeFeeTax, sellerChargeFeeTax))
                {
                    Reports.StatusUpdate("Could not add the fee type : Recording and Tax", false);
                }
                //Playback.Wait(3000);
                if (!AddFeeTax("Recording Fee - Deed", buyerChargeRecording, sellerChargeRecording))
                {
                    Reports.StatusUpdate("Could not add the fee type : Recording Fee - Deed", false);
                }
                //Playback.Wait(3000);
                AddPayRecordingTax();
                var getFeeEntryDetailsResponse = ServiceFactory.GetFileService().GetFeeEntryDetails(fileID, "");
                var feeRecap = getFeeEntryDetailsResponse.FileFeeRecap.Fees;
                var escrowTitle = getFeeEntryDetailsResponse.TitleAndEscrow.FileFees;
                var underwriter = getFeeEntryDetailsResponse.TitleAndEscrow.UnderWriterAgentDetail;
                var recordingTax = getFeeEntryDetailsResponse.RecordingAndTax.FileFees;
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();

                #region Validate Fee Recap
                ServiceHelper.CompareWithUI(FastDriver.FileFees.TotalTitleFees, "value", string.Format("{0:0.00}", (Convert.ToDouble(feeRecap.Title.ToString()))), true);
                ServiceHelper.CompareWithUI(FastDriver.FileFees.TotalEscrowFees, "value", string.Format("{0:0.00}", (Convert.ToDouble(feeRecap.Escrow.ToString()))), true);
                ServiceHelper.CompareWithUI(FastDriver.FileFees.TotalRecordingFees, "value", string.Format("{0:0.00}", (Convert.ToDouble(feeRecap.Recording.ToString()))), true);
                ServiceHelper.CompareWithUI(FastDriver.FileFees.TotalTransferTaxFees, "value", string.Format("{0:0.00}", (Convert.ToDouble(feeRecap.TransferTax.ToString()))), true);
                ServiceHelper.CompareWithUI(FastDriver.FileFees.TotalFees, "value", string.Format("{0:0.00}", (Convert.ToDouble(feeRecap.TotalFees.ToString()))), true);
                #endregion

                if (AutoConfig.FormType == "HUD")
                {
                    FastDriver.FileFees.TitleandEscrow.FAClick();
                    FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.UnderwriterAgentDetail);
                    FastDriver.FileFees.UnderwriterAgentDetail.FAClick();
                    //Playback.Wait(3000);
                    FastDriver.UnderwriterAgentDetailDlg.WaitForScreenToLoad();

                    Assert.AreEqual(string.Format("{0:0.0000}", (Convert.ToDouble(underwriter.UnderWriter.SplitPercentage.ToString()))), ServiceHelper.GetText(FastDriver.UnderwriterAgentDetailDlg.UnderwriterSplitPercent));
                    ServiceHelper.ContainsUIVal(FastDriver.UnderwriterAgentDetailDlg.UnderwriterSplitAmt, "value", string.Format("{0:0.00}", (Convert.ToDouble(underwriter.UnderWriter.SplitAmount.ToString()))), true, true);
                    Assert.AreEqual(underwriter.UnderWriter.Name.ToString(), ServiceHelper.GetText(FastDriver.UnderwriterAgentDetailDlg.Underwriter));
                    Assert.AreEqual(underwriter.TitleAgent1.Name.ToString(), ServiceHelper.GetText(FastDriver.UnderwriterAgentDetailDlg.TitleAgent1));
                    Assert.AreEqual(string.Format("{0:0.0000}", (Convert.ToDouble(underwriter.TitleAgent1.SplitPercentage.ToString()))), ServiceHelper.GetText(FastDriver.UnderwriterAgentDetailDlg.Agent1SplitPercent));
                    Assert.AreEqual(string.Format("{0:0.00}", (Convert.ToDouble(underwriter.TitleAgent1.SplitAmount.ToString()))), ServiceHelper.GetText(FastDriver.UnderwriterAgentDetailDlg.Agent1SplitAmt));
                    Assert.AreEqual(underwriter.TitleAgent2.Name.ToString(), ServiceHelper.GetText(FastDriver.UnderwriterAgentDetailDlg.TitleAgent2));
                    Assert.AreEqual(string.Format("{0:0.00}", (Convert.ToDouble(underwriter.TotalPremiumAmount.ToString()))), ServiceHelper.GetText(FastDriver.UnderwriterAgentDetailDlg.TotalPremium));

                    FastDriver.DialogBottomFrame.ClickDone();
                    //Keyboard.SendKeys("^D");
                    Playback.Wait(3000);
                }
                FastDriver.FileFees.WaitForScreenToLoad();

                //var feeDescElement = 
                for (int i = 0; i < escrowTitle.Length; i++)
                {

                    var expectedFeeDesc = escrowTitle[i].FeePaymentDetails.Description.ToString();
                    Assert.AreEqual(expectedFeeDesc, FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, expectedFeeDesc, 2, TableAction.GetText).Message);

                    var expectedBuyerCharge = escrowTitle[i].FeePaymentDetails.BuyerDetails.ChargeAmount.ToString();
                    Assert.AreEqual(expectedBuyerCharge, FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, expectedFeeDesc, 4, TableAction.GetAttribute, "value").Message);

                    var expectedSellerCharge = escrowTitle[i].FeePaymentDetails.SellerDetails.ChargeAmount.ToString();
                    Assert.AreEqual(expectedSellerCharge, FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, expectedFeeDesc, 7, TableAction.GetAttribute, "value").Message);

                    var expectedTotalCharge = escrowTitle[i].FeePaymentDetails.TotalCharge.ToString();
                    Assert.AreEqual(expectedTotalCharge, FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, expectedFeeDesc, 10, TableAction.GetAttribute, "value").Message);
                }

                FastDriver.FileFees.SwitchToContentFrame();
                Reports.TestStep = "Navigate to File Fees page";
                FastDriver.FileFees.RecordingandTax.FAClick();
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.PayRecordingTax); // RecordingLoanEstUnrounded);
                for (int i = 0; i < recordingTax.Length; i++)
                {
                    var expectedFeeDescRecording = recordingTax[i].FeePaymentDetails.Description.ToString();
                    Assert.AreEqual(expectedFeeDescRecording, FastDriver.FileFees.RecordingandTaxTable.PerformTableAction(2, expectedFeeDescRecording, 2, TableAction.GetText).Message);
                    if (i == 0)
                    {
                        FeeDesc1 = expectedFeeDescRecording;
                    }

                    string ChargeAmountWCF = recordingTax[i].FeePaymentDetails.BuyerDetails.ChargeAmount.ToString();
                    string ChargeAmountUI = FastDriver.FileFees.RecordingandTaxTable.PerformTableAction(2, expectedFeeDescRecording, 4, TableAction.GetAttribute, "value").Message.ToString();

                    if (!(ChargeAmountWCF == ""))
                    {
                        if (i == 0)
                        {
                            var expectedBuyerChargeRecording = recordingTax[i].FeePaymentDetails.BuyerDetails.ChargeAmount.ToString();
                            Assert.AreEqual(expectedBuyerChargeRecording, FastDriver.FileFees.RecordingandTaxTable.PerformTableAction(2, expectedFeeDescRecording, 4, TableAction.GetAttribute, "value").Message);

                            var expectedSellerChargeRecording = recordingTax[i].FeePaymentDetails.SellerDetails.ChargeAmount.ToString();
                            Assert.AreEqual(expectedSellerChargeRecording, FastDriver.FileFees.RecordingandTaxTable.PerformTableAction(2, expectedFeeDescRecording, 5, TableAction.GetAttribute, "value").Message);

                            var expectedTotalChargeRecording = recordingTax[i].FeePaymentDetails.TotalCharge.ToString();
                            Assert.AreEqual(expectedTotalChargeRecording, FastDriver.FileFees.RecordingandTaxTable.PerformTableAction(2, expectedFeeDescRecording, 6, TableAction.GetAttribute, "value").Message);
                        }
                        else
                        {
                            if (!(expectedFeeDescRecording == FeeDesc1))
                            {
                                var expectedBuyerChargeRecording = recordingTax[i].FeePaymentDetails.BuyerDetails.ChargeAmount.ToString();
                                Assert.AreEqual(expectedBuyerChargeRecording, FastDriver.FileFees.RecordingandTaxTable.PerformTableAction(2, 4, TableAction.GetAttribute, "value").Message);

                                var expectedSellerChargeRecording = recordingTax[i].FeePaymentDetails.SellerDetails.ChargeAmount.ToString();
                                Assert.AreEqual(expectedSellerChargeRecording, FastDriver.FileFees.RecordingandTaxTable.PerformTableAction(2, 5, TableAction.GetAttribute, "value").Message);

                                var expectedTotalChargeRecording = recordingTax[i].FeePaymentDetails.TotalCharge.ToString();
                                Assert.AreEqual(expectedTotalChargeRecording, FastDriver.FileFees.RecordingandTaxTable.PerformTableAction(2, 6, TableAction.GetAttribute, "value").Message);
                            }
                        }
                    }
                }

                FastDriver.FileFees.PayRecordingTax.FAClick();
                var chargeDetailsDisbursement = getFeeEntryDetailsResponse.RecordingAndTax.RecordingFeesTranferTaxDisbursement.ChargeDetails;
                var payeeDetailsDisbursement = getFeeEntryDetailsResponse.RecordingAndTax.RecordingFeesTranferTaxDisbursement.PayeeInformation;
                FastDriver.RecordFeeTransferTaxDisb.WaitForScreenToLoad(FastDriver.RecordFeeTransferTaxDisb.PayeeSummary);
                for (int j = 0; j < chargeDetailsDisbursement.Length; j++)
                {
                    var expectedDescription = chargeDetailsDisbursement[j].Description.ToString();
                    Assert.AreEqual(expectedDescription, FastDriver.RecordFeeTransferTaxDisb.ChargeSelection.PerformTableAction(2, expectedDescription, 2, TableAction.GetText).Message);

                    var expectedBuyerCharge = chargeDetailsDisbursement[j].BuyerCharge.ToString();
                    string test = FastDriver.RecordFeeTransferTaxDisb.ChargeSelection.PerformTableAction(2, expectedDescription, 4, TableAction.GetText).Message.ToString();
                    Assert.AreEqual(expectedBuyerCharge, FastDriver.RecordFeeTransferTaxDisb.ChargeSelection.PerformTableAction(2, expectedDescription, 4, TableAction.GetText).Message.ToString());

                    var expectedSellerCharge = chargeDetailsDisbursement[j].SellerCharge.ToString();
                    Assert.AreEqual(expectedSellerCharge, FastDriver.RecordFeeTransferTaxDisb.ChargeSelection.PerformTableAction(2, expectedDescription, 5, TableAction.GetText).Message.ToString());

                    if (chargeDetailsDisbursement[j].ePaymentMethodType.ToString().ToLower().Contains("chk"))
                    {
                        var checkBoxElement = FastDriver.RecordFeeTransferTaxDisb.ChargeSelection.PerformTableAction(2, expectedDescription, 1, TableAction.GetText).Element.FindElement(By.XPath(".//span/span/input"));
                        Assert.AreEqual("true", checkBoxElement.FAGetAttribute("checked").ToLower());
                    }
                }

                FastDriver.BottomFrame.Done();

                if (AutoConfig.FormType == "HUD")
                {
                    // FindAndClickLink("Title and Escrow");
                    FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.PayRecordingTax);
                    FastDriver.FileFees.Open();
                    FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.SalesTaxOverride);
                    FastDriver.FileFees.SplitLSP.FAClick();
                    FastDriver.SplitGFE4LenderSelectedProvider.WaitForScreenToLoad();

                    var splitLSPFee = getFeeEntryDetailsResponse.TitleAndEscrow.SplitLSP.FeeEntry;
                    var splitLSPOTC = getFeeEntryDetailsResponse.TitleAndEscrow.SplitLSP.OutsideTitleCompany;

                    ServiceHelper.ContainsUIVal(FastDriver.SplitGFE4LenderSelectedProvider.FeeEntryTitleServicesGFE4BreakdownAmount, "value", splitLSPFee[0].GFE4BreakDownAmout.ToString(), true, true);
                    ServiceHelper.ContainsUIVal(FastDriver.SplitGFE4LenderSelectedProvider.FeeEntrySettlementClosingGFE4BreakdownAmount, "value", splitLSPFee[1].GFE4BreakDownAmout.ToString(), true, true);
                    ServiceHelper.ContainsUIVal(FastDriver.SplitGFE4LenderSelectedProvider.FeeEntryLendersTitleInsuranceBuyerCharge, "value", splitLSPFee[2].BuyerCharge.ToString(), true, true);
                    ServiceHelper.ContainsUIVal(FastDriver.SplitGFE4LenderSelectedProvider.FeeEntryLendersTitleInsuranceGFE4BreakdownAmount, "value", splitLSPFee[2].GFE4BreakDownAmout.ToString(), true, true);
                    ServiceHelper.ContainsUIVal(FastDriver.SplitGFE4LenderSelectedProvider.OTCTitleServicesGFE4BreakdownAmount, "value", splitLSPOTC[0].GFE4BreakDownAmout.ToString(), true, true);
                    ServiceHelper.ContainsUIVal(FastDriver.SplitGFE4LenderSelectedProvider.OTCSettlementClosingGFE4BreakdownAmount, "value", splitLSPOTC[1].GFE4BreakDownAmout.ToString(), true, true);
                    ServiceHelper.ContainsUIVal(FastDriver.SplitGFE4LenderSelectedProvider.OTCLendersTitleInsuranceGFE4BreakdownAmount, "values", splitLSPOTC[2].GFE4BreakDownAmout.ToString(), true, true);
                }
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG_UpdateFeeEntryDetails()
        {
            Reports.TestDescription = "Verify REG_UpdateFeeEntryDetails operation.";
            try
            {
                Reports.TestStep = "Create a file using WCF and get the fileId.";

                string buyerChargeEscrow = "10.02";
                string buyerChargeTitle = "20.02";
                string buyerChargeFeeTax = "40.02";
                string buyerChargeRecording = "10.02";
                string sellerChargeEscrow = "20.01";
                string sellerChargeTitle = "30.01";
                string sellerChargeFeeTax = "50.01";
                string sellerChargeRecording = "10.01";
                var FeeDesc1 = string.Empty;
                int escrowFeeID1 = 0;
                int escrowFeeID2 = 0;
                int escrowServiceFileFeeId1 = 0;
                int escrowServiceFileFeeId2 = 0;
                int fbpIdFee1 = 0;
                int recordingFeeID1 = 0;
                int recordingFeeID2 = 0;
                int recordingServiceFileFeeId1 = 0;
                int recordingServiceFileFeeId2 = 0;


                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                // FAST_Login_IIS();
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                #endregion

                Reports.TestStep = "Create a file using WCF and get the fileId.";
                int fileID = CreateFile();

                if (!AddFeeEscrowTitle("Escrow Fee", buyerChargeEscrow, sellerChargeEscrow))
                {
                    Reports.StatusUpdate("Could not add the fee type : Escrow Fee !", false);
                }
                ///FindAndClickLink("Title and Escrow");
                if (!AddFeeEscrowTitle("Title - Endorsement Fee", buyerChargeTitle, sellerChargeTitle))
                {
                    Reports.StatusUpdate("Could not add the fee type : Title - Endorsement Fee !", false);
                }

                //FindAndClickLink("Title and Escrow");
                //Playback.Wait(3000);
                if (!AddFeeTax("Recording and Tax", buyerChargeFeeTax, sellerChargeFeeTax))
                {
                    Reports.StatusUpdate("Could not add the fee type : Recording and Tax", false);
                }
                //Playback.Wait(3000);
                if (!AddFeeTax("Recording Fee - Deed", buyerChargeRecording, sellerChargeRecording))
                {
                    Reports.StatusUpdate("Could not add the fee type : Recording Fee - Deed", false);
                }
                //Playback.Wait(3000);
                AddPayRecordingTax();
                var getFeeEntryDetailsResponse = ServiceFactory.GetFileService().GetFeeEntryDetails(fileID, "");
                if (AutoConfig.FormType == "HUD")
                {
                    var feeRecap = getFeeEntryDetailsResponse.FileFeeRecap.Fees;
                    var escrowTitle = getFeeEntryDetailsResponse.TitleAndEscrow.FileFees;
                    var underwriter = getFeeEntryDetailsResponse.TitleAndEscrow.UnderWriterAgentDetail;
                    var recordingTax = getFeeEntryDetailsResponse.RecordingAndTax.FileFees;

                    recordingFeeID1 = (int)recordingTax[0].FeePaymentDetails.FeeID;
                    recordingFeeID2 = (int)recordingTax[1].FeePaymentDetails.FeeID;
                    recordingServiceFileFeeId1 = (int)recordingTax[0].FeePaymentDetails.ServiceFileFeeId;
                    recordingServiceFileFeeId2 = (int)recordingTax[1].FeePaymentDetails.ServiceFileFeeId;

                    escrowFeeID1 = (int)escrowTitle[0].FeePaymentDetails.FeeID;
                    escrowFeeID2 = (int)escrowTitle[1].FeePaymentDetails.FeeID;
                    escrowServiceFileFeeId1 = (int)escrowTitle[0].FeePaymentDetails.ServiceFileFeeId;
                    escrowServiceFileFeeId2 = (int)escrowTitle[1].FeePaymentDetails.ServiceFileFeeId;
                    fbpIdFee1 = (int)getFeeEntryDetailsResponse.RecordingAndTax.RecordingFeesTranferTaxDisbursement.PayeeInformation[0].FileBusinessParty.FileBusinessPartyID;
                }
                else
                {
                    var feeRecap = getFeeEntryDetailsResponse.FileFeeRecap.Fees;
                    var escrowTitle = getFeeEntryDetailsResponse.TitleAndEscrow.CdFileFees;
                    var underwriter = getFeeEntryDetailsResponse.TitleAndEscrow.UnderWriterAgentDetail;
                    var recordingTax = getFeeEntryDetailsResponse.RecordingAndTax.CdFileFees;

                    recordingFeeID1 = (int)recordingTax[0].FeePaymentDetails.FeeID;
                    recordingFeeID2 = (int)recordingTax[1].FeePaymentDetails.FeeID;
                    recordingServiceFileFeeId1 = (int)recordingTax[0].FeePaymentDetails.ServiceFileFeeId;
                    recordingServiceFileFeeId2 = (int)recordingTax[1].FeePaymentDetails.ServiceFileFeeId;

                    escrowFeeID1 = (int)escrowTitle[0].FeePaymentDetails.FeeID;
                    escrowFeeID2 = (int)escrowTitle[1].FeePaymentDetails.FeeID;
                    escrowServiceFileFeeId1 = (int)escrowTitle[0].FeePaymentDetails.ServiceFileFeeId;
                    escrowServiceFileFeeId2 = (int)escrowTitle[1].FeePaymentDetails.ServiceFileFeeId;
                    fbpIdFee1 = (int)getFeeEntryDetailsResponse.RecordingAndTax.RecordingFeesTranferTaxDisbursement.PayeeInformation[0].FileBusinessParty.FileBusinessPartyID;
                }

                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                var feeEntryUpdateRequest = UpdateFeeEntryRequest(fileID);
                //var feeEntryUpdateRequest = RequestFactory.GetUpdateFeeEntry_DDRequest(Convert.ToInt32(File.FileID), 2);

                feeEntryUpdateRequest.FileID = fileID;
                feeEntryUpdateRequest.TitleAndEscrow.FileFees[0].FeePaymentDetails.FeeID = escrowFeeID1;
                feeEntryUpdateRequest.TitleAndEscrow.FileFees[1].FeePaymentDetails.FeeID = escrowFeeID2;
                feeEntryUpdateRequest.RecordingAndTax.FileFees[0].FeePaymentDetails.FeeID = recordingFeeID1;
                feeEntryUpdateRequest.RecordingAndTax.FileFees[1].FeePaymentDetails.FeeID = recordingFeeID2;
                feeEntryUpdateRequest.TitleAndEscrow.FileFees[0].FeePaymentDetails.ServiceFileFeeId = escrowServiceFileFeeId1;
                feeEntryUpdateRequest.TitleAndEscrow.FileFees[1].FeePaymentDetails.ServiceFileFeeId = escrowServiceFileFeeId2;
                feeEntryUpdateRequest.RecordingAndTax.FileFees[0].FeePaymentDetails.ServiceFileFeeId = recordingServiceFileFeeId1;
                feeEntryUpdateRequest.RecordingAndTax.FileFees[1].FeePaymentDetails.ServiceFileFeeId = recordingServiceFileFeeId2;
                feeEntryUpdateRequest.RecordingAndTax.RecordingFeesTranferTaxDisbursement.PayeeInformation[0].FileBusinessParty.FileBusinessPartyID = fbpIdFee1;
                feeEntryUpdateRequest.RecordingAndTax.RecordingFeesTranferTaxDisbursement.ChargeDetails[0].ServiceFeeID = recordingServiceFileFeeId1;
                feeEntryUpdateRequest.RecordingAndTax.RecordingFeesTranferTaxDisbursement.ChargeDetails[1].ServiceFeeID = recordingServiceFileFeeId2;

                feeEntryUpdateRequest.RecordingAndTax.RecordingFeesTranferTaxDisbursement.ChargeDetails[0].FileBusinessPartyID = fbpIdFee1;
                feeEntryUpdateRequest.RecordingAndTax.RecordingFeesTranferTaxDisbursement.ChargeDetails[1].FileBusinessPartyID = fbpIdFee1;

                var feeEntryUpdateResponse = FASTWCFHelpers.FileService.UpdateFeeEntryDetails(feeEntryUpdateRequest);
                Support.AreEqual("1", feeEntryUpdateResponse.TitleEscrowFileFeesResponse.Status.ToString());
                Support.AreEqual("Title and Escrow File Fee(s) Updated Successfully", feeEntryUpdateResponse.TitleEscrowFileFeesResponse.StatusDescription);
                Support.AreEqual("Recording And Tax File Fee(s) Updated Successfully", feeEntryUpdateResponse.TitleEscrowFileFeesResponse.StatusDescription);

                FastDriver.FileFees.Open();
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.SalesTaxOverride);
                FastDriver.FileFees.SplitLSP.FAClick();
                FastDriver.SplitGFE4LenderSelectedProvider.WaitForScreenToLoad();

                var splitLSPFee = feeEntryUpdateRequest.TitleAndEscrow.SplitLSP.FeeEntry;
                var splitLSPOTC = feeEntryUpdateRequest.TitleAndEscrow.SplitLSP.OutsideTitleCompany;

                if (splitLSPFee.Length > 0)
                {
                    ServiceHelper.ContainsUIVal(FastDriver.SplitGFE4LenderSelectedProvider.FeeEntryTitleServicesGFE4BreakdownAmount, "value", splitLSPFee[0].GFE4BreakDownAmout.ToString(), true, true);

                    if (splitLSPFee.Length > 1)
                    {
                        ServiceHelper.ContainsUIVal(FastDriver.SplitGFE4LenderSelectedProvider.FeeEntrySettlementClosingGFE4BreakdownAmount, "value", splitLSPFee[1].GFE4BreakDownAmout.ToString(), true, true);
                        if (splitLSPFee.Length > 2)
                        {
                            ServiceHelper.ContainsUIVal(FastDriver.SplitGFE4LenderSelectedProvider.FeeEntrySettlementClosingGFE4BreakdownAmount, "value", splitLSPFee[2].GFE4BreakDownAmout.ToString(), true, true);
                        }
                    }
                }

                if (splitLSPOTC.Length > 0)
                {
                    ServiceHelper.ContainsUIVal(FastDriver.SplitGFE4LenderSelectedProvider.OTCTitleServicesGFE4BreakdownAmount, "value", splitLSPOTC[0].GFE4BreakDownAmout.ToString(), true, true);
                    if (splitLSPOTC.Length > 1)
                    {
                        ServiceHelper.ContainsUIVal(FastDriver.SplitGFE4LenderSelectedProvider.OTCTitleServicesGFE4BreakdownAmount, "value", splitLSPOTC[1].GFE4BreakDownAmout.ToString(), true, true);
                        if (splitLSPOTC.Length > 2)
                        {
                            ServiceHelper.ContainsUIVal(FastDriver.SplitGFE4LenderSelectedProvider.OTCTitleServicesGFE4BreakdownAmount, "value", splitLSPOTC[2].GFE4BreakDownAmout.ToString(), true, true);
                        }
                    }
                }
                FastDriver.BottomFrame.Done();

                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.SalesTaxOverride);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }


        [TestMethod]
        public void REG_GetServiceFeeDetails()
        {
            Reports.TestDescription = "Verify GetServiceFeeDetails operation";
            try
            {
                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                // FAST_Login_IIS();
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                #endregion

                Reports.TestStep = "Create a file using WCF and get the fileId.";
                int fileID = CreateFile();

                UpdateServiceFeeDetails(fileID, "new");

                var GetServiceFeeDetailsResponse = ServiceFactory.GetFileService().GetServiceFeeDetails(fileID);

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.HomePage>(@"Home");
                FastDriver.WebDriver.HandleDialogMessage();

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ServiceFee>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry>Service Fees").WaitForScreenToLoad();

                var feeRecap = GetServiceFeeDetailsResponse.FileFeeRecap.Fees;
                var serviceFeeDetails = GetServiceFeeDetailsResponse.ServiceFeeDetails;
                serviceFileFeeId = Convert.ToInt32(serviceFeeDetails[0].ServiceFees.ServiceFeeID);


                ServiceHelper.ContainsUIVal(FastDriver.FileFees.TotalTitleFees, "value", feeRecap.Title.ToString(), true);
                ServiceHelper.ContainsUIVal(FastDriver.FileFees.TotalEscrowFees, "value", feeRecap.Escrow.ToString(), true);
                ServiceHelper.ContainsUIVal(FastDriver.FileFees.TotalRecordingFees, "value", feeRecap.Recording.ToString(), true);
                ServiceHelper.ContainsUIVal(FastDriver.FileFees.TotalTransferTaxFees, "value", feeRecap.TransferTax.ToString(), true);
                ServiceHelper.ContainsUIVal(FastDriver.FileFees.TotalFees, "value", feeRecap.TotalFees.ToString(), true);

                ServiceHelper.CompareWithUI(FastDriver.ServiceFee.ServiceFeeStatus, "value", serviceFeeDetails[0].ServiceFees.Status.ToString());
                ServiceHelper.CompareWithUI(FastDriver.ServiceFee.ServiceFeeAmount.FAGetAttribute("value").ToString(), serviceFeeDetails[0].ServiceFees.Amount.ToString(), true, true);
                ServiceHelper.CompareWithUI(FastDriver.ServiceFee.ServiceFeePayeeDesc, "value", serviceFeeDetails[0].ServiceFees.Payee.ToString(), true, true);

                FastDriver.ServiceFee.ServiceFeeStatus.FAClick();
                FastDriver.ServiceFee.PayeeDetails.FAClick();
                //Playback.Wait(2000);
                FastDriver.PayeeDetailsDlg.WaitForScreenToLoad();
                ServiceHelper.CompareWithUI(FastDriver.PayeeDetailsDlg.BUIDPane, "value", serviceFeeDetails[0].PayeeDetails.BusinessUnitID.ToString());
                ServiceHelper.CompareWithUI(FastDriver.PayeeDetailsDlg.OfficeName, "value", serviceFeeDetails[0].PayeeDetails.PayeeName.ToString());
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void Reg_SearchFeeEntryFileFees()
        {
            Reports.TestDescription = "Verify SearchFeeEntryFileFees operation";
            try
            {
                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                // FAST_Login_IIS();
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                #endregion

                Reports.TestStep = "Create a file using WCF and get the fileId.";
                int fileID = CreateFile();
                Reports.TestStep = "Construct SearchFeeEntryFileFees request parameter object.";
                var searchRequest = new FASTWCFHelpers.FastFileService.SearchFileFeeRequest()
                {
                    FileID = fileID,
                    eFeeType = FASTWCFHelpers.FastFileService.FeeType.EscrowFee
                };

                Reports.TestStep = "Invoke SearchFeeEntryFileFees service operation.";
                var response = ServiceFactory.GetFileService().SearchFeeEntryFileFees(searchRequest);

                Reports.TestStep = "Verify the response of SearchFeeEntryFileFees operation.";
                Reports.StatusUpdate("Is status == 1 in the response ?", Convert.ToInt16(response.Status).Equals(1));
                Reports.StatusUpdate("Is the status description as expected in the response ?", response.StatusDescription.ToLower().ToString().Contains("successful"));
                Reports.StatusUpdate("SearchFileFees is invoked successfully ?", response.SearchFileFees.Length > 0);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG_GetSplitFeeAssignStateDetails()
        {
            Reports.TestDescription = "Get SplitFee Assign State Details.";

            try
            {
                string state = "";

                string buyerChargeEscrow = "10.02";
                string buyerChargeTitle = "20.02";
                string buyerChargeFeeTax = "40.02";
                string buyerChargeRecording = "10.02";
                string sellerChargeEscrow = "20.01";
                string sellerChargeTitle = "30.01";
                string sellerChargeFeeTax = "50.01";
                string sellerChargeRecording = "10.01";
                var FeeDesc1 = string.Empty;

                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                // FAST_Login_IIS();
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                #endregion

                Reports.TestStep = "Create a file using WCF and get the fileId.";
                //int fileID = 36864196;
                int fileID = CreateFile();

                if (!AddFeeEscrowTitle("Escrow Fee", buyerChargeEscrow, sellerChargeEscrow))
                {
                    Reports.StatusUpdate("Could not add the fee type : Escrow Fee !", false);
                }
                ///FindAndClickLink("Title and Escrow");
                if (!AddFeeEscrowTitle("Title - Endorsement Fee", buyerChargeTitle, sellerChargeTitle))
                {
                    Reports.StatusUpdate("Could not add the fee type : Title - Endorsement Fee !", false);
                }

                //FindAndClickLink("Title and Escrow");
                //Playback.Wait(3000);
                if (!AddFeeTax("Recording and Tax", buyerChargeFeeTax, sellerChargeFeeTax))
                {
                    Reports.StatusUpdate("Could not add the fee type : Recording and Tax", false);
                }
                //Playback.Wait(3000);
                if (!AddFeeTax("Recording Fee - Deed", buyerChargeRecording, sellerChargeRecording))
                {
                    Reports.StatusUpdate("Could not add the fee type : Recording Fee - Deed", false);
                }

                AddProperty(2);

                SplitFeeToPayees(fileID);
                SplitFeeToStates(fileID);

                var response = ServiceFactory.GetFileService().GetSplitFeeAssignStateDetails(fileID);
                Reports.TestStep = "Verify the response of GetSplitFeeAssignStateDetails operation.";
                Reports.StatusUpdate("Is status == 1 in the response ?", Convert.ToInt16(response.Status).Equals(1));
                Reports.StatusUpdate("Is the status description as expected in the response ?", response.StatusDescription.ToLower().ToString().Contains("split fee details loaded successfully"));

                //if (Convert.ToBoolean(response.AssignFeeToPropertyStates[0].AssignProperties[0].IsSelected.ToString()))
                //    state = response.AssignFeeToPropertyStates[0].AssignProperties[0].PropertyState.ToString();
                //else if (Convert.ToBoolean(response.AssignFeeToPropertyStates[0].AssignProperties[1].IsSelected.ToString()))
                //    state = response.AssignFeeToPropertyStates[0].AssignProperties[1].PropertyState.ToString();
                //else
                //    state = response.AssignFeeToPropertyStates[0].AssignProperties[2].PropertyState.ToString();


                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.AssignFeetoPropertyStates>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry>Split Fees/Assign State");
                FastDriver.SplitFeeDisbursements.WaitForScreenToLoad(FastDriver.SplitFeeDisbursements.PayeesSummary);

                #region VALIDATIONS
                // feeDescriotion_titleEscrow = GetFeeDescriptionOfRecordingAndTax("Recording and Tax");

                // FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.AssignFeetoPropertyStates>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry>Split Fees/Assign State");

                ValidateSplitFee("Payee", "Get", response.PayeeSummaryList); //response.PayeeSummaryList
                ValidateSplitFee("SplitFee", "Get", null, null, response); //response.ServiceFeeDetails 
                ValidateSplitFee("States", null, null, null, response, null, fileID); //response.AssignFeeToPropertyStates[0].AssignFeeBtwMulPropStatesArray
                // ValidateSplitFee("States", "update", null, response.ServiceFeeDetails, response, null, fileID);  //GetSplitFeeAssignStateResponse.AssignFeeToPropertyStates[0].AssignProperties[0].PropertyState

                #endregion

                //Reports.StatusUpdate("GetSplitFeeAssignStateDetails is successful.", Reports.TestResult);
                //Assert.IsTrue(Reports.TestResult, "Unable to Get SplitFeeAssignStateDetails.");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }


        [TestMethod]
        public void REG_UpdateSplitFeeDetails()
        {
            try
            {
                Reports.TestDescription = "Verify UpdateSplitFeeDetails service operation.";
                int serviceFeeId1 = 0;
                int serviceFeeId2 = 0;
                string buyerChargeEscrow = "10.02";
                string buyerChargeTitle = "20.02";
                string buyerChargeFeeTax = "40.02";
                string buyerChargeRecording = "10.02";
                string sellerChargeEscrow = "20.01";
                string sellerChargeTitle = "30.01";
                string sellerChargeFeeTax = "50.01";
                string sellerChargeRecording = "10.01";
                var FeeDesc1 = string.Empty;

                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                // FAST_Login_IIS();
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                #endregion

                Reports.TestStep = "Create a file using WCF and get the fileId.";
                // int fileID = 36864791;
                int fileID = CreateFile();

                if (!AddFeeEscrowTitle("Escrow Fee", buyerChargeEscrow, sellerChargeEscrow))
                {
                    Reports.StatusUpdate("Could not add the fee type : Escrow Fee !", false);
                }
                if (!AddFeeEscrowTitle("Title - Endorsement Fee", buyerChargeTitle, sellerChargeTitle))
                {
                    Reports.StatusUpdate("Could not add the fee type : Title - Endorsement Fee !", false);
                }
                if (!AddFeeTax("Recording and Tax", buyerChargeFeeTax, sellerChargeFeeTax))
                {
                    Reports.StatusUpdate("Could not add the fee type : Recording and Tax", false);
                }
                if (!AddFeeTax("Recording Fee - Deed", buyerChargeRecording, sellerChargeRecording))
                {
                    Reports.StatusUpdate("Could not add the fee type : Recording Fee - Deed", false);
                }

                //  AddPayRecordingTax();

                var getFeeEntryResponse = ServiceFactory.GetFileService().GetFeeEntryDetails(fileID, "");

                if (AutoConfig.FormType == "HUD")
                {
                    serviceFeeId1 = (int)getFeeEntryResponse.TitleAndEscrow.FileFees[0].FeePaymentDetails.ServiceFileFeeId;
                    serviceFeeId2 = (int)getFeeEntryResponse.TitleAndEscrow.FileFees[1].FeePaymentDetails.ServiceFileFeeId;
                }
                else
                {
                    serviceFeeId1 = (int)getFeeEntryResponse.TitleAndEscrow.CdFileFees[0].FeePaymentDetails.ServiceFileFeeId;
                    serviceFeeId2 = (int)getFeeEntryResponse.TitleAndEscrow.CdFileFees[1].FeePaymentDetails.ServiceFileFeeId;
                }

                AddProperty(2);
                SplitFeeToPayees(fileID);
                SplitFeeToStates(fileID);
                var getOrderDetailsResponse = ServiceFactory.GetFileService().GetOrderDetails(fileID);
                var GetSplitFeeAssignStateResponse = ServiceFactory.GetFileService().GetSplitFeeAssignStateDetails(fileID);


                var updateSplitFeeDetailsRequest = new FASTWCFHelpers.FastFileService.UpdateSplitFeeRequest()
                {
                    AssignStateLists = new AssignStateList[] 
                {
                    new AssignStateList()
                    {
                        AssignFeeBetweenPropertyStates = true,
                        PropertyStatesFeeList = new PropertyStatesFeeList[]
                        {
                            new PropertyStatesFeeList()
                            { 
                                AssignPercenatge = 50,
                            },
                            new PropertyStatesFeeList()
                            { 
                                AssignPercenatge = 25,
                            }
                        },
                    },
                },

                    ServiceFeeLists = new FASTWCFHelpers.FastFileService.ServiceFeeList[]
                {
                    new ServiceFeeList()
                    {
                        SpliteFeeLists = new FASTWCFHelpers.FastFileService.SpliteFeeList[]
                        {
                            new FASTWCFHelpers.FastFileService.SpliteFeeList()
                            { 
                                SplitPercentage = 75,
                                ePayeeRoleType = FASTWCFHelpers.FastFileService.SplitPayee.GAB,
                                eSplitType = FASTWCFHelpers.FastFileService.SplitType.New
                            }
                        }
                    }
                },
                    LoginName = @"fastts\fastqa07",
                    Source = "FAST",
                };


                updateSplitFeeDetailsRequest.FileID = fileID;
                updateSplitFeeDetailsRequest.AssignStateLists[0].ServiceFileFeeID = serviceFeeId2;
                updateSplitFeeDetailsRequest.AssignStateLists[0].PropertyStatesFeeList[0].PhysicalAddrId = GetSplitFeeAssignStateResponse.AssignFeeToPropertyStates[0].AssignProperties[1].PhysicalAddressID;
                updateSplitFeeDetailsRequest.AssignStateLists[0].PropertyStatesFeeList[1].PhysicalAddrId = GetSplitFeeAssignStateResponse.AssignFeeToPropertyStates[0].AssignProperties[2].PhysicalAddressID;
                updateSplitFeeDetailsRequest.ServiceFeeLists[0].ServiceFileFeeID = serviceFeeId2;
                updateSplitFeeDetailsRequest.ServiceFeeLists[0].SpliteFeeLists[0].BusOrgID = getOrderDetailsResponse.FileBusinessParties[0].BusOrgID;
                updateSplitFeeDetailsRequest.ServiceFeeLists[0].SpliteFeeLists[0].SplitFeeID = serviceFeeId2;

                var updateSplitFeeDetailsResponse = ServiceFactory.GetFileService().UpdateSplitFeeDetails(updateSplitFeeDetailsRequest);

                Reports.TestStep = "Verify the response of SearchFeeEntryFileFees operation.";
                Reports.StatusUpdate("Is status == 1 in the response ?", Convert.ToInt16(updateSplitFeeDetailsResponse.ServiceFeeListResponse.Status).Equals(1));
                Reports.StatusUpdate("Is the status description as expected in the response ?", updateSplitFeeDetailsResponse.ServiceFeeListResponse.StatusDescription.ToLower().ToString().Contains("splitfee updated sucessfully"));
                Reports.StatusUpdate("Is the status description as expected in the response ?", updateSplitFeeDetailsResponse.StatusDescription.ToLower().ToString().Contains("splitfee updated partially"));

                SplitFeeToStates(fileID);
                // feeDescriotion_titleEscrow = "";
                // feeDescriotion_fee = GetFeeDescriptionOfRecordingAndTax("Recording and Tax");

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.AssignFeetoPropertyStates>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry>Split Fees/Assign State");
                FastDriver.SplitFeeDisbursements.WaitForScreenToLoad(FastDriver.SplitFeeDisbursements.SplitFeesSummary);

                #region VALIDATIONS
                //GetSplitFeeAssignStateResponse = InvokeServiceMethod("FASTFileService", "GetSplitFeeAssignStateDetails", null, null, null, null, fileId);

                /*ValidateSplitFee(GetSplitFeeAssignStateResponse.PayeeSummaryList, "Payee", "update");
                ValidateSplitFee(response.ServiceFeeLists[0].SpliteFeeLists[0].SplitPercentage, "SplitFee", "update");
                ValidateSplitFee(GetSplitFeeAssignStateResponse.AssignFeeToPropertyStates[0].PropertyStatesFeeList, "States", "update");*/

                var GetSplitFeeAssignStateResponse2 = ServiceFactory.GetFileService().GetSplitFeeAssignStateDetails(fileID);
                ValidateSplitFee("Payee", "update", GetSplitFeeAssignStateResponse2.PayeeSummaryList, GetSplitFeeAssignStateResponse2.ServiceFeeDetails, GetSplitFeeAssignStateResponse2);
                ValidateSplitFee("SplitFee", "update", null, GetSplitFeeAssignStateResponse2.ServiceFeeDetails, GetSplitFeeAssignStateResponse2, updateSplitFeeDetailsResponse); //(decimal)updateSplitFeeDetailsRequest.ServiceFeeLists[0].SpliteFeeLists[0].SplitPercentage
                ValidateSplitFee("States", null, null, GetSplitFeeAssignStateResponse2.ServiceFeeDetails, GetSplitFeeAssignStateResponse2, null, fileID);  //GetSplitFeeAssignStateResponse.AssignFeeToPropertyStates[0].AssignProperties[0].PropertyState

                Reports.StatusUpdate("Is UpdateSplitFeeDetails successful ?", Reports.TestResult);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG_UpdateServiceFeeDetails_New()
        {
            Reports.TestDescription = "Verify Update operation for Service Fee.";
            try
            {
                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                // FAST_Login_IIS();
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                #endregion

                Reports.TestStep = "Create a file using WCF and get the fileId.";
                int fileID = CreateFile();

                UpdateServiceFeeDetails(fileID, "new");

                var GetServiceFeeDetailsResponse = ServiceFactory.GetFileService().GetServiceFeeDetails(fileID);

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.HomePage>(@"Home");
                FastDriver.WebDriver.HandleDialogMessage();

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ServiceFee>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry>Service Fees").WaitForScreenToLoad();

                var feeRecap = GetServiceFeeDetailsResponse.FileFeeRecap.Fees;
                var serviceFeeDetails = GetServiceFeeDetailsResponse.ServiceFeeDetails;
                serviceFileFeeId = Convert.ToInt32(serviceFeeDetails[0].ServiceFees.ServiceFeeID);


                ServiceHelper.ContainsUIVal(FastDriver.FileFees.TotalTitleFees, "value", feeRecap.Title.ToString(), true);
                ServiceHelper.ContainsUIVal(FastDriver.FileFees.TotalEscrowFees, "value", feeRecap.Escrow.ToString(), true);
                ServiceHelper.ContainsUIVal(FastDriver.FileFees.TotalRecordingFees, "value", feeRecap.Recording.ToString(), true);
                ServiceHelper.ContainsUIVal(FastDriver.FileFees.TotalTransferTaxFees, "value", feeRecap.TransferTax.ToString(), true);
                ServiceHelper.ContainsUIVal(FastDriver.FileFees.TotalFees, "value", feeRecap.TotalFees.ToString(), true);

                ServiceHelper.CompareWithUI(FastDriver.ServiceFee.ServiceFeeStatus, "value", serviceFeeDetails[0].ServiceFees.Status.ToString());
                ServiceHelper.CompareWithUI(FastDriver.ServiceFee.ServiceFeeAmount.FAGetAttribute("value").ToString(), serviceFeeDetails[0].ServiceFees.Amount.ToString(), true, true);
                ServiceHelper.CompareWithUI(FastDriver.ServiceFee.ServiceFeePayeeDesc, "value", serviceFeeDetails[0].ServiceFees.Payee.ToString(), true, true);

                FastDriver.ServiceFee.ServiceFeeStatus.FAClick();
                FastDriver.ServiceFee.PayeeDetails.FAClick();
                //Playback.Wait(2000);
                FastDriver.PayeeDetailsDlg.WaitForScreenToLoad();
                ServiceHelper.CompareWithUI(FastDriver.PayeeDetailsDlg.BUIDPane, "value", serviceFeeDetails[0].PayeeDetails.BusinessUnitID.ToString());
                ServiceHelper.CompareWithUI(FastDriver.PayeeDetailsDlg.OfficeName, "value", serviceFeeDetails[0].PayeeDetails.PayeeName.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG_UpdateServiceFeeDetails_Update()
        {
            Reports.TestDescription = "Verify Update operation for Service Fee.";
            try
            {
                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                // FAST_Login_IIS();
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                #endregion

                Reports.TestStep = "Create a file using WCF and get the fileId.";
                int fileID = CreateFile();

                UpdateServiceFeeDetails(fileID, "new");

                var GetServiceFeeDetailsResponse = ServiceFactory.GetFileService().GetServiceFeeDetails(fileID);

                UpdateServiceFeeDetails(fileID, "update");

                var GetServiceFeeDetailsResponse2 = ServiceFactory.GetFileService().GetServiceFeeDetails(fileID);

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.HomePage>(@"Home");
                FastDriver.WebDriver.HandleDialogMessage();

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ServiceFee>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry>Service Fees").WaitForScreenToLoad();

                var feeRecap2 = GetServiceFeeDetailsResponse2.FileFeeRecap.Fees;
                var serviceFeeDetails2 = GetServiceFeeDetailsResponse2.ServiceFeeDetails;
                serviceFileFeeId = Convert.ToInt32(serviceFeeDetails2[0].ServiceFees.ServiceFeeID);


                ServiceHelper.ContainsUIVal(FastDriver.FileFees.TotalTitleFees, "value", feeRecap2.Title.ToString(), true);
                ServiceHelper.ContainsUIVal(FastDriver.FileFees.TotalEscrowFees, "value", feeRecap2.Escrow.ToString(), true);
                ServiceHelper.ContainsUIVal(FastDriver.FileFees.TotalRecordingFees, "value", feeRecap2.Recording.ToString(), true);
                ServiceHelper.ContainsUIVal(FastDriver.FileFees.TotalTransferTaxFees, "value", feeRecap2.TransferTax.ToString(), true);
                ServiceHelper.ContainsUIVal(FastDriver.FileFees.TotalFees, "value", feeRecap2.TotalFees.ToString(), true);

                ServiceHelper.CompareWithUI(FastDriver.ServiceFee.ServiceFeeStatus, "value", serviceFeeDetails2[0].ServiceFees.Status.ToString());
                ServiceHelper.CompareWithUI(FastDriver.ServiceFee.ServiceFeeAmount.FAGetAttribute("value").ToString(), serviceFeeDetails2[0].ServiceFees.Amount.ToString(), true, true);
                ServiceHelper.CompareWithUI(FastDriver.ServiceFee.ServiceFeePayeeDesc, "value", serviceFeeDetails2[0].ServiceFees.Payee.ToString(), true, true);

                FastDriver.ServiceFee.ServiceFeeStatus.FAClick();
                FastDriver.ServiceFee.PayeeDetails.FAClick();
                //Playback.Wait(2000);
                FastDriver.PayeeDetailsDlg.WaitForScreenToLoad();
                ServiceHelper.CompareWithUI(FastDriver.PayeeDetailsDlg.BUIDPane, "value", serviceFeeDetails2[0].PayeeDetails.BusinessUnitID.ToString());
                ServiceHelper.CompareWithUI(FastDriver.PayeeDetailsDlg.OfficeName, "value", serviceFeeDetails2[0].PayeeDetails.PayeeName.ToString());
                FastDriver.DialogBottomFrame.ClickDone();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG_UpdateServiceFeeDetails_Cancel()
        {
            Reports.TestDescription = "Verify Cancel operation for UpdateServiceFeeDetails.";
            try
            {
                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                // FAST_Login_IIS();
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                #endregion

                Reports.TestStep = "Create a file using WCF and get the fileId.";
                int fileID = CreateFile();

                UpdateServiceFeeDetails(fileID, "new");

                var GetServiceFeeDetailsResponse = ServiceFactory.GetFileService().GetServiceFeeDetails(fileID);

                UpdateServiceFeeDetails(fileID, "cancel");

                var GetServiceFeeDetailsResponse2 = ServiceFactory.GetFileService().GetServiceFeeDetails(fileID);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }

        }

        [TestMethod]
        public void REG_UpdateServiceFeeDetails_Remove()
        {
            Reports.TestDescription = "Verify Remove operation for UpdateServiceFeeDetails.";
            try
            {
                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                // FAST_Login_IIS();
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                #endregion

                Reports.TestStep = "Create a file using WCF and get the fileId.";
                int fileID = CreateFile();

                UpdateServiceFeeDetails(fileID, "new");

                var GetServiceFeeDetailsResponse = ServiceFactory.GetFileService().GetServiceFeeDetails(fileID);

                UpdateServiceFeeDetails(fileID, "remove");

                var GetServiceFeeDetailsResponse2 = ServiceFactory.GetFileService().GetServiceFeeDetails(fileID);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        #region Private Functions

        public bool UpdateServiceFeeDetails(int fileID, string updateType) //this function is defined as public because this function itself could be UpdateSplitFeeDetails operation. Once done with the ful analysis, then [Test Method] attribute will be added 
        {
            try
            {
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ServiceFee>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry>Service Fees").WaitForScreenToLoad();

                #region Request Parameter Creation
                var UpdateServiceFeeDetailsRequest = new UpdateServiceFeeRequest()
                {
                    FileID = fileID,
                    ServiceFileFees = new ServiceFileFee[]
                {
                    new ServiceFileFee()
                    {
                        BusinessUnitID = 1486,
                        ServiceFileFeeID = 0,
                    }
                },
                    eUpdateType = UpdateType.New,
                    LoginName = "fastts\fastqa07",
                    Source = "FAST"
                };
                #endregion

                string statusDescription = null;
                switch (updateType.ToLower())
                {
                    case "new":
                        if (UpdateServiceFeeDetailsRequest != null)
                        {
                            UpdateServiceFeeDetailsRequest.eUpdateType = UpdateType.New;
                            UpdateServiceFeeDetailsRequest.ServiceFileFees[0].ServiceFeeAmount = Convert.ToDecimal(50.02);
                            statusDescription = "Service Fee/Fees Created Successfully";
                        }
                        break;
                    case "update":
                        UpdateServiceFeeDetailsRequest.eUpdateType = UpdateType.Update;
                        UpdateServiceFeeDetailsRequest.ServiceFileFees[0].ServiceFeeAmount = Convert.ToDecimal(60.02);
                        statusDescription = "Service Fee/Fees Updated Successfully";
                        break;
                    case "remove":
                        UpdateServiceFeeDetailsRequest.eUpdateType = UpdateType.Remove;
                        statusDescription = "Service Fee/Fees Removed Successfully";
                        break;
                    case "cancel":
                        UpdateServiceFeeDetailsRequest.eUpdateType = UpdateType.Cancel;
                        if (Convert.ToInt32(FastDriver.ServiceFee.Table.GetRowCount() - 1) > 0)
                        {
                            FastDriver.ServiceFee.Table.PerformTableAction(1, 1, TableAction.Click);
                            FastDriver.ServiceFee.Transfer.FAClick();
                            Playback.Wait(3000);
                            FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.HomePage>(@"Home");
                            FastDriver.WebDriver.HandleDialogMessage();
                            FastDriver.WebDriver.HandleDialogMessage();
                            FastDriver.WebDriver.HandleDialogMessage();
                            Playback.Wait(3000);
                            UpdateServiceFeeDetailsRequest.ServiceFileFees[0].CancelReason = "Cancel check";
                            statusDescription = "Service Fee/Fees Cancelled Successfully";
                        }
                        break;
                }

                if (updateType.ToLower() != "new")
                    UpdateServiceFeeDetailsRequest.ServiceFileFees[0].ServiceFileFeeID = serviceFileFeeId;

                var UpdateServiceFeeDetailsResponse = ServiceFactory.GetFileService().UpdateServiceFeeDetails(UpdateServiceFeeDetailsRequest);
                Reports.TestStep = "Verify the Service Response";

                Reports.StatusUpdate("Status = " + UpdateServiceFeeDetailsResponse.Status, Convert.ToInt16(UpdateServiceFeeDetailsResponse.Status).Equals(1));
                Reports.StatusUpdate("Status Description = " + UpdateServiceFeeDetailsResponse.StatusDescription, UpdateServiceFeeDetailsResponse.StatusDescription.ToLower().ToString().Contains(statusDescription.ToLower()));

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.HomePage>(@"Home");
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.ServiceFee>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry>Service Fees").WaitForScreenToLoad();

                if (updateType.ToLower() == "remove")
                {
                    bool isPresent = FastDriver.ServiceFee.ServiceFeeStatus.IsVisible();
                    Reports.StatusUpdate("Has Service fee been removed ?", !isPresent);
                }
                else
                {
                    ServiceHelper.CompareWithUI(FastDriver.ServiceFee.ServiceFeeStatus, "value", "Pending");
                    if (UpdateServiceFeeDetailsRequest.ServiceFileFees[0].ServiceFeeAmount.ToString() != "0")
                        ServiceHelper.CompareWithUI(FastDriver.ServiceFee.ServiceFeeAmount.FAGetAttribute("InnerText").ToString(), UpdateServiceFeeDetailsRequest.ServiceFileFees[0].ServiceFeeAmount.ToString(), true, true);
                }
                return true;
            }
            catch
            {
                return false;
            }
        }

        private void StateValidation(string state, FASTWCFHelpers.FastFileService.SplitFeesAsignStateResponse data, string operation)
        {
            switch (operation.ToString().ToLower())
            {
                case "get":

                    if (FastDriver.AssignFeetoPropertyStates.AssignState.FAGetAttribute("checked").ToString().ToLower().Contains("true"))
                    {
                        Support.AreEqual(data.AssignFeeToPropertyStates[0].AssignFeeBtwMulPropStates[1].PropertyState.ToString(), ServiceHelper.GetText(FastDriver.AssignFeetoPropertyStates.State1));
                        Support.AreEqual(data.AssignFeeToPropertyStates[1].AssignFeeBtwMulPropStates[1].AssignPercentage.ToString(), ServiceHelper.GetText(FastDriver.AssignFeetoPropertyStates.SplitPercentage));

                        Support.AreEqual(data.AssignFeeToPropertyStates[2].AssignProperties[0].PropertyState.ToString(), ServiceHelper.GetText(FastDriver.AssignFeetoPropertyStates.State2));
                        Support.AreEqual(data.AssignFeeToPropertyStates[2].AssignFeeBtwMulPropStates[0].AssignPercentage.ToString(), ServiceHelper.GetText(FastDriver.AssignFeetoPropertyStates.SplitPercentage1));

                        //Support.AreEqual(data.AssignFeeToPropertyStates[0].AssignProperties[0].PropertyState.ToString(), ServiceHelper.GetText(FastDriver.AssignFeetoPropertyStates.PropertyState3));
                        //Support.AreEqual(data.AssignPercentage.ToString(), ServiceHelper.GetText(FastDriver.AssignFeetoPropertyStates.SplitPercentage1));

                    }
                    else
                    {
                        switch (state.ToLower())
                        {
                            case "ca":
                                {
                                    Reports.StatusUpdate("Verifying that the State : " + state + "is selected ?", FastDriver.AssignFeetoPropertyStates.State1.FAGetAttribute("checked").ToString().ToLower().Contains("true"));
                                    break;
                                }
                            case "aa":
                                {
                                    Reports.StatusUpdate("Verify that the State : " + state + "is selected ?", FastDriver.AssignFeetoPropertyStates.State2.FAGetAttribute("checked").ToString().ToLower().Contains("true"));
                                    break;
                                }
                            case "ak":
                                {
                                    Reports.StatusUpdate("Verify that the State : " + state + "is selected ?", FastDriver.AssignFeetoPropertyStates.State2.FAGetAttribute("checked").ToString().ToLower().Contains("true"));
                                    break;
                                }
                            case "ga":
                                {
                                    Reports.StatusUpdate("Verify that the State : " + state + "is selected ?", FastDriver.AssignFeetoPropertyStates.State2.FAGetAttribute("checked").ToString().ToLower().Contains("true"));
                                    break;
                                }
                            case "id":
                                {
                                    Reports.StatusUpdate("Verify that the State : " + state + "is selected ?", FastDriver.AssignFeetoPropertyStates.State3.FAGetAttribute("checked").ToString().ToLower().Contains("true"));
                                    break;
                                }
                        }
                    }
                    break;

                case "update":
                    FastDriver.AssignFeetoPropertyStates.WaitForScreenToLoad();
                    FastDriver.AssignFeetoPropertyStates.AssignState.Highlight();
                    string test = FastDriver.AssignFeetoPropertyStates.AssignState.IsSelected().ToString().ToLower();
                    // if (FastDriver.AssignFeetoPropertyStates.AssignState.FAGetAttribute("checked").ToString().ToLower().Contains("true"))
                    if (FastDriver.AssignFeetoPropertyStates.AssignState.IsSelected().ToString().ToLower().Contains("true"))
                    {
                        Support.AreEqual(data.AssignFeeToPropertyStates[0].AssignFeeBtwMulPropStates[0].AssignPercentage.ToString(), ServiceHelper.GetText(FastDriver.AssignFeetoPropertyStates.SplitPercentage));  //(GetSplitFeeAssignStateResponse.AssignFeeToPropertyStates[0].PropertyStatesFeeList
                        Support.AreEqual(data.AssignFeeToPropertyStates[1].AssignFeeBtwMulPropStates[1].AssignPercentage.ToString(), ServiceHelper.GetText(FastDriver.AssignFeetoPropertyStates.SplitPercentage1)); //(GetSplitFeeAssignStateResponse.AssignFeeToPropertyStates[0].PropertyStatesFeeList
                    }
                    else
                    {
                        switch (state.ToLower())
                        {
                            case "ca":
                                {
                                    Reports.StatusUpdate("Verifying that the State : " + state + "is selected ?", FastDriver.AssignFeetoPropertyStates.State1.FAGetAttribute("checked").ToString().ToLower().Contains("true"));
                                    break;
                                }
                            case "aa":
                                {
                                    Reports.StatusUpdate("Verify that the State : " + state + "is selected ?", FastDriver.AssignFeetoPropertyStates.State2.FAGetAttribute("checked").ToString().ToLower().Contains("true"));
                                    break;
                                }
                            case "ak":
                                {
                                    Reports.StatusUpdate("Verify that the State : " + state + "is selected ?", FastDriver.AssignFeetoPropertyStates.State2.FAGetAttribute("checked").ToString().ToLower().Contains("true"));
                                    break;
                                }
                        }
                    }
                    break;
            }
        }

        private void ValidateSplitFee(string type, string operation, PayeeSummary[] PayeeSummaryList = null, SplitServiceFeeDetails[] ServiceFeeDetails = null, FASTWCFHelpers.FastFileService.SplitFeesAsignStateResponse data = null, FASTWCFHelpers.FastFileService.UpdateSplitFeeResponse updateSplitFeeResponse = null, int fileID = 0)
        {
            FastDriver.SplitFeeDisbursements.WaitForScreenToLoad(FastDriver.SplitFeeDisbursements.PayeesSummary);
            switch (type.ToLower())
            {
                case "states":
                    FastDriver.SplitFeeDisbursements.Next.FAClick();
                        FastDriver.AssignFeetoPropertyStates.WaitForScreenToLoad();

                    // if (operation.ToLower().Contains("get"))
                    //     FastDriver.AssignFeetoPropertyStates.FeeTable.PerformTableAction(1, feeDescriotion_titleEscrow, 1, TableAction.Click);
                    // else
                    //     FastDriver.AssignFeetoPropertyStates.FeeTable.PerformTableAction(1, feeDescriotion_fee, 1, TableAction.Click);

                    // var state = GetState(fileID);
                    // StateValidation(state, data, operation);
                    
                    
                    var response = ServiceFactory.GetFileService().GetSplitFeeAssignStateDetails(fileID);
                    Reports.TestStep = "Verify the response of GetSplitFeeAssignStateDetails operation.";
                    Reports.StatusUpdate("Is status == 1 in the response ?", Convert.ToInt16(response.Status).Equals(1));
                    Reports.StatusUpdate("Is the status description as expected in the response ?", response.StatusDescription.ToLower().ToString().Contains("split fee details loaded successfully"));

                    int Fees = Convert.ToInt32(data.AssignFeeToPropertyStates.Length.ToString());

                    for (int i = 0; i < Fees; i++)
                    {
                        
                        string FeeName = data.AssignFeeToPropertyStates[i].AssignFeeBtwMulPropStates[0].Description.ToString();
                        FastDriver.AssignFeetoPropertyStates.FeeTable.PerformTableAction("Description", FeeName, "Description", TableAction.Click);
                        Playback.Wait(5000);
                        if (FastDriver.AssignFeetoPropertyStates.AssignState.IsSelected().ToString() == "True")
                        {
                            string test = data.AssignFeeToPropertyStates[i].AssignFeeBtwMulPropStates[0].AssignAmount.ToString();

                            Support.AreEqual(data.AssignFeeToPropertyStates[i].AssignFeeBtwMulPropStates[0].PropertyState.ToString(), ServiceHelper.GetText(FastDriver.AssignFeetoPropertyStates.FirstState));
                            Support.AreEqual(data.AssignFeeToPropertyStates[i].AssignFeeBtwMulPropStates[1].PropertyState.ToString(), ServiceHelper.GetText(FastDriver.AssignFeetoPropertyStates.SecondState));
                            Support.AreEqual(data.AssignFeeToPropertyStates[i].AssignFeeBtwMulPropStates[2].PropertyState.ToString(), ServiceHelper.GetText(FastDriver.AssignFeetoPropertyStates.ThirdState));

                            Support.AreEqual(string.Format("{0:0.0000}", (Convert.ToDouble((data.AssignFeeToPropertyStates[i].AssignFeeBtwMulPropStates[0].AssignPercentage.ToString())))), ServiceHelper.GetText(FastDriver.AssignFeetoPropertyStates.FirstSplitPercentage));
                            Support.AreEqual(string.Format("{0:0.0000}", (Convert.ToDouble((data.AssignFeeToPropertyStates[i].AssignFeeBtwMulPropStates[1].AssignPercentage.ToString())))), ServiceHelper.GetText(FastDriver.AssignFeetoPropertyStates.SecondSplitPercentage));
                            Support.AreEqual(string.Format("{0:0.0000}", (Convert.ToDouble((data.AssignFeeToPropertyStates[i].AssignFeeBtwMulPropStates[2].AssignPercentage.ToString())))), ServiceHelper.GetText(FastDriver.AssignFeetoPropertyStates.ThirdSplitPercentage));

                            Support.AreEqual(string.Format("{0:0.00}", (Convert.ToDouble((data.AssignFeeToPropertyStates[i].AssignFeeBtwMulPropStates[0].AssignAmount.ToString())))), ServiceHelper.GetText(FastDriver.AssignFeetoPropertyStates.FirstSplitAmount));
                            Support.AreEqual(string.Format("{0:0.00}", (Convert.ToDouble((data.AssignFeeToPropertyStates[i].AssignFeeBtwMulPropStates[1].AssignAmount.ToString())))), ServiceHelper.GetText(FastDriver.AssignFeetoPropertyStates.SecondSplitAmount));
                            Support.AreEqual(string.Format("{0:0.00}", (Convert.ToDouble((data.AssignFeeToPropertyStates[i].AssignFeeBtwMulPropStates[2].AssignAmount.ToString())))), ServiceHelper.GetText(FastDriver.AssignFeetoPropertyStates.ThirdSplitAmount));
                        }
                        else
                        {
                            string state = "";
                            if (Convert.ToBoolean(response.AssignFeeToPropertyStates[0].AssignProperties[0].IsSelected.ToString()))
                                state = response.AssignFeeToPropertyStates[0].AssignProperties[0].PropertyState.ToString();
                            else if (Convert.ToBoolean(response.AssignFeeToPropertyStates[0].AssignProperties[1].IsSelected.ToString()))
                                state = response.AssignFeeToPropertyStates[0].AssignProperties[1].PropertyState.ToString();
                            else
                                state = response.AssignFeeToPropertyStates[0].AssignProperties[2].PropertyState.ToString();

                            int propertiesCount = FastDriver.AssignFeetoPropertyStates.PropertyTable.GetRowCount();
                            for (int k = 1; k<= propertiesCount; k++)
                            {
                                string UIstate = FastDriver.AssignFeetoPropertyStates.PropertyTable.PerformTableAction(k, 1, TableAction.GetAttribute, "selected").Message.Clean();
                                if (UIstate == "True")
                                {
                                    ActualState = FastDriver.AssignFeetoPropertyStates.PropertyTable.PerformTableAction(k, 2, TableAction.GetText).ToString();
                                }
                            }
                            Support.AreEqual(state, ActualState);              
                        }
                    }
                    break;

                case "payee":
                    int length = PayeeSummaryList.Length;

                    for (int i = 0; i <= length - 1; i++)
                    {
                        string test = PayeeSummaryList[i].TotalAmount.ToString();
                        var actualValue = FastDriver.SplitFeeDisbursements.PayeesSummary.PerformTableAction(1, PayeeSummaryList[i].FileBusinessPartyDetails.Name, 2, TableAction.GetText).Message;
                        Support.AreEqual(PayeeSummaryList[i].FileBusinessPartyDetails.PhysicalAddress.AddrLine1, actualValue);

                        actualValue = FastDriver.SplitFeeDisbursements.PayeesSummary.PerformTableAction(3, PayeeSummaryList[i].FileBusinessPartyDetails.PhysicalAddress.City, 4, TableAction.GetText).Message;
                        Support.AreEqual(PayeeSummaryList[i].FileBusinessPartyDetails.PhysicalAddress.State, actualValue);

                        actualValue = FastDriver.SplitFeeDisbursements.PayeesSummary.PerformTableAction(5, PayeeSummaryList[i].FileBusinessPartyDetails.PhysicalAddress.Zip, 6, TableAction.GetText).Message;
                        Support.AreEqual((string.Format("{0:0.00}", (Convert.ToDouble(PayeeSummaryList[i].TotalAmount.ToString())))), actualValue);
                    }
                    break;

                case "splitfee":
                    switch (operation.ToLower())
                    {
                        //response.ServiceFeeDetails

                        case "get":
                            //data.ServiceFeeDetails[0].SplitPercentage
                            //
                            Support.AreEqual(data.ServiceFeeDetails[0].Description.ToString(), ServiceHelper.GetText(FastDriver.SplitFeeDisbursements.splitFeePayeeDescr11)); //  ServiceFeeLists[0].SpliteFeeLists[0].SplitPercentage
                            Support.AreEqual(data.ServiceFeeDetails[0].PayeeName.ToString(), ServiceHelper.GetText(FastDriver.SplitFeeDisbursements.SplitFeePayee11));
                            Support.AreEqual(data.ServiceFeeDetails[0].splitFeeDetails[0].PayeeName.ToString(), ServiceHelper.GetText(FastDriver.SplitFeeDisbursements.SplitFeePayee12));                  //splitFeePayee12
                            Support.AreEqual(data.ServiceFeeDetails[0].Description.ToString(), ServiceHelper.GetText(FastDriver.SplitFeeDisbursements.splitFeePayeeDescr11)); //splitFeePayeeDescr11
                            break;
                        case "update":
                            // Support.AreEqual(feeDescriotion_fee.ToString(), ServiceHelper.GetText(FastDriver.SplitFeeDisbursements.splitFeePayeeDescr21));
                            // Support.AreEqual(feeDescriotion_fee.ToString(), ServiceHelper.GetText(FastDriver.SplitFeeDisbursements.Payee2Description));
                            // Support.AreEqual(data.ServiceFeeDetails[0].splitFeeDetails[0].SplitPercentage.ToString(), ServiceHelper.GetText(FastDriver.SplitFeeDisbursements.SplitPercentage21)); //there's no SplitPercentage field is available for  UpdateSplitFeeResponse. Hence, SplitFeesAssignStateResponse object is used in the expected data part i.e. data.ServiceFeeDetails[0].splitFeeDetails[0].SplitPercentage.ToString().
                            // Support.AreEqual(string.Format("{0:0.0000}", (Convert.ToDouble(ServiceFeeDetails[2].splitFeeDetails[0].SplitPercentage.Value.ToString()))), string.Format("{0:0.0000}", (Convert.ToDouble(ServiceHelper.GetText(FastDriver.SplitFeeDisbursements.SplitPercent(1)))))); //there's no SplitPercentage field is available for  UpdateSplitFeeResponse. Hence, SplitFeesAssignStateResponse object is used in the expected data part i.e. data.ServiceFeeDetails[0].splitFeeDetails[0].SplitPercentage.ToString().


                            string test = FastDriver.SplitFeeDisbursements.SplitPercent1.FAGetText().ToString();
                            Support.AreEqual(string.Format("{0:0.0000}", (Convert.ToDouble(ServiceFeeDetails[0].splitFeeDetails[0].SplitPercentage.Value.ToString()))), ServiceHelper.GetText(FastDriver.SplitFeeDisbursements.SplitPercent1));  //there's no SplitPercentage field is available for  UpdateSplitFeeResponse. Hence, SplitFeesAssignStateResponse object is used in the expected data part i.e. data.ServiceFeeDetails[0].splitFeeDetails[0].SplitPercentage.ToString().
                            Support.AreEqual(string.Format("{0:0.00}", (Convert.ToDouble(ServiceFeeDetails[0].splitFeeDetails[0].SplitFeeAmount.Value.ToString()))), ServiceHelper.GetText(FastDriver.SplitFeeDisbursements.SplitAmount11));
                            
                            Support.AreEqual(string.Format("{0:0.0000}", (Convert.ToDouble(ServiceFeeDetails[2].splitFeeDetails[0].SplitPercentage.Value.ToString()))), ServiceHelper.GetText(FastDriver.SplitFeeDisbursements.SplitPercent41));
                            Support.AreEqual(string.Format("{0:0.00}", (Convert.ToDouble(ServiceFeeDetails[2].splitFeeDetails[0].SplitFeeAmount.Value.ToString()))), ServiceHelper.GetText(FastDriver.SplitFeeDisbursements.SplitAmount41));
                            
                            
                            break;
                    }
                    break;
            }
        }

        private string GetState(int fileID)
        {
            string state = "";

            try
            {
                // AddPreconditions_SplitFee(fileID); 

                var response = ServiceFactory.GetFileService().GetSplitFeeAssignStateDetails(fileID);
                Reports.TestStep = "Verify the response of GetSplitFeeAssignStateDetails operation.";
                Reports.StatusUpdate("Is status == 1 in the response ?", Convert.ToInt16(response.Status).Equals(1));
                Reports.StatusUpdate("Is the status description as expected in the response ?", response.StatusDescription.ToLower().ToString().Contains("split fee details loaded successfully"));

                if (Convert.ToBoolean(response.AssignFeeToPropertyStates[0].AssignProperties[0].IsSelected.ToString()))
                    state = response.AssignFeeToPropertyStates[0].AssignProperties[0].PropertyState.ToString();
                else if (Convert.ToBoolean(response.AssignFeeToPropertyStates[0].AssignProperties[1].IsSelected.ToString()))
                    state = response.AssignFeeToPropertyStates[0].AssignProperties[1].PropertyState.ToString();
                else
                    state = response.AssignFeeToPropertyStates[0].AssignProperties[2].PropertyState.ToString();

                if (Convert.ToInt16(response.Status).Equals(1))
                {
                    return state;
                }
                return "";
            }
            catch (Exception)
            {
                return "";
            }
        }

        private bool WaitForEnabled(IWebElement element = null)
        {
            Reports.TestStep = "Wait for the element until it becomes enabled.";

            //element = Principals;
            try
            {
                FastDriver.TermsDatesStatus.SwitchToContentFrame();
                //                element = element ?? FindNow;
                FastDriver.TermsDatesStatus.WaitCreation(element);
                FastDriver.TermsDatesStatus.Wait.Until(dr =>
                {
                    return element.IsEnabled();
                });
            }
            catch (Exception e)
            {
                return false;
            }
            return true;
        }

        private string GetFeeDescription(string feeType)
        {
            string feeDescription_titleEscrow = "";
            try
            {
                Reports.TestStep = "Navigate to File Fees page";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.AddFees.FAClick();
                Playback.Wait(3000);
                FastDriver.FileFees.SwitchToContentFrame();
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem(feeType);
                FastDriver.FileFees.FindNow.FAClick();
                //Playback.Wait(3000);
                FastDriver.FileFees.SwitchToContentFrame();
                //FastDriver.FileFees.FeeSearchFeeSelect.FAClick();
                int feeRowIndex = 1;
                //bool continueWithinLoop=false;
                string alertMessage = "";
                while (true)
                {
                    FastDriver.FileFees.SwitchToContentFrame();
                    FastDriver.FileFees.AddFeeTable.PerformTableAction(feeRowIndex, 1, TableAction.On);
                    feeDescription_titleEscrow = FastDriver.FileFees.AddFeeTable.PerformTableAction(feeRowIndex, 2, TableAction.GetText).Message;
                    FastDriver.BottomFrame.Done();
                    alertMessage = FastDriver.WebDriver.HandleDialogMessage(timeout: 10);
                    if (alertMessage != "No dialog present")
                    {
                        Reports.StatusUpdate("An Alert with the following message has been handled:" + alertMessage, true);
                        FastDriver.FileFees.SwitchToContentFrame();
                        FastDriver.FileFees.AddFeeTable.PerformTableAction(feeRowIndex, 1, TableAction.Off);
                        alertMessage = "No dialog present";
                        feeRowIndex++;
                        continue;
                    }
                    break;
                }
                return feeDescription_titleEscrow;
            }
            catch (Exception)
            {
                return string.Empty;
            }
        }

        private bool AddFeeEscrowTitle(string feeType, string buyerCharge, string sellerCharge)
        {
            string feeDescriotion_titleEscrow = string.Empty;

            try
            {
                feeDescriotion_titleEscrow = GetFeeDescription(feeType);
                if (feeDescriotion_titleEscrow == string.Empty)
                {
                    return false;
                }

                //feeDescriotion_titleEscrow = ServiceHelper.GetText(FastDriver.FileFees.SearchResultsFeeDescription);

                /*Playback.Wait(4000);
                if(!FindAndClickLink("Title and Escrow"))
                {
                    Reports.StatusUpdate("Could not find or click on a link with the text 'Title and Escrow'!", false);
                }*/

                /*Dictionary<int,IWebElement> feeDesc = new Dictionary<int,IWebElement>() 
                {
                    {0,FastDriver.FileFees.FeeDescription}, 
                    {1,FastDriver.FileFees.FeeDescription1},
                    {2,FastDriver.FileFees.FeeDescription2},
                };

                Dictionary<int,IWebElement> selectCheckBox = new Dictionary<int,IWebElement>() 
                {
                    {0,FastDriver.FileFees.SelectCheckbox}, 
                    {1,FastDriver.FileFees.SelectCheckbox1},
                    {2,FastDriver.FileFees.SelectCheckbox2},
                };

                Dictionary<int,IWebElement> buyerChargeCtrls = new Dictionary<int,IWebElement>() 
                {
                    {0,FastDriver.FileFees.buyercharge}, 
                    {1,FastDriver.FileFees.buyercharge1},
                    {2,FastDriver.FileFees.buyercharge2},
                };

                Dictionary<int,IWebElement> sellerChargeCtrls = new Dictionary<int,IWebElement>() 
                {
                    {0,FastDriver.FileFees.Sellercharge}, 
                    {1,FastDriver.FileFees.sellercharge1},
                    {2,FastDriver.FileFees.sellercharge2},
                };*/

                FastDriver.FileFees.WaitForScreenToLoad();
                var feeDescElement = FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, feeDescriotion_titleEscrow, 2, TableAction.GetText).Message;

                //var IsfeeSelected1 = FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, feeDescriotion_titleEscrow, 1, TableAction.GetAttribute,"checked").Message.Trim();
                var IsfeeSelected = FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, feeDescriotion_titleEscrow, 1, TableAction.GetText).Element.FindElement(By.XPath(".//span/span/input"));
                var feeSelectedFlag = IsfeeSelected.FAGetAttribute("checked"); //this statement is also working fine.


                if (feeDescElement.Equals(feeDescriotion_titleEscrow))
                {
                    if (feeSelectedFlag.Trim().ToLower() == "true")
                    {

                        FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, feeDescriotion_titleEscrow, 4, TableAction.SendKeys, buyerCharge + FAKeys.Tab);
                        //FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, feeDescriotion_titleEscrow, 5, TableAction.SetText, FAKeys.Tab);
                        FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, feeDescriotion_titleEscrow, 7, TableAction.SendKeys, sellerCharge + FAKeys.Tab);
                        //FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, feeDescriotion_titleEscrow, 8, TableAction.SetText, FAKeys.Tab);
                        Playback.Wait(2000);
                        //          buyerChargeCtrls[i].FASetText(buyerCharge);
                        //          sellerChargeCtrls[i].FASetText(sellerCharge);

                        FastDriver.BottomFrame.Done();
                        Playback.Wait(4000);
                        FastDriver.FileFees.WaitForScreenToLoad();
                        /*if(!FindAndClickLink("Title and Escrow"))
                        {
                            Reports.StatusUpdate("Could not find or click on a link with the text 'Title and Escrow'!", false);
                            return false;
                        }*/
                        return true;
                    }
                }
                return false;
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("Error occurred in function : " + MethodBase.GetCurrentMethod().Name + "\r\n" + "Message:" + ex.Message, false);
                return false;
            }
        }

        private string GetFeeDescriptionOfRecordingAndTax(string feeType)
        {
            string feeDescription = "";
            try
            {
                Reports.TestStep = "Navigate to File Fees page";
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();

                FastDriver.FileFees.SwitchToContentFrame();
                Reports.TestStep = "Click Recroding And Tax button.";
                FastDriver.FileFees.RecordingandTax.FAClick();
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.PayRecordingTax); //(FastDriver.FileFees.RecordingLoanEstUnrounded);

                Reports.TestStep = "Click Add Fees Tax button.";
                FastDriver.FileFees.AddFeesTax.FAClick();
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.FeeSearchFeeDescription);

                Reports.TestStep = "Select fee type and click Find Now button.";
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem(feeType);
                FastDriver.FileFees.FindNow.FAClick();

                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.AddFeeTable);
                //FastDriver.FileFees.FeeSearchFeeSelect.FAClick();

                FastDriver.FileFees.SwitchToContentFrame();
                //FastDriver.FileFees.FeeSearchFeeSelect.FAClick();
                int feeRowIndex = 1;
                //bool continueWithinLoop = false;
                string alertMessage = "";
                while (true)
                {
                    FastDriver.FileFees.SwitchToContentFrame();
                    FastDriver.FileFees.AddFeeTable.PerformTableAction(feeRowIndex, 1, TableAction.On);
                    feeDescription = FastDriver.FileFees.AddFeeTable.PerformTableAction(feeRowIndex, 2, TableAction.GetText).Message;
                    FastDriver.BottomFrame.Done();
                    alertMessage = FastDriver.WebDriver.HandleDialogMessage(timeout: 10);
                    if (alertMessage != "No dialog present")
                    {
                        Reports.StatusUpdate("An Alert with the following message has been handled:" + alertMessage, true);
                        FastDriver.FileFees.SwitchToContentFrame();
                        FastDriver.FileFees.AddFeeTable.PerformTableAction(feeRowIndex, 1, TableAction.Off);
                        alertMessage = "No dialog present";
                        feeRowIndex++;
                        continue;
                    }
                    FastDriver.FileFees.SwitchToContentFrame();
                    break;
                }
                return feeDescription;
            }
            catch (Exception)
            {
                return string.Empty;
            }
        }

        private bool AddFeeTax(string feeType, string buyerCharge, string sellerCharge)
        {
            string feeDescription = "";
            try
            {

                feeDescription = GetFeeDescriptionOfRecordingAndTax(feeType);
                if (feeDescription == string.Empty)
                {
                    return false;
                }

                //page.GetControl("IIS.FileFees", "FeeSearchFeeSelect").Click();

                //feeDescriotion_fee = FastDriver.FileFees.SearchResultsFeeDescription.FAGetValue().ToString();

                //FastDriver.BottomFrame.Done();
                //FASTLibrary.FASTLibrary.PerformBottomFrameAction("Done");
                //Playback.Wait(5000);
                //FindAndClickLink("Title and Escrow");
                FastDriver.FileFees.RecordingandTax.FAClick();
                //Playback.Wait(3000);

                /* Dictionary<int,IWebElement> feeDescriptionRecording = new Dictionary<int,IWebElement>() 
                 {
                     {0,FastDriver.FileFees.FeeDescriptionRecording}, 
                     {1,FastDriver.FileFees.FeeDescriptionRecording1},
                     {2,FastDriver.FileFees.FeeDescriptionRecording2},
                 };

                 Dictionary<int,IWebElement> selectRecording = new Dictionary<int,IWebElement>() 
                 {
                     {0,FastDriver.FileFees.SelectRecording}, 
                     {1,FastDriver.FileFees.SelectRecording1},
                     {2,FastDriver.FileFees.SelectRecording2},
                 };

                 Dictionary<int,IWebElement> buyerChargeRecording = new Dictionary<int,IWebElement>() 
                 {
                     {0,FastDriver.FileFees.BuyerChargeRecording1}, 
                     {1,FastDriver.FileFees.BuyerChargeRecording2},
                     {2,FastDriver.FileFees.BuyerChargeRecording3},
                 };

                 Dictionary<int,IWebElement> sellerChargeRecording = new Dictionary<int,IWebElement>() 
                 {
                     {0,FastDriver.FileFees.SellerChargeRecording}, 
                     {1,FastDriver.FileFees.SellerChargeRecording1},
                     {2,FastDriver.FileFees.SellerChargeRecording2},
                 };*/


                //for (int i = 0; i < 3; i++)
                //{

                var feeDescInFeeEntry = FastDriver.FileFees.RecordingandTaxTable.PerformTableAction(2, feeDescription, 2, TableAction.GetText).Message;

                //var IsfeeSelected1 = FastDriver.FileFees.TitleandescrowTable.PerformTableAction(2, feeDescriotion_titleEscrow, 1, TableAction.GetAttribute,"checked").Message.Trim();
                var IsfeeSelected = FastDriver.FileFees.RecordingandTaxTable.PerformTableAction(2, feeDescription, 1, TableAction.GetText).Element.FindElement(By.XPath(".//span/span/input"));
                var feeSelectedFlag = IsfeeSelected.FAGetAttribute("checked"); //this statement is also working fine.


                if (feeDescInFeeEntry.Equals(feeDescription))
                {
                    if (feeSelectedFlag.Trim().ToLower() == "true")
                    {
                        FastDriver.FileFees.RecordingandTaxTable.PerformTableAction(2, feeDescription, 4, TableAction.SetText, buyerCharge);
                        FastDriver.FileFees.RecordingandTaxTable.PerformTableAction(2, feeDescription, 5, TableAction.SetText, sellerCharge);
                        FastDriver.BottomFrame.Done();
                        Playback.Wait(5000);
                        FindAndClickLink("Recording and Tax");
                        return true;
                    }
                }
                //}
                return false;
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate(ex.Message, false);
            }
            return false;
        }

        private void AddPayRecordingTax()
        {
            Reports.TestStep = "Executing AddPayRecordingTax() function.";
            FastDriver.FileFees.SwitchToContentFrame();
            FastDriver.FileFees.PayRecordingTax.FAClick();
            //Playback.Wait(5000);
            FastDriver.RecordFeeTransferTaxDisb.WaitForScreenToLoad();
            FastDriver.RecordFeeTransferTaxDisb.New.FAClick();
            FastDriver.RecordFeeTransferTaxDisb.GABcode.FASetText("508");
            FastDriver.RecordFeeTransferTaxDisb.Find.FAClick();
            //            Playback.Wait(3000);
            FastDriver.RecordFeeTransferTaxDisb.WaitForScreenToLoad(FastDriver.RecordFeeTransferTaxDisb.FirstCheckBox);
            FastDriver.RecordFeeTransferTaxDisb.FirstCheckBox.FASetCheckbox(true);
            //            Playback.Wait(3000);
            FastDriver.BottomFrame.Done();
            Playback.Wait(5000);
            FindAndClickLink("Title and Escrow");
        }

        private FileFeeDeliveryRequest CreateFileFeeDeliveryRequest(int fileID)
        {
            Reports.TestStep = "Construct RemoveProductRequest object.";
            var request = new FASTWCFHelpers.FastFileService.FileFeeDeliveryRequest()
            {
                EmployeeID = 1,
                FileID = fileID,
                LoginName = "Fastts\\Fastqa07",
                Source = "FAMOS",
                eDeliveryMethod = DeliveryMethod.Preview
            };
            return request;
        }

        private bool FindAndClickLink(string linkText)
        {
            try
            {
                FastDriver.FileFees.SwitchToContentFrame();
                By elemBy = By.LinkText(linkText);
                var elem = FastDriver.WebDriver.FindElement(elemBy);
                //By elemBy = FAByFactory.From(() => elem);
                var wait = new WebDriverWait(FastDriver.WebDriver, TimeSpan.FromSeconds(10));
                IWebElement imgElement = wait.Until(ExpectedConditions.ElementIsVisible(elemBy));
                return true;
            }
            catch
            {
                return false;
            }
        }

        private void AddPreconditions_SplitFee(int fileID)
        {
            // Commenting below code since escrow title is already added.

            //string buyer1Charge = "10.01";
            //string seller1Charge = "20.02";
            //string buyer2Charge = "10.11";
            //string seller2Charge = "20.22";

            //Reports.TestStep = "Navigate to File Fees page";
            //FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
            ////Add Fee
            //if (!AddFeeEscrowTitle("Escrow Fee", buyer1Charge, seller1Charge))
            //{
            //    Reports.StatusUpdate("Could not add Fee Type : Escrow Fee", false);
            //}
            //FindAndClickLink("Title and Escrow");
            //if (!AddFeeEscrowTitle("Title - Endorsement Fee", buyer2Charge, seller2Charge))
            //{
            //    Reports.StatusUpdate("Could not add Fee Type : Title - Endorsement Fee", false);
            //}
            //FindAndClickLink("Title and Escrow");

            // Commenting the below code since properties are added already.
            ////Adding Property
            //for (int i = 0; i < 2; i++)
            //{
            //    try
            //    {
            //        Reports.TestStep = "Navigate to Properties/Tax Info";
            //        //FASTLibrary.FASTLibrary.Treeview("Home/Order Entry/Properties//Tax Info");
            //        FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info").WaitForScreenToLoad();
            //        //Playback.Wait(2000);

            //        FastDriver.PropertiesSummary.SummaryRow1.FADoubleClick();
            //        Playback.Wait(500);
            //        FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
            //        FastDriver.PropertyTaxInfoGeneral.GeneralNew.FAClick();
            //        Playback.Wait(500);

            //        FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine1.FASetText("Address1");
            //        FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine2.FASetText("Address2");
            //        FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine3.FASetText("Address3");
            //        FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine4.FASetText("Address4");

            //        if (i == 0)
            //            FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailState.FASelectItem("GA");
            //        else
            //            // FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailState.FASelectItem("AK");
            //            FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailState.FASelectItem("ID");


            //        FastDriver.BottomFrame.Save();
            //        Playback.Wait(1000);

            //        //var win = new FATAF.WinSupport();
            //        var popupMessage = FastDriver.WebDriver.HandleDialogMessage(true, true, 5);
            //        Playback.Wait(1000);

            //        FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();

            //        if (FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailState.FAGetSelectedItem().ToString() == "AA")
            //        {
            //            FastDriver.BottomFrame.Reset();
            //        }
            //        else
            //        {
            //            FastDriver.BottomFrame.Done();
            //        }
            //        Playback.Wait(1000);
            //    }
            //    catch (Exception ex)
            //    {
            //        Reports.StatusUpdate(ex.Message, false);
            //    }
            //}

            // SplitFeeToPayeesAndState(fileID);
        }

        private void SplitFeeToStates(int fileID)
        {
            FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.AssignFeetoPropertyStates>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry>Split Fees/Assign State");
            FastDriver.SplitFeeDisbursements.WaitForScreenToLoad();
            //if (!(FastDriver.SplitFeeDisbursements.Next.IsDisplayed().ToString() == "True"))
            //{
            //    string[] StrArr = null;
            //    int FeeRows = FastDriver.SplitFeeDisbursements.SplitFeesSummary.GetRowCount();
            //    for (int i = 1; i < FeeRows; i++)
            //    {
            //        StrArr[i - 1] = FastDriver.SplitFeeDisbursements.SplitFeesSummary.PerformTableAction(1, 1, TableAction.GetText).ToString();
            //    }


            //}
            FastDriver.SplitFeeDisbursements.Next.FAClick();
            FastDriver.AssignFeetoPropertyStates.WaitForScreenToLoad(FastDriver.AssignFeetoPropertyStates.AssignState);
            int rows = FastDriver.AssignFeetoPropertyStates.FeeTable.GetRowCount();
            for (int i = 1; i <= rows; i++)
            {
                FastDriver.AssignFeetoPropertyStates.WaitForScreenToLoad(FastDriver.AssignFeetoPropertyStates.AssignState);
                FastDriver.AssignFeetoPropertyStates.FeeTable.PerformTableAction(i, 1, TableAction.Click);
                if (i == 1)
                {
                    if (FastDriver.AssignFeetoPropertyStates.AssignState.IsEnabled().ToString() == "True")
                    {
                        FastDriver.AssignFeetoPropertyStates.WaitForScreenToLoad();
                        Playback.Wait(5000);
                        FastDriver.AssignFeetoPropertyStates.AssignState.FASetCheckbox(true);
                        Playback.Wait(5000);
                        FastDriver.AssignFeetoPropertyStates.WaitForScreenToLoad();
                        FastDriver.AssignFeetoPropertyStates.AssignTable.PerformTableAction("Property State", "GA", "Assign %", TableAction.Click);
                        FastDriver.AssignFeetoPropertyStates.AssignTable.PerformTableAction("Property State", "GA", "Assign %", TableAction.SetText, "10" + FAKeys.Tab);
                        FastDriver.AssignFeetoPropertyStates.AssignTable.PerformTableAction("Property State", "ID", "Assign %", TableAction.Click);
                        FastDriver.AssignFeetoPropertyStates.AssignTable.PerformTableAction("Property State", "ID", "Assign %", TableAction.SetText, "20" + FAKeys.Tab);
                    }
                }
                else
                {
                    if (FastDriver.AssignFeetoPropertyStates.AssignState.IsEnabled().ToString() == "True")
                    {
                        FastDriver.AssignFeetoPropertyStates.AssignState.FASetCheckbox(true);
                        Playback.Wait(3000);
                        FastDriver.AssignFeetoPropertyStates.WaitForScreenToLoad();
                        FastDriver.AssignFeetoPropertyStates.AssignTable.PerformTableAction("Property State", "GA", "Assign %", TableAction.Click);
                        FastDriver.AssignFeetoPropertyStates.AssignTable.PerformTableAction("Property State", "GA", "Assign %", TableAction.SetText, "20" + FAKeys.Tab);
                        FastDriver.AssignFeetoPropertyStates.AssignTable.PerformTableAction("Property State", "ID", "Assign %", TableAction.Click);
                        FastDriver.AssignFeetoPropertyStates.AssignTable.PerformTableAction("Property State", "ID", "Assign %", TableAction.SetText, "30" + FAKeys.Tab);
                    }
                }
                FastDriver.BottomFrame.Save();
                Playback.Wait(5000);
            }
            // FastDriver.BottomFrame.Save();
            FastDriver.BottomFrame.Done();

        }

        private void SplitFeeToPayees(int fileID)
        {
            //   var bframe = new FATAF.HtmlSupport();

            int serviceFeeId1 = 0;
            int serviceFeeId2 = 0;
            var getFeeEntryResponse = ServiceFactory.GetFileService().GetFeeEntryDetails(fileID, "");
            if (AutoConfig.FormType == "HUD")
            {
                serviceFeeId1 = (int)getFeeEntryResponse.TitleAndEscrow.FileFees[0].FeePaymentDetails.ServiceFileFeeId;
                serviceFeeId2 = (int)getFeeEntryResponse.TitleAndEscrow.FileFees[1].FeePaymentDetails.ServiceFileFeeId;
            }
            else
            {
                serviceFeeId1 = (int)getFeeEntryResponse.TitleAndEscrow.CdFileFees[0].FeePaymentDetails.ServiceFileFeeId;
                serviceFeeId2 = (int)getFeeEntryResponse.TitleAndEscrow.CdFileFees[1].FeePaymentDetails.ServiceFileFeeId;
            }
            var getOrderDetailsResponse = ServiceFactory.GetFileService().GetOrderDetails(fileID);
            var GetSplitFeeAssignStateResponse = ServiceFactory.GetFileService().GetSplitFeeAssignStateDetails(fileID);


            int busOrgId = (int)getOrderDetailsResponse.FileBusinessParties[0].BusOrgID;
            int fbp = (int)getOrderDetailsResponse.FileBusinessParties[0].FileBusinessPartyID;

            var request = new FASTWCFHelpers.FastFileService.UpdateSplitFeeRequest()
            {
                ServiceFeeLists = new FASTWCFHelpers.FastFileService.ServiceFeeList[]
                {
                    new ServiceFeeList()
                    {
                        SpliteFeeLists = new FASTWCFHelpers.FastFileService.SpliteFeeList[]
                        {
                            new FASTWCFHelpers.FastFileService.SpliteFeeList()
                            { 
                                SplitPercentage = 50,
                                ePayeeRoleType = FASTWCFHelpers.FastFileService.SplitPayee.GAB,
                                eSplitType = FASTWCFHelpers.FastFileService.SplitType.New
                            }
                        }
                    }
                },
                LoginName = @"fastts\fastqa07",
                Source = "FAST",
            };

            request.FileID = fileID;
            splitPayeePercentage = (decimal)request.ServiceFeeLists[0].SpliteFeeLists[0].SplitPercentage;
            request.ServiceFeeLists[0].ServiceFileFeeID = serviceFeeId1;
            request.ServiceFeeLists[0].SpliteFeeLists[0].BusOrgID = busOrgId;
            request.ServiceFeeLists[0].SpliteFeeLists[0].SplitFeeID = serviceFeeId1;

            var response = ServiceFactory.GetFileService().UpdateSplitFeeDetails(request);
            Assert.IsTrue(Convert.ToInt16(response.ServiceFeeListResponse.Status).Equals(1));
            Assert.IsTrue(response.ServiceFeeListResponse.StatusDescription.ToLower().ToString().Contains("splitfee updated sucessfully"));

            // Commenting the below part of code.

            //FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.AssignFeetoPropertyStates>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry>Split Fees/Assign State");
            //FastDriver.SplitFeeDisbursements.WaitForScreenToLoad();

            ////var splitFee = new FATAF.HtmlSupport();

            //// splitFee.SetParent("IIS.SplitFeeDisbursements", "SplitFeeDisbursements");
            //// splitFee.GetControl("IIS.SplitFeeDisbursements", "New").Click();
            //// Playback.Wait(1000);

            //// splitFee.SetParent("IIS.PayeeSearchDlg", "PayeeSearchDlg");
            //// splitFee.GetControl("IIS.PayeeSearchDlg", "FABFirstCheckBox").Click();
            //// Playback.Wait(2000);
            //// //splitFee.GetControl("IIS.PayeeSearchDlg", "Done").Click();
            ////// FASTLibrary.FASTLibrary.PerformBottomFrameAction("Done");
            //// //bframe.SetParent("BottomFrame", "BottomFrame");
            //// //bframe.GetControl("BottomFrame", "Done").Click();

            //// Keyboard.SendKeys("^D");
            //// Playback.Wait(1000);

            ////splitFee.SetParent("IIS.SplitFeeDisbursements", "SplitFeeDisbursements");
            ////string PayeeName = splitFee.GetControl("IIS.PayeeSearchDlg", "Payee2").Get("InnerText").ToString();
            ////splitFee.GetControl("IIS.SplitFeeDisbursements", "Scissor1").Click();
            ////splitFee.GetControl("IIS.SplitFeeDisbursements", "Payee").Set("SelectedItem", PayeeName);
            ////splitFee.GetControl("IIS.SplitFeeDisbursements", "SplitPercentage").Set("Text", splitPayeePercentage);
            //FastDriver.SplitFeeDisbursements.Next.FAClick();
            ////splitFee.GetControl("IIS.SplitFeeDisbursements", "Next").Click();



            //FastDriver.AssignFeetoPropertyStates.WaitForScreenToLoad();
            //FastDriver.AssignFeetoPropertyStates.AssignState.FAClick();
            //FastDriver.AssignFeetoPropertyStates.State1.FAClick();
            //FastDriver.AssignFeetoPropertyStates.SplitPercentage.FASetText(splitStatePercentage1.ToString());
            //FastDriver.AssignFeetoPropertyStates.State2.FAClick();
            //FastDriver.AssignFeetoPropertyStates.SplitPercentage1.FASetText(splitStatePercentage2.ToString());

            ////bframe.SetParent("BottomFrame", "BottomFrame");
            ////FastDriver.BottomFrame.Save();
            ////Playback.Wait(1000);
            //FastDriver.BottomFrame.Done();
            //Playback.Wait(1000);
        }

        private int CreateFile()
        {
            int fileID;
            #region Create a file through WCF
            Reports.TestStep = "Create a file with required values through WCF.";
            var fileRequest = CreateFileRequest();

            var fileResponse = FASTWCFHelpers.FileService.CreateFile(fileRequest);
            fileID = (int)fileResponse.FileID;
            Support.IsTrue((int)(fileResponse.FileID ?? 0) > 0, "Is this FileId valid ? " + fileID);

            var fileDetails = FASTWCFHelpers.FileService.GetOrderDetails(fileID);
            Reports.TestStep = "Search File in MRU.";
            FastDriver.TopFrame.SearchFileByFileNumber(fileDetails.FileNumber);
            #endregion

            return fileID;
        }

        private CreateFileRequest CreateFileRequest()
        {
            return new CreateFileRequest
            {
                EmployeeObjectCD = "1",
                Source = "FAMOS",
                formType = ClosingDisclosureSupport.FormType,
                File = new FASTWCFHelpers.FastFileService.File()
                {
                    TransactionTypeObjectCD = "SALE",
                    BusinessSegmentObjectCD = "Commercial",
                    ExternalFileNumber = "12345678905",
                    AutoNumberIndicator = true,

                    BusinessParties = new FileBusinessParty[] 
                    {
                        new FileBusinessParty()
                        {
                            //AddrBookEntryID = AdminService.GetGABAddressBookEntryId("8835227"),
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                            RoleTypeObjectCD = "BUSSOURCE",
                        } 
                    },

                    Services = new Service[] 
                    { 
                        new Service() 
                        { 
                            OfficeInfo = new OfficeInfo() 
                            { 
                                RegionID = int.Parse(ClosingDisclosureSupport.IMDRegionBUID), 
                                BUID = 1487,
                            },
                        ServiceTypeObjectCD = "TO" 
                        },
                        new Service() 
                        {
                            OfficeInfo = new OfficeInfo() 
                            { 
                                RegionID = int.Parse(ClosingDisclosureSupport.IMDRegionBUID), 
                                BUID = 1487, 
                            },
                            ServiceTypeObjectCD = "EO"
                        }
                    },

                    Properties = new Property[] 
                    { 
                        new Property() 
                        {
                            Name = "my-test-property",
                            PropertyAddress = new FASTWCFHelpers.FastFileService.PhysicalAddress[] 
                            {
                                new FASTWCFHelpers.FastFileService.PhysicalAddress() 
                                { 
                                    State = "CA", 
                                    City = "Santa Ana", 
                                    County = "Orange", 
                                    Country = "USA" 
                                } 
                            } 
                        } 
                    },
                }
            };
        }

        public static FeeEntryRequest UpdateFeeEntryRequest(int? fileId = null)
        {
            return new FeeEntryRequest()
            {
                EmployeeID = 1,
                FileID = fileId,
                RecordingAndTax = new RecordingAndTax()
                {
                    GovernmentRecordingAndTransferTaxes = new GovernmentRecordingAndTransferTaxes()
                    {
                        CdTransferTax = new LoanEstimateRAndUR() { },
                        GovernmentCdRecordingCharges = new LoanEstimateRAndUR() { }
                    },
                },
                TitleAndEscrow = new TitleAndEscrow()
                {
                    TitlePolicyCalculationsForCD = new CdTitlePolicyCalculations()
                    {
                        DisclosedOwnerPremium = new CdFeeInformation() { },
                        FullLoanPremium = new CdFeeInformation() { }
                    },
                    TitleServicesAndTitleInsurance = new TitleServicesAndTitleInsurance()
                    {
                        OwnersTitleInsurance = new GFEInformation() { },
                        TitleServicesOrLenderTitleIns = new GFEInformation() { }
                    },
                },
                LoginName = AutoConfig.UserName,
                Source = @"FAMOS"
            };
        }

        private void AddProperty(int properties)
        {
            for (int i = 0; i < properties; i++)
            {
                try
                {
                    Reports.TestStep = "Navigate to Properties/Tax Info";
                    FastDriver.LeftNavigation.Navigate<PropertiesSummary>(@"Home>Order Entry>Properties/Tax Info").WaitForScreenToLoad();
                    FastDriver.PropertiesSummary.New.FAClick();
                    FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                    FastDriver.PropertyTaxInfoGeneral.GeneralNew.FAClick();
                    Playback.Wait(5000);
                    FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine1.FASetText("Address1");
                    FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine2.FASetText("Address2");
                    FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine3.FASetText("Address3");
                    FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailStreetLine4.FASetText("Address4");
                    if (i == 0)
                        FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailState.FASelectItem("GA");
                    if (i == 1)
                        FastDriver.PropertyTaxInfoGeneral.GeneralAddressDetailState.FASelectItem("ID");

                    FastDriver.BottomFrame.Save();
                    Playback.Wait(1000);
                    var popupMessage = FastDriver.WebDriver.HandleDialogMessage(true, true, 5);
                    FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                    FastDriver.BottomFrame.Done();
                }
                catch (Exception ex)
                {
                    Reports.StatusUpdate(ex.Message, false);
                }
            }
        }

        /*public object SetEnumNode(Object parentInstance, string propertyName, object value,int indexValue=-1)
        {
            Type instanceType = parentInstance.GetType().GetProperty(propertyName).PropertyType;
            object instanceObject = Activator.CreateInstance(instanceType);
            dynamic enumType = Enum.GetValues(instanceType);
            dynamic enumNames = Enum.GetNames(instanceObject.GetType());
           
            int index = 0;
            if (indexValue >= 0)
            {
                instanceObject = enumType[indexValue];
            }
            else
            {
                foreach (var name in enumNames)
                {
                    if (name.ToLower().Contains(value.ToString().ToLower()))
                    {
                        instanceObject = enumType[index];
                        break;
                    }
                    index++;
                }
            }
            parentInstance.GetType().GetProperty(propertyName).SetValue(parentInstance, instanceObject, null);
            return instanceObject;
        }*/
        #endregion
                #endregion
    }
}
