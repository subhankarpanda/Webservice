﻿using FASTSelenium.Common;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers.FastFileService;
using FASTWCFHelpers.Factories;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using FASTWCFHelpers;


namespace WebServices.File
{
    [CodedUITest]
    public class ProductWS : FASTHelpers
    {
        bool isProductadded = false;

        [TestMethod]
        //[Owner("Yusuf")]
        //[TestCategory("CD")]

        /// <summary>
        /// Author : Yusuf
        /// Date : 31-12-2015
        /// Test case to add a Product
        /// </summary>
        public void REG_AddProduct()
        {
            try
            {

                Reports.TestDescription = "Adding Product.";

                Reports.TestStep = "Login to FAST, create a file using QFE and get the fileId.";

                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FAST_Login_IIS();
                #endregion

                int fileID = CreateFile();
                var request = CreateRequestForAddProduct<AddProductRequest>(fileID);
                InvokeAddProductAndValidateOutcome(request);
                
                Reports.TestStep = "Navigate to File HomePage";
                FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                Playback.Wait(3000);

                #region VALIDATIONS
                //Helper.GetStatusOnReport(page.GetControl("FileHomepage", "Products").Get("Checked").ToString().ToLower().Contains("true"), "Product is added to the list of products.");
                //Helper.ContainsUIVal(page.GetControl("FileHomepage", "ProductsLable"), "InnerText", productName);
                var ProductCollection = GetProductCollection();
                string product_FromRequest = ProductCollection[(int)request.Product.ProductID];

                Reports.StatusUpdate("Product is added to the list of products ?", FastDriver.FileHomepage.Products.IsSelected().ToString().ToLower().Contains("true"));

                Reports.TestStep = "Verify that the product has been added successfully.";
                ServiceHelper.ContainsUIVal(FastDriver.FileHomepage.ProductLabel, "text", product_FromRequest);
                #endregion

                if (Reports.TestResult)
                {
                    Reports.StatusUpdate("Product added successfully !", Reports.TestResult);
                    Support.IsTrue(Reports.TestResult, "Test Passed !");
                }
                if (!Reports.TestResult)
                {
                    Reports.StatusUpdate("Product could not be added !", false);
                    Support.IsTrue(!Reports.TestResult, "Test Failed !");
                }
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }





          [TestMethod]
          public void REG_RemoveProduct()
          {
              Reports.TestDescription = "Removing Product.";

              Reports.TestStep = "Login to FAST.";

              #region FAST Login IIS side
              FAST_Login_IIS();
              #endregion

              Reports.TestStep = "Create a file through WCF and get the fileId.";

              var fileID = CreateFile();
              var addProductRequest = CreateRequestForRemoveProduct<RemoveProductRequest>(fileID);

              if(InvokeRemoveProductAndValidateOutcome(addProductRequest))
              {
                  var removeProductRequest = CreateRequestForRemoveProduct<RemoveProductRequest>(fileID);
                  var removeProductResponse = InvokeRemoveProductAndValidateOutcome(removeProductRequest);

                  Reports.TestStep = "Navigate to File HomePage.";
                  FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
                  Playback.Wait(3000);

                  #region VALIDATIONS
                  var ProductCollection = GetProductCollection();
                  string product_FromRequest = ProductCollection[(int)removeProductRequest.Product.ProductID];

                  //Reports.StatusUpdate("Product is removed from the list of products ?", !FastDriver.FileHomepage.Products.IsSelected().ToString().ToLower().Contains("true"));
                  Reports.TestStep = "Verify that the product has been removed successfully.";
                  if(FastDriver.FileHomepage.ProductLabel.FAGetText().Contains(product_FromRequest))
                  {
                      Reports.TestResult = false;
                  }
                  #endregion
                  if (Reports.TestResult)
                  {
                      Reports.StatusUpdate("Product removed successfully !", Reports.TestResult);
                      Support.IsTrue(Reports.TestResult, "Test Passed !");
                  }
                  if (!Reports.TestResult)
                  {
                      Reports.StatusUpdate("Product could not be removed !", false);
                      Support.IsTrue(!Reports.TestResult, "Test Failed !");
                  }

              }
              else
              {
                  Reports.StatusUpdate("Product could not be added successfully ! ", false);
                  Assert.Fail();
              }
          }



        #region Private Functions
        private bool WaitForEnabled(IWebElement element = null)
        {
            Reports.TestStep = "Wait for the element until it becomes enabled.";

            //element = Principals;
            try
            {
                FastDriver.TermsDatesStatus.SwitchToContentFrame();
                //                element = element ?? FindNow;
                FastDriver.TermsDatesStatus.WaitCreation(element);
                FastDriver.TermsDatesStatus.Wait.Until(dr =>
                {
                    return element.IsEnabled();
                });
            }
            catch (Exception e)
            {
                return false;
            }
            return true;
        }


        private bool InvokeAddProductAndValidateOutcome(AddProductRequest request)
        {
            bool result = false;
            try
            {
                Reports.TestStep = "Invoke AddProduct operation and get the response.";
                var response = ServiceFactory.GetFileService().AddProduct(request);
                Reports.StatusUpdate("AddProduct operation invoked !", true);

                Reports.TestStep = "Validate the response.";

                Reports.StatusUpdate("Status = " + response.Status, Convert.ToInt16(response.Status).Equals(1));
                Reports.StatusUpdate("Status Description = " + response.StatusDescription, response.StatusDescription.ToLower().ToString().Contains("product added successfully."));
                if(Convert.ToInt16(response.Status).Equals(1) && response.StatusDescription.ToLower().ToString().Contains("product added successfully."))
                {
                    Reports.StatusUpdate("AddProduct operation is successful !", true);
                    result = true;
                }
            }
            catch(Exception ex)
            {
                throw new Exception("Invoking AddProduct operation failed! Error : "+ex.Message);
            }
            return result;
        }


        private bool InvokeRemoveProductAndValidateOutcome(RemoveProductRequest request)
        {
            bool result = false;
            try
            {
                Reports.TestStep = "Invoke RemoveProduct operation and get the response.";
                var response = ServiceFactory.GetFileService().RemoveProduct(request);
                Reports.StatusUpdate("RemoveProduct operation invoked !", true);

                Reports.TestStep = "Validate the response.";

                Reports.StatusUpdate("Status = " + response.Status, Convert.ToInt16(response.Status).Equals(1));
                Reports.StatusUpdate("Status Description = " + response.StatusDescription, response.StatusDescription.ToLower().ToString().Contains("product removed successfully."));
                if (Convert.ToInt16(response.Status).Equals(1) && response.StatusDescription.ToLower().ToString().Contains("product removed successfully."))
                {
                    Reports.StatusUpdate("RemoveProduct operation is successful !", true);
                    result = true;
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Invoking RemoveProduct operation failed! Error : " + ex.Message);
            }
            return result;
        }


        private int CreateFile()
        {
            int fileID;
            #region Create a file through WCF
            Reports.TestStep = "Create a file with required values through WCF.";
            var fileRequest = CreateFileRequest();

            var fileResponse = FASTWCFHelpers.FileService.CreateFile(fileRequest);
            fileID = (int)fileResponse.FileID;
            Support.IsTrue((int)(fileResponse.FileID ?? 0) > 0, "Is this FileId valid ? " + fileID);

            var fileDetails = FASTWCFHelpers.FileService.GetOrderDetails(fileID);
            Reports.TestStep = "Search File in MRU.";
            FastDriver.TopFrame.SearchFileByFileNumber(fileDetails.FileNumber);
            #endregion
            
            return fileID;
        }

        private AddProductRequest CreateRequestForAddProduct<T>(int fileID)
        {
            Reports.TestStep = "Construct AddProductRequest object.";
            var request = new FASTWCFHelpers.FastFileService.AddProductRequest()
            {
                FielID = fileID,
                Product = new Product() 
                {
                    ProductID = 866
                }
            };
            return request;
        }


        private RemoveProductRequest CreateRequestForRemoveProduct<T>(int fileID)
        {
            Reports.TestStep = "Construct RemoveProductRequest object.";
            var request = new FASTWCFHelpers.FastFileService.RemoveProductRequest()
            {
                FielID = fileID,
                Product = new Product() 
                {
                    ProductID = 866
                }
            };
            return request;
        }

        private CreateFileRequest CreateFileRequest()
        {
            return new CreateFileRequest
            {
                EmployeeObjectCD = "1",
                Source = "FAMOS",
                formType = ClosingDisclosureSupport.FormType,
                File = new FASTWCFHelpers.FastFileService.File()
                {
                    TransactionTypeObjectCD = "SALE",
                    BusinessSegmentObjectCD = "Commercial",
                    ExternalFileNumber = "12345678905",
                    AutoNumberIndicator = true,

                    BusinessParties = new FileBusinessParty[] 
                    {
                        new FileBusinessParty()
                        {
                            //AddrBookEntryID = AdminService.GetGABAddressBookEntryId("8835227"),
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                            RoleTypeObjectCD = "BUSSOURCE",
                        } 
                    },

                    Services = new Service[] 
                    { 
                        new Service() 
                        { 
                            OfficeInfo = new OfficeInfo() 
                            { 
                                RegionID = int.Parse(ClosingDisclosureSupport.IMDRegionBUID), 
                                BUID = 1487,
                            },
                        ServiceTypeObjectCD = "TO" 
                        },
                        new Service() 
                        {
                            OfficeInfo = new OfficeInfo() 
                            { 
                                RegionID = int.Parse(ClosingDisclosureSupport.IMDRegionBUID), 
                                BUID = 1487, 
                            },
                            ServiceTypeObjectCD = "EO"
                        }
                    },

                    Properties = new Property[] 
                    { 
                        new Property() 
                        {
                            Name = "my-test-property",
                            PropertyAddress = new FASTWCFHelpers.FastFileService.PhysicalAddress[] 
                            {
                                new FASTWCFHelpers.FastFileService.PhysicalAddress() 
                                { 
                                    State = "CA", 
                                    City = "Santa Ana", 
                                    County = "Orange", 
                                    Country = "USA" 
                                } 
                            } 
                        } 
                    },
                }
            };
        }


        private Dictionary<int, string> GetProductCollection()
        {
            return new Dictionary<int, string>
            {
                {884,"Abstract"},
                {1254,"Agency File Scanning"},
                {1255,"Agency Policy Typing"},
                {1256,"Agency Post Closing"},
                {866, "*ALTA Construction Loan 1992 Policy"},
                {886, "*ALTA Expanded (Eagle Loan) Policy"},
                {868, "ALTA Extended Leasehold Loan Policy"},
                {869,"ALTA Extended Leasehold Owners Policy"},
                {1317,"ALTA Extended Loan Policy"},
                {1318,"ALTA Extended Owner Policy"},
                {2189,"ALTA Homeowner’s Policy (Agent Use Only)"},
                {887,"ALTA Homeowners (Eagle Owner) Policy"},
                {1257,"ALTA Res Ltd Cov Jr Loan Policy (Express)"},
                {877,"ALTA Residential Plain Language Owners Policy"},
                {888,"ALTA Short Form Commercial Loan Policy"},
                {903,"ALTA Short Form Expanded Coverage Residential Loan Policy"},
                {1711,"ALTA Short Form Residential Loan Policy"},
                {1828,"ALTA Short Form Residential Loan Policy - Extended"},
                {875,"ALTA Standard Leasehold Loan Policy"},
                {876,"ALTA Standard Leasehold Owners Policy"},
                {1320,"ALTA Standard Loan Policy"},
                {1838,"ALTA Standard Mtgees Assur Rec Title (SMART)"},
                {1321,"ALTA Standard Owner Policy"},
                {881,"ALTA Standard U.S. Policy 1991"},
                {1674,"America First Loan Policy"},
                {1678,"America First Protection Homeowner’s Binder Policy"},
                {1676,"America First Protection Homeowner’s Policy"},
                {1677,"America First Protection New Home Policy"},
                {1675,"America First Short Form Loan Policy"},
                {1259,"Attorney Assistance"},
                {1260,"Back Plant Request"},
                {900,"Closing Table OP – Land Contract"},
                {906,"CLTA Chain of Title Guar Form"},
                {907,"CLTA Fin Stmt Ln Guar with Add Verif"},
                {908,"CLTA Financing Statement/Lien Guarantee"},
                {1261,"CLTA Interim Binder - Resale"},
                {909,"CLTA Judgment/Tax Lien Guarantee"},
                {1262,"CLTA Lender's Datedown Guarantee"},
                {910,"CLTA Litigation Guar Form 1992"},
                {911,"CLTA Lot Book Guarantee Form 12"},
                {912,"CLTA Mechanic's Lien Guarantee"},
                {1263,"CLTA Parcel Map Guarantee"},
                {913,"CLTA Plant Info Guar Form 17 1992"},
                {914,"CLTA Record Owner Guarantee Form"},
                {915,"CLTA Recorded Doc Guar Form 1990"},
                {882,"CLTA Standard Coverage Loan Policy"},
                {883,"CLTA Standard Coverage Owners Policy"},
                {916,"CLTA Subdivision Guar Form"},
                {1552,"Combo Guarantee"},
                {885,"Commerce Title Eagle Owners"},
                {1147,"Commitment"},
                {928,"Commitment to Endorse"},
                {1264,"Construction Loan Continuation"},
                {917,"Contract Forfeiture Guarantee"},
                {1265,"Copies Only"},
                {1008,"Eagle Search Product"},
                {929,"Endorsement"},
                {1148,"FACT"},
                {1647,"Foreclosure Guarantee and Commitment"},
                {891,"Foreclosure Report"},
                {918,"Future Financing Binder"},
                {1582,"HOA Trustee Sale Guarantee"},
                {1266,"International Loan Policy"},
                {1267,"International Owner Policy"},
                {1550,"Judicial Foreclosure"},
                {919,"Legal, Vesting Information Report"},
                {893,"Letter Report"},
                {920,"Limited Liability Report"},
                {894,"Limited Pre-Foreclosure Policy"},
                {1268,"Limited Trustee Sale Guarantee"},
                {921,"Litigation Guarantee"},
                {922,"Lot Book Guarantee"},
                {1269,"Lot Book Report"},
                {1654,"Manufactured Home Loan Policy"},
                {1653,"Manufactured Home Owner Policy"},
                {1270,"Measure 37 Report"},
                {895,"Misc Report"},
                {1746,"Mortgage Guarantee"},
                {1697,"Mortgage Priority Guarantee"},
                {901,"Mortgagee Policy"},
                {930,"No Product Issued"},
                {902,"Owner Policy of Land"},
                {896,"Ownership & Encumbrances Report"},
                {1149,"Prelim"},
                {1271,"Preliminary Judicial Report"},
                {897,"Prime Loan Policy"},
                {1272,"Private Examination"},
                {898,"Pro Forma"},
                {923,"Property Report"},
                {1273,"Property Search Guarantee"},
                {1734,"Record Owner and Lien Certificate"},
                {924,"Recorded Document Guarantee"},
                {710,"RPIR"},
                {1150,"RPIR-GI"},
                {1733,"Sheriff's Distribution Policy"},
                {1152,"Short Form Commitment"},
                {1274,"Signature Services"},
                {1275,"Standard Owners 1992 - Top"},
                {1577,"Streamline Trustee Sales Guarantee"},
                {925,"Subdivision Guarantee"},
                {1136,"Super Eagle"},
                {1151,"Super Eagle-24 mo"},
                {1549,"Tax Foreclosure Search"},
                {1783,"Texas Chain of Title Policy (T-53)"},
                {1735,"Texas Limited Pre-Foreclosure Policy (T-98)"},
                {1304,"Texas Mortgage Binder on Construction Loan (T13)"},
                {1302,"Texas Mortgagee Policy (T2)"},
                {1305,"Texas Nothing Further Certificate"},
                {1300,"Texas Owner Policy (T1)"},
                {1301,"Texas Residential Owner Policy (T1R)"},
                {1303,"Texas Short Form Mortgagee Policy (T2R)"},
                {1276,"Title Examination"},
                {926,"Title Guaranty"},
                {927,"Title Opinion"},
                {1277,"Tract Search Report"},
                {931,"Trustee Sale Guarantee"},
                {1799,"TX-City Planning Letter"},
                {1286,"UCC - Annual Reports"},
                {1287,"UCC - Articles of Organization"},
                {1288, "UCC - Bankruptcy Search"},
                {1289, "UCC - Corporate Certificate"},
                {1290,"UCC - Judgments Search"},
                {1291,"UCC - Litigation Search"},
                {1292,"UCC - Pending Civil" },
                {1293,"UCC - Tax Lien Search" },
                {1294,"UCC - The Assisted UCC Filing" },
                {1295,"UCC - The Assisted UCC Search" },
                {1296, "UCC - The EAGLE 9 Buyers Policy"},
                {1297,"UCC - The EAGLE 9 UCC Insurance Policy for Lenders" },
                {1298, "UCC - The Insured UCC Filing" },
                {1299, "UCC - The Insured UCC Search"},
                {932,"UCC Policy" },
                {1322,"Water Right Loan Policy" },
                {1323,"Water Right Owners Policy" },
                {1324, "Water Right Search"},
                {1153,"Water Rights Conveyance Report" },
                {1651, "WY Foreclosure Title Policy"}
            };
        }
        #endregion
    }
}
