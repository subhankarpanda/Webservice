﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.DataObjects;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;
using WebServices.Helpers.File;

namespace WebServices.File
{
    [CodedUITest]
    public class BuyerSellerWS : MasterTestClass
    {

        public static int fileID;
        public static bool isAuthorizedSigCreates = false;
        public static string principleId = "";
        public static string authorizedSignatureId = "";
        public static string authorizedSignatureTypeCDId = "";
        public static bool isUserLoggedIn = false;

        //Order-1
        [TestMethod]

        public void REG_AddBuyerSeller_Buyer_Individual_CD()
        {
            bool testRunCompleted = false;
            Reports.TestDescription = "Add a new buyer of Individual type.";
            //FAST_Init_File();
            #region FAST Login IIS side
            Reports.TestStep = "Login to IIS";
            FASTHelpers.FAST_Login_IIS();
            #endregion

            Reports.TestStep = "Create a file using WCF and get the fileId.";
            fileID = CreateFile();

            if (REG_AddBuyerSeller_CD("buyer", "individual"))
            {
                testRunCompleted = true;
            }
            Reports.StatusUpdate("Has test been run through the end ?", testRunCompleted);
        }

        //Order-2
        [TestMethod]
        public void REG_AddBuyerSeller_Buyer_Husband_CD()
        {
            bool testRunCompleted = false;
            Reports.TestDescription = "Add a new buyer of Husband/Wife type.";

            #region FAST Login IIS side
            Reports.TestStep = "Login to IIS";
            FASTHelpers.FAST_Login_IIS();
            #endregion

            Reports.TestStep = "Create a file using WCF and get the fileId.";
            fileID = CreateFile();

            if (REG_AddBuyerSeller_CD("buyer", "husband/wife"))
            {
                testRunCompleted = true;
            }
            Reports.StatusUpdate("Has test been run through the end ?", testRunCompleted);
        }

        //Order-3
        [TestMethod]
        public void REG_AddBuyerSeller_Buyer_Trust_CD()
        {
            bool testRunCompleted = false;
            Reports.TestDescription = "Add a new buyer of Trust type.";

            #region FAST Login IIS side
            Reports.TestStep = "Login to IIS";
            FASTHelpers.FAST_Login_IIS();
            #endregion

            Reports.TestStep = "Create a file using WCF and get the fileId.";
            fileID = CreateFile();

            if (REG_AddBuyerSeller_CD("buyer", "trust"))
            {
                testRunCompleted = true;
            }
            Reports.StatusUpdate("Has test been run through the end ?", testRunCompleted);
        }

        //Order-4
        [TestMethod]
        public void REG_AddBuyerSeller_Buyer_BusinessEntity_CD()
        {
            bool testRunCompleted = false;
            Reports.TestDescription = "Add a new buyer of Business Entity type.";

            #region FAST Login IIS side
            Reports.TestStep = "Login to IIS";
            FASTHelpers.FAST_Login_IIS();
            #endregion

            Reports.TestStep = "Create a file using WCF and get the fileId.";
            fileID = CreateFile();

            if (REG_AddBuyerSeller_CD("buyer", "business entity"))
            {
                testRunCompleted = true;
            }
            Reports.StatusUpdate("Has test been run through the end ?", testRunCompleted);
        }

        //Order-5
        [TestMethod]
        public void REG_AddBuyerSeller_Seller_Individual_CD()
        {
            bool testRunCompleted = false;
            Reports.TestDescription = "Add a new seller of Individual type.";

            #region FAST Login IIS side
            Reports.TestStep = "Login to IIS";
            FASTHelpers.FAST_Login_IIS();
            #endregion

            Reports.TestStep = "Create a file using WCF and get the fileId.";
            fileID = CreateFile();

            if (REG_AddBuyerSeller_CD("seller", "individual"))
            {
                testRunCompleted = true;
            }
            Reports.StatusUpdate("Has test been run through the end ?", testRunCompleted);
        }

        //Order-6
        [TestMethod]
        public void REG_AddBuyerSeller_Seller_Husband_CD()
        {
            bool testRunCompleted = false;
            Reports.TestDescription = "Add a new seller of Husband/Wife type.";

            #region FAST Login IIS side
            Reports.TestStep = "Login to IIS";
            FASTHelpers.FAST_Login_IIS();
            #endregion

            Reports.TestStep = "Create a file using WCF and get the fileId.";
            fileID = CreateFile();

            if (REG_AddBuyerSeller_CD("seller", "husband/wife"))
            {
                testRunCompleted = true;
            }
            Reports.StatusUpdate("Has test been run through the end ?", testRunCompleted);
        }

        //Order-7
        [TestMethod]
        public void REG_AddBuyerSeller_Seller_Trust_CD()
        {
            bool testRunCompleted = false;
            Reports.TestDescription = "Add a new seller of Trust type.";

            #region FAST Login IIS side
            Reports.TestStep = "Login to IIS";
            FASTHelpers.FAST_Login_IIS();
            #endregion

            Reports.TestStep = "Create a file using WCF and get the fileId.";
            fileID = CreateFile();

            if (REG_AddBuyerSeller_CD("seller", "trust"))
            {
                testRunCompleted = true;
            }
            Reports.StatusUpdate("Has test been run through the end ?", testRunCompleted);
        }

        //Order-8
        [TestMethod]
        public void REG_AddBuyerSeller_Seller_BusinessEntity_CD()
        {
            bool testRunCompleted = false;
            Reports.TestDescription = "Add a new seller of Business Entity type.";

            #region FAST Login IIS side
            Reports.TestStep = "Login to IIS";
            FASTHelpers.FAST_Login_IIS();
            #endregion

            Reports.TestStep = "Create a file using WCF and get the fileId.";
            fileID = CreateFile();

            if (REG_AddBuyerSeller_CD("seller", "business entity"))
            {
                testRunCompleted = true;
            }
            Reports.StatusUpdate("Has test been run through the end ?", testRunCompleted);
        }

        //Order-9
        [TestMethod]
        public void REG_UpdateBuyerSeller_Buyer_Individual_CD()
        {
            Reports.TestDescription = "Update a buyer of Individual type.";

            #region FAST Login IIS side
            Reports.TestStep = "Login to IIS";
            FASTHelpers.FAST_Login_IIS();
            #endregion

            Reports.TestStep = "Create a file using WCF and get the fileId.";
            fileID = CreateFile();

            if (REG_AddBuyerSeller_CD("buyer", "individual"))
            {
                REG_UpdateBuyerSeller_CD("buyer", "individual");
            }
        }

        [TestMethod]
        public void REG_DeleteBuyerSeller_Buyer_Individual_CD()
        {
            Reports.TestDescription = "Delete a buyer of Individual type.";

            #region FAST Login IIS side
            Reports.TestStep = "Login to IIS";
            FASTHelpers.FAST_Login_IIS();
            #endregion

            Reports.TestStep = "Create a file using WCF and get the fileId.";
            fileID = CreateFile();
            if (REG_AddBuyerSeller_CD("buyer", "individual"))
            {
                REG_DeleteBuyerSeller_CD("buyer", "individual");
            }
        }

        [TestMethod]
        public void REG_UpdateCompleteVesting()
        {
            try
            {
                Reports.TestDescription = "Update Complete Vesting";

                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FASTHelpers.FAST_Login_IIS();
                #endregion

                Reports.TestStep = "Create a file using WCF and get the fileId.";
                fileID = CreateFile();

                var result = UpdateCompleteVesting_CD("Buyer", fileID);
                Reports.StatusUpdate("Has Complete Vesting been updated successfully for Buyer PrincipalType ?", result);

                result = UpdateCompleteVesting_CD("Seller", fileID);
                Reports.StatusUpdate("Has Complete Vesting been updated successfully for Seller PrincipalType ?", result);
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate(ex.Message, false);
            }
        }

        #region BAT
        [TestMethod]
        [Description("Create Individual Buyer")]
        public void BAT0001()
        {
            try
            {
                Reports.TestDescription = "Create Individual Buyer";

                FASTHelpers.FAST_Login_IIS();
                FASTHelpers.FAST_WCF_File_IIS();

                #region Request new Individual Buyer type
                Reports.TestStep = "Request new Individual Buyer type";
                var request = BuyerSellerHelpers.GetIndividualBuyerSellerRequest();
                request.FileID = FASTHelpers.File.FileID ?? 0;
                request.BuyerSeller.BuyerSellerTypeID = BuyerSellerTypeCdID.Individual;
                request.PrincipalType = BuyerSellerPrincipalTypeOCD.Buyer;
                var response = FileService.AddBuyerSeller(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Validate Individual Buyer details
                Reports.TestStep = "Validate Individual Buyer details";
                FastDriver.BuyerSellerSummary.Open(isBuyer: true, index: 1);
                BuyerSellerHelpers.ValidateIndividualBuyerSeller(request);
                FastDriver.BottomFrame.Done();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Create Husband/Wife Buyer")]
        public void BAT0002()
        {
            try
            {
                Reports.TestDescription = "Create Husband/Wife Buyer";

                FASTHelpers.FAST_Login_IIS();
                FASTHelpers.FAST_WCF_File_IIS();

                #region Request new Husband/Wife Buyer type
                Reports.TestStep = "Request new Husband/Wife Buyer type";
                var request = BuyerSellerHelpers.GetHusbandWifeBuyerSellerRequest();
                request.FileID = FASTHelpers.File.FileID ?? 0;
                request.BuyerSeller.BuyerSellerTypeID = BuyerSellerTypeCdID.HusbandAndWife;
                request.PrincipalType = BuyerSellerPrincipalTypeOCD.Buyer;
                var response = FileService.AddBuyerSeller(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Validate Husband/Wife Buyer details
                Reports.TestStep = "Validate Husband/Wife Buyer details";
                FastDriver.BuyerSellerSummary.Open(isBuyer: true, index: 1);
                BuyerSellerHelpers.ValidateHusbandWifeBuyerSeller(request);
                FastDriver.BottomFrame.Done();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Create Trust/Estate Buyer")]
        public void BAT0003()
        {
            try
            {
                Reports.TestDescription = "Create Trust/Estate Buyer";

                FASTHelpers.FAST_Login_IIS();
                FASTHelpers.FAST_WCF_File_IIS();

                #region Request new Trust/Estate Buyer type
                Reports.TestStep = "Request new Trust/Estate Buyer type";
                var request = BuyerSellerHelpers.GetTrustEstateBuyerSellerRequest();
                request.FileID = FASTHelpers.File.FileID ?? 0;
                request.BuyerSeller.BuyerSellerTypeID = BuyerSellerTypeCdID.TrustEstate;
                request.PrincipalType = BuyerSellerPrincipalTypeOCD.Buyer;
                var response = FileService.AddBuyerSeller(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Validate Trust/Estate Buyer details
                Reports.TestStep = "Validate Trust/Estate Buyer details";
                FastDriver.BuyerSellerSummary.Open(isBuyer: true, index: 1);
                BuyerSellerHelpers.ValidateTrustEstateBuyerSeller(request);
                FastDriver.BottomFrame.Done();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Create Business Trust Buyer")]
        public void BAT0004()
        {
            try
            {
                Reports.TestDescription = "Create Business Trust Buyer";

                FASTHelpers.FAST_Login_IIS();
                FASTHelpers.FAST_WCF_File_IIS();

                #region Request new Business Trust Buyer type
                Reports.TestStep = "Request new Business Trust Buyer type";
                var request = BuyerSellerHelpers.GetBusinessTrustBuyerSellerRequest();
                request.FileID = FASTHelpers.File.FileID ?? 0;
                request.BuyerSeller.BuyerSellerTypeID = BuyerSellerTypeCdID.BusinessEntity;
                request.PrincipalType = BuyerSellerPrincipalTypeOCD.Buyer;
                var response = FileService.AddBuyerSeller(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Validate Business Trust Buyer details
                Reports.TestStep = "Validate Business Trust Buyer details";
                FastDriver.BuyerSellerSummary.Open(isBuyer: true, index: 1);
                BuyerSellerHelpers.ValidateBusinessBuyerSeller(request);
                FastDriver.BottomFrame.Done();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Update Buyer Complete Vesting")]
        public void BAT0005()
        {
            try
            {
                Reports.TestDescription = "Update Buyer Complete Vesting";

                FASTHelpers.FAST_Login_IIS();
                FASTHelpers.FAST_WCF_File_IIS();

                #region Request new Individual Seller type
                Reports.TestStep = "Request new Individual Seller type";
                var request = BuyerSellerHelpers.GetIndividualBuyerSellerRequest();
                request.FileID = FASTHelpers.File.FileID ?? 0;
                request.BuyerSeller.BuyerSellerTypeID = BuyerSellerTypeCdID.Individual;
                request.PrincipalType = BuyerSellerPrincipalTypeOCD.Buyer;
                var response = FileService.AddBuyerSeller(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Update Complete Vesting
                Reports.TestStep = "Update Complete Vesting";
                var updateVestingRes = FileService.UpdateCompleteVesting(FASTHelpers.File.FileID ?? 0, PrincipalTypeCdID.Buyer, "this a test text");
                Support.AreEqual("1", updateVestingRes.Status.ToString(), updateVestingRes.StatusDescription);
                #endregion

                #region Validate Individual Buyer details
                Reports.TestStep = "Validate Individual Buyer details";
                FastDriver.BuyerSellerSummary.Open(isBuyer: true, index: 1);
                BuyerSellerHelpers.ValidateFullVestingBuyerSeller(vestingText: "this a test text");
                FastDriver.BottomFrame.Done();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Create Individual Seller")]
        public void BAT0006()
        {
            try
            {
                Reports.TestDescription = "Create Individual Seller";

                FASTHelpers.FAST_Login_IIS();
                FASTHelpers.FAST_WCF_File_IIS();

                #region Request new Individual Seller type
                Reports.TestStep = "Request new Individual Seller type";
                var request = BuyerSellerHelpers.GetIndividualBuyerSellerRequest();
                request.FileID = FASTHelpers.File.FileID ?? 0;
                request.BuyerSeller.BuyerSellerTypeID = BuyerSellerTypeCdID.Individual;
                request.PrincipalType = BuyerSellerPrincipalTypeOCD.Seller;
                var response = FileService.AddBuyerSeller(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Validate Individual Seller details
                Reports.TestStep = "Validate Individual Seller details";
                FastDriver.BuyerSellerSummary.Open(isBuyer: false, index: 1);
                BuyerSellerHelpers.ValidateIndividualBuyerSeller(request);
                FastDriver.BottomFrame.Done();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Create Husband/Wife Seller")]
        public void BAT0007()
        {
            try
            {
                Reports.TestDescription = "Create Husband/Wife Seller";

                FASTHelpers.FAST_Login_IIS();
                FASTHelpers.FAST_WCF_File_IIS();

                #region Request new Husband/Wife Seller type
                Reports.TestStep = "Request new Husband/Wife Seller type";
                var request = BuyerSellerHelpers.GetHusbandWifeBuyerSellerRequest();
                request.FileID = FASTHelpers.File.FileID ?? 0;
                request.BuyerSeller.BuyerSellerTypeID = BuyerSellerTypeCdID.HusbandAndWife;
                request.PrincipalType = BuyerSellerPrincipalTypeOCD.Seller;
                var response = FileService.AddBuyerSeller(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Validate Husband/Wife Seller details
                Reports.TestStep = "Validate Husband/Wife Seller details";
                FastDriver.BuyerSellerSummary.Open(isBuyer: false, index: 1);
                BuyerSellerHelpers.ValidateHusbandWifeBuyerSeller(request);
                FastDriver.BottomFrame.Done();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Create Trust/Estate Seller")]
        public void BAT0008()
        {
            try
            {
                Reports.TestDescription = "Create Trust/Estate Seller";

                FASTHelpers.FAST_Login_IIS();
                FASTHelpers.FAST_WCF_File_IIS();

                #region Request new Trust/Estate Seller type
                Reports.TestStep = "Request new Trust/Estate Seller type";
                var request = BuyerSellerHelpers.GetTrustEstateBuyerSellerRequest();
                request.FileID = FASTHelpers.File.FileID ?? 0;
                request.BuyerSeller.BuyerSellerTypeID = BuyerSellerTypeCdID.TrustEstate;
                request.PrincipalType = BuyerSellerPrincipalTypeOCD.Seller;
                var response = FileService.AddBuyerSeller(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Validate Trust/Estate Seller details
                Reports.TestStep = "Validate Trust/Estate Seller details";
                FastDriver.BuyerSellerSummary.Open(isBuyer: false, index: 1);
                BuyerSellerHelpers.ValidateTrustEstateBuyerSeller(request);
                FastDriver.BottomFrame.Done();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Create Business Trust Seller")]
        public void BAT0009()
        {
            try
            {
                Reports.TestDescription = "Create Business Trust Seller";

                FASTHelpers.FAST_Login_IIS();
                FASTHelpers.FAST_WCF_File_IIS();

                #region Request new Business Trust Seller type
                Reports.TestStep = "Request new Business Trust Seller type";
                var request = BuyerSellerHelpers.GetBusinessTrustBuyerSellerRequest();
                request.FileID = FASTHelpers.File.FileID ?? 0;
                request.BuyerSeller.BuyerSellerTypeID = BuyerSellerTypeCdID.BusinessEntity;
                request.PrincipalType = BuyerSellerPrincipalTypeOCD.Seller;
                var response = FileService.AddBuyerSeller(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Validate Business Trust Seller details
                Reports.TestStep = "Validate Business Trust Seller details";
                FastDriver.BuyerSellerSummary.Open(isBuyer: false, index: 1);
                BuyerSellerHelpers.ValidateBusinessBuyerSeller(request);
                FastDriver.BottomFrame.Done();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Update Seller Complete Vesting")]
        public void BAT0010()
        {
            try
            {
                Reports.TestDescription = "Update Seller Complete Vesting";

                FASTHelpers.FAST_Login_IIS();
                FASTHelpers.FAST_WCF_File_IIS();

                #region Request new Individual Seller type
                Reports.TestStep = "Request new Individual Seller type";
                var request = BuyerSellerHelpers.GetIndividualBuyerSellerRequest();
                request.FileID = FASTHelpers.File.FileID ?? 0;
                request.BuyerSeller.BuyerSellerTypeID = BuyerSellerTypeCdID.Individual;
                request.PrincipalType = BuyerSellerPrincipalTypeOCD.Seller;
                var response = FileService.AddBuyerSeller(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Update Complete Vesting
                Reports.TestStep = "Update Complete Vesting";
                var updateVestingRes = FileService.UpdateCompleteVesting(FASTHelpers.File.FileID ?? 0, PrincipalTypeCdID.Seller, "this a test text");
                Support.AreEqual("1", updateVestingRes.Status.ToString(), updateVestingRes.StatusDescription);
                #endregion

                #region Validate Individual Seller details
                Reports.TestStep = "Validate Individual Seller details";
                FastDriver.BuyerSellerSummary.Open(isBuyer: false, index: 1);
                BuyerSellerHelpers.ValidateFullVestingBuyerSeller(vestingText: "this a test text");
                FastDriver.BottomFrame.Done();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Update Individual Buyer")]
        public void BAT0011()
        {
            try
            {
                Reports.TestDescription = "Update Individual Buyer";

                FASTHelpers.FAST_Login_IIS();
                FASTHelpers.FAST_WCF_File_IIS();

                #region Request new Individual Buyer type
                Reports.TestStep = "Request new Individual Buyer type";
                var request = RequestFactory.GetAddBuyerSellerRequest(BuyerSellerTypeOCD.Individual);
                request.FileID = FASTHelpers.File.FileID ?? 0;
                request.PrincipalType = BuyerSellerPrincipalTypeOCD.Buyer;
                var response = FileService.AddBuyerSeller(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Update the newly created instance
                Reports.TestStep = "Update the newly created instance";
                var updateReq = BuyerSellerHelpers.GetIndividualBuyerSellerUpdateRequest();
                updateReq.FileID = FASTHelpers.File.FileID ?? 0;
                updateReq.BuyerSeller.BuyerSellerTypeID = BuyerSellerTypeCdID.Individual;
                updateReq.PrincipalType = BuyerSellerPrincipalTypeOCD.Buyer;
                var updateResponse = FileService.UpdateBuyerSeller(updateReq);
                Support.AreEqual("1", updateResponse.Status.ToString(), updateResponse.StatusDescription);
                #endregion

                #region Validate Individual Buyer details
                Reports.TestStep = "Validate Individual Buyer details";
                FastDriver.BuyerSellerSummary.Open(isBuyer: true, index: 1);
                BuyerSellerHelpers.ValidateIndividualBuyerSeller(updateReq);
                FastDriver.BottomFrame.Done();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Update Husband/Wife Buyer")]
        public void BAT0012()
        {
            try
            {
                Reports.TestDescription = "Update Husband/Wife Buyer";

                FASTHelpers.FAST_Login_IIS();
                FASTHelpers.FAST_WCF_File_IIS();

                #region Request new Husband/Wife Buyer type
                Reports.TestStep = "Request new Husband/Wife Buyer type";
                var request = RequestFactory.GetAddBuyerSellerRequest("husband/wife");
                request.FileID = FASTHelpers.File.FileID ?? 0;
                request.PrincipalType = BuyerSellerPrincipalTypeOCD.Buyer;
                var response = FileService.AddBuyerSeller(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Update the newly created instance
                Reports.TestStep = "Update the newly created instance";
                var updateReq = BuyerSellerHelpers.GetHusbandWifeBuyerSellerUpdateRequest();
                updateReq.FileID = FASTHelpers.File.FileID ?? 0;
                updateReq.BuyerSeller.BuyerSellerTypeID = BuyerSellerTypeCdID.HusbandAndWife;
                updateReq.PrincipalType = BuyerSellerPrincipalTypeOCD.Buyer;
                var updateResponse = FileService.UpdateBuyerSeller(updateReq);
                Support.AreEqual("1", updateResponse.Status.ToString(), updateResponse.StatusDescription);
                #endregion

                #region Validate Husband/Wife Buyer details
                Reports.TestStep = "Validate Husband/Wife Buyer details";
                FastDriver.BuyerSellerSummary.Open(isBuyer: true, index: 1);
                BuyerSellerHelpers.ValidateHusbandWifeBuyerSeller(updateReq);
                FastDriver.BottomFrame.Done();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Update Trust/Estate Buyer")]
        public void BAT0013()
        {
            try
            {
                Reports.TestDescription = "Update Trust/Estate Buyer";

                FASTHelpers.FAST_Login_IIS();
                FASTHelpers.FAST_WCF_File_IIS();

                #region Request new Trust/Estate Buyer type
                Reports.TestStep = "Request new Trust/Estate Buyer type";
                var request = RequestFactory.GetAddBuyerSellerRequest("trust");
                request.FileID = FASTHelpers.File.FileID ?? 0;
                request.PrincipalType = BuyerSellerPrincipalTypeOCD.Buyer;
                var response = FileService.AddBuyerSeller(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Update the newly created instance
                Reports.TestStep = "Update the newly created instance";
                var updateReq = BuyerSellerHelpers.GetTrustEstateBuyerSellerUpdateRequest();
                updateReq.FileID = FASTHelpers.File.FileID ?? 0;
                updateReq.BuyerSeller.BuyerSellerTypeID = BuyerSellerTypeCdID.TrustEstate;
                updateReq.PrincipalType = BuyerSellerPrincipalTypeOCD.Buyer;
                var updateResponse = FileService.UpdateBuyerSeller(updateReq);
                Support.AreEqual("1", updateResponse.Status.ToString(), updateResponse.StatusDescription);
                #endregion

                #region Validate Trust/Estate Buyer details
                Reports.TestStep = "Validate Trust/Estate Buyer details";
                FastDriver.BuyerSellerSummary.Open(isBuyer: true, index: 1);
                BuyerSellerHelpers.ValidateTrustEstateBuyerSeller(updateReq);
                FastDriver.BottomFrame.Done();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Update Business Trust Buyer")]
        public void BAT0014()
        {
            try
            {
                Reports.TestDescription = "Update Business Trust Buyer";

                FASTHelpers.FAST_Login_IIS();
                FASTHelpers.FAST_WCF_File_IIS();

                #region Request new Business Trust Buyer type
                Reports.TestStep = "Request new Business Trust Buyer type";
                var request = RequestFactory.GetAddBuyerSellerRequest("business entity");
                request.FileID = FASTHelpers.File.FileID ?? 0;
                request.PrincipalType = BuyerSellerPrincipalTypeOCD.Buyer;
                var response = FileService.AddBuyerSeller(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Update the newly created instance
                Reports.TestStep = "Update the newly created instance";
                var updateReq = BuyerSellerHelpers.GetBusinessTrustBuyerSellerUpdateRequest();
                updateReq.FileID = FASTHelpers.File.FileID ?? 0;
                updateReq.BuyerSeller.BuyerSellerTypeID = BuyerSellerTypeCdID.BusinessEntity;
                updateReq.PrincipalType = BuyerSellerPrincipalTypeOCD.Buyer;
                var updateResponse = FileService.UpdateBuyerSeller(updateReq);
                Support.AreEqual("1", updateResponse.Status.ToString(), updateResponse.StatusDescription);
                #endregion

                #region Validate Business Trust Buyer details
                Reports.TestStep = "Validate Business Trust Buyer details";
                FastDriver.BuyerSellerSummary.Open(isBuyer: true, index: 1);
                BuyerSellerHelpers.ValidateBusinessBuyerSeller(updateReq);
                FastDriver.BottomFrame.Done();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Modify Buyer types")]
        public void BAT0015()
        {
            try
            {
                Reports.TestDescription = "Modify Buyer types";

                FASTHelpers.FAST_Login_IIS();
                FASTHelpers.FAST_WCF_File_IIS();

                #region Request new Individual Buyer type
                Reports.TestStep = "Request new Individual Buyer type";
                var request = RequestFactory.GetAddBuyerSellerRequest(BuyerSellerTypeOCD.Individual);
                request.FileID = FASTHelpers.File.FileID ?? 0;
                request.PrincipalType = BuyerSellerPrincipalTypeOCD.Buyer;
                var response = FileService.AddBuyerSeller(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Change Buyer instance to Husband/Wife
                Reports.TestStep = "Change Buyer instance to Husband/Wife";
                var updateReq = BuyerSellerHelpers.GetHusbandWifeBuyerSellerUpdateRequest();
                updateReq.FileID = FASTHelpers.File.FileID ?? 0;
                updateReq.BuyerSeller.BuyerSellerTypeID = BuyerSellerTypeCdID.HusbandAndWife;
                updateReq.PrincipalType = BuyerSellerPrincipalTypeOCD.Buyer;
                var updateResponse = FileService.UpdateBuyerSeller(updateReq);
                Support.AreEqual("1", updateResponse.Status.ToString(), updateResponse.StatusDescription);
                #endregion

                #region Change Buyer instance to Trust/Estate
                Reports.TestStep = "Change Buyer instance to Trust/Estate";
                updateReq = BuyerSellerHelpers.GetTrustEstateBuyerSellerUpdateRequest();
                updateReq.FileID = FASTHelpers.File.FileID ?? 0;
                updateReq.BuyerSeller.BuyerSellerTypeID = BuyerSellerTypeCdID.TrustEstate;
                updateReq.PrincipalType = BuyerSellerPrincipalTypeOCD.Buyer;
                updateResponse = FileService.UpdateBuyerSeller(updateReq);
                Support.AreEqual("1", updateResponse.Status.ToString(), updateResponse.StatusDescription);
                #endregion

                #region Change Buyer instance to Business Trust
                Reports.TestStep = "Change Buyer instance to Business Trust";
                updateReq = BuyerSellerHelpers.GetTrustEstateBuyerSellerUpdateRequest();
                updateReq.FileID = FASTHelpers.File.FileID ?? 0;
                updateReq.BuyerSeller.BuyerSellerTypeID = BuyerSellerTypeCdID.BusinessEntity;
                updateReq.PrincipalType = BuyerSellerPrincipalTypeOCD.Buyer;
                updateResponse = FileService.UpdateBuyerSeller(updateReq);
                Support.AreEqual("1", updateResponse.Status.ToString(), updateResponse.StatusDescription);
                #endregion

                #region Change Buyer instance to Trust/Estate
                Reports.TestStep = "Change Buyer instance to Trust/Estate";
                updateReq = BuyerSellerHelpers.GetTrustEstateBuyerSellerUpdateRequest();
                updateReq.FileID = FASTHelpers.File.FileID ?? 0;
                updateReq.BuyerSeller.BuyerSellerTypeID = BuyerSellerTypeCdID.TrustEstate;
                updateReq.PrincipalType = BuyerSellerPrincipalTypeOCD.Buyer;
                updateResponse = FileService.UpdateBuyerSeller(updateReq);
                Support.AreEqual("1", updateResponse.Status.ToString(), updateResponse.StatusDescription);
                #endregion

                #region Change Buyer instance to Husband/Wife
                Reports.TestStep = "Change Buyer instance to Husband/Wife";
                updateReq = BuyerSellerHelpers.GetHusbandWifeBuyerSellerUpdateRequest();
                updateReq.FileID = FASTHelpers.File.FileID ?? 0;
                updateReq.BuyerSeller.BuyerSellerTypeID = BuyerSellerTypeCdID.HusbandAndWife;
                updateReq.PrincipalType = BuyerSellerPrincipalTypeOCD.Buyer;
                updateResponse = FileService.UpdateBuyerSeller(updateReq);
                Support.AreEqual("1", updateResponse.Status.ToString(), updateResponse.StatusDescription);
                #endregion

                #region Change Buyer instance to Individual
                Reports.TestStep = "Change Buyer instance to Individual";
                updateReq = BuyerSellerHelpers.GetIndividualBuyerSellerUpdateRequest();
                updateReq.FileID = FASTHelpers.File.FileID ?? 0;
                updateReq.BuyerSeller.BuyerSellerTypeID = BuyerSellerTypeCdID.Individual;
                updateReq.PrincipalType = BuyerSellerPrincipalTypeOCD.Buyer;
                updateResponse = FileService.UpdateBuyerSeller(updateReq);
                Support.AreEqual("1", updateResponse.Status.ToString(), updateResponse.StatusDescription);
                #endregion

                #region Validate Individual Buyer details
                Reports.TestStep = "Validate Individual Buyer details";
                FastDriver.BuyerSellerSummary.Open(isBuyer: true, index: 1);
                BuyerSellerHelpers.ValidateIndividualBuyerSeller(updateReq);
                FastDriver.BottomFrame.Done();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Update Individual Seller")]
        public void BAT0016()
        {
            try
            {
                Reports.TestDescription = "Update Individual Seller";

                FASTHelpers.FAST_Login_IIS();
                FASTHelpers.FAST_WCF_File_IIS();

                #region Request new Individual Seller type
                Reports.TestStep = "Request new Individual Seller type";
                var request = RequestFactory.GetAddBuyerSellerRequest("individual");
                request.FileID = FASTHelpers.File.FileID ?? 0;
                request.PrincipalType = BuyerSellerPrincipalTypeOCD.Seller;
                var response = FileService.AddBuyerSeller(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Update the newly created instance
                Reports.TestStep = "Update the newly created instance";
                var updateReq = BuyerSellerHelpers.GetIndividualBuyerSellerUpdateRequest();
                updateReq.FileID = FASTHelpers.File.FileID ?? 0;
                updateReq.BuyerSeller.BuyerSellerTypeID = BuyerSellerTypeCdID.Individual;
                updateReq.PrincipalType = BuyerSellerPrincipalTypeOCD.Seller;
                var updateResponse = FileService.UpdateBuyerSeller(updateReq);
                Support.AreEqual("1", updateResponse.Status.ToString(), updateResponse.StatusDescription);
                #endregion

                #region Validate Individual Seller details
                Reports.TestStep = "Validate Individual Seller details";
                FastDriver.BuyerSellerSummary.Open(isBuyer: false, index: 1);
                BuyerSellerHelpers.ValidateIndividualBuyerSeller(updateReq);
                FastDriver.BottomFrame.Done();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Update Husband/Wife Seller")]
        public void BAT0017()
        {
            try
            {
                Reports.TestDescription = "Update Husband/Wife Seller";

                FASTHelpers.FAST_Login_IIS();
                FASTHelpers.FAST_WCF_File_IIS();

                #region Request new Husband/Wife Seller type
                Reports.TestStep = "Request new Husband/Wife Seller type";
                var request = RequestFactory.GetAddBuyerSellerRequest("husband/wife");
                request.FileID = FASTHelpers.File.FileID ?? 0;
                request.PrincipalType = BuyerSellerPrincipalTypeOCD.Seller;
                var response = FileService.AddBuyerSeller(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Update the newly created instance
                Reports.TestStep = "Update the newly created instance";
                var updateReq = BuyerSellerHelpers.GetHusbandWifeBuyerSellerUpdateRequest();
                updateReq.FileID = FASTHelpers.File.FileID ?? 0;
                updateReq.BuyerSeller.BuyerSellerTypeID = BuyerSellerTypeCdID.HusbandAndWife;
                updateReq.PrincipalType = BuyerSellerPrincipalTypeOCD.Seller;
                var updateResponse = FileService.UpdateBuyerSeller(updateReq);
                Support.AreEqual("1", updateResponse.Status.ToString(), updateResponse.StatusDescription);
                #endregion

                #region Validate Husband/Wife Seller details
                Reports.TestStep = "Validate Husband/Wife Seller details";
                FastDriver.BuyerSellerSummary.Open(isBuyer: false, index: 1);
                BuyerSellerHelpers.ValidateHusbandWifeBuyerSeller(updateReq);
                FastDriver.BottomFrame.Done();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Update Trust/Estate Seller")]
        public void BAT0018()
        {
            try
            {
                Reports.TestDescription = "Update Trust/Estate Seller";

                FASTHelpers.FAST_Login_IIS();
                FASTHelpers.FAST_WCF_File_IIS();

                #region Request new Trust/Estate Seller type
                Reports.TestStep = "Request new Trust/Estate Seller type";
                var request = RequestFactory.GetAddBuyerSellerRequest("trust");
                request.FileID = FASTHelpers.File.FileID ?? 0;
                request.PrincipalType = BuyerSellerPrincipalTypeOCD.Seller;
                var response = FileService.AddBuyerSeller(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Update the newly created instance
                Reports.TestStep = "Update the newly created instance";
                var updateReq = BuyerSellerHelpers.GetTrustEstateBuyerSellerUpdateRequest();
                updateReq.FileID = FASTHelpers.File.FileID ?? 0;
                updateReq.BuyerSeller.BuyerSellerTypeID = BuyerSellerTypeCdID.TrustEstate;
                updateReq.PrincipalType = BuyerSellerPrincipalTypeOCD.Seller;
                var updateResponse = FileService.UpdateBuyerSeller(updateReq);
                Support.AreEqual("1", updateResponse.Status.ToString(), updateResponse.StatusDescription);
                #endregion

                #region Validate Trust/Estate Seller details
                Reports.TestStep = "Validate Trust/Estate Seller details";
                FastDriver.BuyerSellerSummary.Open(isBuyer: false, index: 1);
                BuyerSellerHelpers.ValidateTrustEstateBuyerSeller(updateReq);
                FastDriver.BottomFrame.Done();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Update Business Trust Seller")]
        public void BAT0019()
        {
            try
            {
                Reports.TestDescription = "Update Business Trust Seller";

                FASTHelpers.FAST_Login_IIS();
                FASTHelpers.FAST_WCF_File_IIS();

                #region Request new Business Trust Seller type
                Reports.TestStep = "Request new Business Trust Seller type";
                var request = RequestFactory.GetAddBuyerSellerRequest("business entity");
                request.FileID = FASTHelpers.File.FileID ?? 0;
                request.PrincipalType = BuyerSellerPrincipalTypeOCD.Seller;
                var response = FileService.AddBuyerSeller(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Update the newly created instance
                Reports.TestStep = "Update the newly created instance";
                var updateReq = BuyerSellerHelpers.GetBusinessTrustBuyerSellerUpdateRequest();
                updateReq.FileID = FASTHelpers.File.FileID ?? 0;
                updateReq.BuyerSeller.BuyerSellerTypeID = BuyerSellerTypeCdID.BusinessEntity;
                updateReq.PrincipalType = BuyerSellerPrincipalTypeOCD.Seller;
                var updateResponse = FileService.UpdateBuyerSeller(updateReq);
                Support.AreEqual("1", updateResponse.Status.ToString(), updateResponse.StatusDescription);
                #endregion

                #region Validate Business Trust Seller details
                Reports.TestStep = "Validate Business Trust Seller details";
                FastDriver.BuyerSellerSummary.Open(isBuyer: false, index: 1);
                BuyerSellerHelpers.ValidateBusinessBuyerSeller(updateReq);
                FastDriver.BottomFrame.Done();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Modify Seller types")]
        public void BAT0020()
        {
            try
            {
                Reports.TestDescription = "Modify Seller types";

                FASTHelpers.FAST_Login_IIS();
                FASTHelpers.FAST_WCF_File_IIS();

                #region Request new Individual Seller type
                Reports.TestStep = "Request new Individual Seller type";
                var request = RequestFactory.GetAddBuyerSellerRequest(BuyerSellerTypeOCD.Individual);
                request.FileID = FASTHelpers.File.FileID ?? 0;
                request.PrincipalType = BuyerSellerPrincipalTypeOCD.Seller;
                var response = FileService.AddBuyerSeller(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Change Seller instance to Husband/Wife
                Reports.TestStep = "Change Seller instance to Husband/Wife";
                var updateReq = BuyerSellerHelpers.GetHusbandWifeBuyerSellerUpdateRequest();
                updateReq.FileID = FASTHelpers.File.FileID ?? 0;
                updateReq.BuyerSeller.BuyerSellerTypeID = BuyerSellerTypeCdID.HusbandAndWife;
                updateReq.PrincipalType = BuyerSellerPrincipalTypeOCD.Seller;
                var updateResponse = FileService.UpdateBuyerSeller(updateReq);
                Support.AreEqual("1", updateResponse.Status.ToString(), updateResponse.StatusDescription);
                #endregion

                #region Change Seller instance to Trust/Estate
                Reports.TestStep = "Change Seller instance to Trust/Estate";
                updateReq = BuyerSellerHelpers.GetTrustEstateBuyerSellerUpdateRequest();
                updateReq.FileID = FASTHelpers.File.FileID ?? 0;
                updateReq.BuyerSeller.BuyerSellerTypeID = BuyerSellerTypeCdID.TrustEstate;
                updateReq.PrincipalType = BuyerSellerPrincipalTypeOCD.Seller;
                updateResponse = FileService.UpdateBuyerSeller(updateReq);
                Support.AreEqual("1", updateResponse.Status.ToString(), updateResponse.StatusDescription);
                #endregion

                #region Change Seller instance to Business Trust
                Reports.TestStep = "Change Seller instance to Business Trust";
                updateReq = BuyerSellerHelpers.GetTrustEstateBuyerSellerUpdateRequest();
                updateReq.FileID = FASTHelpers.File.FileID ?? 0;
                updateReq.BuyerSeller.BuyerSellerTypeID = BuyerSellerTypeCdID.BusinessEntity;
                updateReq.PrincipalType = BuyerSellerPrincipalTypeOCD.Seller;
                updateResponse = FileService.UpdateBuyerSeller(updateReq);
                Support.AreEqual("1", updateResponse.Status.ToString(), updateResponse.StatusDescription);
                #endregion

                #region Change Seller instance to Trust/Estate
                Reports.TestStep = "Change Seller instance to Trust/Estate";
                updateReq = BuyerSellerHelpers.GetTrustEstateBuyerSellerUpdateRequest();
                updateReq.FileID = FASTHelpers.File.FileID ?? 0;
                updateReq.BuyerSeller.BuyerSellerTypeID = BuyerSellerTypeCdID.TrustEstate;
                updateReq.PrincipalType = BuyerSellerPrincipalTypeOCD.Seller;
                updateResponse = FileService.UpdateBuyerSeller(updateReq);
                Support.AreEqual("1", updateResponse.Status.ToString(), updateResponse.StatusDescription);
                #endregion

                #region Change Seller instance to Husband/Wife
                Reports.TestStep = "Change Seller instance to Husband/Wife";
                updateReq = BuyerSellerHelpers.GetHusbandWifeBuyerSellerUpdateRequest();
                updateReq.FileID = FASTHelpers.File.FileID ?? 0;
                updateReq.BuyerSeller.BuyerSellerTypeID = BuyerSellerTypeCdID.HusbandAndWife;
                updateReq.PrincipalType = BuyerSellerPrincipalTypeOCD.Seller;
                updateResponse = FileService.UpdateBuyerSeller(updateReq);
                Support.AreEqual("1", updateResponse.Status.ToString(), updateResponse.StatusDescription);
                #endregion

                #region Change Seller instance to Individual
                Reports.TestStep = "Change Seller instance to Individual";
                updateReq = BuyerSellerHelpers.GetIndividualBuyerSellerUpdateRequest();
                updateReq.FileID = FASTHelpers.File.FileID ?? 0;
                updateReq.BuyerSeller.BuyerSellerTypeID = BuyerSellerTypeCdID.Individual;
                updateReq.PrincipalType = BuyerSellerPrincipalTypeOCD.Seller;
                updateResponse = FileService.UpdateBuyerSeller(updateReq);
                Support.AreEqual("1", updateResponse.Status.ToString(), updateResponse.StatusDescription);
                #endregion

                #region Validate Individual Seller details
                Reports.TestStep = "Validate Individual Seller details";
                FastDriver.BuyerSellerSummary.Open(isBuyer: false, index: 1);
                BuyerSellerHelpers.ValidateIndividualBuyerSeller(updateReq);
                FastDriver.BottomFrame.Done();
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Delete Buyer")]
        public void BAT0021()
        {
            try
            {
                Reports.TestDescription = "Delete Buyer";

                FASTHelpers.FAST_Login_IIS();
                FASTHelpers.FAST_WCF_File_IIS();

                #region Request new Individual Buyer type
                Reports.TestStep = "Request new Individual Buyer type";
                var request = BuyerSellerHelpers.GetIndividualBuyerSellerRequest();
                request.FileID = FASTHelpers.File.FileID ?? 0;
                request.BuyerSeller.BuyerSellerTypeID = BuyerSellerTypeCdID.Individual;
                request.PrincipalType = BuyerSellerPrincipalTypeOCD.Buyer;
                var response = FileService.AddBuyerSeller(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Request new Husband/Wife Buyer type
                Reports.TestStep = "Request new Husband/Wife Buyer type";
                request = BuyerSellerHelpers.GetHusbandWifeBuyerSellerRequest();
                request.FileID = FASTHelpers.File.FileID ?? 0;
                request.BuyerSeller.BuyerSellerTypeID = BuyerSellerTypeCdID.HusbandAndWife;
                request.PrincipalType = BuyerSellerPrincipalTypeOCD.Buyer;
                response = FileService.AddBuyerSeller(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Request new Trust/Estate Buyer type
                Reports.TestStep = "Request new Trust/Estate Buyer type";
                request = BuyerSellerHelpers.GetTrustEstateBuyerSellerRequest();
                request.FileID = FASTHelpers.File.FileID ?? 0;
                request.BuyerSeller.BuyerSellerTypeID = BuyerSellerTypeCdID.TrustEstate;
                request.PrincipalType = BuyerSellerPrincipalTypeOCD.Buyer;
                response = FileService.AddBuyerSeller(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Request new Business Trust Buyer type
                Reports.TestStep = "Request new Business Trust Buyer type";
                request = BuyerSellerHelpers.GetBusinessTrustBuyerSellerRequest();
                request.FileID = FASTHelpers.File.FileID ?? 0;
                request.BuyerSeller.BuyerSellerTypeID = BuyerSellerTypeCdID.BusinessEntity;
                request.PrincipalType = BuyerSellerPrincipalTypeOCD.Buyer;
                response = FileService.AddBuyerSeller(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Remove all Buyer instances
                Reports.TestStep = "Remove all Buyer instances";
                var requests = new DeleteBuyerSellerRequest[]{
                    RequestFactory.GetDeleteBuyerSellerRequest(FASTHelpers.File.FileID ?? 0, BuyerSellerPrincipalTypeOCD.Buyer, seqNum: 1),
                    RequestFactory.GetDeleteBuyerSellerRequest(FASTHelpers.File.FileID ?? 0, BuyerSellerPrincipalTypeOCD.Buyer, seqNum: 2),
                    RequestFactory.GetDeleteBuyerSellerRequest(FASTHelpers.File.FileID ?? 0, BuyerSellerPrincipalTypeOCD.Buyer, seqNum: 3),
                    RequestFactory.GetDeleteBuyerSellerRequest(FASTHelpers.File.FileID ?? 0, BuyerSellerPrincipalTypeOCD.Buyer, seqNum: 4),
                };
                foreach (var deleteReq in requests)
                {
                    var delResponse = FileService.DeleteBuyerSeller(deleteReq);
                    Support.AreEqual("1", delResponse.Status.ToString(), delResponse.StatusDescription);
                }
                #endregion

                #region Verify Buyer instances are not available
                Reports.TestStep = "Verify Buyer instances are not available";
                FastDriver.BuyerSellerSummary.Open(isBuyer: true);
                var tableText = FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.Text;
                Support.Match(@"1\s+Available\s+Individual", tableText);
                Support.Match(@"2\s+Available\s+/\s+Available\s+Husband/Wife", tableText);
                Support.Match(@"3\s+Available\s+Trust/Estate", tableText);
                Support.Match(@"4\s+Available\s+BusinessEntity", tableText);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Delete Seller")]
        public void BAT0022()
        {
            try
            {
                Reports.TestDescription = "Delete Seller";

                FASTHelpers.FAST_Login_IIS();
                FASTHelpers.FAST_WCF_File_IIS();

                #region Request new Individual Seller type
                Reports.TestStep = "Request new Individual Seller type";
                var request = BuyerSellerHelpers.GetIndividualBuyerSellerRequest();
                request.FileID = FASTHelpers.File.FileID ?? 0;
                request.BuyerSeller.BuyerSellerTypeID = BuyerSellerTypeCdID.Individual;
                request.PrincipalType = BuyerSellerPrincipalTypeOCD.Seller;
                var response = FileService.AddBuyerSeller(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Request new Husband/Wife Seller type
                Reports.TestStep = "Request new Husband/Wife Seller type";
                request = BuyerSellerHelpers.GetHusbandWifeBuyerSellerRequest();
                request.FileID = FASTHelpers.File.FileID ?? 0;
                request.BuyerSeller.BuyerSellerTypeID = BuyerSellerTypeCdID.HusbandAndWife;
                request.PrincipalType = BuyerSellerPrincipalTypeOCD.Seller;
                response = FileService.AddBuyerSeller(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Request new Trust/Estate Seller type
                Reports.TestStep = "Request new Trust/Estate Seller type";
                request = BuyerSellerHelpers.GetTrustEstateBuyerSellerRequest();
                request.FileID = FASTHelpers.File.FileID ?? 0;
                request.BuyerSeller.BuyerSellerTypeID = BuyerSellerTypeCdID.TrustEstate;
                request.PrincipalType = BuyerSellerPrincipalTypeOCD.Seller;
                response = FileService.AddBuyerSeller(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Request new Business Trust Seller type
                Reports.TestStep = "Request new Business Trust Seller type";
                request = BuyerSellerHelpers.GetBusinessTrustBuyerSellerRequest();
                request.FileID = FASTHelpers.File.FileID ?? 0;
                request.BuyerSeller.BuyerSellerTypeID = BuyerSellerTypeCdID.BusinessEntity;
                request.PrincipalType = BuyerSellerPrincipalTypeOCD.Seller;
                response = FileService.AddBuyerSeller(request);
                Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
                #endregion

                #region Remove all Seller instances
                Reports.TestStep = "Remove all Seller instances";
                var requests = new DeleteBuyerSellerRequest[]{
                    RequestFactory.GetDeleteBuyerSellerRequest(FASTHelpers.File.FileID ?? 0, BuyerSellerPrincipalTypeOCD.Seller, seqNum: 1),
                    RequestFactory.GetDeleteBuyerSellerRequest(FASTHelpers.File.FileID ?? 0, BuyerSellerPrincipalTypeOCD.Seller, seqNum: 2),
                    RequestFactory.GetDeleteBuyerSellerRequest(FASTHelpers.File.FileID ?? 0, BuyerSellerPrincipalTypeOCD.Seller, seqNum: 3),
                    RequestFactory.GetDeleteBuyerSellerRequest(FASTHelpers.File.FileID ?? 0, BuyerSellerPrincipalTypeOCD.Seller, seqNum: 4),
                };
                foreach (var deleteReq in requests)
                {
                    var delResponse = FileService.DeleteBuyerSeller(deleteReq);
                    Support.AreEqual("1", delResponse.Status.ToString(), delResponse.StatusDescription);
                }
                #endregion

                #region Verify Buyer instances are not available
                Reports.TestStep = "Verify Buyer instances are not available";
                FastDriver.BuyerSellerSummary.Open(isBuyer: false);
                var tableText = FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.Text;
                Support.Match(@"1\s+Available\s+Individual", tableText);
                Support.Match(@"2\s+Available\s+/\s+Available\s+Husband/Wife", tableText);
                Support.Match(@"3\s+Available\s+Trust/Estate", tableText);
                Support.Match(@"4\s+Available\s+BusinessEntity", tableText);
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        #endregion

        #region Triage10.7
        [TestMethod]
        public void Triage_10_7_891728()
        {
            try
            {
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = this.GetBaseCreateFileRequest();
                UpdateBuyerSellerRequest updateBuyerSellerRequest = new UpdateBuyerSellerRequest
                {
                    Source = "FAMOS",
                    Target = "FAST",
                    EmployeeObjectCD = "1",
                    BuyerSeller = new BuyerSeller()
                };
                BuyerSellerAddress buyersCurrAddress = new BuyerSellerAddress
                {
                    BuyerSellerAddressTypeCdID = 0,
                    AddrLine1 = "80246 S Edwards Road",
                    AddrLine2 = "CurrentAddrLine2",
                    AddrLine3 = "CurrentAddrLine3",
                    AddrLine4 = "CurrentAddrLine4",
                    State = "OR",
                    City = "ALBANY",
                    County = null,
                    Country = "USA",
                    Zip = "97838"
                };
                BuyerSellerAddress sellersFwdAddress = new BuyerSellerAddress
                {
                    BuyerSellerAddressTypeCdID = 80,
                    AddrLine1 = "ForwardingAddrLine1",
                    AddrLine2 = "ForwardingAddrLine2",
                    AddrLine3 = "ForwardingAddrLine3",
                    AddrLine4 = "ForwardingAddrLine4",
                    State = "CA",
                    City = "ALBANY",
                    County = "ALAMEDA",
                    Country = "USA",
                    Zip = "12345"
                };

                ContactAddress ca = new ContactAddress
                {
                    Comments = null,
                    ContextTypeCdID = 190,
                    ElectronicAddrID = 110751652,
                    Extension = null,
                    Type = null,
                    TypeCdID = 122,
                    Value = "aaraujo@firstam.com"
                };






                Reports.TestDescription = "CD Screen - Section 1: Header - Populate with basic data";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a basic order";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                updateBuyerSellerRequest.FileID = fileId;
                //update buyer1
                updateBuyerSellerRequest.PrincipalType = "Buyer";
                updateBuyerSellerRequest.BuyerSeller.BuyerSellerTypeID = 49;
                updateBuyerSellerRequest.BuyerSeller.Type = "Buyers";
                updateBuyerSellerRequest.BuyerSeller.SeqNum = 1;
                updateBuyerSellerRequest.BuyerSeller.CurrentAddress = buyersCurrAddress;
                var updateREsponse = FileService.UpdateBuyerSeller(updateBuyerSellerRequest);
                Reports.StatusUpdate("Update Buyer 1: " + updateREsponse.StatusDescription, updateREsponse.Status == 1);
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void Triage_10_7_892106()
        {
            try
            {
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                FastDriver.TopFrame.SearchFileByFileNumber(FastDriver.FACreateFileFromWCF(fileRequest));
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.RecordingandTax.FAClick();
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.RecordingFeesAndTransferTaxes);
                FastDriver.FileFees.RecordingFeesAndTransferTaxes.PerformTableAction(2, 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                var ufr = FileRequestFactory.GetUpdatePropertyTaxDefaultRequest(FastDriver.FACreateFileGetFileId(fileRequest));

                var updateREsponse = FileService.UpdatePropertyTax(ufr);
                Reports.StatusUpdate("Update Buyer 1: " + updateREsponse.StatusDescription, updateREsponse.Status == 1);
            }
            catch (Exception e)
            {

                throw;
            }
        }

        [TestMethod]
        public void Triage_10_7_892557()
        {
            try
            {
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                //Note: some parameters were omitted from the Create File because were not necessary for validation
                var customizableFileRequest = RequestFactory.GetCreateFileDefaultRequest();
                customizableFileRequest.File.SalesPriceAmount = 5000;
                customizableFileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";//RESIDENTIAL
                customizableFileRequest.File.TransactionTypeObjectCD = "SALE";//SALE W/MORTGAGE
                #region FileBusinessParties
                customizableFileRequest.File.BusinessParties = new FileBusinessParty[]
                {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList(){
                            eAddtionalRole = AdditionalRoleType.SellersAttorney
                        },
                        CustomerReferenceNumber = @"Reference1",
                    },
                };
                #endregion
                #region Properties
                customizableFileRequest.File.Properties = new Property[]
                {
                    new Property()
                    {
                        Name = "J305",
                        Lot = "Lot1",
                        Block = "Block1",
                        Unit = "Unit1",
                        ProperyTypeCdID = 15, //Single Family Residence
                        PropertyAddress = new PhysicalAddress[]
                        {
                            new PhysicalAddress()
                            {

                                AddrLine1 = @"J305",
                                AddrLine2 = @"J305",
                                AddrLine3 = @"JJEJAMQ",
                                State = "CA",
                                City = "ALBANY",
                                County = "ALAMEDA",
                            }
                        }
                    }
                };
                #endregion
                var _file = FileService.GetOrderDetails((int)FileService.CreateFile(customizableFileRequest).FileID);
                FastDriver.TopFrame.SearchFileByFileNumber(_file.FileNumber);
                Playback.Wait(2000);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();
                FastDriver.FileHomepage.TransactionType.FASelectItem("Refinance");
                FastDriver.WebDriver.HandleDialogMessage();
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.FileHomepage.WaitForScreenToLoad();
                FastDriver.BottomFrame.Save();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);

                //
                Reports.TestStep = "Navigate to Closing Disclosure";
                FastDriver.LeftNavigation.Navigate<ClosingDisclosure>("Home>Order Entry>Escrow Closing>Closing Disclosure").WaitForClosingDisclosureScreenToLoad();
                FastDriver.ClosingDisclosure.DeliveryOptions.FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.ClosingDisclosure.WaitForScreenToLoad(FastDriver.ClosingDisclosure.InitialCD);
                FastDriver.ClosingDisclosure.InitialCD.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.BuyerOnly.FASetCheckbox(true);
                FastDriver.ClosingDisclosure.DateIssuedtxt.FASendKeys("10-10-2010");

                FastDriver.ClosingDisclosure.ClosingDatetxt.FASetText("10-10-2010");
                FastDriver.ClosingDisclosure.DisbursementDatetxt.FASetText("10-10-2010");
                FastDriver.ClosingDisclosure.DeliveryMethod.FASelectItem("Print");
                FastDriver.ClosingDisclosure.DeliveryButton.FAClick();
                FastDriver.PrintDlg.WaitForScreenToLoad();
                FastDriver.PrintDlg.SendPrint();
                FastDriver.WebDriver.WaitForDeliveryWindow(FADeliveryMethod.Print);

                //
                Reports.TestStep = @"Navigate to Term/Dates?Status";
                FastDriver.LeftNavigation.Navigate<TermsDatesStatus>(@"Home>Order Entry>Terms/Dates/Status").WaitForScreenToLoad();
                Support.AreEqual("10-10-2010", FastDriver.TermsDatesStatus.DateIssuedtxt.FAGetValue());
                Support.AreEqual("10-10-2010", FastDriver.TermsDatesStatus.ClosingDate.FAGetValue());
                Support.AreEqual("10-10-2010", FastDriver.TermsDatesStatus.DisbursementDatetxt.FAGetValue());

                //
                Reports.TestStep = @"Generate Mismo";
                var generateMismoResponse = ClosingDisclosureService.GenerateMismo((int)_file.FileID);
                Support.AreEqual("1", generateMismoResponse.Status.ToString(), "Generate Mismo status");

                //
                Reports.TestStep = @"post Mismo";

                string postMismoResponse = ClosingDisclosureService.PostMismoClosingDisclosure(generateMismoResponse.MismoXml).StatusDescription;
                Support.AreEqual("True", postMismoResponse.Contains("Mismo data posted successfully.").ToString(), "Post Mismo Closing Disclusure");

            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        [TestMethod]
        public void Triage_10_7_892570()
        {
            try
            {
                Reports.TestStep = "Log into FAST application.";
                ToggleDisplayPDFinBrowser(true);
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                var File = FileService.GetOrderDetails(FastDriver.FACreateFileGetFileId(FileRequestFactory.GetDetailedCreateFileDefaultRequest()));
                FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);
                FastDriver.LeftNavigation.Navigate<FileFees>(@"Home>Order Entry>Title/Escrow Fees>Fee Entry").WaitForScreenToLoad();
                FastDriver.FileFees.RecordingandTax.FAClick();
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.RecordingFeesAndTransferTaxes);
                FastDriver.FileFees.AddFeesTax.FAClick();
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.FeeSearchFeeTypes);
                FastDriver.FileFees.FeeSearchFeeTypes.FASelectItem("Recording Fee - Mortgage");
                FastDriver.FileFees.FindNow.FAClick();
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.SearchResultsTable);
                FastDriver.FileFees.SearchResultsTable.PerformTableAction(2, "Record Trust Deed - 1", 1, TableAction.On);
                FastDriver.FileFees.SearchResultsTable.PerformTableAction(2, "Record Trust Deed - 2", 1, TableAction.On);
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("one moment please...",false);
                FastDriver.WebDriver.WaitForWindowAndSwitch(Support.FASTWindowName);
                FastDriver.FileFees.WaitForScreenToLoad(FastDriver.FileFees.RecordingFeesAndTransferTaxes);

                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Record Trust Deed - 1", 4, TableAction.SetText, "200");
                FastDriver.FileFees.RecordingTable.PerformTableAction(2, "Record Trust Deed - 2", 3, TableAction.Click);
                FastDriver.FeePaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("250");
                FastDriver.PaymentDetailsDlg.PaidBySellerAtClosing.FASetText("250");
                FastDriver.PaymentDetailsDlg.SellerPaidByOthersPaymentMethod.FASelectItem("Lender");
                FastDriver.DialogBottomFrame.ClickDone();


                Reports.TestStep = "Navigate to Invoice Screen";
                FastDriver.LeftNavigation.Navigate<InvoiceFees>(@"Home>Order Entry>Title/Escrow Fees>Invoice Fees").WaitForScreenToLoad();
                FastDriver.InvoiceFees.Format.FASetCheckbox(true);
                FastDriver.Delivery.Perform(FADeliveryMethod.Preview);
                int rowCount = FastDriver.InvoiceFees.InvoiceFeeListTable.GetRowCount();
                FastDriver.WebDriver.WaitForDeliveryWindow(FADeliveryMethod.Preview);


                Reports.TestStep = "Save PDF file";
                string tempPdfFile = PDFHelper.SavePDFFile("Triage test",true);
                Playback.Wait(2000);
                Reports.TestStep = "Validate Charges";
                if (rowCount > 1)
                {
                    Support.AreEqual("$200.00", PDFHelper.ReadSSPDF(tempPdfFile, "Total Buyer Charges", "BuyerDebit"), true);
                }

                else
                {
                    Support.AreEqual("$0.00", PDFHelper.ReadSSPDF(tempPdfFile, "Total Buyer Charges", "BuyerDebit"), true);
                }
            }
            catch (Exception e)
            {

                FailTest(e.Message);
            }
        }

        #endregion Triage10.7

        #region Private Functions
        private void LoginToIIS()
        {
            #region data setup
            var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
            #endregion

            try
            {
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
            }
            catch (Exception ex)
            {
                throw new Exception("Login is unsuccessful ! Aborting the test !");
            }
        }


        private CreateFileRequest CreateFileRequest()
        {
            return new CreateFileRequest
            {
                EmployeeObjectCD = "1",
                Source = "FAMOS",
                formType = ClosingDisclosureSupport.FormType,
                File = new FASTWCFHelpers.FastFileService.File()
                {
                    TransactionTypeObjectCD = "SALE",
                    BusinessSegmentObjectCD = "Commercial",
                    ExternalFileNumber = "12345678905",
                    AutoNumberIndicator = true,

                    BusinessParties = new FileBusinessParty[]
                    {
                        new FileBusinessParty()
                        {
                            //AddrBookEntryID = AdminService.GetGABAddressBookEntryId("8835227"),
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                            RoleTypeObjectCD = "BUSSOURCE",
                        }
                    },

                    Services = new Service[]
                    {
                        new Service()
                        {
                            OfficeInfo = new OfficeInfo()
                            {
                                RegionID = int.Parse(ClosingDisclosureSupport.IMDRegionBUID),
                                BUID = 1487,
                            },
                        ServiceTypeObjectCD = "TO"
                        },
                        new Service()
                        {
                            OfficeInfo = new OfficeInfo()
                            {
                                RegionID = int.Parse(ClosingDisclosureSupport.IMDRegionBUID),
                                BUID = 1487,
                            },
                            ServiceTypeObjectCD = "EO"
                        }
                    },

                    Properties = new Property[]
                    {
                        new Property()
                        {
                            Name = "my-test-property",
                            PropertyAddress = new FASTWCFHelpers.FastFileService.PhysicalAddress[]
                            {
                                new FASTWCFHelpers.FastFileService.PhysicalAddress()
                                {
                                    State = "CA",
                                    City = "Santa Ana",
                                    County = "Orange",
                                    Country = "USA"
                                }
                            }
                        }
                    },
                }
            };
        }

        private int CreateFile()
        {
            int fileID;
            #region Create a file through WCF
            Reports.TestStep = "Create a file with required values through WCF.";
            var fileRequest = CreateFileRequest();

            var fileResponse = FASTWCFHelpers.FileService.CreateFile(fileRequest);
            fileID = (int)fileResponse.FileID;
            Support.IsTrue((int)(fileResponse.FileID ?? 0) > 0, "Is this FileId valid ? " + fileID);

            var fileDetails = FASTWCFHelpers.FileService.GetOrderDetails(fileID);
            Reports.TestStep = "Search File in MRU.";
            FastDriver.TopFrame.SearchFileByFileNumber(fileDetails.FileNumber);
            #endregion

            return fileID;
        }

        private bool REG_AddBuyerSeller_CD(string principalType, string buyerSellerType)
        {
            try
            {
                Reports.TestStep = "Invoke the AddBuyerSeller service operation.";

                //   Reports.TestStep = "Login to FAST";
                //this.LoginToIIS();

                //Reports.TestStep = "Create a file using web service.";
                var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                //var fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                //FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                var buyerSellerRequest = RequestFactory.GetAddBuyerSellerRequest(buyerSellerType);
                buyerSellerRequest.FileID = fileID;
                buyerSellerRequest.PrincipalType = principalType.ToUpper();
                buyerSellerRequest.Source = "FAMOS";
                var buyerSellerResponse = FASTWCFHelpers.FileService.AddBuyerSeller(buyerSellerRequest);

                //if (!isUserLoggedIn)
                //{
                //FAST_Init_File();
                //isUserLoggedIn = UserLogin();
                // Reports.TestStep = "Create a file using QFE";
                //CreateFileViaService(FileServicePath, "BuyerSeller", 4);
                //fileId = System.Convert.ToInt32(ContextObjects["FileId"]);
                //}
                //if (fileId == 0)
                //{
                //  Reports.TestStep = "Create a file using QFE";
                //CreateFileViaService(FileServicePath, "BuyerSeller", 4);
                //fileId = System.Convert.ToInt32(ContextObjects["FileId"]);
                //}

                //Reports.TestStep = "Invoke CreateSurvey method with Input parameters mentioned in XML";

                /*object serviceInstance = GetWCFInstance("FASTFileService");
                ParameterInfo[] paramters = serviceInstance.GetType().GetMethod("AddBuyerSeller").GetParameters();
                Type objectType = paramters[0].ParameterType;

                dynamic buyerSellerRequest = GetRequest(objectType, FileServicePath + "BuyerSeller.xml", "AddBuyerSeller", 2);
                buyerSellerRequest.FileID = fileId;
                buyerSellerRequest.PrincipalType = principleType.ToUpper();
               
                switch (buyerSellerType.ToLower())
                {
                    case "individual": buyerSellerRequest.BuyerSeller.BuyerSellerTypeID = 48;
                        break;
                    case "husband": buyerSellerRequest.BuyerSeller.BuyerSellerTypeID = 49;
                        break;
                    case "trust": buyerSellerRequest.BuyerSeller.BuyerSellerTypeID = 50;
                        break;
                    case "business entity": buyerSellerRequest.BuyerSeller.BuyerSellerTypeID = 51;
                        break;
                }*/

                //dynamic buyerSellerResponse = InvokeServiceMethodByInstanceAndRequest(serviceInstance, "AddBuyerSeller", buyerSellerRequest);

                // Assert.IsTrue(Helper.GetStatusOnReport(Convert.ToInt16(buyerSellerResponse.Status).Equals(1), "The status is 1 in the response"));
                //Assert.IsTrue(Helper.GetStatusOnReport(buyerSellerResponse.StatusDescription.ToLower().ToString().Contains(principleType.ToLower() + " added successfully"), "The status description is as expected in the response"));

                Reports.TestStep = "Verify the operation response.";
                Reports.StatusUpdate("Is status == 1 in the response ?", Convert.ToInt16(buyerSellerResponse.Status).Equals(1));
                Reports.StatusUpdate("Is the status description as expected in the response ?", buyerSellerResponse.StatusDescription.ToLower().ToString().Contains(principalType.ToLower() + " added successfully."));

                Reports.TestStep = "Navigate to Buyers/Sellers screen in FAST UI";
                switch (principalType)
                {
                    case "buyer":
                        FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>(@"Home>Order Entry>Buyers").WaitForScreenToLoad();
                        //                      FASTLibrary.FASTLibrary.Treeview("Home/Order Entry/Buyers");
                        break;
                    case "seller":
                        FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>(@"Home>Order Entry>Sellers").WaitForScreenToLoad();
                        //FASTLibrary.FASTLibrary.Treeview("Home/Order Entry/Sellers");
                        break;
                }
                Playback.Wait(3000);

                //Goto SummaryPage
                //var buyerSellerSummaryPage = new FATAF.HtmlSupport();
                //buyerSellerSummaryPage.SetParent("IIS.BuyerSellerSetup", "BuyerSummary");
                //Assert.IsTrue(buyerSellerSummaryPage.SetParent("IIS.BuyerSellerSetup", "BuyerSummary").Exists);
                Reports.TestStep = "Check that the Buyer Seller Summary page is loaded. Once loaded, double click the appropriate buyer/seller type.";
                if (FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.IsVisible())
                {
                    switch (buyerSellerType.ToLower())
                    {
                        case "individual":
                            //buyerSellerSummaryPage.HtmlTableSet("IIS.BuyerSellerSetup", "SummaryTable", "#4^Individual^#4|dclick");

                            FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(4, "Individual", 4, TableAction.DoubleClick);
                            break;
                        case "husband/wife":
                            //buyerSellerSummaryPage.HtmlTableSet("IIS.BuyerSellerSetup", "SummaryTable", "#4^Husband/Wife^#5|dclick");

                            FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(4, "Husband/Wife", 4, TableAction.DoubleClick);
                            break;
                        case "trust":
                            //buyerSellerSummaryPage.HtmlTableSet("IIS.BuyerSellerSetup", "SummaryTable", "#4^Trust/Estate^#5|dclick");

                            FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(4, "Trust/Estate", 4, TableAction.DoubleClick);
                            break;
                        case "business entity":
                            //buyerSellerSummaryPage.HtmlTableSet("IIS.BuyerSellerSetup", "SummaryTable", "#4^BusinessEntity^#5|dclick");
                            FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(4, "BusinessEntity", 4, TableAction.DoubleClick);
                            break;
                    }

                    FastDriver.BuyerSellerSetup.WaitForScreenToLoad(FastDriver.BuyerSellerSetup.cmdSearch);
                }
                Playback.Wait(3000);

                //Validate the screen
                //var buyerSellerPage = new FATAF.HtmlSupport();
                //buyerSellerPage.SetParent("IIS.BuyerSellerSetup", "BuyerSellerSetup");
                //dynamic currentAddress = buyerSellerRequest.BuyerSeller.CurrentAddress;
                //dynamic forwardAddress = buyerSellerRequest.BuyerSeller.ForwardingAddress;

                //BuyerTypes
                Reports.TestStep = "Validate appropriate fields in UI against the corresponding request parameter field.";

                switch (buyerSellerType.ToLower())
                {
                    case "individual":
                        Support.AreEqual(buyerSellerRequest.BuyerSeller.FirstName.ToString(), FastDriver.BuyerSellerSetup.IndividualFirstName.FAGetValue());
                        Support.AreEqual(buyerSellerRequest.BuyerSeller.LastName.ToString(), FastDriver.BuyerSellerSetup.IndividualLastName.FAGetValue());

                        //buyerSellerPage.GetControl("IIS.BuyerSellerSetup", "IndividualFirstName").Val("Text", buyerSellerRequest.BuyerSeller.FirstName.ToString());
                        //buyerSellerPage.GetControl("IIS.BuyerSellerSetup", "IndividualLastName").Val("Text", buyerSellerRequest.BuyerSeller.LastName.ToString());
                        break;
                    case "husband/wife":
                        // buyerSellerPage.GetControl("IIS.BuyerSellerSetup", "Spouse1FirstName").Val("Text", buyerSellerRequest.BuyerSeller.FirstName.ToString());
                        //buyerSellerPage.GetControl("IIS.BuyerSellerSetup", "Spouse1LastName").Val("Text", buyerSellerRequest.BuyerSeller.LastName.ToString());
                        //buyerSellerPage.GetControl("IIS.BuyerSellerSetup", "Spouse2FirstName").Val("Text", buyerSellerRequest.BuyerSeller.SpouseFirstName.ToString());
                        //buyerSellerPage.GetControl("IIS.BuyerSellerSetup", "Spouse2LastName").Val("Text", buyerSellerRequest.BuyerSeller.SpouseLastName.ToString());

                        Support.AreEqual(buyerSellerRequest.BuyerSeller.FirstName.ToString(), FastDriver.BuyerSellerSetup.Husband1FirstName.FAGetValue());
                        Support.AreEqual(buyerSellerRequest.BuyerSeller.LastName.ToString(), FastDriver.BuyerSellerSetup.Husband2LastName.FAGetValue());
                        Support.AreEqual(buyerSellerRequest.BuyerSeller.SpouseFirstName.ToString(), FastDriver.BuyerSellerSetup.HusbandSpouseFirstName.FAGetValue());
                        Support.AreEqual(buyerSellerRequest.BuyerSeller.SpouseLastName.ToString(), FastDriver.BuyerSellerSetup.HusbandSpouseLastName.FAGetValue());
                        break;
                    case "trust":
                        //buyerSellerPage.GetControl("IIS.BuyerSellerSetup", "ShortName").Val("Text", buyerSellerRequest.BuyerSeller.ShortName.ToString());
                        //   buyerSellerPage.GetControl("IIS.BuyerSellerSetup", "Dated").Val("Text", buyerSellerRequest.BuyerSeller.LastName.ToString());
                        //buyerSellerPage.GetControl("IIS.BuyerSellerSetup", "TrustNumber").Val("Text", buyerSellerRequest.BuyerSeller.TrustNumber.ToString());

                        Support.AreEqual(buyerSellerRequest.BuyerSeller.ShortName.ToString(), FastDriver.BuyerSellerSetup.TrusteeShortName.FAGetValue());
                        Support.AreEqual(buyerSellerRequest.BuyerSeller.TrustNumber.ToString(), FastDriver.BuyerSellerSetup.TrustNumber.FAGetValue());
                        break;
                    case "business entity":
                        //buyerSellerPage.GetControl("IIS.BuyerSellerSetup", "BusinessShortName").Val("Text", buyerSellerRequest.BuyerSeller.ShortName.ToString());
                        Support.AreEqual(buyerSellerRequest.BuyerSeller.ShortName.ToString(), FastDriver.BuyerSellerSetup.BusinessEntityShortname.FAGetValue());
                        break;
                }

                //buyerSellerPage.GetControl("IIS.BuyerSellerSetup", "CurrentStreet1").Val("Text", currentAddress.AddrLine1.ToString());
                //buyerSellerPage.GetControl("IIS.BuyerSellerSetup", "CurrentState").Val("SelectedItem", currentAddress.State.ToString());
                //buyerSellerPage.GetControl("IIS.BuyerSellerSetup", "CurrentCity").Val("Text", currentAddress.City.ToString());
                //buyerSellerPage.GetControl("IIS.BuyerSellerSetup", "CurrentCounty").Val("Text", currentAddress.County.ToString());
                //buyerSellerPage.GetControl("IIS.BuyerSellerSetup", "CurrentCountry").Val("SelectedItem", currentAddress.Country.ToString());

                Support.AreEqual(buyerSellerRequest.BuyerSeller.CurrentAddress.AddrLine1.ToString(), FastDriver.BuyerSellerSetup.CurrentStreet1.FAGetValue());
                Support.AreEqual(buyerSellerRequest.BuyerSeller.CurrentAddress.State.ToString(), FastDriver.BuyerSellerSetup.CurrentState.FAGetSelectedItem());
                Support.AreEqual(buyerSellerRequest.BuyerSeller.CurrentAddress.City.ToString(), FastDriver.BuyerSellerSetup.CurrentCity.FAGetValue());
                Support.AreEqual(buyerSellerRequest.BuyerSeller.CurrentAddress.County.ToString(), FastDriver.BuyerSellerSetup.CurrentCounty.FAGetValue());
                Support.AreEqual(buyerSellerRequest.BuyerSeller.CurrentAddress.Country.ToString(), FastDriver.BuyerSellerSetup.CurrentCountry.FAGetSelectedItem());

                Support.AreEqual(buyerSellerRequest.BuyerSeller.ForwardingAddress.AddrLine1.ToString(), FastDriver.BuyerSellerSetup.ForwardingStreet1.FAGetValue());
                Support.AreEqual(buyerSellerRequest.BuyerSeller.ForwardingAddress.State.ToString(), FastDriver.BuyerSellerSetup.ForwardingState.FAGetSelectedItem());
                Support.AreEqual(buyerSellerRequest.BuyerSeller.ForwardingAddress.City.ToString(), FastDriver.BuyerSellerSetup.ForwardingCity.FAGetValue());
                Support.AreEqual(buyerSellerRequest.BuyerSeller.ForwardingAddress.County.ToString(), FastDriver.BuyerSellerSetup.ForwardingCounty.FAGetValue());
                Support.AreEqual(buyerSellerRequest.BuyerSeller.ForwardingAddress.Country.ToString(), FastDriver.BuyerSellerSetup.ForwardingCountry.FAGetSelectedItem());

                //Assert.IsTrue(Reports.TestResult);
                return true;
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate(ex.Message, false);
                return false;
            }
        }


        private bool UpdateCompleteVesting_CD(string principalType, int fileID)
        {
            try
            {
                Reports.TestStep = "Adding Buyer";
                REG_AddBuyerSeller_CD("buyer", "individual");
                Playback.Wait(5000);

                Reports.TestStep = "Adding Seller";
                REG_AddBuyerSeller_CD("seller", "individual");
                Playback.Wait(5000);



                int principalTypeCdID = 0;
                if (principalType.ToLower() == "buyer")
                {
                    principalTypeCdID = 113;
                }
                else
                {
                    principalTypeCdID = 114;
                }

                Reports.TestStep = "Invoke UpdateCompleteVesting with input paramenters mentioned in XML.";
                //dynamic response = InvokeServiceMethod("FASTFileService", "UpdateCompleteVesting", null, null, null, null, input);
                var response = FASTWCFHelpers.FileService.UpdateCompleteVesting(fileID, principalTypeCdID, principalType, "famos", "fastts\\fastqa07");

                Reports.TestStep = "Validate the response.";
                Reports.StatusUpdate("Status = " + response.Status, Convert.ToInt16(response.Status).Equals(1));
                Reports.StatusUpdate("Status Description = " + response.StatusDescription, response.StatusDescription.ToString().Contains(" Complete Vesting Updated Successfully."));

                Reports.TestStep = "Navigate to " + principalType + "screen in FAST UI";
                switch (principalType.ToLower())
                {
                    case "buyer":
                        //FastDriver.LeftNavigation.Navigate<BuyerSellerSetup>(@"Home>Order Entry>Buyers").WaitForScreenToLoad();
                        FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>(@"Home>Order Entry>Buyers").WaitForScreenToLoad();
                        break;
                    case "seller":
                        //FastDriver.LeftNavigation.Navigate<BuyerSellerSetup>(@"Home>Order Entry>Sellers").WaitForScreenToLoad();
                        FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>(@"Home>Order Entry>Sellers").WaitForScreenToLoad();
                        break;
                }
                if (!FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.IsVisible())
                {
                    Reports.StatusUpdate("No " + principalType + " exists for this file.", false);
                    Assert.Fail();
                }

                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(4, "Individual", 4, TableAction.DoubleClick);
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.btnFullVesting.FAClick();

                FastDriver.BuyerVesting.WaitForScreenToLoad();
                ServiceHelper.ContainsUIVal(FastDriver.BuyerVesting.CompleteVesting, "value", principalType);
                return true;
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate(ex.Message, false);
                return false;
            }
        }


        private void REG_UpdateBuyerSeller_CD(string principalType, string buyerSellerType)
        {
            Reports.TestDescription = "Verify UpdateBuyerSeller service";
            Reports.TestStep = "Login to FAST";

            //if (fileId == 0)
            //{
            //  Reports.TestStep = "Create a file using QFE";
            //                CreateFileViaService(FileServicePath, "BuyerSeller", 4);
            //              fileId = System.Convert.ToInt32(ContextObjects["FileId"]);
            //            Reports.TestStep = "Adding Buyer";
            //          REG_AddBuyerSeller_CD("buyer", buyerSellerType);
            //        Playback.Wait(5000);
            //Reports.TestStep = "Adding Seller";
            //REG_AddBuyerSeller("seller", "individual");
            //Playback.Wait(5000);
            //  }

            try
            {
                Reports.TestDescription = "Verify AddBuyerSeller service";

                //Reports.TestStep = "Login to FAST";
                //this.LoginToIIS();

                //Reports.TestStep = "Create a file using web service.";
                //var fileRequest = RequestFactory.GetCreateFileDefaultRequest();
                //var fileNumber = FastDriver.FACreateFileFromWCF(fileRequest);
                //FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                var updateBuyerSellerRequest = RequestFactory.GetUpdateBuyerSellerRequest(buyerSellerType);
                updateBuyerSellerRequest.FileID = fileID;
                updateBuyerSellerRequest.PrincipalType = principalType.ToUpper();
                var buyerSellerResponse = FASTWCFHelpers.FileService.UpdateBuyerSeller(updateBuyerSellerRequest);


                //Reports.TestStep = "Invoke CreateSurvey method with Input parameters mentioned in XML";

                /*object serviceInstance = GetWCFInstance("FASTFileService");
                ParameterInfo[] paramters = serviceInstance.GetType().GetMethod("AddBuyerSeller").GetParameters();
                Type objectType = paramters[0].ParameterType;

                dynamic buyerSellerRequest = GetRequest(objectType, FileServicePath + "BuyerSeller.xml", "UpdateBuyerSeller", 2);
                buyerSellerRequest.FileID = fileId;
                buyerSellerRequest.PrincipalType = principleType.ToUpper();
               
                switch (buyerSellerType.ToLower())
                {
                    case "individual": buyerSellerRequest.BuyerSeller.BuyerSellerTypeID = 48;
                        break;
                    case "husband": buyerSellerRequest.BuyerSeller.BuyerSellerTypeID = 49;
                        break;
                    case "trust": buyerSellerRequest.BuyerSeller.BuyerSellerTypeID = 50;
                        break;
                    case "business entity": buyerSellerRequest.BuyerSeller.BuyerSellerTypeID = 51;
                        break;
                }*/

                //dynamic buyerSellerResponse = InvokeServiceMethodByInstanceAndRequest(serviceInstance, "UpdateBuyerSeller", buyerSellerRequest);

                // Assert.IsTrue(Helper.GetStatusOnReport(Convert.ToInt16(buyerSellerResponse.Status).Equals(1), "The status is 1 in the response"));
                //Assert.IsTrue(Helper.GetStatusOnReport(buyerSellerResponse.StatusDescription.ToLower().ToString().Contains(principleType.ToLower() + " added successfully"), "The status description is as expected in the response"));

                Reports.TestStep = "Verify the Service Response";
                Reports.StatusUpdate("Is status == 1 in the response ?", Convert.ToInt16(buyerSellerResponse.Status).Equals(1));
                Reports.StatusUpdate("Is the status description as expected in the response ?", buyerSellerResponse.StatusDescription.ToLower().ToString().Contains(principalType.ToLower() + " updated successfully"));

                Reports.TestStep = "Navigate to Buyers/Sellers screen in FAST UI";
                switch (principalType)
                {
                    case "buyer":
                        FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>(@"Home>Order Entry>Buyers").WaitForScreenToLoad();
                        //                      FASTLibrary.FASTLibrary.Treeview("Home/Order Entry/Buyers");
                        break;
                    case "seller":
                        FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>(@"Home>Order Entry>Sellers").WaitForScreenToLoad();
                        //FASTLibrary.FASTLibrary.Treeview("Home/Order Entry/Sellers");
                        break;
                }
                Playback.Wait(3000);

                //Goto SummaryPage
                //var buyerSellerSummaryPage = new FATAF.HtmlSupport();
                //buyerSellerSummaryPage.SetParent("IIS.BuyerSellerSetup", "BuyerSummary");
                //Assert.IsTrue(buyerSellerSummaryPage.SetParent("IIS.BuyerSellerSetup", "BuyerSummary").Exists);
                if (FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.IsVisible())
                {
                    switch (buyerSellerType.ToLower())
                    {
                        case "individual":
                            //buyerSellerSummaryPage.HtmlTableSet("IIS.BuyerSellerSetup", "SummaryTable", "#4^Individual^#4|dclick");

                            FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(4, "Individual", 4, TableAction.DoubleClick);
                            break;
                        case "husband/wife":
                            //buyerSellerSummaryPage.HtmlTableSet("IIS.BuyerSellerSetup", "SummaryTable", "#4^Husband/Wife^#5|dclick");

                            FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(4, "Husband/Wife", 4, TableAction.DoubleClick);
                            break;
                        case "trust":
                            //buyerSellerSummaryPage.HtmlTableSet("IIS.BuyerSellerSetup", "SummaryTable", "#4^Trust/Estate^#5|dclick");

                            FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(4, "Trust/Estate", 4, TableAction.DoubleClick);
                            break;
                        case "business entity":
                            //buyerSellerSummaryPage.HtmlTableSet("IIS.BuyerSellerSetup", "SummaryTable", "#4^BusinessEntity^#5|dclick");
                            FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(4, "BusinessEntity", 4, TableAction.DoubleClick);
                            break;
                    }

                    FastDriver.BuyerSellerSetup.WaitForScreenToLoad(FastDriver.BuyerSellerSetup.cmdSearch);
                }
                Playback.Wait(3000);

                //Validate the screen
                //var buyerSellerPage = new FATAF.HtmlSupport();
                //buyerSellerPage.SetParent("IIS.BuyerSellerSetup", "BuyerSellerSetup");
                //dynamic currentAddress = buyerSellerRequest.BuyerSeller.CurrentAddress;
                //dynamic forwardAddress = buyerSellerRequest.BuyerSeller.ForwardingAddress;

                //BuyerTypes

                switch (buyerSellerType.ToLower())
                {
                    case "individual":
                        Support.AreEqual(updateBuyerSellerRequest.BuyerSeller.FirstName.ToString(), FastDriver.BuyerSellerSetup.IndividualFirstName.FAGetValue());
                        Support.AreEqual(updateBuyerSellerRequest.BuyerSeller.LastName.ToString(), FastDriver.BuyerSellerSetup.IndividualLastName.FAGetValue());

                        //buyerSellerPage.GetControl("IIS.BuyerSellerSetup", "IndividualFirstName").Val("Text", buyerSellerRequest.BuyerSeller.FirstName.ToString());
                        //buyerSellerPage.GetControl("IIS.BuyerSellerSetup", "IndividualLastName").Val("Text", buyerSellerRequest.BuyerSeller.LastName.ToString());
                        break;
                    case "husband/wife":
                        // buyerSellerPage.GetControl("IIS.BuyerSellerSetup", "Spouse1FirstName").Val("Text", buyerSellerRequest.BuyerSeller.FirstName.ToString());
                        //buyerSellerPage.GetControl("IIS.BuyerSellerSetup", "Spouse1LastName").Val("Text", buyerSellerRequest.BuyerSeller.LastName.ToString());
                        //buyerSellerPage.GetControl("IIS.BuyerSellerSetup", "Spouse2FirstName").Val("Text", buyerSellerRequest.BuyerSeller.SpouseFirstName.ToString());
                        //buyerSellerPage.GetControl("IIS.BuyerSellerSetup", "Spouse2LastName").Val("Text", buyerSellerRequest.BuyerSeller.SpouseLastName.ToString());

                        Support.AreEqual(updateBuyerSellerRequest.BuyerSeller.FirstName.ToString(), FastDriver.BuyerSellerSetup.Husband1FirstName.FAGetValue());
                        Support.AreEqual(updateBuyerSellerRequest.BuyerSeller.LastName.ToString(), FastDriver.BuyerSellerSetup.Husband2LastName.FAGetValue());
                        Support.AreEqual(updateBuyerSellerRequest.BuyerSeller.SpouseFirstName.ToString(), FastDriver.BuyerSellerSetup.HusbandSpouseFirstName.FAGetValue());
                        Support.AreEqual(updateBuyerSellerRequest.BuyerSeller.SpouseLastName.ToString(), FastDriver.BuyerSellerSetup.HusbandSpouseLastName.FAGetValue());
                        break;
                    case "trust":
                        //buyerSellerPage.GetControl("IIS.BuyerSellerSetup", "ShortName").Val("Text", buyerSellerRequest.BuyerSeller.ShortName.ToString());
                        //   buyerSellerPage.GetControl("IIS.BuyerSellerSetup", "Dated").Val("Text", buyerSellerRequest.BuyerSeller.LastName.ToString());
                        //buyerSellerPage.GetControl("IIS.BuyerSellerSetup", "TrustNumber").Val("Text", buyerSellerRequest.BuyerSeller.TrustNumber.ToString());

                        Support.AreEqual(updateBuyerSellerRequest.BuyerSeller.ShortName.ToString(), FastDriver.BuyerSellerSetup.TrusteeShortName.FAGetValue());
                        Support.AreEqual(updateBuyerSellerRequest.BuyerSeller.TrustNumber.ToString(), FastDriver.BuyerSellerSetup.TrustNumber.FAGetValue());

                        break;
                    case "business entity":
                        //buyerSellerPage.GetControl("IIS.BuyerSellerSetup", "BusinessShortName").Val("Text", buyerSellerRequest.BuyerSeller.ShortName.ToString());
                        Support.AreEqual(updateBuyerSellerRequest.BuyerSeller.ShortName.ToString(), FastDriver.BuyerSellerSetup.BusinessEntityShortname.FAGetValue());
                        break;
                }

                Support.AreEqual(updateBuyerSellerRequest.BuyerSeller.CurrentAddress.AddrLine1.ToString(), FastDriver.BuyerSellerSetup.CurrentStreet1.FAGetValue());
                Support.AreEqual(updateBuyerSellerRequest.BuyerSeller.CurrentAddress.State.ToString(), FastDriver.BuyerSellerSetup.CurrentState.FAGetSelectedItem());
                Support.AreEqual(updateBuyerSellerRequest.BuyerSeller.CurrentAddress.City.ToString(), FastDriver.BuyerSellerSetup.CurrentCity.FAGetValue());
                Support.AreEqual(updateBuyerSellerRequest.BuyerSeller.CurrentAddress.County.ToString(), FastDriver.BuyerSellerSetup.CurrentCounty.FAGetValue());
                Support.AreEqual(updateBuyerSellerRequest.BuyerSeller.CurrentAddress.Country.ToString(), FastDriver.BuyerSellerSetup.CurrentCountry.FAGetSelectedItem());

                Support.AreEqual(updateBuyerSellerRequest.BuyerSeller.ForwardingAddress.AddrLine1.ToString(), FastDriver.BuyerSellerSetup.ForwardingStreet1.FAGetValue());
                Support.AreEqual(updateBuyerSellerRequest.BuyerSeller.ForwardingAddress.State.ToString(), FastDriver.BuyerSellerSetup.ForwardingState.FAGetSelectedItem());
                Support.AreEqual(updateBuyerSellerRequest.BuyerSeller.ForwardingAddress.City.ToString(), FastDriver.BuyerSellerSetup.ForwardingCity.FAGetValue());
                Support.AreEqual(updateBuyerSellerRequest.BuyerSeller.ForwardingAddress.County.ToString(), FastDriver.BuyerSellerSetup.ForwardingCounty.FAGetValue());
                Support.AreEqual(updateBuyerSellerRequest.BuyerSeller.ForwardingAddress.Country.ToString(), FastDriver.BuyerSellerSetup.ForwardingCountry.FAGetSelectedItem());

                Assert.IsTrue(Reports.TestResult);
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate(ex.Message, false);
            }
        }

        private void REG_DeleteBuyerSeller_CD(string principalType, string buyerSellerType)
        {
            Reports.TestDescription = "Verify AddBuyerSeller service";
            //  if (fileId == 0)
            //            {
            //              Reports.TestStep = "Create a file using QFE";
            //CreateFileViaService(FileServicePath, "BuyerSeller", 4);
            //fileId = System.Convert.ToInt32(ContextObjects["FileId"]);
            //}
            //Reports.TestStep = "Invoke CreateSurvey method with Input parameters mentioned in XML";
            //object serviceInstance = GetWCFInstance("FASTFileService");
            //ParameterInfo[] paramters = serviceInstance.GetType().GetMethod("DeleteBuyerSeller").GetParameters();
            //Type objectType = paramters[0].ParameterType;

            //Al

            var deleteBuyerSellerRequest = new DeleteBuyerSellerRequest()
            {
                FileID = fileID,
                BuyerSeller = new FASTWCFHelpers.FastFileService.BuyerSeller()
                {
                    SeqNum = 1
                },
                PrincipalType = principalType,
                LoginName = "fastts\\fastqa07",
                Source = "FAMOS"
            };
            var deleteBuyerSellerResponse = FASTWCFHelpers.FileService.DeleteBuyerSeller(deleteBuyerSellerRequest);

            //object buyerSellerRequest = Activator.CreateInstance(objectType);
            //buyerSellerRequest.GetType().GetProperty("FileID").SetValue(buyerSellerRequest, fileId, null);
            //SetNode(buyerSellerRequest, "BuyerSeller", "SeqNum", 1);
            //buyerSellerRequest.GetType().GetProperty("PrincipalType").SetValue(buyerSellerRequest, principleType, null);
            //buyerSellerRequest.GetType().GetProperty("LoginName").SetValue(buyerSellerRequest, "fastts\\fastqa07", null);
            //buyerSellerRequest.GetType().GetProperty("Source").SetValue(buyerSellerRequest, "FAMOS", null);

            //dynamic buyerSellerResponse = InvokeServiceMethodByInstanceAndRequest(serviceInstance, "DeleteBuyerSeller", buyerSellerRequest);

            // Assert.IsTrue(Helper.GetStatusOnReport(Convert.ToInt16(buyerSellerResponse.Status).Equals(1), "The status is 1 in the response"));
            //Assert.IsTrue(Helper.GetStatusOnReport(buyerSellerResponse.StatusDescription.ToLower().ToString().Contains(principleType.ToLower() + " deleted successfully. [sequence: #1]"), "The status description is as expected in the response"));



            Reports.TestStep = "Verify the Service Response";
            Reports.StatusUpdate("Is status == 1 in the response ?", Convert.ToInt16(deleteBuyerSellerResponse.Status).Equals(1));
            Reports.StatusUpdate("Is the status description as expected in the response ?", deleteBuyerSellerResponse.StatusDescription.ToLower().ToString().Contains(principalType.ToLower() + " deleted successfully. [sequence: #1]"));

            Reports.TestStep = "Navigate to Buyers/Sellers screen in FAST UI";
            switch (principalType)
            {
                case "buyer":
                    FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>(@"Home>Order Entry>Buyers").WaitForScreenToLoad();
                    break;

                case "seller":
                    FastDriver.LeftNavigation.Navigate<BuyerSellerSummary>(@"Home>Order Entry>Sellers").WaitForScreenToLoad();
                    break;
            }
            Playback.Wait(3000);

            if (FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.IsVisible())
            {
                switch (buyerSellerType.ToLower())
                {
                    case "individual":
                        FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(4, "Individual", 4, TableAction.DoubleClick);
                        break;

                    case "husband/wife":
                        FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(4, "Husband/Wife", 4, TableAction.DoubleClick);
                        break;

                    case "trust":
                        FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(4, "Trust/Estate", 4, TableAction.DoubleClick);
                        break;

                    case "business entity":
                        FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(4, "BusinessEntity", 4, TableAction.DoubleClick);
                        break;
                }

                FastDriver.BuyerSellerSetup.WaitForScreenToLoad(FastDriver.BuyerSellerSetup.cmdSearch);
            }
            Playback.Wait(3000);

            Support.AreEqual("", FastDriver.BuyerSellerSetup.IndividualFirstName.FAGetValue());
            Support.AreEqual("Available", FastDriver.BuyerSellerSetup.IndividualLastName.FAGetValue());

            Support.AreEqual("", FastDriver.BuyerSellerSetup.CurrentStreet1.FAGetValue());
            Support.AreEqual("", FastDriver.BuyerSellerSetup.CurrentState.FAGetSelectedItem());
            Support.AreEqual("", FastDriver.BuyerSellerSetup.CurrentCity.FAGetValue());
            Support.AreEqual("", FastDriver.BuyerSellerSetup.CurrentCounty.FAGetValue());
            Support.AreEqual("USA", FastDriver.BuyerSellerSetup.CurrentCountry.FAGetSelectedItem());

            Support.AreEqual("True", FastDriver.BuyerSellerSetup.ForwardngSetToProperty.IsSelected().ToString());

            Assert.IsTrue(Reports.TestResult);
        }

        public static int titleEscrowInfoID = 0;
        private CreateFileRequest GetBaseCreateFileRequest()
        {
            // Create a basic CD file
            CreateFileRequest fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest();
            fileRequest.File.BusinessSegmentObjectCD = "RESIDENTAL";

            // Transaction Type = Sale w/ Mortgage - default
            fileRequest.File.TransactionTypeObjectCD = "SALE";

            // Form Type = CD  - default
            fileRequest.formType = AutoConfig.UseCDFormType ? FormType.CD : FormType.HUD; //this has to be ensured since we are testing CD only

            // Sale Price = 350,999.99
            fileRequest.File.SalesPriceAmount = 350999.99m;

            // First New Loan = 295,999.99
            //fileRequest.File.FirstNewLoanAmount = 295999.99m;   // comment out since it will get overriden by NewLoanAmount
            fileRequest.File.NewLoan.NewLoanAmount = 295999.99m;
            fileRequest.File.NewLoan.LiabilityAmount = 295999.99m;

            // Enter Property address (st1 - st 4, city, state, zip)
            fileRequest.File.Properties[0].PropertyAddress[0].AddrLine1 = "PropertyAddrLine1";
            fileRequest.File.Properties[0].PropertyAddress[0].AddrLine2 = "PropertyAddrLine2";
            fileRequest.File.Properties[0].PropertyAddress[0].AddrLine3 = "PropertyAddrLine3";
            fileRequest.File.Properties[0].PropertyAddress[0].AddrLine4 = "PropertyAddrLine4";
            fileRequest.File.Properties[0].PropertyAddress[0].Zip = "11111";
            fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
            fileRequest.File.Properties[0].EstateTypeObjectCD = "Fee Simple";

            // Enter Buyer type Husband/Wife with names
            fileRequest.File.Buyers[0].Type = "Husband and Wife";
            fileRequest.File.Buyers[0].FirstName = "Buyer1Firstname";
            fileRequest.File.Buyers[0].LastName = "Buyer1Lastname";
            fileRequest.File.Buyers[0].SpouseFirstName = "Buyer1SpouseName";
            fileRequest.File.Buyers[0].SpouseLastName = "Buyer1Lastname";

            // Enter Buyer type Trust Estate with name and SIN
            fileRequest.File.Buyers[1].Type = "Trust/Estate";
            fileRequest.File.Buyers[1].Name = "Buyer2Name";
            fileRequest.File.Buyers[1].TIN = "12-3456789";

            // Enter Seller type Husband/Wife with names
            fileRequest.File.Sellers[0].Type = "Husband and Wife";
            fileRequest.File.Sellers[0].FirstName = "Seller1Firstname";
            fileRequest.File.Sellers[0].LastName = "Seller1Lastname";
            fileRequest.File.Sellers[0].SpouseFirstName = "Seller1SpouseName";
            fileRequest.File.Sellers[0].SpouseLastName = "Seller1Lastname";

            // Enter Seller type Business with name and SIN
            fileRequest.File.Sellers[1].Type = "Business Entity";
            fileRequest.File.Sellers[1].Name = "Seller2Name";
            fileRequest.File.Sellers[1].TIN = "98-7654321";

            // Enter Lender GAB  - default
            fileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1");
            fileRequest.File.BusinessParties[0].AdditionalRole = new AdditionalRoleList() { eAddtionalRole = AdditionalRoleType.NewLender };
            fileRequest.File.BusinessParties[0].CustomerReferenceNumber = "1234567890";

            return fileRequest;
        }

        #endregion

        [TestMethod]
        public void REG0001_UpdateExchangeCompany()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan();
                fileRequest.File.Sellers = new BuyerSeller[0];
                #endregion

                Reports.TestDescription = "Verify CreateNewLoan() service.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                var file = FileService.GetOrderDetails(FastDriver.FACreateFileGetFileId(fileRequest));
                FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

                Reports.TestStep = "Navigate to Buyer";
                FastDriver.BuyerSellerSummary.Open(isBuyer: true);

                Reports.TestStep = "Create Exchange Company for Buyer";
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 2, TableAction.DoubleClick);
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.btnExchangeCompany.FAClick();
                FastDriver.ExchangeCompany.WaitForScrenToLoad();
                FastDriver.ExchangeCompany.FindGAB("508");
                Playback.Wait(1000);
                FastDriver.ExchangeCompany.SalesRep1.FASelectItem("B, Raghu");
                FastDriver.ExchangeCompany.SalesRep2.FASelectItem("B, Raghu");
                FastDriver.ExchangeCompany.Reference.FASetText("1234");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Invoke GetOrderDetails method";
                file = FileService.GetOrderDetails(file.FileID.Value);

                Reports.TestStep = "Update Exchange Company";
                FileBusinessParty fbp = new FileBusinessParty
                {
                    AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                    EditElectronicAddress = true,
                    ElectronicAddress = new ElectronicAddress
                    {
                        BusinessFax = "1234567899",
                        BusinessPhone = "7418523699",
                        Cellular = "8523647812",
                        ElectronicAddrID = 1399,
                        EmailAddress = "ab@aol.com",
                        Enddated = false,
                        Extension = "4569",
                        Pager = "4567891235"
                    }
                };
                try
                {
                    FileService.UpdateExchangeCompany(FileRequestFactory.GetExchangeCompanyRequest(file.FileID.Value, file.Buyers[0].FileBusinessPartyID.Value, fbp)).Validate();
                }
                catch (Exception)
                {
                    throw new Exception("The buyer's FileBusinesPartyID is null");
                }
                //int ftpid = (int)FASqlHelpers.ExecuteSQLQuery(string.Format("select FileBusinessPartyID from FileProcess(nolock) where FileID = {0} and ProcessTypeCdID = 113", file.FileID.Value)).Tables[0].Rows[0]["FileBusinessPartyID"];
                //FileService.UpdateExchangeCompany(FileRequestFactory.GetExchangeCompanyRequest(file.FileID.Value, ftpid, fbp)).Validate();

                Reports.TestStep = "Navigate to Buyer";
                FastDriver.BuyerSellerSummary.Open(isBuyer: true);

                Reports.TestStep = "Validate Exchange Company for Buyer";
                string phoneNumberFormat = "{0:(###)###-####}";
                FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 2, TableAction.DoubleClick);
                FastDriver.BuyerSellerSetup.WaitForScreenToLoad();
                FastDriver.BuyerSellerSetup.btnExchangeCompany.FAClick();
                FastDriver.ExchangeCompany.WaitForScrenToLoad();
                Support.AreEqual("247", FastDriver.ExchangeCompany.GABIdCodeLabel.FAGetText(), "GABIdCodeLabel");
                Support.AreEqual("B, Raghu", FastDriver.ExchangeCompany.SalesRep1.FAGetSelectedItem().Clean(), "SalesRep1");
                Support.AreEqual("B, Raghu", FastDriver.ExchangeCompany.SalesRep2.FAGetSelectedItem().Clean(), "SalesRep2");
                Support.AreEqual("", FastDriver.ExchangeCompany.Reference.FAGetValue().Clean(), "Reference");
                Support.AreEqual(fbp.ElectronicAddress.EmailAddress, FastDriver.ExchangeCompany.EmailAddress.FAGetValue(), "EmailAddress");
                Support.AreEqual(fbp.ElectronicAddress.BusinessPhone.FormatAsPhoneNumber(format: phoneNumberFormat), FastDriver.ExchangeCompany.BusPhone.FAGetValue(), "BusinessPhone");
                Support.AreEqual(fbp.ElectronicAddress.Extension, FastDriver.ExchangeCompany.BusPhoneExt.FAGetValue(), "Extension");
                Support.AreEqual(fbp.ElectronicAddress.BusinessFax.FormatAsPhoneNumber(format: phoneNumberFormat), FastDriver.ExchangeCompany.BusFax.FAGetValue(), "BusFax");
                Support.AreEqual(fbp.ElectronicAddress.Cellular.FormatAsPhoneNumber(format: phoneNumberFormat), FastDriver.ExchangeCompany.CellPhone.FAGetValue(), "CellPhone");
                Support.AreEqual(fbp.ElectronicAddress.Pager.FormatAsPhoneNumber(format: phoneNumberFormat), FastDriver.ExchangeCompany.Pager.FAGetValue(), "Pager");
                FastDriver.BottomFrame.Done();
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}

