﻿using SeleniumInternalHelpersSupportLibrary;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTSelenium.DataObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTSelenium.PageObjects.ADM;
using FASTSelenium.DataObjects.ADM;
using FASTSelenium.PageObjects;
using FASTSelenium.Common;
using SeleniumInternalHelpers;
using OpenQA.Selenium;
using FASTWCFHelpers.FastFileService;
using WebServices.Helpers.File;
using System.Linq;

namespace WebServices.File
{
    [CodedUITest]
    public partial class GeneralFileServiceOperationsWS : MasterTestClass
    {
        [TestMethod]
        public void REG0001_CreateFile()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan();
                fileRequest.File.SalesPriceAmount = 1200m;
                fileRequest.File.Properties = new Property[]
                    {
                        new Property()
                        {
                            Name = "First Property",
                            Block = "Block1",
                            Book = "Book1",
                            Building = "Building1",
                            Fee = "Fee1",
                            PropertyAddress = new PhysicalAddress[]
                            {
                                new PhysicalAddress()
                                {
                                    AddrLine1 = "1 Property 1 Street",
                                    AddrLine2 = "2 Property 1 Street",
                                    AddrLine3 = "3 Property 1 Street",
                                    AddrLine4 = "4 Property 1 Street",
                                    State = "CA",
                                    City = "ALBANY",
                                    County = "ALAMEDA",
                                    Country = "USA",
                                    Zip = "12345"
                                }
                            }
                        }
                    };
                #endregion

                Reports.TestDescription = "Verify CreateFile() service.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Invoke the CreateFile method.";
                int fileid = FastDriver.FACreateFileGetFileId(fileRequest);

                Reports.TestStep = "Invoke the GetOrderDetails method.";
                var file = FileService.GetOrderDetails(fileid);
                Reports.TestStep = "Open file in FAST UI.";
                FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);
                Reports.TestStep = "Validate file data in File Homepage.";
                FastDriver.FileHomepage.Open();
                Support.AreEqual("Residential", FastDriver.FileHomepage.BusinessSegment.FAGetSelectedItem().Clean(), "BusinessSegment");
                Support.AreEqual("Sale w/Mortgage", FastDriver.FileHomepage.TransactionType.FAGetSelectedItem().Clean(), "TransactionType");
                Support.IsTrue(AutoConfig.UseCDFormType ? FastDriver.FileHomepage.FormTypeCD.IsSelected() : FastDriver.FileHomepage.FormTypeHUD.IsSelected(), AutoConfig.FormType + " Form Type");
                Support.AreEqual(fileRequest.File.SalesPriceAmount.ToString().FormatAsMoney(), FastDriver.FileHomepage.TermsDatesPrice.FAGetValue().Clean(), "TermsDatesPrice");

                Reports.TestStep = "Validate Service Types in File Homepage.";
                Support.IsTrue(FastDriver.FileHomepage.Title.IsSelected(), "Title");
                Support.IsTrue(FastDriver.FileHomepage.Escrow.IsSelected(), "Escrow");
                Support.IsTrue(!FastDriver.FileHomepage.SubEscrow.IsSelected(), "SubEscrow");

                Reports.TestStep = "Validate Buyer and Seller in File Homepage.";
                Support.AreEqual(fileRequest.File.Buyers[0].Type, FastDriver.FileHomepage.Buyer1Type.FAGetSelectedItem().Clean(), "Buyer1Type");
                Support.AreEqual(fileRequest.File.Buyers[0].FirstName, FastDriver.FileHomepage.Buyer1FirstName.FAGetValue().Clean(), "Buyer1FirstName");
                Support.AreEqual(fileRequest.File.Buyers[0].LastName, FastDriver.FileHomepage.Buyer1LastName.FAGetValue().Clean(), "Buyer1LastName");
                Support.AreEqual(fileRequest.File.Sellers[0].Type, FastDriver.FileHomepage.Seller1Type.FAGetSelectedItem().Clean(), "Seller1Type");
                Support.AreEqual(fileRequest.File.Sellers[0].FirstName, FastDriver.FileHomepage.Seller1FirstName.FAGetValue().Clean(), "Seller1FirstName");
                Support.AreEqual(fileRequest.File.Sellers[0].LastName, FastDriver.FileHomepage.Seller1LastName.FAGetValue().Clean(), "Seller1LastName");

                Reports.TestStep = "Validate Property in File Homepage.";
                Support.AreEqual(fileRequest.File.Properties[0].Block, FastDriver.FileHomepage.PropertyBlock.FAGetValue().Clean(), "PropertyBlock");
                Support.AreEqual(fileRequest.File.Properties[0].Book, FastDriver.FileHomepage.PropertyBook.FAGetValue().Clean(), "PropertyBook");
                Support.AreEqual(fileRequest.File.Properties[0].Building, FastDriver.FileHomepage.PropertyBuilding.FAGetValue().Clean(), "PropertyBuilding");
                Support.AreEqual(fileRequest.File.Properties[0].Fee, FastDriver.FileHomepage.PropertyFee.FAGetValue().Clean(), "PropertyFee");
                Support.AreEqual(fileRequest.File.Properties[0].Name, FastDriver.FileHomepage.PropertyName.FAGetValue().Clean(), "PropertyName");
                Support.AreEqual(fileRequest.File.Properties[0].PropertyAddress[0].AddrLine1, FastDriver.FileHomepage.PropertyBookAddressLine1.FAGetValue().Clean(), "PropertyBookAddressLine1");
                Support.AreEqual(fileRequest.File.Properties[0].PropertyAddress[0].AddrLine2, FastDriver.FileHomepage.PropertyBookAddressLine2.FAGetValue().Clean(), "PropertyBookAddressLine2");
                Support.AreEqual(fileRequest.File.Properties[0].PropertyAddress[0].AddrLine3, FastDriver.FileHomepage.PropertyBookAddressLine3.FAGetValue().Clean(), "PropertyBookAddressLine3");
                Support.AreEqual(fileRequest.File.Properties[0].PropertyAddress[0].AddrLine4, FastDriver.FileHomepage.PropertyBookAddressLine4.FAGetValue().Clean(), "PropertyBookAddressLine4");
                Support.AreEqual(fileRequest.File.Properties[0].PropertyAddress[0].City, FastDriver.FileHomepage.PropertyAddressBookCity.FAGetValue().Clean(), "PropertyAddressBookCity");
                Support.AreEqual(fileRequest.File.Properties[0].PropertyAddress[0].State, FastDriver.FileHomepage.PropertyState.FAGetSelectedItem().Clean(), "PropertyState");
                Support.AreEqual(fileRequest.File.Properties[0].PropertyAddress[0].Zip, FastDriver.FileHomepage.PropertyZip.FAGetValue().Clean(), "PropertyZip");
                Support.AreEqual(fileRequest.File.Properties[0].PropertyAddress[0].County, FastDriver.FileHomepage.PropertyCounty.FAGetValue().Clean(), "PropertyCounty");
                Support.AreEqual(fileRequest.File.Properties[0].PropertyAddress[0].Country, FastDriver.FileHomepage.PropertyCountry.FAGetSelectedItem().Clean(), "PropertyCountry");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0002_UpdateOrderDetails()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan();
                #region BusinessParties
                fileRequest.File.BusinessParties = new FileBusinessParty[2]
                        {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("BOA"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.None
                        }
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                        RoleTypeObjectCD = "DIRECTEDBY",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.None
                        }
                    }
                        };
                #endregion
                fileRequest.File.BusinessSegmentObjectCD = "NEWHM";
                #region Buyer
                fileRequest.File.Buyers[0] = new BuyerSeller
                {
                    BuyerSellerTypeID = 48,
                    EntityTypeID = 101,
                    FirstName = "James",
                    LastName = "Campbell",
                    MiddleName = "P",
                    PrincipalID = 113,
                    SeqNum = 1,
                    SpouseLastName = "Campbell",
                    Suffix = "MR",
                    Type = "INDIVIDUAL"
                };
                #endregion
                #region Product
                fileRequest.File.Products = new Product[1]
                        {
                    new Product
                    {
                        ObjectCD = "EAGLELENDR",
                        ProductID = 886
                    }
                        };
                #endregion
                #region Properties
                fileRequest.File.Properties = new Property[]
                {
                    new Property()
                    {
                        Name = "my-test-property",
                        Block = "1",
                        Book = "C",
                        Building = "B",
                        Fee = "12",
                        SeqNum = 1,
                        PropertyAddress = new PhysicalAddress[]
                        {
                            new PhysicalAddress()
                            {
                                AddrLine1 = "H.No.9",
                                AddrLine2 = "Street 4",
                                AddrLine3 = "6th Circle",
                                AddrLine4 = "Bay1",
                                Country = "USA",
                                State = "CA",
                                City = "Santa Ana",
                                County = "Orange",
                                Zip = "13425",
                                Enddated = false,
                                EnterpriseID = 0,
                                FastId = 0,
                                GeoRegionID = 0,
                                PhysicalAddrID = 0,
                                PhysicalAddrTypeCdID = 0
                            }
                        }
                    }
                };
                #endregion
                fileRequest.File.SalesPriceAmount = 6000.01m;
                #region Seller
                fileRequest.File.Sellers[0] = new BuyerSeller
                {
                    BuyerSellerTypeID = 49,
                    EntityType = "Miscellaneous",
                    EntityTypeID = 101,
                    FirstName = "Adam",
                    LastName = "Williams",
                    MiddleName = "C",
                    PrincipalID = 114,
                    SeqNum = 1,
                    ShortName = "ShortNS",
                    SpouseLastName = "Williams",
                    Suffix = "MR",
                    Type = "Husband And Wife",
                };
                #endregion
                #endregion

                Reports.TestDescription = "Verify UpdateOrderDetails() service.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Invoke the CreateFile method.";
                int fileid = FastDriver.FACreateFileGetFileId(fileRequest);

                Reports.TestStep = "Invoke the GetOrderDetails method.";
                var file = FileService.GetOrderDetails(fileid);

                Reports.TestStep = "Invoke the UpdateOrderDetails method.";
                var updateFileRequest = FileRequestFactory.GetUpdateOrderDetailsRequest(file.FileID.Value);
                FileService.UpdateOrderDetails(updateFileRequest).OperationResponse.Validate();

                Reports.TestStep = "Open file in FAST UI.";
                FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

                Reports.TestStep = "Validate file data in File Homepage.";
                FastDriver.FileHomepage.Open();
                Support.AreEqual("New Home", FastDriver.FileHomepage.BusinessSegment.FAGetSelectedItem().Clean(), "BusinessSegment");
                Support.AreEqual("Sale w/Mortgage", FastDriver.FileHomepage.TransactionType.FAGetSelectedItem().Clean(), "TransactionType");
                Support.IsTrue(AutoConfig.UseCDFormType ? FastDriver.FileHomepage.FormTypeCD.IsSelected() : FastDriver.FileHomepage.FormTypeHUD.IsSelected(), AutoConfig.FormType + " Form Type");
                //Support.AreEqual(updateFileRequest.File.SalesPriceAmount.ToString().FormatAsMoney(), FastDriver.FileHomepage.TermsDatesPrice.FAGetValue().Clean(), "TermsDatesPrice");

                Reports.TestStep = "Validate Business Source in File Homepage.";
                Support.AreEqual("504", FastDriver.FileHomepage.BusinessPartyIDCodeField.FAGetText().Clean(), "BusinessPartyIDCodeField");
                Support.AreEqual(AdminService.GetGABByAddressBookEntryID(AdminService.GetGABAddressBookEntryId("504").Value).Name1, FastDriver.FileHomepage.BusSrceName.FAGetText().Clean(), "BusSrceName");
                Support.AreEqual(updateFileRequest.File.BusinessParties[0].EditElectronicAddress.Value, FastDriver.FileHomepage.BusinessPartyEditCont.IsSelected(), "BusinessPartyEditCont");
                Support.AreEqual(updateFileRequest.File.BusinessParties[0].ElectronicAddress.BusinessPhone.FormatAsPhoneNumber(format: "{0:(###)###-####}"), FastDriver.FileHomepage.BusinessPartyBusPhone.FAGetValue().Clean(), "BusinessPartyBusPhone");
                Support.AreEqual(updateFileRequest.File.BusinessParties[0].ElectronicAddress.Extension, FastDriver.FileHomepage.BusinessPartyBusPhoneExtension.FAGetValue().Clean(), "BusinessPartyBusPhoneExtension");
                Support.AreEqual(updateFileRequest.File.BusinessParties[0].ElectronicAddress.BusinessFax.FormatAsPhoneNumber(format: "{0:(###)###-####}"), FastDriver.FileHomepage.BusinessPartyBusFax.FAGetValue().Clean(), "BusinessPartyBusFax");
                Support.AreEqual(updateFileRequest.File.BusinessParties[0].ElectronicAddress.Cellular.FormatAsPhoneNumber(format: "{0:(###)###-####}"), FastDriver.FileHomepage.BusinessPartyCellPhone.FAGetValue().Clean(), "BusinessPartyCellPhone");
                Support.AreEqual(updateFileRequest.File.BusinessParties[0].ElectronicAddress.Pager.FormatAsPhoneNumber(format: "{0:(###)###-####}"), FastDriver.FileHomepage.BusinessPartyPager.FAGetValue().Clean(), "BusinessPartyPager");
                Support.AreEqual(updateFileRequest.File.BusinessParties[0].ElectronicAddress.EmailAddress, FastDriver.FileHomepage.BusinessPartyEmailAddress.FAGetValue().Clean(), "BusinessPartyEmailAddress");

                Reports.TestStep = "Validate Business Source Contact Details in File Homepage.";
                Support.AreEqual(updateFileRequest.File.BusinessParties[0].BusOrgContact.EditElectronicAddress.Value, FastDriver.FileHomepage.BusinessPartyEditContact.IsSelected(), "BusinessPartyEditContact");
                Support.AreEqual(updateFileRequest.File.BusinessParties[0].BusOrgContact.ContactName, FastDriver.FileHomepage.BusinessPartyContactName.FAGetText().Clean(), "BusinessPartyContactName");
                Support.AreEqual(updateFileRequest.File.BusinessParties[0].BusOrgContact.StatusEmail.Value == 1, FastDriver.FileHomepage.BSStatusEmail.IsSelected(), "BSStatusEmail");
                Support.AreEqual(updateFileRequest.File.BusinessParties[0].BusOrgContact.ElectronicAddress.BusinessPhone.FormatAsPhoneNumber(format: "{0:(###)###-####}"), FastDriver.FileHomepage.BusinessPartyContactBusPhone.FAGetValue().Clean(), "BusinessPartyContactBusPhone");
                Support.AreEqual(updateFileRequest.File.BusinessParties[0].BusOrgContact.ElectronicAddress.Extension, FastDriver.FileHomepage.BusinessPartyContactPhoneExt.FAGetValue().Clean(), "BusinessPartyContactPhoneExt");
                Support.AreEqual(updateFileRequest.File.BusinessParties[0].BusOrgContact.ElectronicAddress.BusinessFax.FormatAsPhoneNumber(format: "{0:(###)###-####}"), FastDriver.FileHomepage.BusinessPartyContactBusFax.FAGetValue().Clean(), "BusinessPartyContactBusFax");
                Support.AreEqual(updateFileRequest.File.BusinessParties[0].BusOrgContact.ElectronicAddress.Cellular.FormatAsPhoneNumber(format: "{0:(###)###-####}"), FastDriver.FileHomepage.BusinessPartyContactCellPhone.FAGetValue().Clean(), "BusinessPartyContactCellPhone");
                Support.AreEqual(updateFileRequest.File.BusinessParties[0].BusOrgContact.ElectronicAddress.EmailAddress, FastDriver.FileHomepage.BusinessPartyContactEmailAddress.FAGetValue().Clean(), "BusinessPartyContactEmailAddress");

                Reports.TestStep = "Validate Directed By in File Homepage.";
                Support.AreEqual("506", FastDriver.FileHomepage.DirectedByIDCodeField.FAGetText().Clean(), "DirectedByIDCodeField");
                Support.AreEqual(AdminService.GetGABByAddressBookEntryID(AdminService.GetGABAddressBookEntryId("506").Value).Name1, FastDriver.FileHomepage.DirectedByLabelName.FAGetText().Clean(), "DirectedByName");
                Support.AreEqual(updateFileRequest.File.BusinessParties[1].EditElectronicAddress.Value, FastDriver.FileHomepage.DirectedByEditCont.IsSelected(), "DirectedByEditCont");
                Support.AreEqual(updateFileRequest.File.BusinessParties[1].ElectronicAddress.BusinessPhone.FormatAsPhoneNumber(format: "{0:(###)###-####}"), FastDriver.FileHomepage.DirectedByBusPhone.FAGetValue().Clean(), "DirectedByBusPhone");
                Support.AreEqual(updateFileRequest.File.BusinessParties[1].ElectronicAddress.Extension, FastDriver.FileHomepage.DirectedByBusPhoneExtn.FAGetValue().Clean(), "DirectedByBusPhoneExtn");
                Support.AreEqual(updateFileRequest.File.BusinessParties[1].ElectronicAddress.BusinessFax.FormatAsPhoneNumber(format: "{0:(###)###-####}"), FastDriver.FileHomepage.DirectedByBusFax.FAGetValue().Clean(), "DirectedByBusFax");
                Support.AreEqual(updateFileRequest.File.BusinessParties[1].ElectronicAddress.Cellular.FormatAsPhoneNumber(format: "{0:(###)###-####}"), FastDriver.FileHomepage.DirectedByCellPhone.FAGetValue().Clean(), "DirectedByCellPhone");
                Support.AreEqual(updateFileRequest.File.BusinessParties[1].ElectronicAddress.Pager.FormatAsPhoneNumber(format: "{0:(###)###-####}"), FastDriver.FileHomepage.DirectedByPager.FAGetValue().Clean(), "DirectedByPager");
                Support.AreEqual(updateFileRequest.File.BusinessParties[1].ElectronicAddress.EmailAddress, FastDriver.FileHomepage.DirectedByEmailAddress.FAGetValue().Clean(), "DirectedByEmailAddress");

                Reports.TestStep = "Validate Business Source Contact Details in File Homepage.";
                Support.AreEqual(updateFileRequest.File.BusinessParties[1].BusOrgContact.EditElectronicAddress.Value, FastDriver.FileHomepage.DirectedByEditContact.IsSelected(), "DirectedByEditContact");
                Support.AreEqual(updateFileRequest.File.BusinessParties[1].BusOrgContact.ContactName, FastDriver.FileHomepage.DirectedByContactName.FAGetText().Clean(), "DirectedByContactName");
                Support.AreEqual(updateFileRequest.File.BusinessParties[1].BusOrgContact.StatusEmail.Value == 1, FastDriver.FileHomepage.DirectedByContactStatusEmail.IsSelected(), "BSStatusEmail");
                Support.AreEqual(updateFileRequest.File.BusinessParties[1].BusOrgContact.ElectronicAddress.BusinessPhone.FormatAsPhoneNumber(format: "{0:(###)###-####}"), FastDriver.FileHomepage.DirectedByContactBusPhone.FAGetValue().Clean(), "DirectedByContactBusPhone");
                Support.AreEqual(updateFileRequest.File.BusinessParties[1].BusOrgContact.ElectronicAddress.Extension, FastDriver.FileHomepage.DirectedByContactPhoneExt.FAGetValue().Clean(), "DirectedByContactPhoneExt");
                Support.AreEqual(updateFileRequest.File.BusinessParties[1].BusOrgContact.ElectronicAddress.BusinessFax.FormatAsPhoneNumber(format: "{0:(###)###-####}"), FastDriver.FileHomepage.DirectedByContactBusFax.FAGetValue().Clean(), "DirectedByContactBusFax");
                Support.AreEqual(updateFileRequest.File.BusinessParties[1].BusOrgContact.ElectronicAddress.Cellular.FormatAsPhoneNumber(format: "{0:(###)###-####}"), FastDriver.FileHomepage.DirectedByContactCellPhone.FAGetValue().Clean(), "DirectedByContactCellPhone");
                Support.AreEqual(updateFileRequest.File.BusinessParties[1].BusOrgContact.ElectronicAddress.EmailAddress, FastDriver.FileHomepage.DirectedByContactEmailAddress.FAGetValue().Clean(), "BusinessPartyContactEmailAddress");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0003_UpdateSecondOrderSource()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan();
                #endregion

                Reports.TestDescription = "Verify UpdateSecondOrderSource() service.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Invoke the CreateFile method.";
                int fileid = FastDriver.FACreateFileGetFileId(fileRequest);

                Reports.TestStep = "Invoke the GetOrderDetails method.";
                var file = FileService.GetOrderDetails(fileid);

                Reports.TestStep = "Invoke the UpdateSecondOrderSource method.";
                var updateFileRequest = FileRequestFactory.GetUpdateSecondOrderSourceRequest(file.FileID.Value, appID: 38, Source: "LVIS");
                FileService.UpdateSecondOrderSource(updateFileRequest).Validate();

                Reports.TestStep = "Open file in FAST UI.";
                FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

                Reports.TestStep = "Validate Order Source in File Homepage.";
                FastDriver.FileHomepage.Open();
                FastDriver.FileHomepage.OrderSourceExpand.FAClick();
                Support.AreEqual(updateFileRequest.Source, FastDriver.FileHomepage.SecondOrderSource.FAGetText(), "SecondOrderSource");
                Support.AreEqual(updateFileRequest.SecondExternalFileNum, FastDriver.FileHomepage.SecondExternalNumber.FAGetText(), "SecondExternalNumber");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0004_AddProductionOffice()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan();
                #endregion

                Reports.TestDescription = "Verify AddProductionOffice() service.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a file.";
                var file = FileService.GetOrderDetails(FastDriver.FACreateFileGetFileId(fileRequest));

                Reports.TestStep = "Open file in FAST UI.";
                FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

                Reports.TestStep = "Navigate to File Homepage";
                FastDriver.FileHomepage.Open();
                int escrowIndex = FastDriver.FileHomepage.EscrowProdOfficeTable.GetRowCount(thisTableOnly: true) + 1;
                int titleIndex = FastDriver.FileHomepage.TitleProdOfficeTable.GetRowCount(thisTableOnly: true) + 1;

                Reports.TestStep = "And an Escrow Production Office with the AddProductionOffice method.";
                FileService.AddProductionOffice(FileRequestFactory.GetAddProductionOfficeRequest(file.FileID.Value, productionOfficeID: 2484, serviceTypeCdID: 22)).Validate();

                Reports.TestStep = "And a Title Production Office with the AddProductionOffice method.";
                FileService.AddProductionOffice(FileRequestFactory.GetAddProductionOfficeRequest(file.FileID.Value, productionOfficeID: 2484, serviceTypeCdID: 21)).Validate();

                Reports.TestStep = "Navigate to File Homepage";
                FastDriver.FileHomepage.Open();

                Reports.TestStep = "Validate added Escrow Production Office";
                Support.IsTrue(FastDriver.FileHomepage.EscrowProdOfficeTable.PerformTableAction(escrowIndex, 1, TableAction.GetText).Message.Contains("2484"), "EscrowProdOfficeTable contains 2484");

                Reports.TestStep = "Validate added Title Production Office";
                Support.IsTrue(FastDriver.FileHomepage.TitleProdOfficeTable.PerformTableAction(escrowIndex, 1, TableAction.GetText).Message.Contains("2484"), "TitleProdOfficeTable contains 2484");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0005_RemoveProductionOffice()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan();
                #endregion

                Reports.TestDescription = "Verify RemoveProductionOffice() service.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a file.";
                var file = FileService.GetOrderDetails(FastDriver.FACreateFileGetFileId(fileRequest));

                Reports.TestStep = "Open file in FAST UI.";
                FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

                Reports.TestStep = "Navigate to File Homepage";
                FastDriver.FileHomepage.Open();
                int escrowIndex = FastDriver.FileHomepage.EscrowProdOfficeTable.GetRowCount(thisTableOnly: true) + 1;
                int titleIndex = FastDriver.FileHomepage.TitleProdOfficeTable.GetRowCount(thisTableOnly: true) + 1;

                Reports.TestStep = "Add an Escrow Production Office with the AddProductionOffice method.";
                FileService.AddProductionOffice(FileRequestFactory.GetAddProductionOfficeRequest(file.FileID.Value, productionOfficeID: 2484, serviceTypeCdID: 22)).Validate();

                Reports.TestStep = "Add a Title Production Office with the AddProductionOffice method.";
                FileService.AddProductionOffice(FileRequestFactory.GetAddProductionOfficeRequest(file.FileID.Value, productionOfficeID: 2484, serviceTypeCdID: 21)).Validate();

                Reports.TestStep = "Navigate to File Homepage";
                FastDriver.FileHomepage.Open();

                Reports.TestStep = "Validate added Escrow Production Office";
                Support.IsTrue(FastDriver.FileHomepage.EscrowProdOfficeTable.PerformTableAction(escrowIndex, 1, TableAction.GetText).Message.Contains("2484"), "EscrowProdOfficeTable contains 2484");

                Reports.TestStep = "Validate added Title Production Office";
                Support.IsTrue(FastDriver.FileHomepage.TitleProdOfficeTable.PerformTableAction(escrowIndex, 1, TableAction.GetText).Message.Contains("2484"), "TitleProdOfficeTable contains 2484");

                Reports.TestStep = "Remove Escrow Production Office with the RemoveProductionOffice method.";
                FileService.RemoveProductionOffice(FileRequestFactory.GetRemoveProductionOfficeRequest(file.FileID.Value, productionOfficeID: 2484, serviceTypeCdID: 22)).Validate();

                Reports.TestStep = "Remove Title Production Office with the RemoveProductionOffice method.";
                FileService.RemoveProductionOffice(FileRequestFactory.GetRemoveProductionOfficeRequest(file.FileID.Value, productionOfficeID: 2484, serviceTypeCdID: 21)).Validate();

                Reports.TestStep = "Navigate to File Homepage";
                FastDriver.FileHomepage.Open();

                Reports.TestStep = "Validate Escrow Production Office is removed";
                Support.AreEqual(FastDriver.FileHomepage.EscrowProdOfficeTable.GetRowCount().ToString(), (escrowIndex - 1).ToString(), "EscrowProdOfficeTable row count");
                Support.IsTrue(!FastDriver.FileHomepage.EscrowProdOfficeTable.FAGetText().Contains("2484"), "EscrowProdOfficeTable contains 2484");

                Reports.TestStep = "Validate Title Production Office is removed";
                Support.AreEqual(FastDriver.FileHomepage.TitleProdOfficeTable.GetRowCount().ToString(), (titleIndex - 1).ToString(), "TitleProdOfficeTable row count");
                Support.IsTrue(!FastDriver.FileHomepage.TitleProdOfficeTable.FAGetText().Contains("2484"), "TitleProdOfficeTable contains 2484");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0006_AddOrAppendServiceFileNotes()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan();
                #endregion

                Reports.TestDescription = "Verify AddOrAppendServiceFileNotes() service.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a file.";
                var file = FileService.GetOrderDetails(FastDriver.FACreateFileGetFileId(fileRequest));
                FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

                Reports.TestStep = "Invoke the AddOrAppendServiceFileNotes method.";
                var fileNotesRequest = FileRequestFactory.GetFileNotesRequest(file.FileID.Value);
                Support.AreEqual(true, FileService.AddOrAppendServiceFileNotes(fileNotesRequest), "Response status");

                Reports.TestStep = "Navigate to File Notes";
                FastDriver.FileNotes.Open();
                Support.AreEqual(fileNotesRequest.Note, FastDriver.FileNotes.Table.PerformTableAction(2, 1, TableAction.GetText).Message, "Note");
                Support.AreEqual(fileNotesRequest.CreateEmployeeName, FastDriver.FileNotes.Table.PerformTableAction(2, 2, TableAction.GetText).Message, "Created By");
                string date = fileNotesRequest.CreationDate.Value.ToDateString(slash: true);
                Support.IsTrue(FastDriver.FileNotes.Table.PerformTableAction(2, 3, TableAction.GetText).Message.Contains(date), "Date contains " + date);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        /// <summary>
        /// REG0007-REG0008 : 540839: Agency -Enhance existing GetOrderDetails() method to include the Estate Type Descr
        /// </summary>
        [TestMethod]
        public void REG0007_ValidateEstateTypeDescrField()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.Properties[0].Name = "Property 1";
                fileRequest.File.Properties[0].PropertyTypeObjectCD = "SF";
                #endregion
                Reports.TestDescription = "Verify Estate type descr field.";
                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                //
                Reports.TestStep = "Create a file.";
                var file = FileService.GetOrderDetails(FastDriver.FACreateFileGetFileId(fileRequest));
                //
                Reports.TestStep = "Open file in FAST UI.";
                FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);
                //
                Reports.TestStep = "Navigate to property tax info";
                FastDriver.PropertiesSummary.Open();
                FastDriver.PropertiesSummary.PropertiesSummaryTable.PerformTableAction(2, 1, TableAction.Click);
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.LegalDescriptionTab.FAClick();
                FastDriver.PropertyTaxInfoLegalDesciption.WaitForScreenToLoad();
                //
                Reports.TestStep = "Update Estate type description";
                FastDriver.PropertyTaxInfoLegalDesciption.EstateType.FASelectItem("Leasehold");
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                //
                Reports.TestStep = "Get updated order details.";
                var fileUpdated = FileService.GetOrderDetails((int)file.FileID);
                //
                Reports.TestStep = "Validate Estate type description";
                Support.AreEqual(fileUpdated.RealProperties[0].EstateTypeDescr, "Leasehold");
                //
                Reports.TestStep = "Create second instance of property info";
                FastDriver.PropertiesSummary.Open();
                FastDriver.PropertiesSummary.New.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.LegalDescriptionTab.FAClick();
                FastDriver.PropertyTaxInfoLegalDesciption.WaitForScreenToLoad();
                //
                Reports.TestStep = "Add Estate type description";
                FastDriver.PropertyTaxInfoLegalDesciption.EstateType.FASelectItem("Easement");
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                //
                Reports.TestStep = "Get updated order details to validate second propert info.";
                var fileSecondPropertyInfo = FileService.GetOrderDetails((int)file.FileID);
                //
                Reports.TestStep = "Validate Estate type description";
                Support.AreEqual(fileSecondPropertyInfo.RealProperties[1].EstateTypeDescr, "Easement");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }
        //
        [TestMethod]
        public void REG0008_ValidateEstateTypeDescrFieldStarterRef()
        {
            try
            {
                Reports.TestDescription = "Validate that Estate type descr field is copied to reference file from starter file.";
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
               // fileRequest.File.Properties[0].EstateTypeDescr = "Fee Simple";
                #endregion
                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                //
                Reports.TestStep = "Create a starter file.";
                var StarterFile = FileService.GetOrderDetails(FastDriver.FACreateFileGetFileId(fileRequest));
                //
                Reports.TestStep = "Open file in FAST UI.";
                FastDriver.TopFrame.SearchFileByFileNumber(StarterFile.FileNumber);
                //
                Reports.TestStep = "Navigate to property tax info";
                FastDriver.PropertiesSummary.Open();
                FastDriver.PropertiesSummary.PropertiesSummaryTable.PerformTableAction(2, 1, TableAction.Click);
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad();
                FastDriver.PropertyTaxInfoGeneral.LegalDescriptionTab.FAClick();
                FastDriver.PropertyTaxInfoLegalDesciption.WaitForScreenToLoad();
                //
                Reports.TestStep = "Update Estate type description";
                FastDriver.PropertyTaxInfoLegalDesciption.EstateType.FASelectItem("Leasehold");
                FastDriver.BottomFrame.Save();
                FastDriver.BottomFrame.Done();
                //
                Reports.TestStep = "Create a ref file.";
                var RefFile = FileService.GetOrderDetails(FastDriver.FACreateFileGetFileId(fileRequest));
                Reports.TestStep = "Open file in FAST UI.";
                FastDriver.TopFrame.SearchFileByFileNumber(RefFile.FileNumber);
                //
                Reports.TestStep = "Navigate to Starter/ref";
                FastDriver.StarterReference.Open();
                FastDriver.StarterReference.StarterFileNumber.FASetText(StarterFile.FileNumber.ToString());
                if (!FastDriver.StarterReference.SelectFileItems.IsSelected())
                    FastDriver.StarterReference.SelectFileItems.FAClick();
                FastDriver.StarterReference.PropertyAddressLegalTaxInformation.FASetCheckbox(true);
                FastDriver.StarterReference.CopyNow.FAClick();
                FastDriver.WebDriver.HandleDialogMessage(true, true);
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 60);
                //
                //
                Reports.TestStep = "Get updated order details.";
                var fileUpdated = FileService.GetOrderDetails((int)RefFile.FileID);
                //
                Reports.TestStep = "Validate Estate type description";
                Support.AreEqual(fileUpdated.RealProperties[0].EstateTypeDescr, "Leasehold");
                //               
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0009_GetOrderDetails()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan();
                fileRequest.File.SalesPriceAmount = 1200m;
                fileRequest.File.Properties = new Property[]
                    {
                        new Property()
                        {
                            Name = "First Property",
                            Block = "Block1",
                            Book = "Book1",
                            Building = "Building1",
                            Fee = "Fee1",
                            PropertyAddress = new PhysicalAddress[]
                            {
                                new PhysicalAddress()
                                {
                                    AddrLine1 = "1 Property 1 Street",
                                    AddrLine2 = "2 Property 1 Street",
                                    AddrLine3 = "3 Property 1 Street",
                                    AddrLine4 = "4 Property 1 Street",
                                    State = "CA",
                                    City = "ALBANY",
                                    County = "ALAMEDA",
                                    Country = "USA",
                                    Zip = "12345"
                                }
                            }
                        }
                    };
                #endregion

                Reports.TestDescription = "Verify GetOrderDetails() service.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Invoke the CreateFile service.";
                int fileid = FastDriver.FACreateFileGetFileId(fileRequest);

                Reports.TestStep = "Invoke the GetOrderDetails service.";
                var orderDetails = FileService.GetOrderDetails(fileid);

                Reports.TestStep = "Open the file in FAST UI";
                FastDriver.TopFrame.SearchFileByFileNumber(orderDetails.FileNumber);

                Reports.TestStep = "Navigate to Property/Tax Info screen";
                FastDriver.PropertiesSummary.Open();

                Reports.TestStep = "Select the Property, and click Edit button";
                FastDriver.PropertiesSummary.PropertiesSummaryTable.PerformTableAction(2, 1, TableAction.Click);
                FastDriver.PropertiesSummary.Edit.FAClick();
                FastDriver.PropertyTaxInfoGeneral.WaitForScreenToLoad(FastDriver.PropertyTaxInfoGeneral.LegalDescriptionTab);
                FastDriver.PropertyTaxInfoGeneral.ClickLegalDescriptionTab().WaitForScreenToLoad();

                Reports.TestStep = "Input some description in Legal Desc and Complete Desc textboxes as indicated in [US690796]";
                FastDriver.PropertyTaxInfoLegalDesciption.AbbrLegalDesciptionComments.FASetText("First Line \nSecond Line \nThird Line \nFourth Line");
                FastDriver.PropertyTaxInfoLegalDesciption.CompleteLegalDescriptionComments.FASetText("First Line \nSecond Line \nThird Line \nFourth Line");
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Invoke the GetOrderDetails request, again.";
                var GetOrderDetailsRequest = FileService.GetOrderDetails(fileid);

                Reports.TestStep = "Navigate to File Homepage";
                FastDriver.FileHomepage.Open();

                Reports.TestStep = "Validate file data in File Homepage.";
                Support.AreEqual("Residential", FastDriver.FileHomepage.BusinessSegment.FAGetSelectedItem().Clean(), "BusinessSegment");
                Support.AreEqual("Sale w/Mortgage", FastDriver.FileHomepage.TransactionType.FAGetSelectedItem().Clean(), "TransactionType");
                Support.IsTrue(AutoConfig.UseCDFormType ? FastDriver.FileHomepage.FormTypeCD.IsSelected() : FastDriver.FileHomepage.FormTypeHUD.IsSelected(), AutoConfig.FormType + " Form Type");
                Support.AreEqual(fileRequest.File.SalesPriceAmount.ToString().FormatAsMoney(), FastDriver.FileHomepage.TermsDatesPrice.FAGetValue().Clean(), "TermsDatesPrice");

                Reports.TestStep = "Validate Business Source in File Homepage.";
                Support.AreEqual(GetOrderDetailsRequest.FileBusinessParties[0].IDCode, FastDriver.FileHomepage.BusinessPartyIDCodeField.FAGetText().Clean(), "BusinessPartyIDCodeField");
                Support.AreEqual(GetOrderDetailsRequest.FileBusinessParties[0].Name, FastDriver.FileHomepage.BusinessPartyNameField.FAGetText().Clean(), "BusSrceName");
                Support.AreEqual(GetOrderDetailsRequest.FileBusinessParties[0].EditElectronicAddress.Value, FastDriver.FileHomepage.BusinessPartyEditCont.IsSelected(), "BusinessPartyEditCont");
                Support.AreEqual(GetOrderDetailsRequest.FileBusinessParties[0].ElectronicAddress.BusinessPhone, FastDriver.FileHomepage.BusinessPartyBusPhone.FAGetValue().Clean(), "BusinessPartyBusPhone");
                Support.AreEqual(GetOrderDetailsRequest.FileBusinessParties[0].ElectronicAddress.Extension, FastDriver.FileHomepage.BusinessPartyBusPhoneExtension.FAGetValue().Clean(), "BusinessPartyBusPhoneExtension");
                Support.AreEqual(GetOrderDetailsRequest.FileBusinessParties[0].ElectronicAddress.BusinessFax, FastDriver.FileHomepage.BusinessPartyBusFax.FAGetValue().Clean(), "BusinessPartyBusFax");
                Support.AreEqual(GetOrderDetailsRequest.FileBusinessParties[0].ElectronicAddress.Cellular, FastDriver.FileHomepage.BusinessPartyCellPhone.FAGetValue().Clean(), "BusinessPartyCellPhone");
                Support.AreEqual(GetOrderDetailsRequest.FileBusinessParties[0].ElectronicAddress.Pager, FastDriver.FileHomepage.BusinessPartyPager.FAGetValue().Clean(), "BusinessPartyPager");
                Support.AreEqual(GetOrderDetailsRequest.FileBusinessParties[0].ElectronicAddress.EmailAddress, FastDriver.FileHomepage.BusinessPartyEmailAddress.FAGetValue().Clean(), "BusinessPartyEmailAddress");

                Reports.TestStep = "Validate Service Types in File Homepage.";
                Support.IsTrue(FastDriver.FileHomepage.Title.IsSelected(), "Title");
                Support.IsTrue(FastDriver.FileHomepage.Escrow.IsSelected(), "Escrow");
                Support.IsTrue(!FastDriver.FileHomepage.SubEscrow.IsSelected(), "SubEscrow");

                Reports.TestStep = "Validate Buyer and Seller in File Homepage.";
                Support.AreEqual(GetOrderDetailsRequest.Buyers[0].Type, FastDriver.FileHomepage.Buyer1Type.FAGetSelectedItem().Clean(), "Buyer1Type");
                Support.AreEqual(GetOrderDetailsRequest.Buyers[0].FirstName, FastDriver.FileHomepage.Buyer1FirstName.FAGetValue().Clean(), "Buyer1FirstName");
                Support.AreEqual(GetOrderDetailsRequest.Buyers[0].LastName, FastDriver.FileHomepage.Buyer1LastName.FAGetValue().Clean(), "Buyer1LastName");
                Support.AreEqual(GetOrderDetailsRequest.Sellers[0].Type, FastDriver.FileHomepage.Seller1Type.FAGetSelectedItem().Clean(), "Seller1Type");
                Support.AreEqual(GetOrderDetailsRequest.Sellers[0].FirstName, FastDriver.FileHomepage.Seller1FirstName.FAGetValue().Clean(), "Seller1FirstName");
                Support.AreEqual(GetOrderDetailsRequest.Sellers[0].LastName, FastDriver.FileHomepage.Seller1LastName.FAGetValue().Clean(), "Seller1LastName");

                Reports.TestStep = "Validate Property in File Homepage.";
                Support.AreEqual(GetOrderDetailsRequest.RealProperties[0].Block, FastDriver.FileHomepage.PropertyBlock.FAGetValue().Clean(), "PropertyBlock");
                Support.AreEqual(GetOrderDetailsRequest.RealProperties[0].Book, FastDriver.FileHomepage.PropertyBook.FAGetValue().Clean(), "PropertyBook");
                Support.AreEqual(GetOrderDetailsRequest.RealProperties[0].Building, FastDriver.FileHomepage.PropertyBuilding.FAGetValue().Clean(), "PropertyBuilding");
                Support.AreEqual(GetOrderDetailsRequest.RealProperties[0].Fee, FastDriver.FileHomepage.PropertyFee.FAGetValue().Clean(), "PropertyFee");
                Support.AreEqual(GetOrderDetailsRequest.RealProperties[0].Name, FastDriver.FileHomepage.PropertyName.FAGetValue().Clean(), "PropertyName");
                Support.AreEqual(GetOrderDetailsRequest.RealProperties[0].PropertyAddress[0].AddrLine1, FastDriver.FileHomepage.PropertyBookAddressLine1.FAGetValue().Clean(), "PropertyBookAddressLine1");
                Support.AreEqual(GetOrderDetailsRequest.RealProperties[0].PropertyAddress[0].AddrLine2, FastDriver.FileHomepage.PropertyBookAddressLine2.FAGetValue().Clean(), "PropertyBookAddressLine2");
                Support.AreEqual(GetOrderDetailsRequest.RealProperties[0].PropertyAddress[0].AddrLine3, FastDriver.FileHomepage.PropertyBookAddressLine3.FAGetValue().Clean(), "PropertyBookAddressLine3");
                Support.AreEqual(GetOrderDetailsRequest.RealProperties[0].PropertyAddress[0].AddrLine4, FastDriver.FileHomepage.PropertyBookAddressLine4.FAGetValue().Clean(), "PropertyBookAddressLine4");
                Support.AreEqual(GetOrderDetailsRequest.RealProperties[0].PropertyAddress[0].City, FastDriver.FileHomepage.PropertyAddressBookCity.FAGetValue().Clean(), "PropertyAddressBookCity");
                Support.AreEqual(GetOrderDetailsRequest.RealProperties[0].PropertyAddress[0].State, FastDriver.FileHomepage.PropertyState.FAGetSelectedItem().Clean(), "PropertyState");
                Support.AreEqual(GetOrderDetailsRequest.RealProperties[0].PropertyAddress[0].Zip, FastDriver.FileHomepage.PropertyZip.FAGetValue().Clean(), "PropertyZip");
                Support.AreEqual(GetOrderDetailsRequest.RealProperties[0].PropertyAddress[0].County, FastDriver.FileHomepage.PropertyCounty.FAGetValue().Clean(), "PropertyCounty");
                Support.AreEqual(GetOrderDetailsRequest.RealProperties[0].PropertyAddress[0].Country, FastDriver.FileHomepage.PropertyCountry.FAGetSelectedItem().Clean(), "PropertyCountry");

                Reports.TestStep = "Validate data on Property Tax Info Screen with response from Web Service as indicated in [US690796]";
                Support.IsTrue(GetOrderDetailsRequest.RealProperties[0].Legal.Split('\n').Length > 1, "Legal field has more than one element when separated by line breaks");
                Support.IsTrue(GetOrderDetailsRequest.RealProperties[0].ShortLegal.Split('\n').Length > 1, "Short Legal field has more than one element when separated by line breaks");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0010_StarterRefCopy()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = FileRequestFactory.GetDetailedCreateFileDefaultRequest();
                #endregion

                Reports.TestDescription = "Verify StarterRefCopy() service.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Invoke the CreateFile service.";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);

                Reports.TestStep = "Invoke the GetOrderDetails service.";
                var file1 = FileService.GetOrderDetails(fileId);

                Reports.TestStep = "Create another file invoking the CreateFile service";
                int fileId2 = FastDriver.FACreateFileGetFileId(fileRequest);
                var fileRequest2 = FileRequestFactory.GetCreateFileDefaultRequest();

                Reports.TestStep = "Invoke the GetOrderDetails service, again.";
                var file2 = FileService.GetOrderDetails(fileId2);

                Reports.TestStep = "Open the second file in FAST UI.";
                FastDriver.TopFrame.SearchFileByFileNumber(file2.FileNumber);

                Reports.TestStep = "Invoke the StarterRefCopy service.";
                var starterCopyRequest = FileRequestFactory.GetStarterRefCopyRequest(starterFile: file2.FileNumber, targetFile: file1.FileNumber);
                var starterCopyResponse = FileService.StarterRefCopy(starterCopyRequest);
                starterCopyResponse.Validate();

                Reports.TestStep = "Navigate to File HomePage";
                FastDriver.FileHomepage.Open();

                Reports.TestStep = "Validate file data in File Homepage.";
                Support.AreEqual(file2.FileNumber, FastDriver.FileHomepage.FileNum.FAGetValue(), "FileNumber");
                Support.AreEqual(fileRequest.File.BusinessSegmentObjectCD.ToUpperFirst(), FastDriver.FileHomepage.BusinessSegment.FAGetSelectedItem().Clean(), "BusinessSegment");
                Support.AreEqual("Sale w/Mortgage", FastDriver.FileHomepage.TransactionType.FAGetSelectedItem().Clean(), "TransactionType");
                Support.IsTrue(AutoConfig.UseCDFormType ? FastDriver.FileHomepage.FormTypeCD.IsSelected() : FastDriver.FileHomepage.FormTypeHUD.IsSelected(), AutoConfig.FormType + " Form Type");
                Support.AreEqual(fileRequest.File.SalesPriceAmount.ToString().FormatAsMoney(), FastDriver.FileHomepage.TermsDatesPrice.FAGetValue().Clean(), "TermsDatesPrice");

                Reports.TestStep = "Validate Service Types in File Homepage.";
                Support.IsTrue(FastDriver.FileHomepage.Title.IsSelected(), "Title");
                Support.IsTrue(FastDriver.FileHomepage.Escrow.IsSelected(), "Escrow");
                Support.IsTrue(!FastDriver.FileHomepage.SubEscrow.IsSelected(), "SubEscrow");

                Reports.TestStep = "Validate Buyer and Seller in File Homepage.";
                Support.AreEqual(fileRequest.File.Buyers[0].Type, FastDriver.FileHomepage.Buyer1Type.FAGetSelectedItem().Clean(), "Buyer1Type");
                Support.AreEqual(fileRequest.File.Buyers[0].FirstName, FastDriver.FileHomepage.Buyer1FirstName.FAGetValue().Clean(), "Buyer1FirstName");
                Support.AreEqual(fileRequest.File.Buyers[0].LastName, FastDriver.FileHomepage.Buyer1LastName.FAGetValue().Clean(), "Buyer1LastName");
                Support.AreEqual(fileRequest.File.Sellers[0].Type, FastDriver.FileHomepage.Seller1Type.FAGetSelectedItem().Clean(), "Seller1Type");
                Support.AreEqual(fileRequest.File.Sellers[0].FirstName, FastDriver.FileHomepage.Seller1FirstName.FAGetValue().Clean(), "Seller1FirstName");
                Support.AreEqual(fileRequest.File.Sellers[0].LastName, FastDriver.FileHomepage.Seller1LastName.FAGetValue().Clean(), "Seller1LastName");

                Reports.TestStep = "Validate Property in File Homepage.";
                Support.AreEqual(fileRequest.File.Properties[0].Name, FastDriver.FileHomepage.PropertyName.FAGetValue().Clean(), "PropertyName");
                Support.AreEqual(fileRequest.File.Properties[0].Lot, FastDriver.FileHomepage.PropertyLotName.FAGetValue().Clean(), "PropertyLot");
                Support.AreEqual(fileRequest.File.Properties[0].Block, FastDriver.FileHomepage.PropertyBlock.FAGetValue().Clean(), "PropertyBlock");
                Support.AreEqual(fileRequest.File.Properties[0].Unit, FastDriver.FileHomepage.PropertyUnit.FAGetValue().Clean(), "PropertyUnit");
                Support.AreEqual(fileRequest.File.Properties[0].PropertyAddress[0].AddrLine1, FastDriver.FileHomepage.PropertyBookAddressLine1.FAGetValue().Clean(), "PropertyBookAddressLine1");
                Support.AreEqual(fileRequest.File.Properties[0].PropertyAddress[0].AddrLine2, FastDriver.FileHomepage.PropertyBookAddressLine2.FAGetValue().Clean(), "PropertyBookAddressLine2");
                Support.AreEqual(fileRequest.File.Properties[0].PropertyAddress[0].AddrLine3, FastDriver.FileHomepage.PropertyBookAddressLine3.FAGetValue().Clean(), "PropertyBookAddressLine3");
                Support.AreEqual(fileRequest.File.Properties[0].PropertyAddress[0].City, FastDriver.FileHomepage.PropertyAddressBookCity.FAGetValue().Clean(), "PropertyAddressBookCity");
                Support.AreEqual(fileRequest.File.Properties[0].PropertyAddress[0].State, FastDriver.FileHomepage.PropertyState.FAGetSelectedItem().Clean(), "PropertyState");
                Support.AreEqual(fileRequest.File.Properties[0].PropertyAddress[0].Zip, FastDriver.FileHomepage.PropertyZip.FAGetValue().Clean(), "PropertyZip");
                Support.AreEqual(fileRequest.File.Properties[0].PropertyAddress[0].County, FastDriver.FileHomepage.PropertyCounty.FAGetValue().Clean(), "PropertyCounty");
                Support.AreEqual(fileRequest.File.Properties[0].PropertyAddress[0].Country, FastDriver.FileHomepage.PropertyCountry.FAGetSelectedItem().Clean(), "PropertyCountry");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0011_GetOrderSummary()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = FileRequestFactory.GetDetailedCreateFileDefaultRequest();
                #endregion

                Reports.TestDescription = "Verify GetOrderSummary() service";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a File using Web Service";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                var file = FileService.GetOrderDetails(fileId);

                Reports.TestStep = "Invoke GetOrderSummary service";
                var GetOrderSummaryRequest = FileRequestFactory.GetOrderSummaryRequest(fileId);
                var GetOrderSummaryResponse = FileService.GetOrderSummary(GetOrderSummaryRequest);
                
                Reports.TestStep = "Open the file in the UI";
                FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

                Reports.TestStep = "Navigate to File Summary";
                FastDriver.FileSummary.Open();

                Reports.TestStep = "Validate the data in File Summary with the response from Web Service";
                Support.AreEqual(GetOrderSummaryResponse.FileNumber, FastDriver.FileSummary.FileNumber.FAGetText(), "File Number");
                Support.AreEqual(GetOrderSummaryResponse.ExternalFileNumber, FastDriver.FileSummary.ExternalNumber.FAGetText(), "External File Number");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0012_GetGFEDetails()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                fileRequest.formType = FormType.HUD;
                fileRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan();

                #region BusinessParties
                fileRequest.File.BusinessParties = new FileBusinessParty[2]
                        {
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("BOA"),
                        RoleTypeObjectCD = "BUSSOURCE",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.None
                        }
                    },
                    new FileBusinessParty()
                    {
                        AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                        RoleTypeObjectCD = "DIRECTEDBY",
                        AdditionalRole = new AdditionalRoleList()
                        {
                            eAddtionalRole = AdditionalRoleType.None
                        }
                    }
                        };
                #endregion

                fileRequest.File.BusinessSegmentObjectCD = "NEWHM";

                #region Buyer
                fileRequest.File.Buyers[0] = new BuyerSeller
                {
                    BuyerSellerTypeID = 48,
                    EntityTypeID = 101,
                    FirstName = "James",
                    LastName = "Campbell",
                    MiddleName = "P",
                    PrincipalID = 113,
                    SeqNum = 1,
                    SpouseLastName = "Campbell",
                    Suffix = "MR",
                    Type = "INDIVIDUAL"
                };
                #endregion

                #region Product
                fileRequest.File.Products = new Product[1]
                        {
                    new Product
                    {
                        ObjectCD = "EAGLELENDR",
                        ProductID = 886
                    }
                        };
                #endregion

                #region Properties
                fileRequest.File.Properties = new Property[]
                {
                    new Property()
                    {
                        Name = "my-test-property",
                        Block = "1",
                        Book = "C",
                        Building = "B",
                        Fee = "12",
                        SeqNum = 1,
                        PropertyAddress = new PhysicalAddress[]
                        {
                            new PhysicalAddress()
                            {
                                AddrLine1 = "H.No.9",
                                AddrLine2 = "Street 4",
                                AddrLine3 = "6th Circle",
                                AddrLine4 = "Bay1",
                                Country = "USA",
                                State = "CA",
                                City = "Santa Ana",
                                County = "Orange",
                                Zip = "13425",
                                Enddated = false,
                                EnterpriseID = 0,
                                FastId = 0,
                                GeoRegionID = 0,
                                PhysicalAddrID = 0,
                                PhysicalAddrTypeCdID = 0
                            }
                        }
                    }
                };
                #endregion

                fileRequest.File.SalesPriceAmount = 6000.01m;

                #region Seller
                fileRequest.File.Sellers[0] = new BuyerSeller
                {
                    BuyerSellerTypeID = 49,
                    EntityType = "Miscellaneous",
                    EntityTypeID = 101,
                    FirstName = "Adam",
                    LastName = "Williams",
                    MiddleName = "C",
                    PrincipalID = 114,
                    SeqNum = 1,
                    ShortName = "ShortNS",
                    SpouseLastName = "Williams",
                    Suffix = "MR",
                    Type = "Husband And Wife",
                };
                #endregion
                #endregion

                Reports.TestDescription = "Verify GetGFEDetails() service";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a HUD File from Web Service.";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                var file = FileService.GetOrderDetails(fileId);

                Reports.TestStep = "Create Loan charges by Invoking Update NewLoan method from Web Service";
                var loanRequest = FileRequestFactory.GetNewLoanUpdateRequest(fileID: fileId.ToString(), seqNum: 1);

                #region Modifying New Loan charges
                loanRequest.LoanCharges.GFE6LoanCharges = new GFELoanCharges[]
                {
                    new GFELoanCharges
                    {
                            PaymentDetail = new PaymentDetailsWithGFEAndPOC
                            {
                                Description = "Extra Charge",
                                AdhocFlag = 1,
                                BuyerCharge = 10.02m,
                                BuyerPaymentMethodTypeID = 385,
                                SellerCharge = 22.01m,
                                SellerPaymentMethodTypeID = 385,
                                Borrowerflag = 1
                            },
                            GFEAmount = 120m
                    },
                    new GFELoanCharges
                    {
                            PaymentDetail = new PaymentDetailsWithGFEAndPOC
                            {
                                Description = "Extra Charge 2",
                                AdhocFlag = 1,
                                BuyerCharge = 10.02m,
                                BuyerPaymentMethodTypeID = 385,
                                SellerCharge = 22.01m,
                                SellerPaymentMethodTypeID = 385,
                                Borrowerflag = 1
                            },
                            GFEAmount = 150m
                    }
                };
                loanRequest.LoanCharges.GFE3LoanCharges = new GFELoanCharges[]
                {
                    new GFELoanCharges
                    {
                        PaymentDetail = new PaymentDetailsWithGFEAndPOC
                        {
                            Description = "Another Charge",
                            AdhocFlag = 1,
                            BuyerCharge = 10.02m,
                            BuyerPaymentMethodTypeID = 385,
                            SellerCharge = 22.01m,
                            SellerPaymentMethodTypeID = 385,
                            Borrowerflag = 1
                        },
                        GFEAmount = 520.00m
                    },
                    new GFELoanCharges
                    {
                        PaymentDetail = new PaymentDetailsWithGFEAndPOC
                        {
                            Description = "Another Charge 2",
                            AdhocFlag = 1,
                            BuyerCharge = 10.02m,
                            BuyerPaymentMethodTypeID = 385,
                            SellerCharge = 22.01m,
                            SellerPaymentMethodTypeID = 385,
                            Borrowerflag = 1
                        },
                        GFEAmount = 185.00m
                    }
                };
                #endregion

                var loanResponse = FileService.UpdateNewLoan(loanRequest);
                loanResponse.Validate();

                Reports.TestStep = "Invoke GetGFEDetails service.";
                var GetGFEDetailsRequest = FileService.GetGFEDetails(fileId);

                Reports.TestStep = "Open the file in the FAST UI.";
                FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

                Reports.TestStep = "Navigate to GFE Entry screen";
                FastDriver.GFEEntry.Open();

                Reports.TestStep = "Validate data on Loan Terms section with Web Service response";
                Support.AreEqual(GetGFEDetailsRequest.Sec_1_InititalLoanAmount.Value.ToString().FormatAsMoney(), FastDriver.GFEEntryLoanTerms.InitialLoanAmount.FAGetText(), "Initial Loan Amount");

                Reports.TestStep = "Validate data on GFE section with Web Service response";
                FastDriver.GFEEntryGFE.GFETabClick();
                FastDriver.GFEEntryGFE.WaitForScreenToLoad();

                Support.AreEqual(GetGFEDetailsRequest.GFE_1_Origination_Charge.Value.ToString().FormatAsMoney(), FastDriver.GFEEntryGFE.GFE1.FAGetValue(), "GFE #1 Origination Charge");
                Support.AreEqual(GetGFEDetailsRequest.GFE_3_Required_Lender_selected_services.TotalGFE3.ToString().FormatAsMoney(), FastDriver.GFEEntryGFE.GFE3total.FAGetText(), "GFE #3 Section/Table");
                Support.AreEqual(GetGFEDetailsRequest.GFE_3_Required_Lender_selected_services.GFE_3[0].ProcessTypeDescription, FastDriver.GFEEntryGFE.GFE3Table.PerformTableAction(1, 1, TableAction.GetText).Message.Clean(), "GFE #3 Section/Table");
                Support.AreEqual(GetGFEDetailsRequest.GFE_3_Required_Lender_selected_services.GFE_3[0].ChargeDescription, FastDriver.GFEEntryGFE.GFE3Table.PerformTableAction(1, 2, TableAction.GetText).Message.Clean(), "GFE #3 Section/Table");
                Support.AreEqual(GetGFEDetailsRequest.GFE_3_Required_Lender_selected_services.GFE_3[0].GFEAmount.ToString().FormatAsMoney(), FastDriver.GFEEntryGFE.GFE3Table.PerformTableAction(1, 3, TableAction.GetText).Message.Clean(), "GFE #3 Section/Table");
                Support.AreEqual(GetGFEDetailsRequest.GFE_3_Required_Lender_selected_services.GFE_3[1].ProcessTypeDescription, FastDriver.GFEEntryGFE.GFE3Table.PerformTableAction(1, 1, TableAction.GetText).Message.Clean(), "GFE #3 Section/Table");
                Support.AreEqual(GetGFEDetailsRequest.GFE_3_Required_Lender_selected_services.GFE_3[1].ChargeDescription, FastDriver.GFEEntryGFE.GFE3Table.PerformTableAction(2, 2, TableAction.GetText).Message.Clean(), "GFE #3 Section/Table");
                Support.AreEqual(GetGFEDetailsRequest.GFE_3_Required_Lender_selected_services.GFE_3[1].GFEAmount.ToString().FormatAsMoney(), FastDriver.GFEEntryGFE.GFE3Table.PerformTableAction(2, 3, TableAction.GetText).Message.Clean(), "GFE #3 Section/Table");

                Support.AreEqual(GetGFEDetailsRequest.GFE_6_Required_Lender_selected_services.TotalGFE6.ToString().FormatAsMoney(), FastDriver.GFEEntryGFE.GFE6total.FAGetText(), "GFE #6 Section/Table");
                Support.AreEqual(GetGFEDetailsRequest.GFE_6_Required_Lender_selected_services.GFE_6[0].ProcessTypeDescription, FastDriver.GFEEntryGFE.GFE6Table.PerformTableAction(1, 1, TableAction.GetText).Message.Clean(), "GFE #6 Section/Table");
                Support.AreEqual(GetGFEDetailsRequest.GFE_6_Required_Lender_selected_services.GFE_6[0].ChargeDescription, FastDriver.GFEEntryGFE.GFE6Table.PerformTableAction(1, 2, TableAction.GetText).Message.Clean(), "GFE #6 Section/Table");
                Support.AreEqual(GetGFEDetailsRequest.GFE_6_Required_Lender_selected_services.GFE_6[0].GFEAmount.ToString().FormatAsMoney(), FastDriver.GFEEntryGFE.GFE6Table.PerformTableAction(1, 3, TableAction.GetText).Message.Clean(), "GFE #6 Section/Table");
                Support.AreEqual(GetGFEDetailsRequest.GFE_6_Required_Lender_selected_services.GFE_6[1].ProcessTypeDescription, FastDriver.GFEEntryGFE.GFE6Table.PerformTableAction(1, 1, TableAction.GetText).Message.Clean(), "GFE #6 Section/Table");
                Support.AreEqual(GetGFEDetailsRequest.GFE_6_Required_Lender_selected_services.GFE_6[1].ChargeDescription, FastDriver.GFEEntryGFE.GFE6Table.PerformTableAction(2, 2, TableAction.GetText).Message.Clean(), "GFE #6 Section/Table");
                Support.AreEqual(GetGFEDetailsRequest.GFE_6_Required_Lender_selected_services.GFE_6[1].GFEAmount.ToString().FormatAsMoney(), FastDriver.GFEEntryGFE.GFE6Table.PerformTableAction(2, 3, TableAction.GetText).Message.Clean(), "GFE #6 Section/Table");

                Support.AreEqual(GetGFEDetailsRequest.GFE_9_Initial_deposit_for_escrow_account.ToString().FormatAsMoney(), FastDriver.GFEEntryGFE.GFE9.FAGetValue(), "GFE #9 Initial deposit for escrow account");

                Reports.TestStep = "Validate data on Tolerance Summary section with Web Service response";
                FastDriver.GFEToleranceSummary.ToleranceSummaryTabClick();

                Support.AreEqual(GetGFEDetailsRequest.ToleranceSummary.ChargesThatCannotIncrease[0].GFEAmount.ToString().FormatAsMoney(), FastDriver.GFEToleranceSummary.GFEHUDChargesTable.PerformTableAction(3, 4, TableAction.GetText).Message.Clean(), "Good Faith Estimate Amount");
                Support.AreEqual(GetGFEDetailsRequest.ToleranceSummary.ChargesThatCannotIncrease[0].HUD1Amount.ToString().FormatAsMoney(), FastDriver.GFEToleranceSummary.GFEHUDChargesTable.PerformTableAction(3, 5, TableAction.GetText).Message.Clean(), "HUD-1 Amount");
                Support.AreEqual(GetGFEDetailsRequest.ToleranceSummary.ChargesThatCannotIncrease[2].GFEAmount.ToString().FormatAsMoney(), FastDriver.GFEToleranceSummary.GFEHUDChargesTable.PerformTableAction(3, 4, TableAction.GetText).Message.Clean(), "Good Faith Estimate Amount");
                Support.AreEqual(GetGFEDetailsRequest.ToleranceSummary.ChargesThatCannotIncrease[2].HUD1Amount.ToString().FormatAsMoney(), FastDriver.GFEToleranceSummary.GFEHUDChargesTable.PerformTableAction(3, 5, TableAction.GetText).Message.Clean(), "HUD-1 Amount");

                Support.AreEqual(GetGFEDetailsRequest.ToleranceSummary.ChargesThatCannotIncreaseMoreThan10[1].GFEAmount.ToString().FormatAsMoney(), FastDriver.GFEToleranceSummary.ChargesNoIncreaseTable.PerformTableAction(3, 4, TableAction.GetText).Message.Clean(), "Credit report - Good Faith Estimate");
                Support.AreEqual(GetGFEDetailsRequest.ToleranceSummary.ChargesThatCannotIncreaseMoreThan10[1].HUD1Amount.ToString().FormatAsMoney(), FastDriver.GFEToleranceSummary.ChargesNoIncreaseTable.PerformTableAction(3, 5, TableAction.GetText).Message.Clean(), "Credit report - HUD-1");

                Support.AreEqual(GetGFEDetailsRequest.ToleranceSummary.TotalHud1.ToString().FormatAsMoney(), FastDriver.GFEToleranceSummary.TotalIncreaseTable.PerformTableAction(1, 4, TableAction.GetText).Message.Clean(), "Total - HUD-1");
                Support.AreEqual(GetGFEDetailsRequest.ToleranceSummary.GFEandHUD1ChargesIncreaseDifference.ToString().Split(' ')[0], FastDriver.GFEToleranceSummary.TotalIncreaseTable.PerformTableAction(2, 3, TableAction.GetText).Message.Clean(), "Total - Good Faith Estimate");

                Support.AreEqual(GetGFEDetailsRequest.ToleranceSummary.ChargesThatCanChange[0].Description, FastDriver.GFEToleranceSummary.ChargesCanChangeTable.PerformTableAction(2, 1, TableAction.GetText).Message.Clean(), "Description");
                Support.AreEqual(GetGFEDetailsRequest.ToleranceSummary.ChargesThatCanChange[0].GFEAmount.ToString().FormatAsMoney(), FastDriver.GFEToleranceSummary.ChargesCanChangeTable.PerformTableAction(2, 4, TableAction.GetText).Message.Clean(), "Good Faith Estimate Amount");
                Support.AreEqual(GetGFEDetailsRequest.ToleranceSummary.ChargesThatCanChange[0].HUD1Amount.ToString().FormatAsMoney(), FastDriver.GFEToleranceSummary.ChargesCanChangeTable.PerformTableAction(2, 5, TableAction.GetText).Message.Clean(), "HUD-1 Amount");

                Support.AreEqual(GetGFEDetailsRequest.ToleranceSummary.ChargesThatCanChange[3].Description, FastDriver.GFEToleranceSummary.ChargesCanChangeTable.PerformTableAction(5, 1, TableAction.GetText).Message.Clean(), "Description");
                Support.AreEqual(GetGFEDetailsRequest.ToleranceSummary.ChargesThatCanChange[3].GFEAmount.ToString().FormatAsMoney(), FastDriver.GFEToleranceSummary.ChargesCanChangeTable.PerformTableAction(5, 4, TableAction.GetText).Message.Clean(), "Good Faith Estimate Amount");
                Support.AreEqual(GetGFEDetailsRequest.ToleranceSummary.ChargesThatCanChange[3].HUD1Amount.ToString().FormatAsMoney(), FastDriver.GFEToleranceSummary.ChargesCanChangeTable.PerformTableAction(5, 5, TableAction.GetText).Message.Clean(), "HUD-1 Amount");
                Support.AreEqual(GetGFEDetailsRequest.ToleranceSummary.ChargesThatCanChange[4].Description, FastDriver.GFEToleranceSummary.ChargesCanChangeTable.PerformTableAction(6, 1, TableAction.GetText).Message.Clean(), "Description");
                Support.AreEqual(GetGFEDetailsRequest.ToleranceSummary.ChargesThatCanChange[4].GFEAmount.ToString().FormatAsMoney(), FastDriver.GFEToleranceSummary.ChargesCanChangeTable.PerformTableAction(6, 4, TableAction.GetText).Message.Clean(), "Good Faith Estimate Amount");
                Support.AreEqual(GetGFEDetailsRequest.ToleranceSummary.ChargesThatCanChange[4].HUD1Amount.ToString().FormatAsMoney(), FastDriver.GFEToleranceSummary.ChargesCanChangeTable.PerformTableAction(6, 5, TableAction.GetText).Message.Clean(), "HUD-1 Amount");
                Support.AreEqual(GetGFEDetailsRequest.ToleranceSummary.ChargesThatCanChange[5].Description, FastDriver.GFEToleranceSummary.ChargesCanChangeTable.PerformTableAction(7, 1, TableAction.GetText).Message.Clean(), "Description");
                Support.AreEqual(GetGFEDetailsRequest.ToleranceSummary.ChargesThatCanChange[5].GFEAmount.ToString().FormatAsMoney(), FastDriver.GFEToleranceSummary.ChargesCanChangeTable.PerformTableAction(7, 4, TableAction.GetText).Message.Clean(), "Good Faith Estimate Amount");
                Support.AreEqual(GetGFEDetailsRequest.ToleranceSummary.ChargesThatCanChange[5].HUD1Amount.ToString().FormatAsMoney(), FastDriver.GFEToleranceSummary.ChargesCanChangeTable.PerformTableAction(7, 5, TableAction.GetText).Message.Clean(), "HUD-1 Amount");
                Support.AreEqual(GetGFEDetailsRequest.ToleranceSummary.ChargesThatCanChange[6].Description, FastDriver.GFEToleranceSummary.ChargesCanChangeTable.PerformTableAction(8, 1, TableAction.GetText).Message.Clean(), "Description");
                Support.AreEqual(GetGFEDetailsRequest.ToleranceSummary.ChargesThatCanChange[6].GFEAmount.ToString().FormatAsMoney(), FastDriver.GFEToleranceSummary.ChargesCanChangeTable.PerformTableAction(8, 4, TableAction.GetText).Message.Clean(), "Good Faith Estimate Amount");
                Support.AreEqual(GetGFEDetailsRequest.ToleranceSummary.ChargesThatCanChange[6].HUD1Amount.ToString().FormatAsMoney(), FastDriver.GFEToleranceSummary.ChargesCanChangeTable.PerformTableAction(8, 5, TableAction.GetText).Message.Clean(), "HUD-1 Amount");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0013_UpdateGFEDetails()
        {
            try
            {
                Reports.TestDescription = "Verify UpdateGFEDetails service";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.formType = FASTWCFHelpers.FastFileService.FormType.HUD;
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a HUD file using web service";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                string fileNum = FileService.GetOrderDetails(fileId).FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(fileNum);

                Reports.TestStep = "Invoke UpdateGFEDetails method, validate response (WS) [US # 704107]";
                var request = FileRequestFactory.GetGFELoanRequest(fileId);
                request.GFE_3_Required_Lender_selected_services = new GFE_3_Required_Lender_selected_services()
                {
                    GFE_3 = new GFERequiredLender[]
                    {
                        new GFERequiredLender()
                        {
                            ChargeDescription = "Appraisal fee",
                            GFEAmount = "200",
                            GFEEntryTypeCdID = 1589,
                            ProcessTypeDescription = "New Loan 1 Lender"
                        }
                    }
                };

                //[US # 704107]
                request.GFE_10_Daily_interest_charges = (decimal)0.0;
                request.GFE_10_Daily_interest_charges_Flag = GFEChargeFlags.Zero;
                request.GFE_7_Government_recording_charges = (decimal)0.0;
                request.GFE_8_Transfer_taxes = (decimal)10000;
                var response = FileService.UpdateGFEDetails(request);
                response.Validate();

                // This part is not working, waiting for confirmation from QA: TFS# 911604
                //Reports.TestStep = "Navigate to New Loan screen, click Loan Charges tab";
                //FastDriver.NewLoan.Open();
                //FastDriver.NewLoan.ClickChargesTab();

                //Reports.TestStep = "Validate charge description and GFE #3 amount in the response";
                //Support.AreEqual("Appraisal fee updated", FastDriver.NewLoan.LoanCharges_NewLoanTable.PerformTableAction(2, 1, TableAction.GetInputValue).Message.Clean(), "Charge Description");
                //Support.AreEqual("200", FastDriver.NewLoan.LoanCharges_NewLoanTable.PerformTableAction(2, 7, TableAction.GetInputValue).Message.Clean(), "GFE Amount");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally { FastDriver.WebDriver.Quit(); }
        }

        [TestMethod]
        public void REG0014_GetHUD1StatementDetails()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                var fileRequest = FileRequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.formType = FormType.HUD;
                #endregion

                Reports.TestDescription = "Verify GetHUD1StatementDetails() service";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a HUD file using Web Service";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                var file = FileService.GetOrderDetails(fileId);

                Reports.TestStep = "Invoke GetHUD1StatementDetails service";
                var getHudResponse = FileService.GetHUD1StatementDetails(fileId);

                Reports.TestStep = "Open the file in FAST UI";
                FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

                Reports.TestStep = "Navigate to HUD-1 Statement";
                FastDriver.HUD1PrintOptions.Open();

                Reports.TestStep = "Validate the data on the screen with the response from Web Service";
                Support.AreEqual(getHudResponse.HUDHeader.FileNumber, FastDriver.WebDriver.FAFindElement(ByLocator.Id, "lblFileNum").FAGetText(), "File Number on Header section");
                Support.AreEqual(getHudResponse.HUDHeader.HUDLoanType, FastDriver.HUD1PrintOptions.LoanType.FAGetSelectedItem(), "Loan Type on Header section");
                Support.AreEqual(getHudResponse.HUDHeader.BorrowersName, FastDriver.HUD1PrintOptions.BorrowerName.FAGetValue(), "Borrower Name(s) on Header section");
                Support.AreEqual(getHudResponse.HUDHeader.SellerName, FastDriver.HUD1PrintOptions.SellerName.FAGetValue(), "Seller Name(s) on Header section");
                Support.AreEqual(getHudResponse.HUDHeader.AddressOfSellers.CurrentAddress, FastDriver.HUD1PrintOptions.AddressOfSeller.FAGetValue(), "Address of Seller(s) on Header section");
                Support.AreEqual(getHudResponse.HUDHeader.Lender.Clean(), FastDriver.HUD1PrintOptions.Lender.FAGetValue().Clean(), "Lender on Header section");
                Support.AreEqual(getHudResponse.HUDHeader.PropertyLocation, FastDriver.HUD1PrintOptions.PropLocation.FAGetValue(), "Property Location on Header section");
                //Support.AreEqual(getHudResponse.HUDHeader.SettlementAgent.Replace('-', ' '), FastDriver.HUD1PrintOptions.SettlementAgent.FAGetValue().Replace('-', ' '), "Settlement Agent on Header section");
                Support.AreEqual(getHudResponse.HUDHeader.SettlementAgentPhoneNo, FastDriver.HUD1PrintOptions.SettlementAgentsPhoneNo.FAGetValue(), "Settlement Agent's Phone on Header section");
                Support.AreEqual(getHudResponse.HUDHeader.PlaceOfSettlement, FastDriver.HUD1PrintOptions.PlaceofSettlement.FAGetValue(), "Place of Statement on Header section");

                Support.AreEqual(getHudResponse.NewLoanLenders[0].Name, FastDriver.HUD1PrintOptions.NewLoanLendersTable.PerformTableAction(2, 1, TableAction.GetText).Message.Clean(), "Lender Name on New Loan section");
                Support.AreEqual(getHudResponse.NewLoanLenders[0].Address, FastDriver.HUD1PrintOptions.NewLoanLendersTable.PerformTableAction(2, 2, TableAction.GetText).Message.Clean(), "Lender Address on New Loan section");
                Support.AreEqual(getHudResponse.NewLoanLenders[0].City, FastDriver.HUD1PrintOptions.NewLoanLendersTable.PerformTableAction(2, 3, TableAction.GetText).Message.Clean(), "Lender City on New Loan section");
                Support.AreEqual(getHudResponse.NewLoanLenders[0].State, FastDriver.HUD1PrintOptions.NewLoanLendersTable.PerformTableAction(2, 4, TableAction.GetText).Message.Clean(), "Lender State on New Loan section");
                Support.AreEqual(getHudResponse.NewLoanLenders[0].ZipCode.Clean(), FastDriver.HUD1PrintOptions.NewLoanLendersTable.PerformTableAction(2, 5, TableAction.GetText).Message.Clean(), "Lender Zip Code on New Loan section");

                Support.AreEqual(getHudResponse.PropertyLocations[0].Address.Clean(), FastDriver.HUD1PrintOptions.ProplocTable.PerformTableAction(2, 1, TableAction.GetText).Message.Clean(), "Property Line 1 on Property section");
                Support.AreEqual(getHudResponse.PropertyLocations[0].City, FastDriver.HUD1PrintOptions.ProplocTable.PerformTableAction(2, 2, TableAction.GetText).Message.Clean(), "Property City on Property section");
                Support.AreEqual(getHudResponse.PropertyLocations[0].State, FastDriver.HUD1PrintOptions.ProplocTable.PerformTableAction(2, 3, TableAction.GetText).Message.Clean(), "Property State on Property section");
                Support.AreEqual(getHudResponse.PropertyLocations[0].ZipCode, FastDriver.HUD1PrintOptions.ProplocTable.PerformTableAction(2, 4, TableAction.GetText).Message.Clean(), "Property Zip Cde on Property section");

                FastDriver.WebDriver.FAFindElement(ByLocator.Id, "Td3").FAClick();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 10);
                FastDriver.HUD1PrintOptions.WaitForScreenToLoad(FastDriver.HUD1PrintOptions.SettlementagentPhoneTable);
                Support.AreEqual(getHudResponse.SettlementAgentsPhoneNos[0].FileParty, FastDriver.HUD1PrintOptions.SettlementagentPhoneTable.PerformTableAction(2, 1, TableAction.GetText).Message.Clean(), "File Party on Settmnt Agent's Phone No. section");
                Support.AreEqual(getHudResponse.SettlementAgentsPhoneNos[0].Name, FastDriver.HUD1PrintOptions.SettlementagentPhoneTable.PerformTableAction(2, 2, TableAction.GetText).Message.Clean(), "File Party on Settmnt Agent's Phone No. section");
                Support.AreEqual(getHudResponse.SettlementAgentsPhoneNos[0].PhoneNo, FastDriver.HUD1PrintOptions.SettlementagentPhoneTable.PerformTableAction(2, 3, TableAction.GetText).Message.Clean(), "File Party on Settmnt Agent's Phone No. section");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message.Clean());
            }
        }

        [TestMethod]
        public void REG0015_UpdateHUD1StatementDetails()
        {
            try
            {
                Reports.TestDescription = "Verify UpdateHUD1StatementDetails service";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetDetailedCreateFileDefaultRequest();
                fileRequest.formType = FASTWCFHelpers.FastFileService.FormType.HUD;
                #endregion

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create a HUD file using web service";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                string fileNum = FileService.GetOrderDetails(fileId).FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(fileNum);

                Reports.TestStep = "Invoke UpdateHUD1StatementDetails method, validate response (WS)";
                var request = FileRequestFactory.GetHUDStatementRequest(fileId);
                request.HUDHeader = new HUDHeaderRequest()
                {
                    BorrowersName = "Borrowers Name",
                    Lender = "Bank of America",
                    PlaceOfSettlement = "Place Of Settlement",
                    PropertyLocation = "Property Location",
                    SellersName = "Sellers Name"
                };
                request.NewLoanLender = new NewLoanLender()
                {
                    Address = "123 Test Street",
                    City = "Santa Ana",
                    FileBusinessPartyID = AdminService.GetGABAddressBookEntryId("247", Convert.ToInt32(AutoConfig.SelectedRegionBUID)),
                    LoanTypeCdID = 977,
                    SeqNum = 1,
                    State = "CA",
                    ZipCode = "92707"
                };
                GeneralFileServiceOperationsHelpers.UpdateHUD1StatementDetails(request).Validate();

                Reports.TestStep = "Navigate to HUD-1 Print Options screen, validate results";
                FastDriver.HUD1PrintOptions.Open();
                Support.AreEqual("Borrowers Name", FastDriver.HUD1PrintOptions.BorrowerName.FAGetValue().Clean(), "Borrower Name");
                Support.AreEqual("Bank of America", FastDriver.HUD1PrintOptions.Lender.FAGetValue().Clean(), "Lender Name");
                Support.AreEqual("Place Of Settlement", FastDriver.HUD1PrintOptions.PlaceofSettlement.FAGetValue().Clean(), "Placeof Settlement");
                Support.AreEqual("Property Location", FastDriver.HUD1PrintOptions.PropLocation.FAGetValue().Clean(), "Property Location Header");
                Support.AreEqual("Sellers Name", FastDriver.HUD1PrintOptions.SellerName.FAGetValue().Clean(), "Seller Name");

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally { FastDriver.WebDriver.Quit(); }
        }

        [TestMethod]
        public void REG0016_ModifyGAB()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan();
                #endregion

                Reports.TestDescription = "Verify ModifyGAB() service.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Invoke the CreateFile method.";
                int fileid = FastDriver.FACreateFileGetFileId(fileRequest);

                Reports.TestStep = "Invoke the GetOrderDetails method.";
                var file = FileService.GetOrderDetails(fileid);

                Reports.TestStep = "Open file in FAST UI.";
                FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

                Reports.TestStep = "Navigate to New Loan";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.NewLoan>("Home>Order Entry>New Loan").WaitForScreenToLoad();

                Reports.TestStep = "Add a New Loan 1 Lender";
                FastDriver.NewLoan.FindGABCode("207315");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Validate file data in File Homepage.";
                FileService.ModifyGAB(FileRequestFactory.GetModifyGABRequest(fileid, 1486, "TESTWCFGAB Modified Name", 196525992, 1, "famos", 366, 1)).Validate();

                Reports.TestStep = "Navigate to Event/Tracking Log";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>("Home>Order Entry>Event/Tracking Log").WaitForScreenToLoad();
                FastDriver.EventTrackingLog.EventCategory.FASelectItem("File Process");
                Support.AreEqual(true, FastDriver.EventTrackingLog.EventTable.FAGetText().Contains("[GAB Update Request]"), "Validating event for GAB Creation Request");
                Support.AreEqual(true, FastDriver.EventTrackingLog.EventTable.FAGetText().Contains(file.FileNumber), "Validating event associated file number");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0017_CreateGAB()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan();
                #endregion

                Reports.TestDescription = "Verify CreateGAB() service.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Invoke the CreateFile method.";
                int fileid = FastDriver.FACreateFileGetFileId(fileRequest);

                Reports.TestStep = "Invoke the GetOrderDetails method.";
                var file = FileService.GetOrderDetails(fileid);

                Reports.TestStep = "Open file in FAST UI.";
                FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

                Reports.TestStep = "Validate file data in File Homepage.";
                FileService.CreateGAB(FileRequestFactory.GetCreateGABRequest(fileid, 1, "famos", 50, 86, "TESTWCFGAB", 118, "8214 NW", "Santa Ana", "CA", "USA", 1486, 365, 1)).Validate();

                Reports.TestStep = "Navigate to Event/Tracking Log";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>("Home>Order Entry>Event/Tracking Log").WaitForScreenToLoad();
                FastDriver.EventTrackingLog.EventCategory.FASelectItem("File Process");
                Support.AreEqual(true, FastDriver.EventTrackingLog.EventTable.FAGetText().Contains("[GAB Creation Request]"), "Validating event for GAB Creation Request");
                Support.AreEqual(true, FastDriver.EventTrackingLog.EventTable.FAGetText().Contains("TESTWCFGAB"), "Validating event associated Entity Name");
                Support.AreEqual(true, FastDriver.EventTrackingLog.EventTable.FAGetText().Contains(file.FileNumber), "Validating event associated file number");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0018_GetSearchTypeInfo()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan();
                #endregion

                Reports.TestDescription = "Verify GetSearchTypeInfo() service.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Invoke the CreateFile method.";
                int fileid = FastDriver.FACreateFileGetFileId(fileRequest);

                Reports.TestStep = "Invoke the GetOrderDetails method.";
                var file = FileService.GetOrderDetails(fileid);

                Reports.TestStep = "Open file in FAST UI.";
                FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

                Reports.TestStep = "Validate file data in Quick File Entry.";
                var searchTypeArray = FileService.GetSearchTypeInfo();

                Support.AreEqual(true, searchTypeArray.searchTypeInfo.Length > 0, "Validating response has content in array");

                Reports.TestStep = "Navigate to Quick File Entry";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>("Home>Order Entry>Quick File Entry").WaitForScreenToLoad();
                FastDriver.DuplicateFileSearch.SkipSearchButton.FAClick();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();

                Reports.TestStep = "Click on Search Type: ++View More... option.";
                FastDriver.QuickFileEntry.SearchType.FASelectItemByIndex(2);
                FastDriver.SearchTypeDialogDlg.WaitForScreenToLoad();

                Reports.TestStep = "Compare Search Types on the table with GetSearchTypeInfo web service response.";
                Support.AreEqual(FastDriver.SearchTypeDialogDlg.SearchTypeTable.GetRowCount().ToString(), (searchTypeArray.searchTypeInfo.Length - 1).ToString(), "Validating Search Type count");

                bool flag = false;
                for (int i = 0; i < FastDriver.SearchTypeDialogDlg.SearchTypeTable.GetRowCount(); i++)
                {
                    var searchType = FastDriver.SearchTypeDialogDlg.SearchTypeTable.PerformTableAction(i + 1, 2, TableAction.GetText).Message.Clean();
                    if (searchTypeArray.searchTypeInfo[i].Description.Contains("NOSRCHTYPE-No Search Type"))
                        flag = true;

                    if (flag)
                        Support.AreEqual(searchType, searchTypeArray.searchTypeInfo[i + 1].Description.Clean());
                    else Support.AreEqual(searchType, searchTypeArray.searchTypeInfo[i].Description.Clean());
                }
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0019_GetServiceFileNotes()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan();
                #endregion

                Reports.TestDescription = "Verify GetServiceFileNotes() service.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Invoke the CreateFile method.";
                int fileid = FastDriver.FACreateFileGetFileId(fileRequest);

                Reports.TestStep = "Invoke the GetOrderDetails method.";
                var file = FileService.GetOrderDetails(fileid);

                Reports.TestStep = "Open file in FAST UI.";
                FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

                Reports.TestStep = "Navigate to File Notes.";
                FastDriver.LeftNavigation.Navigate<FileNotes>("Home>Order Entry>File Notes").WaitForScreenToLoad();

                Reports.TestStep = "Create new File Note.";
                FastDriver.FileNotes.New.FAClick();
                //FastDriver.FileNotes.WaitForNoteEditScreenToLoad();
                Keyboard.SendKeys("Testing WCF GetServiceFileNotes");
                FastDriver.BottomFrame.Done();
                FastDriver.FileNotes.WaitForScreenToLoad();

                Reports.TestStep = "Validate file notes data.";
                var fileNotes = FileService.GetServiceFileNotes(fileid);

                Support.AreEqual(true, fileNotes.FileNotes.Length > 0, "Validating response has content in array");

                Support.AreEqual(true, fileNotes.FileNotes[0].Note.Clean().Contains("Testing WCF GetServiceFileNotes"), "Validating file note matches created file note.");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0020_GetFileByFileNum()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan();
                #endregion

                Reports.TestDescription = "Verify GetFileByFileNum() service.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Invoke the CreateFile method.";
                int fileid = FastDriver.FACreateFileGetFileId(fileRequest);

                Reports.TestStep = "Invoke the GetOrderDetails method.";
                var file = FileService.GetOrderDetails(fileid);

                Reports.TestStep = "Open file in FAST UI.";
                FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

                Reports.TestStep = "Request file by file number";
                var fileSearchResponse = FileService.GetFilesByFileNum(file.FileNumber, 1486, 1);

                Reports.TestStep = "Verify file search response matches file information";
                Support.AreEqual(file.FileNumber, fileSearchResponse.FileSearchResults[0].FileNum, "Validating file number");
                Support.AreEqual(fileid.ToString(), fileSearchResponse.FileSearchResults[0].FileID.ToString(), "Validating file ID");

                FastDriver.BuyerSellerSummary.Open();
                var buyersName = FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 2, TableAction.GetText).Message.Clean();
                Support.AreEqual(buyersName, fileSearchResponse.FileSearchResults[0].BuyerName, "Validating Buyer Name");

                FastDriver.BuyerSellerSummary.Open(false);
                var sellerName = FastDriver.BuyerSellerSummary.tblBuyerSellerSummaryTable.PerformTableAction(2, 2, TableAction.GetText).Message.Clean();
                Support.AreEqual(sellerName, fileSearchResponse.FileSearchResults[0].SellerName, "Validating Seller Name");

                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>("Home>Order Entry>Event/Tracking Log").WaitForScreenToLoad();
                Support.AreEqual(false, FastDriver.EventTrackingLog.EventTable.FAGetText().Contains("[Closed]"), "Validating Status File is Open");
                Support.AreEqual(true, FastDriver.EventTrackingLog.EventTable.FAGetText().Contains("[Opened]"), "Validating Status File is Open");

                FastDriver.LeftNavigation.Navigate<FileSummary>("Home>Order Entry>File Summary").WaitForScreenToLoad();
                Support.AreEqual(FastDriver.FileSummary.ExternalNumber.FAGetText().Clean(), fileSearchResponse.FileSearchResults[0].ExternalFileNum, "Validating External File Number");

                FastDriver.WebDriver.SwitchTo().DefaultContent();
                Support.AreEqual(true, FastDriver.StatusBarFrame.CurrentRegion.FAGetAttribute("title").Contains(fileSearchResponse.FileSearchResults[0].RegionName.Clean()), "Verifying current region name");
                Support.AreEqual(true, FastDriver.StatusBarFrame.CurrentRegion.FAGetAttribute("title").Contains(fileSearchResponse.FileSearchResults[0].OwningRegionID.ToString()), "Verifying current region ID");
                Support.AreEqual(true, FastDriver.StatusBarFrame.CurrentOffice.FAGetAttribute("title").Contains(fileSearchResponse.FileSearchResults[0].OwnerOfficerName.Clean()), "Verifying current office name");
                Support.AreEqual(true, FastDriver.StatusBarFrame.CurrentOffice.FAGetAttribute("title").Contains(fileSearchResponse.FileSearchResults[0].OwningOfficeID.ToString()), "Verifying current office ID");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0021_SearchFAB()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan();
                #endregion

                Reports.TestDescription = "Verify SearchFAB() service.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Invoke the CreateFile method.";
                int fileid = FastDriver.FACreateFileGetFileId(fileRequest);

                Reports.TestStep = "Invoke the GetOrderDetails method.";
                var file = FileService.GetOrderDetails(fileid);

                Reports.TestStep = "Open file in FAST UI.";
                FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

                Reports.TestStep = "Navigate to File Homepage.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();

                Reports.TestStep = "Change GAB.";
                FastDriver.FileHomepage.FindBusPartyGAB("207315");
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Validate file notes data.";
                var fileFABs = FileService.SearchFAB(fileid);

                Support.AreEqual(true, (fileFABs.FABResults.Length == 3), "Validating File Address Books amount");
                Support.AreEqual("BuyerName BuyerLastName", fileFABs.FABResults[0].Name1, "Validating Buyers Name from FAB");
                Support.AreEqual("SellerName SellerLastName", fileFABs.FABResults[1].Name1, "Validating Seller Name from FAB");
                Support.AreEqual("TESTWCFGAB", fileFABs.FABResults[2].Name1, "Validating GAB Name from FAB");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0022_GetFileBySearch()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan();
                #endregion

                Reports.TestDescription = "Verify GetFileBySearch() service.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Invoke the CreateFile method.";
                var dateFrom = DateTime.Now.ToPST().AddHours(-1);
                int fileid = FastDriver.FACreateFileGetFileId(fileRequest);
                var dateTo = DateTime.Now.ToPST().AddHours(1);

                Reports.TestStep = "Invoke the GetOrderDetails method.";
                var file = FileService.GetOrderDetails(fileid);

                Reports.TestStep = "Open file in FAST UI.";
                FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

                Reports.TestStep = "Validate file notes data.";
                FileSearchResult matches = null;
                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    var filesSearch = FileService.GetFilesBySearch(FileRequestFactory.GetFileSearchRequest(dateFrom, dateTo, regionID: 1486));
                    Reports.StatusUpdate("Invoked GetFilesBySearch", true);
                    matches = filesSearch.FileSearchResults.ToList().FirstOrDefault(p => p.FileNum == file.FileNumber);

                    return !(matches == null);
                }, timeout: 200, idleInterval: 5);

                Support.AreEqual(true, !(matches == null), "Validating file is contained in file search response list");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0023_SearchFiles()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan();
                #endregion

                Reports.TestDescription = "Verify SearchFiles() service.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Invoke the CreateFile method.";
                var dateFrom = DateTime.Now.ToPST().AddHours(-1);
                int fileid = FastDriver.FACreateFileGetFileId(fileRequest);
                var dateTo = DateTime.Now.ToPST().AddHours(1);

                Reports.TestStep = "Invoke the GetOrderDetails method.";
                var file = FileService.GetOrderDetails(fileid);

                Reports.TestStep = "Open file in FAST UI.";
                FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

                Reports.TestStep = "Validate file notes data.";
                FileInfo matches = null;
                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    var searchFiles = FileService.SearchFiles(FileRequestFactory.GetSearchFileRequest(dateFrom, dateTo, regionID: 1486));
                    searchFiles.Validate();
                    Reports.StatusUpdate("Invoked SearchFiles", true);
                    matches = searchFiles.FileInfos.ToList().FirstOrDefault(p => p.FileNumber == file.FileNumber);

                    return !(matches == null);
                }, timeout: 200, idleInterval: 5);

                Support.AreEqual(true, !(matches == null), "Validating file is contained in file search response list");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0024_ReserveFileNumber()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan();
                #endregion

                Reports.TestDescription = "Verify ReserveFileNumber() service.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Invoke the CreateFile method.";
                int fileid = FastDriver.FACreateFileGetFileId(fileRequest);

                Reports.TestStep = "Invoke the GetOrderDetails method.";
                var file = FileService.GetOrderDetails(fileid);

                Reports.TestStep = "Open file in FAST UI.";
                FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

                Reports.TestStep = "Invoke ReserFileNumber request";
                var reservedFileNumberResponse = FileService.ReserveFileNumber(FileRequestFactory.GetReserveFileNumberRequest(1, 1487, 1486));

                Reports.TestStep = "Validate reserved file number.";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>("Home>Order Entry>Reserve File Num").WaitForScreenToLoad();
                FastDriver.DuplicateFileSearch.SkipSearchButton.FAClick();
                FastDriver.ReserveFileNumber.WaitForScreenToLoad();
                FastDriver.ReserveFileNumber.EnterFileNumAndClickFind(reservedFileNumberResponse.ReservedFileNumber);

                Support.AreEqual(true, FastDriver.ReserveFileNumber.FindSummary.FAGetText().Contains(reservedFileNumberResponse.ReservedFileNumber), "Validating file number in search result table.");
                Support.AreEqual(true, FastDriver.ReserveFileNumber.FindSummary.FAGetText().Contains("Super User"), "Validating reserved user in search result table.");
                Support.AreEqual(true, FastDriver.ReserveFileNumber.FindSummary.FAGetText().Contains("QA Automation Office - DO NOT TOUCH"), "Validating Office in search result table.");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0025_GetSearchInstructionInfo()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan();
                #endregion

                Reports.TestDescription = "Verify GetSearchInstructionInfo() service.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Invoke the CreateFile method.";
                int fileid = FastDriver.FACreateFileGetFileId(fileRequest);

                Reports.TestStep = "Invoke the GetOrderDetails method.";
                var file = FileService.GetOrderDetails(fileid);

                Reports.TestStep = "Open file in FAST UI.";
                FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

                Reports.TestStep = "Invoke GetSearchInstructionInfo request";
                var searchInstructionResponse = FileService.GetSearchInstructionInfo(FileRequestFactory.GetSearchInstructionsRequest(1486));

                Reports.TestStep = "Validate search instructions in Quick File Entry.";
                FastDriver.LeftNavigation.Navigate<DuplicateFileSearch>("Home>Order Entry>Quick File Entry").WaitForScreenToLoad();
                FastDriver.DuplicateFileSearch.SkipSearchButton.FAClick();
                FastDriver.QuickFileEntry.WaitForScreenToLoad();
                FastDriver.QuickFileEntry.AddRemoveInstructions.FAClick();
                FastDriver.SelectInstructionDlg.WaitForScreenLoad();

                Support.AreEqual(FastDriver.SelectInstructionDlg.InstructionTable.GetRowCount().ToString(), searchInstructionResponse.searchInstructionInfo.Length.ToString(), "Validating response matches instruction table size.");

                var tableText = FastDriver.SelectInstructionDlg.InstructionTable.FAGetText();
                foreach (var item in searchInstructionResponse.searchInstructionInfo)
                    Support.AreEqual(true, tableText.Contains(item.SearchInstructionName), string.Format("Validating {0} is presented on Instructions Table.", item.SearchInstructionName));
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0026_LaunchFastSearch()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan();
                fileRequest.File.Properties = new FASTWCFHelpers.FastFileService.Property[]
                    {
                        new FASTWCFHelpers.FastFileService.Property()
                        {
                            PropertyAddress = new FASTWCFHelpers.FastFileService.PhysicalAddress[]
                            {
                                new FASTWCFHelpers.FastFileService.PhysicalAddress()
                                {
                                    State = "CA",
                                    County = "Orange",
                                    City = "Santa Ana",
                                    Country = "USA",
                                    AddrLine1 = "1 First American Way",
                                    Zip = "92707"
                                }
                            }
                        }
                    };
                #endregion

                Reports.TestDescription = "Verify LaunchFastSearch() service.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Invoke the CreateFile method.";
                int fileid = FastDriver.FACreateFileGetFileId(fileRequest);

                Reports.TestStep = "Invoke the GetOrderDetails method.";
                var file = FileService.GetOrderDetails(fileid);

                Reports.TestStep = "Open file in FAST UI.";
                FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

                Reports.TestStep = "Invoke ReserFileNumber request";
                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    var response = FileService.LaunchFastSearch(FileRequestFactory.GetFastSearchRequest(fileid));
                    return response.Status == 1;
                }, timeout: 600, idleInterval: 60);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0027_SubscribeNotification()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan();
                #endregion

                Reports.TestDescription = "Verify SubscribeNotification() service.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Invoke the CreateFile method.";
                int fileid = FastDriver.FACreateFileGetFileId(fileRequest);

                Reports.TestStep = "Invoke the GetOrderDetails method.";
                var file = FileService.GetOrderDetails(fileid);

                Reports.TestStep = "Open file in FAST UI.";
                FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

                Reports.TestStep = "Invoke SubscribeNotification request.";
                FileService.SubscribeNotification(FileRequestFactory.GetNotificationRequest(fileid)).Validate();

                Reports.TestStep = "Validate subscribe notification succeeded in Event/Tracking Log.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>("Home>Order Entry>Event/Tracking Log").WaitForScreenToLoad();
                FastDriver.EventTrackingLog.EventCategory.FASelectItem("File Process");
                Support.AreEqual(true, FastDriver.EventTrackingLog.EventTable.FAGetText().Contains("[External Event Status]"), "Validating event for subscribe notification");
                Support.AreEqual(true, FastDriver.EventTrackingLog.EventTable.FAGetText().Contains("Subscribe Notification Request Completed Successfully"), "Validating event for subscribe notification");


            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0028_UnSubscribeNotification()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan();
                #endregion

                Reports.TestDescription = "Verify UnSubscribeNotification() service.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Invoke the CreateFile method.";
                int fileid = FastDriver.FACreateFileGetFileId(fileRequest);

                Reports.TestStep = "Invoke the GetOrderDetails method.";
                var file = FileService.GetOrderDetails(fileid);

                Reports.TestStep = "Open file in FAST UI.";
                FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

                Reports.TestStep = "Invoke SubscribeNotification request.";
                FileService.SubscribeNotification(FileRequestFactory.GetNotificationRequest(fileid)).Validate();

                Reports.TestStep = "Validate subscribe notification succeeded in Event/Tracking Log.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>("Home>Order Entry>Event/Tracking Log").WaitForScreenToLoad();
                FastDriver.EventTrackingLog.EventCategory.FASelectItem("File Process");
                Support.AreEqual(true, FastDriver.EventTrackingLog.EventTable.FAGetText().Contains("[External Event Status]"), "Validating event for subscribe notification");
                Support.AreEqual(true, FastDriver.EventTrackingLog.EventTable.FAGetText().Contains("Subscribe Notification Request Completed Successfully"), "Validating event for subscribe notification");

                Reports.TestStep = "Invoke UnSubscribeNotification request.";
                FileService.UnSubscribeNotification(FileRequestFactory.GetNotificationRequest(fileid)).Validate();

                Reports.TestStep = "Validate unsubscribe notification succeeded in Event/Tracking Log.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>("Home>Order Entry>Event/Tracking Log").WaitForScreenToLoad();
                FastDriver.EventTrackingLog.EventCategory.FASelectItem("File Process");
                Support.AreEqual(true, FastDriver.EventTrackingLog.EventTable.FAGetText().Contains("[External Event Status]"), "Validating event for UnSubscribe Notification");
                Support.AreEqual(true, FastDriver.EventTrackingLog.EventTable.FAGetText().Contains("UnSubscribe Notification Request Completed Successfully"), "Validating event for UnSubscribe Notification");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0029_DeArchiveFileService()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan();
                #endregion

                Reports.TestDescription = "Verify DeArchiveFileService() service.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Invoke the CreateFile method.";
                int fileid = FastDriver.FACreateFileGetFileId(fileRequest);

                Reports.TestStep = "Invoke the GetOrderDetails method.";
                var file = FileService.GetOrderDetails(fileid);

                Reports.TestStep = "Open file in FAST UI.";
                FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

                Reports.TestStep = "Archive file.";
                FASqlHelpers.ArchiveFile(fileid);

                Reports.TestStep = "Invoke DeArchiveFileService request.";
                FileService.DeArchiveFileService(FileRequestFactory.GetDeArchiveFileRequestt(fileid)).Validate();

                Reports.TestStep = "Validate DeArchiveFileService succeeded in Event/Tracking Log.";
                FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>("Home>Order Entry>Event/Tracking Log").WaitForScreenToLoad();
                FastDriver.EventTrackingLog.EventCategory.FASelectItem("File Process");
                Support.AreEqual(true, FastDriver.EventTrackingLog.EventTable.FAGetText().Contains("[File De-Archive]"), "Validating event for DeArchiveFileService");
                Support.AreEqual(true, FastDriver.EventTrackingLog.EventTable.FAGetText().Contains("Documents De-Archived Successfully."), "Validating event for DeArchiveFileService");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0030_FASSNotaryServices()
        {
            try
            {
                Reports.TestDescription = "Verify FASSNotaryServices() service.";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest(189, 191);
                fileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("BOA", 189);
                fileRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan();
                fileRequest.File.NewLoan.FileBusinessParty = new FileBusinessParty();
                fileRequest.File.NewLoan.FileBusinessParty.AddrBookEntryID = AdminService.GetGABAddressBookEntryId("BOA", 189);
                #endregion

                Reports.TestStep = "Log into FAST application, navigate to QA Sandpointe Office";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("191");

                Reports.TestStep = "Invoke the CreateFile method.";
                int fileid = FastDriver.FACreateFileGetFileId(fileRequest);

                Reports.TestStep = "Invoke the GetOrderDetails method.";
                var file = FileService.GetOrderDetails(fileid);

                Reports.TestStep = "Open file in FAST UI.";
                FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

                Reports.TestStep = "Create a signing order using web service (WS)";
                var signatureSigningRequest = CreateOrderSigningRequest(fileid);
                signatureSigningRequest.LoanDetails[0].LenderAddressBookEntryID = AdminService.GetGABAddressBookEntryId("BOA", 189);
                ServiceFactory.GetFileService().SetSignatureSigning(signatureSigningRequest).Validate();

                Reports.TestStep = "Create a signing order using web service (WS)";
                var getSigningResponse = SignatureSigningHelpers.GetSignatureSigning(fileid);
                int signingID = (int)getSigningResponse.OrderSigningInfo[0].SigningDetails.SigningID;

                FastDriver.SignatureSigning.Open();
                FastDriver.SignatureSigning.SigningSummary.PerformTableAction(1, 4, TableAction.Click);
                FastDriver.SignatureSigning.PrimaryAddressLine1.FASetText("Prim Addr");
                FastDriver.SignatureSigning.PrimaryAddressLine2.FASetText("Prim Street");
                FastDriver.SignatureSigning.PrimaryAddressCity.FASetText("Prim City");
                FastDriver.SignatureSigning.PrimaryAddressState.FASelectItem("CA");
                FastDriver.SignatureSigning.PrimaryAddressZip.FASetText("11223");

                FastDriver.BottomFrame.Save();

                Reports.TestStep = "Submit the signing order using web service (WS)";
                SignatureSigningHelpers.SetOrderSigning(fileid, signingID).Validate();

                Reports.TestStep = "Navigate to Signature Signing screen, validate sigining Ordered status";
                string currentStatus = "";

                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    FastDriver.SignatureSigning.Open();
                    currentStatus = FastDriver.SignatureSigning.SigningSummary.PerformTableAction(1, 4, TableAction.GetText).Message.Clean();
                    return (currentStatus == "Ordered");
                }, timeout: 180, idleInterval: 10);

                if (currentStatus != "Ordered")
                    Reports.StatusUpdate("Signing is not in Ordered status! Make sure the environment is connected to FASSNotary interface.", false);

                Reports.TestStep = "Invoke FASSNotaryServices request.";
                FileService.FASSNotaryServices(FileRequestFactory.GetSigningDetailRequest(fileid, signingID, SigningFASSNotary.CancelSigning)).Validate();

                Reports.TestStep = "Validate FASSNotaryServices succeeded in Signature Signing.";
                FastDriver.LeftNavigation.Navigate<SignatureSigning>(@"Home>Order Entry>Escrow Closing>Signature Signing").WaitForScreenToLoad();
                FastDriver.WebDriver.WaitForActionToComplete(() =>
                {
                    FastDriver.SignatureSigning.Open();
                    currentStatus = FastDriver.SignatureSigning.SigningSummary.PerformTableAction(1, 4, TableAction.GetText).Message.Clean();
                    return (currentStatus == "Pending Cancellation");
                }, timeout: 60, idleInterval: 10);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            }

        [TestMethod]
        public void REG0031_GetHud()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan();
                fileRequest.formType = FormType.HUD;
                #endregion

                Reports.TestDescription = "Verify GetHud() service.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Invoke the CreateFile method.";
                int fileid = FastDriver.FACreateFileGetFileId(fileRequest);

                Reports.TestStep = "Invoke the GetOrderDetails method.";
                var file = FileService.GetOrderDetails(fileid);

                Reports.TestStep = "Open file in FAST UI.";
                FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

                Reports.TestStep = "Invoke GetHud request.";
                var response = FileService.GetHud(FileRequestFactory.GetHudRequest(fileid, FASTWCFHelpers.FastFileService.DocumentFormat.PDF));
                response.Validate();

                //Reports.TestStep = "Validate GetHud succeeded in Event/Tracking Log.";
                //FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>("Home>Order Entry>Event/Tracking Log").WaitForScreenToLoad();
                //FastDriver.EventTrackingLog.EventCategory.FASelectItem("File Process");
                //Support.AreEqual(true, FastDriver.EventTrackingLog.EventTable.FAGetText().Contains("[File De-Archive]"), "Validating event for GetHud");
                //Support.AreEqual(true, FastDriver.EventTrackingLog.EventTable.FAGetText().Contains("Documents De-Archived Successfully."), "Validating event for GetHud");
        }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0032_UpdateInterfaceOrder()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan();
                #endregion

                Reports.TestDescription = "Verify UpdateInterfaceOrder() service.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Invoke the CreateFile method.";
                int fileid = FastDriver.FACreateFileGetFileId(fileRequest);

                Reports.TestStep = "Invoke the GetOrderDetails method.";
                var file = FileService.GetOrderDetails(fileid);


                Reports.TestStep = "Open file in FAST UI.";
                FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

                Reports.TestStep = "Invoke UpdateInterfaceOrder request.";
                FileService.UpdateInterfaceOrder(FileRequestFactory.GetInterfaceOrderRequest(fileid, 2227)).Validate();

                //Reports.TestStep = "Validate UpdateInterfaceOrder succeeded in Event/Tracking Log.";
                //FastDriver.LeftNavigation.Navigate<FASTSelenium.PageObjects.IIS.EventTrackingLog>("Home>Order Entry>Event/Tracking Log").WaitForScreenToLoad();
                //FastDriver.EventTrackingLog.EventCategory.FASelectItem("File Process");
                //Support.AreEqual(true, FastDriver.EventTrackingLog.EventTable.FAGetText().Contains("[File De-Archive]"), "Validating event for UpdateInterfaceOrder");
                //Support.AreEqual(true, FastDriver.EventTrackingLog.EventTable.FAGetText().Contains("Documents De-Archived Successfully."), "Validating event for UpdateInterfaceOrder");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0033_SetProjectFileID()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan();
                #endregion

                Reports.TestDescription = "Verify SetProjectFileID() service.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Invoke the CreateFile method for project file.";
                int projectFileID = FastDriver.FACreateFileGetFileId(fileRequest);

                Reports.TestStep = "Invoke the CreateFile method.";
                int siteFileID = FastDriver.FACreateFileGetFileId(fileRequest);

                Reports.TestStep = "Invoke the GetOrderDetails method.";
                var projectFile = FileService.GetOrderDetails(projectFileID);

                Reports.TestStep = "Open file in FAST UI.";
                FastDriver.TopFrame.SearchFileByFileNumber(projectFile.FileNumber);

                Reports.TestStep = "Navigate to File Homepage.";
                FastDriver.LeftNavigation.Navigate<FileHomepage>("Home>Order Entry>File Homepage").WaitForScreenToLoad();

                Reports.TestStep = "Set file as project file.";
                FastDriver.FileHomepage.BusinessSegment.FASelectItem("Commercial");
                FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);

                Reports.TestStep = "Click on Done.";
                FastDriver.BottomFrame.Done();
                FastDriver.WebDriver.WaitForWindowAndSwitch("One moment please...", false, 15);

                Reports.TestStep = "Invoke SetProjectFileID request.";
                FileService.SetProjectFileID(FileRequestFactory.GetSetProjectFileRequest(projectFileID, siteFileID)).OperationResponse.Validate();

                Reports.TestStep = "Validate file is associated in Project Workbench.";
                FastDriver.LeftNavigation.Navigate<ProjectWorkBench>("Home>Order Entry>Project Workbench").WaitForScreenToLoad();
                Support.AreEqual("1", FastDriver.ProjectWorkBench.TotalSiteFilesValue.FAGetText().Clean(), "Validating project file has a site file associated");

                Reports.TestStep = "Invoke SetProjectFileID request.";
                FileService.SetProjectFileID(FileRequestFactory.GetSetProjectFileRequest(0, siteFileID)).OperationResponse.Validate();

                Reports.TestStep = "Validate file is disassociated in Project Workbench.";
                FastDriver.LeftNavigation.Navigate<ProjectWorkBench>("Home>Order Entry>Project Workbench").WaitForScreenToLoad();
                Support.AreEqual("0", FastDriver.ProjectWorkBench.TotalSiteFilesValue.FAGetText().Clean(), "Validating project file has a site file disassociated");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG_GetWorkGroups()
        {
            try
            {
                Reports.TestDescription = "Verify GetWorkGroups operation.";

                Reports.TestStep = "Invoke GetWorkGroups operation.";
                int regionId = 1486;
                var response = ServiceFactory.GetFileService().GetWorkGroups(regionId);
                Reports.StatusUpdate("GetWorkGroups operation invoked !", true);

                Reports.TestStep = "Verify the operation response.";
                Reports.StatusUpdate("Status = " + response.Status, Convert.ToInt16(response.Status).Equals(1));
                Reports.StatusUpdate("Status Description = " + response.StatusDescription, response.StatusDescription.ToLower().ToString().Contains("work group details returned sucessfully"));
                Reports.StatusUpdate("UI validation may need to be added ! No UI validation provided in the base Coded UI version of the scripts !", true);

            }
            catch (Exception ex)
            {
            }
        }

        [TestMethod]
        [Description("Verify the error message in Createfile() Response xml.")]
        public void REG_CreateFile()
        {
            string hiddenOfficeBUID = "";
            string Statusdesc = "";
            #region Call gethidden office method.
            hiddenOfficeBUID = GetHiddenOfficeBUID();
            #endregion

            #region Create a file through WCF with Hidden office
            if (hiddenOfficeBUID != "")
            {
                Reports.TestStep = "Create a Title only file with required values through WCF.";
                var fileRequest = CreateFileRequest(Convert.ToInt32(hiddenOfficeBUID), "TO");

                var fileResponse = FASTWCFHelpers.FileService.CreateFile(fileRequest);
                Support.IsTrue(fileResponse.OperationResponse.StatusDescription.Length > 0, (fileResponse.OperationResponse.StatusDescription.Contains("hidden") ? "true" : "false"));
                if (fileResponse.OperationResponse.StatusDescription.Length > 0)
                {
                    Statusdesc = fileResponse.OperationResponse.StatusDescription;
                    Support.AreEqual(Statusdesc, "Title Owning Office is marked as hidden.");
                }

                Statusdesc = "";
                Reports.TestStep = "Create a Escrow only file with required values through WCF.";
                var fileRequest1 = CreateFileRequest(Convert.ToInt32(hiddenOfficeBUID), "EO");

                var fileResponse1 = FASTWCFHelpers.FileService.CreateFile(fileRequest1);
                Support.IsTrue(fileResponse1.OperationResponse.StatusDescription.Length > 0, (fileResponse1.OperationResponse.StatusDescription.Contains("hidden") ? "true" : "false"));
                if (fileResponse1.OperationResponse.StatusDescription.Length > 0)
                {
                    Statusdesc = fileResponse1.OperationResponse.StatusDescription;
                    Support.AreEqual(Statusdesc, "Escrow Owning Office is marked as hidden.");
                }

            }
            #endregion
        }

        [TestMethod]
        [Description("Verify the error message for Hidden Office while creating the site file.")]
        public void REG_Validate_HiddenOffice_For_SiteFile()
        {
            string hiddenOfficeBUID = "";
            string Statusdesc = "";
            int projectFileID = 0;

            Reports.TestDescription = "System shall not create a site file with Hidden Title and Escrow Owning office using CreateFile() method";

            var fileReq = CreateFileRequest();

            var fileRes = FASTWCFHelpers.FileService.CreateFile(fileReq);

            projectFileID = fileRes.FileID.Value;

            var File = FASTWCFHelpers.FileService.GetOrderDetails(projectFileID);

            #region Log into IIS of testing enviroment

            Reports.TestStep = "Log into IIS of testing enviroment";

            var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

            FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

            #endregion

            #region Turn file into a Project File

            //search the File
            FastDriver.TopFrame.SearchFileByFileNumber(File.FileNumber);

            Reports.TestStep = "Turn file into a Project File";
            FastDriver.LeftNavigation.Navigate<FileHomepage>(@"Home>Order Entry>File Homepage").WaitForScreenToLoad();
            FastDriver.FileHomepage.WaitForScreenToLoad();
            FastDriver.FileHomepage.ProjectFile.FASetCheckbox(true);
            Playback.Wait(5000);
            FastDriver.BottomFrame.Done();
            FastDriver.FileHomepage.WaitForScreenToLoad();
            Support.AreEqual("true", FastDriver.FileHomepage.ProjectFile.FAGetAttribute("selected").ToString().ToLower(), "Verify Project File checkbox is selected");

            #endregion


            #region Call get hidden office method.

            hiddenOfficeBUID = GetHiddenOfficeBUID();

            #endregion

            #region Create a file through WCF with Hidden office
            if (hiddenOfficeBUID != "")
            {
                Reports.TestStep = "Create a Title only file with required values through WCF.";

                //Create Site File Request
                var fileRequest = CreateFileRequest(Convert.ToInt32(hiddenOfficeBUID), "TO", projectFileID);

                var fileResponse = FASTWCFHelpers.FileService.CreateFile(fileRequest);
                Support.IsTrue(fileResponse.OperationResponse.StatusDescription.Length > 0, (fileResponse.OperationResponse.StatusDescription.Contains("hidden") ? "true" : "false"));
                if (fileResponse.OperationResponse.StatusDescription.Length > 0)
                {
                    Statusdesc = fileResponse.OperationResponse.StatusDescription;
                    Support.AreEqual(Statusdesc, "Title Owning Office is marked as hidden.");
                }

                Statusdesc = "";
                Reports.TestStep = "Create a Escrow only file with required values through WCF.";

                //Create Site File Request
                var fileRequest1 = CreateFileRequest(Convert.ToInt32(hiddenOfficeBUID), "EO", projectFileID);

                var fileResponse1 = FASTWCFHelpers.FileService.CreateFile(fileRequest1);
                Support.IsTrue(fileResponse1.OperationResponse.StatusDescription.Length > 0, (fileResponse1.OperationResponse.StatusDescription.Contains("hidden") ? "true" : "false"));
                if (fileResponse1.OperationResponse.StatusDescription.Length > 0)
                {
                    Statusdesc = fileResponse1.OperationResponse.StatusDescription;
                    Support.AreEqual(Statusdesc, "Escrow Owning Office is marked as hidden.");
                }

            }
            #endregion
        }

        [TestMethod]
        [Description("Verify Title Owning office BUID is Hidden or Active in UpdateChangeOwningOfficeAndServiceType")]
        public void REG_UpdateChangeOwningOfficeAndServiceType_1()
        {
            #region Variables
            string hiddenOfficeBUID = "";
            string Statusdesc = "";
            UpdateFileRequest request = null;
            #endregion

            #region Call gethidden office method.
            hiddenOfficeBUID = GetHiddenOfficeBUID();
            #endregion

            #region FAST Login IIS side
            Reports.TestStep = "Login to IIS and create Title and Escrow File";
            FASTSelenium.Common.FASTHelpers.FAST_Login_IIS();
            #endregion

            FASTSelenium.Common.FASTHelpers.FAST_WCF_File_IIS(GAB: "508", GABRole: AdditionalRoleType.None, isTO: true, isEO: true, SPAmt: (decimal)1000000, loanAmt: (decimal)1000);

            if (hiddenOfficeBUID != "")
            {
                Reports.TestStep = "Try to update Title service in file with Hidden BUID";
                request = ConstructUpdateFileRequest("TO", Convert.ToInt32(hiddenOfficeBUID));
                var response = FASTWCFHelpers.FileService.UpdateChangeOwningOfficeAndServiceType(request);
                Support.IsTrue(response.OperationResponse.StatusDescription.Length > 0, (response.OperationResponse.StatusDescription.Contains("hidden") ? "true" : "false"));
                if (response.OperationResponse.StatusDescription.Length > 0)
                {
                    Statusdesc = response.OperationResponse.StatusDescription;
                    Support.AreEqual(Statusdesc, "Title Owning Office is marked as hidden.");
                }

            }

        }

        [TestMethod]
        [Description("Verify Escrow Owning office BUID is Hidden or Active in UpdateChangeOwningOfficeAndServiceType")]
        public void REG_UpdateChangeOwningOfficeAndServiceType_EO()
        {
            #region Variables
            string hiddenOfficeBUID = "";
            string Statusdesc = "";
            UpdateFileRequest request = null;
            #endregion

            #region Call gethidden office method.
            hiddenOfficeBUID = GetHiddenOfficeBUID();
            #endregion

            #region FAST Login IIS side
            Reports.TestStep = "Login to IIS and Create Title File";
            FASTSelenium.Common.FASTHelpers.FAST_Login_IIS();
            #endregion

            FASTSelenium.Common.FASTHelpers.FAST_WCF_File_IIS(GAB: "508", GABRole: AdditionalRoleType.None, isTO: true, isEO: true, SPAmt: (decimal)1000000, loanAmt: (decimal)1000);
            //int fileID = CreateFile_TO();
            if (hiddenOfficeBUID != "")
            {
                Reports.TestStep = "Try to add Escrow service in file with Hidden BUID";
                request = ConstructUpdateFileRequest("EO", Convert.ToInt32(hiddenOfficeBUID));
                var response = FASTWCFHelpers.FileService.UpdateChangeOwningOfficeAndServiceType(request);
                Support.IsTrue(response.OperationResponse.StatusDescription.Length > 0, (response.OperationResponse.StatusDescription.Contains("hidden") ? "true" : "false"));
                if (response.OperationResponse.StatusDescription.Length > 0)
                {
                    Statusdesc = response.OperationResponse.StatusDescription;
                    Support.AreEqual(Statusdesc, "Escrow Owning Office is marked as hidden.");
                }

            }

        }

        #region Helper Methods
        private SetOrderSigningRequest CreateOrderSigningRequest(int fileId)
        {
            return new SetOrderSigningRequest()
            {
                BuyerDetails = new BuyerDetail[]
                {
                    new BuyerDetail()
                    {
                        FirstName = "BuyerFirst",
                        LangPrefTypeCdID = 2545,
                        LastName = "BuyerLast",
                        NameEditable = true,
                        PhoneDetails = new PhoneDetail[]
                        {
                            new PhoneDetail()
                            {
                                ElectronicAddrCdID = 1398,
                                Ext = "11",
                                Number = "1231231234",
                            }
                        }
                    }
                },

                DeliverAddress = new SigningAddress()
                {
                    PhysicalAddrTypeCdID = 1375,
                    PhysicalAddress = new PhysicalAddress()
                    {
                        AddrLine1 = "DelAddress",
                        AddrLine2 = "Del Street",
                        City = "Del City",
                        Country = "Del Country",
                        Enddated = false,
                        State = "CA",
                        Zip = "12312"
                    }
                },

                LoanDetails = new LoanDetail[]
                {
                    new LoanDetail()
                    {
                        AddButtonEditable = true,
                        LenderAddressBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                        LoanAmount = "100.02",
                        LoanNum = "1212333",
                        SearchButtonEditable = true
                    }
                },

                PrimaryAddress = new SigningAddress()
                {
                    PhysicalAddrTypeCdID = 1376,
                    PhysicalAddress = new PhysicalAddress()
                    {
                        AddrLine1 = "Pri Addr",
                        AddrLine2 = "Pri street",
                        City = "Pri City",
                        Enddated = false,
                        State = "CA",
                        Zip = "12312"
                    },
                },
                SigningAddress = new SigningAddress()
                {
                    PhysicalAddress = new PhysicalAddress()
                    {
                        AddrLine1 = "Sig addr",
                        AddrLine2 = "Sig Street",
                        City = "Sig City",
                        Enddated = false,
                        State = "CA",
                        Zip = "11223",
                    }
                },

                SigningDetails = new SigningDetail()
                {
                    FileID = (int?)fileId,
                    OrderSource = "FAST",
                    SigningLocTypeCdID = 2543,
                    SigningMethodTypeCdID = 2534,
                    SpecialInstructions = "Validate set",
                    ProposedDate = DateTime.Today.AddDays(2).ToDateString(),
                    ProposedTime = "07:56:03 AM"
                },
            };
        }

        private string GetHiddenOfficeBUID()
        {
            string OfficeBuid = "0";

            try
            {

                Reports.TestDescription = "User Story 856583:REQ0909373 - NCS - WCF - Hide Select Office Names in FAST Office Selection-CreateFile";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserNameSU, Password = AutoConfig.UserPasswordSU };
                #endregion

                #region UI Iteration

                Reports.TestStep = "Login to FAST ADM";
                FASTLogin.Login(AutoConfig.FASTAdmURL, credentials, true);

                Reports.TestStep = "Navigate to Region Level.";
                FastDriver.LeftNavigation.Navigate<SecuritySelectRegionOffice>(@"Home>Others>Select Office").WaitForScreenToLoad();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("1486");

                Reports.TestStep = "Check if automation office exists";
                FastDriver.LeftNavigation.Navigate<OfficeSummary>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices").WaitForScreenToLoad();
                Playback.Wait(3000);
                FastDriver.OfficeSummary.Status.FASelectItem("Active & Hidden");
                FastDriver.OfficeSummary.WaitForScreenToLoad();
                if (FastDriver.OfficeSummary.OfficeSummaryTable.FAGetText().Contains("SRT Test Automation Office"))
                {
                    Reports.TestStep = "Select an office and edit it.";
                    FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "Name", TableAction.Click);
                    OfficeBuid = FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "BUID", TableAction.GetText).Message.ToString();
                    FastDriver.OfficeSummary.Edit.FAClick();
                    FastDriver.OfficeSetupOffice.WaitForScreenToLoad();

                    Reports.TestStep = "Set the Hidden flag status as true for office if it's not set";
                    if (!FastDriver.OfficeSetupOffice.Hidden.Selected)
                    {
                        FastDriver.OfficeSetupOffice.Hidden.FASetCheckbox(true);

                    }
                    FastDriver.BottomFrame.Done();
                    Playback.Wait(4000);
                }
                else
                {
                    Reports.TestStep = "Create a new office.";
                    this.CreateNewOffice();
                    FastDriver.LeftNavigation.Navigate<OfficeSummary>(@"Home>System Maintenance>Business Unit>Corporations>FIRSTAM>Proc. Regions>STEST>Offices").WaitForScreenToLoad();
                    FastDriver.OfficeSummary.Status.FASelectItem("Active & Hidden");
                    FastDriver.OfficeSummary.WaitForScreenToLoad();
                    FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "Name", TableAction.Click);
                    OfficeBuid = FastDriver.OfficeSummary.OfficeSummaryTable.PerformTableAction("Name", "SRT Test Automation Office", "BUID", TableAction.GetText).Message.ToString();
                    FastDriver.OfficeSummary.Edit.FAClick();
                    FastDriver.OfficeSetupOffice.WaitForScreenToLoad();

                    Reports.TestStep = "Set the Hidden flag status as true for office if it's not set";
                    if (!FastDriver.OfficeSetupOffice.Hidden.Selected)
                    {
                        FastDriver.OfficeSetupOffice.Hidden.FASetCheckbox(true);

                    }
                    FastDriver.BottomFrame.Done();
                    Playback.Wait(4000);
                }

                return OfficeBuid;

                #endregion UI

            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
                return "";
            }
        }

        private CreateFileRequest CreateFileRequest(int BUID = 1487, string serviceType = "", int? projectFileID = null)
        {
            Service[] services = new Service[2];
            if (serviceType == "")
            {
                services[0] =
                        new Service()
                        {
                            OfficeInfo = new OfficeInfo()
                            {
                                RegionID = int.Parse(ClosingDisclosureSupport.IMDRegionBUID),
                                BUID = BUID,
                            },
                            ServiceTypeObjectCD = "TO"
                        };

                services[1] = new Service()
                {
                    OfficeInfo = new OfficeInfo()
                    {
                        RegionID = int.Parse(ClosingDisclosureSupport.IMDRegionBUID),
                        BUID = BUID,
                    },
                    ServiceTypeObjectCD = "EO"
                };


            }
            else
            {
                services[0] =
                        new Service()
                        {
                            OfficeInfo = new OfficeInfo()
                            {
                                RegionID = int.Parse(ClosingDisclosureSupport.IMDRegionBUID),
                                BUID = BUID,
                            },
                            ServiceTypeObjectCD = serviceType
                        };

            }

            return new CreateFileRequest
            {
                EmployeeObjectCD = "1",
                Source = "FAMOS",
                formType = ClosingDisclosureSupport.FormType,
                File = new FASTWCFHelpers.FastFileService.File()
                {
                    TransactionTypeObjectCD = "SALE",
                    BusinessSegmentObjectCD = "Commercial",
                    ExternalFileNumber = "12345678905",
                    AutoNumberIndicator = true,
                    ProjectFileID = projectFileID,//For Site File Creation

                    BusinessParties = new FileBusinessParty[] 
                    {
                        new FileBusinessParty()
                        {
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("HUDFLINSR1"),
                            RoleTypeObjectCD = "BUSSOURCE",
                        } 
                    },

                    Services = services,

                    Properties = new Property[] 
                    { 
                        new Property() 
                        {
                            Name = "my-test-property",
                            PropertyAddress = new FASTWCFHelpers.FastFileService.PhysicalAddress[] 
                            {
                                new FASTWCFHelpers.FastFileService.PhysicalAddress() 
                                { 
                                    State = "CA", 
                                    City = "Santa Ana", 
                                    County = "Orange", 
                                    Country = "USA" 
                                } 
                            } 
                        } 
                    },
                }
            };
        }

        private void CreateNewOffice()
        {
            FastDriver.OfficeSummary.New.FAClick();

            Reports.TestStep = "Enter details to newly created office.";
            FastDriver.OfficeSetupOffice.WaitForScreenToLoad();
            Random random = new Random();
            string OfficeCode1 = random.Next(999, 10000).ToString();
            FastDriver.OfficeSetupOffice.OfficeCode.FASetText(OfficeCode1);
            FastDriver.OfficeSetupOffice.FederalTaxID.FASetText("567891234");
            FastDriver.OfficeSetupOffice.OfficeName.FASetText("SRT Test Automation Office");
            FastDriver.OfficeSetupOffice.OfficeCompanyName1.FASetText("SRT DO Not Touch Automation Office");
            FastDriver.OfficeSetupOffice.OfficeComments.FASetText("Creating a new Office");
            FastDriver.OfficeSetupOffice.OfficeLogoFile1.FASetText("Test");
            FastDriver.OfficeSetupOffice.OfficeSystemLogoFile.FASetText("Automation Test");
            FastDriver.OfficeSetupOffice.BusinessSegment.FASelectItem("Commercial");
            FastDriver.OfficeSetupOffice.Can_be_Inter_Regional_Production_office.FASetCheckbox(true);
            FastDriver.OfficeSetupOffice.FeeTransmittalType.FASelectItem("Fee Transfer");
            FastDriver.OfficeSetupOffice.TimeZone.FASelectItem("Mountain Time");
            FastDriver.OfficeSetupOffice.DivisionProductionCenter.FASetCheckbox(true);
            FastDriver.OfficeSetupOffice.NPSProductionOffice.FASetCheckbox(true);
            FastDriver.OfficeSetupOffice.StatisticalReportingOffice.FASelectItem("Agency");
            FastDriver.OfficeSetupOffice.ProductionSystem.FASelectItem("FAST deployed");
            FastDriver.OfficeSetupOffice.FileNumberSchemaPrefix.FASetText("EWS");
            FastDriver.OfficeSetupOffice.FileNumberSchemaSeparator1.FASelectItem("-");
            FastDriver.OfficeSetupOffice.FileNumberSchemaSeparator2.FASelectItem("-");
            FastDriver.OfficeSetupOffice.FileNumberSchemaSuffix.FASetText("ADC");
            FastDriver.OfficeSetupOffice.DocumentNumberSchemaInvoicePrefix.FASetText("100");
            FastDriver.OfficeSetupOffice.FastStatCode.FASetText("12345");
            FastDriver.OfficeSetupOffice.CorporateParent.FASelectItemBySendingKeys("First American (FA)");
            FastDriver.OfficeSetupOffice.UnderwritersMenu.FAClick();
            FastDriver.OfficeSetupUnderwriters.UnderwritersNew.FAClick();
            FastDriver.OfficeSetupUnderwriters.UnderwriterName1.FASelectItem("New Underwriter");
            FastDriver.OfficeSetupUnderwriters.PremiumPercentage.FASetText("10");
            FastDriver.OfficeSetupUnderwriters.UseAsDefaultUnderwriter.FASetCheckbox(true);

            FastDriver.OfficeSetupOffice.BankAccountsMenu.FAClick();
            FastDriver.OfficeSetupBankAccounts.WaitForScreenToLoad();
            FastDriver.OfficeSetupBankAccounts.BankAccountSummaryNew.FAClick();
            FastDriver.OfficeSetupBankAccounts.BankAccountDetail_BankName.FASelectItemBySendingKeys("Automation Bank - Automation Testing");
            FastDriver.OfficeSetupBankAccounts.BankAccountDetailAccountNo1.FASetText("232345");
            FastDriver.OfficeSetupBankAccounts.BankAccountDetail_AccountDescription.FASetText("SRT AUTOMATION BANK");
            FastDriver.OfficeSetupBankAccounts.DisburseAcct.FASetCheckbox(true);
            FastDriver.OfficeSetupBankAccounts.PrimaryDisburse.FASetCheckbox(true);
            FastDriver.OfficeSetupBankAccounts.PrimaryDisburse.FASetCheckbox(true);
            FastDriver.OfficeSetupBankAccounts.DepositAcct.FASetCheckbox(true);
            FastDriver.OfficeSetupBankAccounts.PrimaryDeposit.FASetCheckbox(true);
            FastDriver.OfficeSetupBankAccounts.BanksTable.PerformTableAction("Bank Name", "Automation Bank - Automation Testing", "Bank Name", TableAction.Click);

            FastDriver.BottomFrame.Done();


        }

        private UpdateFileRequest ConstructUpdateFileRequest(string serviceType, int BUID = 2811)
        {
            UpdateFileRequest request = new UpdateFileRequest()
            {
                UpdateProductAndSearchType = true,
                UseLatestGabVersion = true,
                File = new FASTWCFHelpers.FastFileService.File()
                {
                    Services = new Service[]
                       {
                           new Service()
                           {
                               OfficeInfo = new OfficeInfo()
                               {
                                   BUID = BUID,
                               },
                               ServiceTypeObjectCD = serviceType,
                           },
                       }
                },
                Source = "FAMOS",
                formType = ClosingDisclosureSupport.FormType,
                FileID = FASTSelenium.Common.FASTHelpers.File.FileID,
            };
            return request;
        }

        private int CreateFile_TO()
        {
            int fileID;
            #region Create a file through WCF
            Reports.TestStep = "Create a file with required values through WCF.";
            var fileRequest = CreateFileRequest(1487, "TO");

            var fileResponse = FASTWCFHelpers.FileService.CreateFile(fileRequest);
            fileID = (int)fileResponse.FileID;
            Support.IsTrue((int)(fileResponse.FileID ?? 0) > 0, "Is this FileId valid ? " + fileID);

            var fileDetails = FASTWCFHelpers.FileService.GetOrderDetails(fileID);
            Reports.TestStep = "Search File in MRU.";
            FastDriver.TopFrame.SearchFileByFileNumber(fileDetails.FileNumber);
            #endregion

            return fileID;
        }

        #endregion

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}