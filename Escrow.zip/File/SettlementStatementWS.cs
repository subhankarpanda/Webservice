﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using FASTSelenium.DataObjects.IIS;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Win32;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using WebServices.Helpers.File;

namespace WebServices.File
{
    [CodedUITest]
    public class SettlementStatementWS : MasterTestClass
    {

        #region REG0001_GetSettlementStatementDetails
        [TestMethod]
        public void REG0001_GetSettlementStatementDetails()
        {
            try
            {
                Reports.TestDescription = "Validate GetSettlementStatementDetails web method";

                Reports.TestStep = "Create a basic file (WS)";
                int fileID = GeneralFileServiceOperationsHelpers.CreateFile();
                string fileNumber = FASTWCFHelpers.FileService.GetOrderDetails(fileID).FileNumber;

                Reports.TestStep = "Log into FAST application";
                Login();

                Reports.TestStep = "Navigate to the file";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to Fee Entry screen, enter negative buyer/seller charge/credit [US # 694856]";
                FastDriver.FileFees.Open();
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(1, 1, TableAction.On);
                FastDriver.FileFees.TitleandescrowTable.PerformTableAction(1, 3, TableAction.Click);
                FastDriver.PaymentDetailsDlg.WaitForScreenToLoad();
                FastDriver.PaymentDetailsDlg.BuyerCharge.FASetText("100");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerAtClosing.FASetText("-100");
                FastDriver.PaymentDetailsDlg.PaidbyBuyerBeforeClosing.FASetText("200");
                FastDriver.PaymentDetailsDlg.SellerCharge.FASetText("100");
                FastDriver.PaymentDetailsDlg.PaidbySellerAtClosing.FASetText("-100");
                FastDriver.PaymentDetailsDlg.PaidbySellerBeforeClosing.FASetText("200");
                FastDriver.DialogBottomFrame.ClickDone();

                Reports.TestStep = "Navigate to View Settlement Statement screen, obtain charge description";
                FastDriver.ViewSettlementStatement.Open();
                string chargeDesc = FastDriver.ViewSettlementStatement.ChargeDescription.FAGetText().Clean();

                Reports.TestStep = "Invoke GetSettlementStatementDetails web method, validate response (WS)";
                var response = SettlementStatementHelpers.GetSettlementStatementDetails(fileID);
                Support.AreEqual(true, response.GroupDataItems[0].ChargeList[0].Description.Clean().Contains(chargeDesc), "Charge Description");

                Reports.TestStep = "Validate negative charge amount on the resposne xml [US # 694856]";
                Support.AreEqual("-100.00", response.GroupDataItems[0].ChargeList[0].BuyerCharge.ToString(), "Buyer Charge");
                Support.AreEqual("-100.00", response.GroupDataItems[0].ChargeList[0].SellerCharge.ToString(), "Seller Charge");
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { FastDriver.WebDriver.Quit(); }
        }
        #endregion

        #region REG0002_GetSettlementStatementScreenDetails
        [TestMethod]
        public void REG0002_GetSettlementStatementScreenDetails()
        {
            try
            {
                Reports.TestDescription = "Validate GetSettlementStatementScreenDetails web method, [US # 691021]";

                Reports.TestStep = "Create a basic file (WS)";
                int fileID = GeneralFileServiceOperationsHelpers.CreateFile();
                string fileNumber = FASTWCFHelpers.FileService.GetOrderDetails(fileID).FileNumber;

                Reports.TestStep = "Log into FAST application";
                Login();

                Reports.TestStep = "Navigate to the file";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Navigate to Settlement Statement screen, select Combines, Buyer only, Seller only client formats, 3 copies each";
                FastDriver.PrintEscrowSetlleStmt.Open();
                FastDriver.PrintEscrowSetlleStmt.Combined.FASetCheckbox(true);
                FastDriver.PrintEscrowSetlleStmt.CombinedNumberofCopies.FASelectItem("3");
                FastDriver.PrintEscrowSetlleStmt.Buyeronly.FASetCheckbox(true);
                FastDriver.PrintEscrowSetlleStmt.BuyerNumberofCopies.FASelectItem("3");
                FastDriver.PrintEscrowSetlleStmt.SellerOnly.FASetCheckbox(true);
                FastDriver.PrintEscrowSetlleStmt.SellerNumberofCopies.FASelectItem("3");
                FastDriver.PrintEscrowSetlleStmt.PrintSettlementLocFromLender.FASetCheckbox(true);
                FastDriver.PrintEscrowSetlleStmt.PrintSettlementLocFromLenderTextBox.FASetText("Settlement Location Details");
                FastDriver.PrintEscrowSetlleStmt.PrintLoanNumber.FASetCheckbox(true);
                FastDriver.PrintEscrowSetlleStmt.Open();
                Thread.Sleep(10000);

                Reports.TestStep = "Invoke GetSettlementStatementScreenDetails web method, validate ClientFormats in the response (WS) [US # 691021]";
                var response = SettlementStatementHelpers.GetSettlementStatementScreenDetails(fileID);
                Support.AreEqual("True", response.ClientFormat.Combined.ToString(), "Combined");
                Support.AreEqual("3", response.ClientFormat.CombinedNumOfCopies.ToString(), "Combined # of copies");
                Support.AreEqual(false, response.ClientFormat.CombinedSignatureEnabled, "Combined signagure");
                Support.AreEqual("True", response.ClientFormat.BuyerOnly.ToString(), "Buyer Only");
                Support.AreEqual("3", response.ClientFormat.BuyerNumOfCopies.ToString(), "Buyer Only # of copies");
                Support.AreEqual(false, response.ClientFormat.BuyerSignatureEnabled, "Buyer only signagure");
                Support.AreEqual("True", response.ClientFormat.SellerOnly.ToString(), "Seller Only");
                Support.AreEqual("3", response.ClientFormat.SellerNumOfCopies.ToString(), "Seller Only # of copies");
                Support.AreEqual(false, response.ClientFormat.SellerSignatureEnabled, "Seller only signagure");

                Reports.TestStep = "Validate PrintOptionsSettlementLocation is present for the following nodes: PrintBusinessAddress, PrintSettlementLocation, and SettlementLocationDetails [US # 691021]";
                Support.AreEqual(false, (bool)response.AltaStatementDetails.PrintOptionsSettlementLocation.PrintBusinessAddress, "Print Business Address");
                Support.AreEqual(true, (bool)response.AltaStatementDetails.PrintOptionsSettlementLocation.PrintSettlementLocation, "Print Settlement Location");
                Support.AreEqual("Settlement Location Details", response.AltaStatementDetails.PrintOptionsSettlementLocation.SettlementLocationDetails, "Settlement Location Details");

                Reports.TestStep = "Validate PrintOptionsPropertyAddress is present for the following nodes: Print Property Address, Print Legal Description, and Print Address and Legal Description [US # 691021]";
                Support.AreEqual(false, (bool)response.AltaStatementDetails.PrintOptionsPropertyAddress.PrintAddressAndLegalDescription, "Print Address And Legal Description");
                Support.AreEqual(false, (bool)response.AltaStatementDetails.PrintOptionsPropertyAddress.PrintLegalDescription, "Print Legal Description");
                Support.AreEqual(true, (bool) response.AltaStatementDetails.PrintOptionsPropertyAddress.PrintPropertyAddress, "Print Property Address");

                Reports.TestStep = "Validate PrintLoanNumber is present [US # 691021]";
                Support.AreEqual(true, (bool)response.AltaStatementDetails.PrintLoanNumber, "Print Loan Number");

                Reports.TestStep = "Validate PrintOptionsEscrowOfficerSignature is present [US # 691021]";
                string escrowOfficerName = FastDriver.PrintEscrowSetlleStmt.PrintBlankSignatureLineText.FAGetValue().Clean();
                Support.AreEqual(escrowOfficerName, response.AltaStatementDetails.PrintOptionsEscrowOfficerSignature.EscrowOfficerName, "Escrow Officer Name");
                Support.AreEqual(false, (bool)response.AltaStatementDetails.PrintOptionsEscrowOfficerSignature.EscrowOfficerSignatureImageFlag, "Escrow Officer Signature Image Flag");
                Support.AreEqual(false, (bool)response.AltaStatementDetails.PrintOptionsEscrowOfficerSignature.NoEscrowOfficerSignature, "No Escrow Officer Signature");
                Support.AreEqual(true, (bool)response.AltaStatementDetails.PrintOptionsEscrowOfficerSignature.PrintBlankSignature, "Print Blank Signature");

                Reports.TestStep = "Validate PrintOptionsAcknowledgementText is present [US # 691021]";
                string estimateStatement = FastDriver.PrintEscrowSetlleStmt.PrintMemoEstimatedNotice.FAGetValue().Clean();
                string finalStatement = FastDriver.PrintEscrowSetlleStmt.PrintMemoFinalNotice.FAGetValue().Clean();
                Support.AreEqual(estimateStatement, response.AltaStatementDetails.PrintOptionsAcknowledgementText.EstimatedStatementDetails.Clean(), "Estimated Statement Details");
                Support.AreEqual(finalStatement, response.AltaStatementDetails.PrintOptionsAcknowledgementText.FinalStatementDetails.Clean(), "Final Statement Details");
                Support.AreEqual(false, (bool)response.AltaStatementDetails.PrintOptionsAcknowledgementText.IsPrintEstimatedAckEnabled, "Is Print Estimated Ack Enabled");
                Support.AreEqual(false, (bool)response.AltaStatementDetails.PrintOptionsAcknowledgementText.PrintEstimatedStatement, "Print Estimated Statement");
                Support.AreEqual(false, (bool)response.AltaStatementDetails.PrintOptionsAcknowledgementText.PrintFinalStatement, "Print Final Statement");

                Reports.TestStep = "Validate PrintOptionsDepositinEscrow is present [US # 691021]";
                Support.AreEqual(false, (bool)response.depositInEscrowDetails.DescrFlag, "DescrFlag");
                Support.AreEqual(false, (bool)response.depositInEscrowDetails.FundsTypeFlag, "FundsTypeFlag");
                Support.AreEqual(true, (bool)response.depositInEscrowDetails.PayorFlag, "PayorFlag");
                Support.AreEqual(true, (bool)response.depositInEscrowDetails.RecptFlag, "RecptFlag");
                Support.AreEqual(false, (bool)response.depositInEscrowDetails.ReprntgFlag, "ReprntgFlag");
                Support.AreEqual(true, (bool)response.depositInEscrowDetails.issueDateFlag, "issueDateFlag");
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { FastDriver.WebDriver.Quit(); }
        }
        #endregion

        #region REG0003_UpdateSettlementStatementDetails
        [TestMethod]
        public void REG0003_UpdateSettlementStatementDetails()
        {
            try
            {
                Reports.TestDescription = "Validate UpdateSettlementStatementDetails web method";

                Reports.TestStep = "Create a basic file (WS)";
                int fileID = GeneralFileServiceOperationsHelpers.CreateFile();
                string fileNumber = FASTWCFHelpers.FileService.GetOrderDetails(fileID).FileNumber;

                Reports.TestStep = "Log into FAST application";
                Login();

                Reports.TestStep = "Navigate to the file";
                FastDriver.TopFrame.SearchFileByFileNumber(fileNumber);

                Reports.TestStep = "Enter Settlement Date";
                FastDriver.TermsDatesStatus.Open();
                FastDriver.TermsDatesStatus.SettlementDate.FASetText(DateTime.Now.ToDateString());
                FastDriver.BottomFrame.Done();

                Reports.TestStep = "Invoke UpdateSettlementStatementDetails web method, validate response (WS) [US # 693157]";
                var info = new UpdateSettelementStatementRequestInfo();
                info.ClientFormat = new SettlementStatementClientFormat()
                {
                    Combined = true,
                    CombinedNumOfCopies = 3,
                    CombinedSignature = true,
                    CombinedSignatureEnabled = true,
                    BuyerOnly = true,
                    BuyerNumOfCopies = 3,
                    BuyerSignature = true,
                    BuyerSignatureEnabled = true,
                    SellerOnly = true,
                    SellerNumOfCopies = 3,
                    SellerSignature = true,
                    SellerSignatureEnabled = true
                };
                info.settelementStatementType = new SettelementStatementType()
                {
                    IsSettlementType = true,
                    FinalFlag = true
                };
                info.AltaStatementDetails = new AltaStatement()
                {
                    PrintLoanNumber = true,
                    PrintOptionsAcknowledgementText = new PrintOptionsAcknowledgementText()
                    {
                        PrintEstimatedStatement = true,
                        PrintFinalStatement = true,
                        IsPrintEstimatedAckEnabled = true,
                        IsPrintFinalAckEnabled = true
                    },
                    PrintOptionsEscrowOfficerSignature = new PrintOptionsEscrowOfficerSignature()
                    {
                        EscrowOfficerName = "Nhat Nguyen",
                        PrintBlankSignature = true,
                        EscrowOfficerSignatureImageFlag = true
                    },
                    PrintOptionsPropertyAddress = new PrintOptionsPropertyAddress()
                    {
                        PrintAddressAndLegalDescription = true
                    },
                    PrintOptionsSettlementLocation = new PrintOptionsSettlementLocation()
                    {
                        PrintSettlementLocation = true,
                        SettlementLocationDetails = "Settlement Location Details"
                    }
                };
                info.depositInEscrowDetails = new DepositsInEscrowDetails()
                {
                    DescrFlag = true,
                    FundsTypeFlag = true,
                    PayorFlag = true,
                    RecptFlag = true,
                    ReprntgFlag = true,
                    issueDateFlag = true
                };

                var response = SettlementStatementHelpers.UpdateSettlementStatementDetails(fileID, info);
                Support.AreEqual("1", response.Status.ToString(), "Status");
                Support.AreEqual("SettlementStatement details Updated successfully", response.StatusDescription, "Status Description");
                Thread.Sleep(5000);

                Reports.TestStep = "Navigate to Settlement Statement screen, validate client formats [US # 693157]";
                FastDriver.PrintEscrowSetlleStmt.Open();
                Support.AreEqual(true, FastDriver.PrintEscrowSetlleStmt.Combined.IsSelected(), "Combined Checkbox");
                Support.AreEqual("3", FastDriver.PrintEscrowSetlleStmt.CombinedNumberofCopies.FAGetSelectedItem(), "Combined # of Copies");
                Support.AreEqual(true, FastDriver.PrintEscrowSetlleStmt.CombinedSignatures.IsSelected(), "Combined Signature");
                Support.AreEqual(true, FastDriver.PrintEscrowSetlleStmt.Buyeronly.IsSelected(), "Buyer Only Checkbox");
                Support.AreEqual("3", FastDriver.PrintEscrowSetlleStmt.BuyerNumberofCopies.FAGetSelectedItem(), "Buyer Only # of Copies");
                Support.AreEqual(true, FastDriver.PrintEscrowSetlleStmt.BuyerSignatures.IsSelected(), "Buyer Signature");
                Support.AreEqual(true, FastDriver.PrintEscrowSetlleStmt.SellerOnly.IsSelected(), "Seller Only Checkbox");
                Support.AreEqual("3", FastDriver.PrintEscrowSetlleStmt.SellerNumberofCopies.FAGetSelectedItem(), "Seller Only # of Copies");
                Support.AreEqual(true, FastDriver.PrintEscrowSetlleStmt.SellerSignatures.IsSelected(), "Seller Signature");

                Reports.TestStep = "Validate Print Options - Settlement Location [US # 693157]";
                Support.AreEqual(true, FastDriver.PrintEscrowSetlleStmt.PrintSettlementLocFromLender.IsSelected(), "Print Settlement Location");
                Support.AreEqual("Settlement Location Details", FastDriver.PrintEscrowSetlleStmt.PrintSettlementLocFromLenderTextBox.FAGetValue().Clean(), "Settlement Location Details");

                Reports.TestStep = "Validate Print Options - Property Address [US # 693157]";
                Support.AreEqual(true, FastDriver.PrintEscrowSetlleStmt.PrintBoth.IsSelected(), "Print Both");

                Reports.TestStep = "Validate Print Options - Loan Number [US # 693157]";
                Support.AreEqual(true, FastDriver.PrintEscrowSetlleStmt.PrintLoanNumber.IsSelected(), "Print Loan Number on Settlement Statement");

                Reports.TestStep = "Validate Print Options - Deposit in Escrow [US # 693157]";
                Support.AreEqual(true, FastDriver.PrintEscrowSetlleStmt.ReceiptNo.IsSelected(), "ReceiptNo");
                Support.AreEqual(true, FastDriver.PrintEscrowSetlleStmt.IssueDate.IsSelected(), "IssueDate");
                Support.AreEqual(true, FastDriver.PrintEscrowSetlleStmt.Payor.IsSelected(), "Payor");
                Support.AreEqual(true, FastDriver.PrintEscrowSetlleStmt.TypeOfFunds.IsSelected(), "TypeOfFunds");
                Support.AreEqual(true, FastDriver.PrintEscrowSetlleStmt.Representing.IsSelected(), "Representing");
                Support.AreEqual(true, FastDriver.PrintEscrowSetlleStmt.Description.IsSelected(), "Description");

                Reports.TestStep = "Validate Print Options - Escrow Officer Signature [US # 693157]";
                FastDriver.PrintEscrowSetlleStmt.PrintBlankSignatureLineWithEscrowOfficerName.ScrollIntoView();
                Support.AreEqual(true, FastDriver.PrintEscrowSetlleStmt.PrintBlankSignatureLineWithEscrowOfficerName.IsSelected(), "PrintBlankSignatureLineWithEscrowOfficerName");
                Support.AreEqual(true, FastDriver.PrintEscrowSetlleStmt.PrintAltaEscrowOfficerSignature.IsSelected(), "PrintEscrowOfficerSigImg");

            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
            finally { FastDriver.WebDriver.Quit(); }
        }
        #endregion


        #region Private class methods

        private void Login(string url = null)
        {
            var credentials = new Credentials()
            {
                UserName = AutoConfig.UserName,
                Password = AutoConfig.UserPassword
            };

            FASTLogin.Login(url ?? AutoConfig.FASTHomeURL, credentials, true);
        }

        
        #endregion
    }
}
