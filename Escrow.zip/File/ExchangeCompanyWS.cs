﻿using FASTSelenium.Common;
using FASTWCFHelpers.DataObjects;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;
using WebServices.Helpers.File;

namespace WebServices.File
{
    [CodedUITest]
    public class ExchangeCompanyWS : FASTHelpers
    {
        #region BAT
        [TestMethod]
        [Description("Retrieve an Individual Buyer's Exchange Company")]
        public void BAT0001()
        {
            try
            {
                Reports.TestDescription = "Retrieve an Individual Buyer's Exchange Company";

                FAST_Login_IIS();
                FAST_WCF_File_IIS();

                #region Request new Individual Buyer type
                Reports.TestStep = "Request new Individual Buyer type";
                BuyerSellerHelpers.AddBuyerSeller(File.FileID ?? 0, BuyerSellerTypeCdID.Individual, BuyerSellerPrincipalTypeOCD.Buyer);
                ExchangeCompanyHelpers.AddExchangeCompany(BuyerSellerPrincipalTypeOCD.Buyer, 1, "BOA");
                #endregion

                #region Verify Exchange Company with GetExchangeCompany web service
                Reports.TestStep = "Verify Exchange Company with GetExchangeCompany web service";
                ExchangeCompanyHelpers.VerifyExchangeCompany(File.FileID ?? 0, "BOA");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Retrieve a Husband/Wife Buyer's Exchange Company")]
        public void BAT0002()
        {
            try
            {
                Reports.TestDescription = "Retrieve a Husband/Wife Buyer's Exchange Company";

                FAST_Login_IIS();
                FAST_WCF_File_IIS();

                #region Request new Husband/Wife Buyer type
                Reports.TestStep = "Request new Husband/Wife Buyer type";
                BuyerSellerHelpers.AddBuyerSeller(File.FileID ?? 0, BuyerSellerTypeCdID.HusbandAndWife, BuyerSellerPrincipalTypeOCD.Buyer);
                ExchangeCompanyHelpers.AddExchangeCompany(BuyerSellerPrincipalTypeOCD.Buyer, 1, "BOA");
                #endregion

                #region Verify Exchange Company with GetExchangeCompany web service
                Reports.TestStep = "Verify Exchange Company with GetExchangeCompany web service";
                ExchangeCompanyHelpers.VerifyExchangeCompany(File.FileID ?? 0, "BOA");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Retrieve a Trust/Estate Buyer's Exchange Company")]
        public void BAT0003()
        {
            try
            {
                Reports.TestDescription = "Retrieve a Trust/Estate Buyer's Exchange Company";

                FAST_Login_IIS();
                FAST_WCF_File_IIS();

                #region Request new Trust/Estate Buyer type
                Reports.TestStep = "Request new Trust/Estate Buyer type";
                BuyerSellerHelpers.AddBuyerSeller(File.FileID ?? 0, BuyerSellerTypeCdID.TrustEstate, BuyerSellerPrincipalTypeOCD.Buyer);
                ExchangeCompanyHelpers.AddExchangeCompany(BuyerSellerPrincipalTypeOCD.Buyer, 1, "BOA");
                #endregion

                #region Verify Exchange Company with GetExchangeCompany web service
                Reports.TestStep = "Verify Exchange Company with GetExchangeCompany web service";
                ExchangeCompanyHelpers.VerifyExchangeCompany(File.FileID ?? 0, "BOA");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Retrieve a Business Buyer's Exchange Company")]
        public void BAT0004()
        {
            try
            {
                Reports.TestDescription = "Retrieve a Business Buyer's Exchange Company";

                FAST_Login_IIS();
                FAST_WCF_File_IIS();

                #region Request new Business Buyer type
                Reports.TestStep = "Request new Business Buyer type";
                BuyerSellerHelpers.AddBuyerSeller(File.FileID ?? 0, BuyerSellerTypeCdID.BusinessEntity, BuyerSellerPrincipalTypeOCD.Buyer);
                ExchangeCompanyHelpers.AddExchangeCompany(BuyerSellerPrincipalTypeOCD.Buyer, 1, "BOA");
                #endregion

                #region Verify Exchange Company with GetExchangeCompany web service
                Reports.TestStep = "Verify Exchange Company with GetExchangeCompany web service";
                ExchangeCompanyHelpers.VerifyExchangeCompany(File.FileID ?? 0, "BOA");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Retrieve an Individual Seller's Exchange Company")]
        public void BAT0005()
        {
            try
            {
                Reports.TestDescription = "Retrieve an Individual Seller's Exchange Company";

                FAST_Login_IIS();
                FAST_WCF_File_IIS();

                #region Request new Individual Seller type
                Reports.TestStep = "Request new Individual Seller type";
                BuyerSellerHelpers.AddBuyerSeller(File.FileID ?? 0, BuyerSellerTypeCdID.Individual, BuyerSellerPrincipalTypeOCD.Seller);
                ExchangeCompanyHelpers.AddExchangeCompany(BuyerSellerPrincipalTypeOCD.Seller, 1, "BOA");
                #endregion

                #region Verify Exchange Company with GetExchangeCompany web service
                Reports.TestStep = "Verify Exchange Company with GetExchangeCompany web service";
                ExchangeCompanyHelpers.VerifyExchangeCompany(File.FileID ?? 0, "BOA");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Retrieve a Husband/Wife Seller's Exchange Company")]
        public void BAT0006()
        {
            try
            {
                Reports.TestDescription = "Retrieve a Husband/Wife Seller's Exchange Company";

                FAST_Login_IIS();
                FAST_WCF_File_IIS();

                #region Request new Husband/Wife Seller type
                Reports.TestStep = "Request new Husband/Wife Seller type";
                BuyerSellerHelpers.AddBuyerSeller(File.FileID ?? 0, BuyerSellerTypeCdID.HusbandAndWife, BuyerSellerPrincipalTypeOCD.Seller);
                ExchangeCompanyHelpers.AddExchangeCompany(BuyerSellerPrincipalTypeOCD.Seller, 1, "BOA");
                #endregion

                #region Verify Exchange Company with GetExchangeCompany web service
                Reports.TestStep = "Verify Exchange Company with GetExchangeCompany web service";
                ExchangeCompanyHelpers.VerifyExchangeCompany(File.FileID ?? 0, "BOA");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Retrieve a Trust/Estate Seller's Exchange Company")]
        public void BAT0007()
        {
            try
            {
                Reports.TestDescription = "Retrieve a Trust/Estate Seller's Exchange Company";

                FAST_Login_IIS();
                FAST_WCF_File_IIS();

                #region Request new Trust/Estate Seller type
                Reports.TestStep = "Request new Trust/Estate Seller type";
                BuyerSellerHelpers.AddBuyerSeller(File.FileID ?? 0, BuyerSellerTypeCdID.TrustEstate, BuyerSellerPrincipalTypeOCD.Seller);
                ExchangeCompanyHelpers.AddExchangeCompany(BuyerSellerPrincipalTypeOCD.Seller, 1, "BOA");
                #endregion

                #region Verify Exchange Company with GetExchangeCompany web service
                Reports.TestStep = "Verify Exchange Company with GetExchangeCompany web service";
                ExchangeCompanyHelpers.VerifyExchangeCompany(File.FileID ?? 0, "BOA");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Retrieve a Business Seller's Exchange Company")]
        public void BAT0008()
        {
            try
            {
                Reports.TestDescription = "Retrieve a Business Seller's Exchange Company";

                FAST_Login_IIS();
                FAST_WCF_File_IIS();

                #region Request new Business Seller type
                Reports.TestStep = "Request new Business Seller type";
                BuyerSellerHelpers.AddBuyerSeller(File.FileID ?? 0, BuyerSellerTypeCdID.BusinessEntity, BuyerSellerPrincipalTypeOCD.Seller);
                ExchangeCompanyHelpers.AddExchangeCompany(BuyerSellerPrincipalTypeOCD.Seller, 1, "BOA");
                #endregion

                #region Verify Exchange Company with GetExchangeCompany web service
                Reports.TestStep = "Verify Exchange Company with GetExchangeCompany web service";
                ExchangeCompanyHelpers.VerifyExchangeCompany(File.FileID ?? 0, "BOA");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Delete an Individual Buyer's Exchange Company")]
        public void BAT0009()
        {
            try
            {
                Reports.TestDescription = "Delete an Individual Buyer's Exchange Company";

                FAST_Login_IIS();
                FAST_WCF_File_IIS();

                #region Request new Individual Buyer type
                Reports.TestStep = "Request new Individual Buyer type";
                BuyerSellerHelpers.AddBuyerSeller(File.FileID ?? 0, BuyerSellerTypeCdID.Individual, BuyerSellerPrincipalTypeOCD.Buyer);
                ExchangeCompanyHelpers.AddExchangeCompany(BuyerSellerPrincipalTypeOCD.Buyer, 1, "BOA");
                #endregion

                #region Delete Exchange Company
                Reports.TestStep = "Delete Exchange Company";
                ExchangeCompanyHelpers.DeleteExchangeCompany(File.FileID ?? 0);
                #endregion

                #region Verify Exchange Company is deleted
                Reports.TestStep = "Verify Exchange Company is deleted";
                ExchangeCompanyHelpers.VerifyExchangeCompany(BuyerSellerPrincipalTypeOCD.Buyer, 1, "");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Delete a Husband/Wife Buyer's Exchange Company")]
        public void BAT0010()
        {
            try
            {
                Reports.TestDescription = "Delete a Husband/Wife Buyer's Exchange Company";

                FAST_Login_IIS();
                FAST_WCF_File_IIS();

                #region Request new Husband/Wife Buyer type
                Reports.TestStep = "Request new Husband/Wife Buyer type";
                BuyerSellerHelpers.AddBuyerSeller(File.FileID ?? 0, BuyerSellerTypeCdID.HusbandAndWife, BuyerSellerPrincipalTypeOCD.Buyer);
                ExchangeCompanyHelpers.AddExchangeCompany(BuyerSellerPrincipalTypeOCD.Buyer, 1, "BOA");
                #endregion

                #region Delete Exchange Company
                Reports.TestStep = "Delete Exchange Company";
                ExchangeCompanyHelpers.DeleteExchangeCompany(File.FileID ?? 0);
                #endregion

                #region Verify Exchange Company is deleted
                Reports.TestStep = "Verify Exchange Company is deleted";
                ExchangeCompanyHelpers.VerifyExchangeCompany(BuyerSellerPrincipalTypeOCD.Buyer, 1, "");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Delete a Trust/Estate Buyer's Exchange Company")]
        public void BAT0011()
        {
            try
            {
                Reports.TestDescription = "Delete a Trust/Estate Buyer's Exchange Company";

                FAST_Login_IIS();
                FAST_WCF_File_IIS();

                #region Request new Trust/Estate Buyer type
                Reports.TestStep = "Request new Trust/Estate Buyer type";
                BuyerSellerHelpers.AddBuyerSeller(File.FileID ?? 0, BuyerSellerTypeCdID.TrustEstate, BuyerSellerPrincipalTypeOCD.Buyer);
                ExchangeCompanyHelpers.AddExchangeCompany(BuyerSellerPrincipalTypeOCD.Buyer, 1, "BOA");
                #endregion

                #region Delete Exchange Company
                Reports.TestStep = "Delete Exchange Company";
                ExchangeCompanyHelpers.DeleteExchangeCompany(File.FileID ?? 0);
                #endregion

                #region Verify Exchange Company is deleted
                Reports.TestStep = "Verify Exchange Company is deleted";
                ExchangeCompanyHelpers.VerifyExchangeCompany(BuyerSellerPrincipalTypeOCD.Buyer, 1, "");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Delete a Business Buyer's Exchange Company")]
        public void BAT0012()
        {
            try
            {
                Reports.TestDescription = "Delete a Business Buyer's Exchange Company";

                FAST_Login_IIS();
                FAST_WCF_File_IIS();

                #region Request new Business Buyer type
                Reports.TestStep = "Request new Business Buyer type";
                BuyerSellerHelpers.AddBuyerSeller(File.FileID ?? 0, BuyerSellerTypeCdID.BusinessEntity, BuyerSellerPrincipalTypeOCD.Buyer);
                ExchangeCompanyHelpers.AddExchangeCompany(BuyerSellerPrincipalTypeOCD.Buyer, 1, "BOA");
                #endregion

                #region Delete Exchange Company
                Reports.TestStep = "Delete Exchange Company";
                ExchangeCompanyHelpers.DeleteExchangeCompany(File.FileID ?? 0);
                #endregion

                #region Verify Exchange Company is deleted
                Reports.TestStep = "Verify Exchange Company is deleted";
                ExchangeCompanyHelpers.VerifyExchangeCompany(BuyerSellerPrincipalTypeOCD.Buyer, 1, "");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Delete an Individual Seller's Exchange Company")]
        public void BAT0013()
        {
            try
            {
                Reports.TestDescription = "Delete an Individual Seller's Exchange Company";

                FAST_Login_IIS();
                FAST_WCF_File_IIS();

                #region Request new Individual Seller type
                Reports.TestStep = "Request new Individual Seller type";
                BuyerSellerHelpers.AddBuyerSeller(File.FileID ?? 0, BuyerSellerTypeCdID.Individual, BuyerSellerPrincipalTypeOCD.Seller);
                ExchangeCompanyHelpers.AddExchangeCompany(BuyerSellerPrincipalTypeOCD.Seller, 1, "BOA");
                #endregion

                #region Delete Exchange Company
                Reports.TestStep = "Delete Exchange Company";
                ExchangeCompanyHelpers.DeleteExchangeCompany(File.FileID ?? 0);
                #endregion

                #region Verify Exchange Company is deleted
                Reports.TestStep = "Verify Exchange Company is deleted";
                ExchangeCompanyHelpers.VerifyExchangeCompany(BuyerSellerPrincipalTypeOCD.Seller, 1, "");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Delete a Husband/Wife Seller's Exchange Company")]
        public void BAT0014()
        {
            try
            {
                Reports.TestDescription = "Delete a Husband/Wife Seller's Exchange Company";

                FAST_Login_IIS();
                FAST_WCF_File_IIS();

                #region Request new Husband/Wife Seller type
                Reports.TestStep = "Request new Husband/Wife Seller type";
                BuyerSellerHelpers.AddBuyerSeller(File.FileID ?? 0, BuyerSellerTypeCdID.HusbandAndWife, BuyerSellerPrincipalTypeOCD.Seller);
                ExchangeCompanyHelpers.AddExchangeCompany(BuyerSellerPrincipalTypeOCD.Seller, 1, "BOA");
                #endregion

                #region Delete Exchange Company
                Reports.TestStep = "Delete Exchange Company";
                ExchangeCompanyHelpers.DeleteExchangeCompany(File.FileID ?? 0);
                #endregion

                #region Verify Exchange Company is deleted
                Reports.TestStep = "Verify Exchange Company is deleted";
                ExchangeCompanyHelpers.VerifyExchangeCompany(BuyerSellerPrincipalTypeOCD.Seller, 1, "");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Delete a Trust/Estate Seller's Exchange Company")]
        public void BAT0015()
        {
            try
            {
                Reports.TestDescription = "Delete a Trust/Estate Seller's Exchange Company";

                FAST_Login_IIS();
                FAST_WCF_File_IIS();

                #region Request new Trust/Estate Seller type
                Reports.TestStep = "Request new Trust/Estate Seller type";
                BuyerSellerHelpers.AddBuyerSeller(File.FileID ?? 0, BuyerSellerTypeCdID.TrustEstate, BuyerSellerPrincipalTypeOCD.Seller);
                ExchangeCompanyHelpers.AddExchangeCompany(BuyerSellerPrincipalTypeOCD.Seller, 1, "BOA");
                #endregion

                #region Delete Exchange Company
                Reports.TestStep = "Delete Exchange Company";
                ExchangeCompanyHelpers.DeleteExchangeCompany(File.FileID ?? 0);
                #endregion

                #region Verify Exchange Company is deleted
                Reports.TestStep = "Verify Exchange Company is deleted";
                ExchangeCompanyHelpers.VerifyExchangeCompany(BuyerSellerPrincipalTypeOCD.Seller, 1, "");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }

        [TestMethod]
        [Description("Delete a Business Seller's Exchange Company")]
        public void BAT0016()
        {
            try
            {
                Reports.TestDescription = "Delete a Business Seller's Exchange Company";

                FAST_Login_IIS();
                FAST_WCF_File_IIS();

                #region Request new Business Seller type
                Reports.TestStep = "Request new Business Seller type";
                BuyerSellerHelpers.AddBuyerSeller(File.FileID ?? 0, BuyerSellerTypeCdID.BusinessEntity, BuyerSellerPrincipalTypeOCD.Seller);
                ExchangeCompanyHelpers.AddExchangeCompany(BuyerSellerPrincipalTypeOCD.Seller, 1, "BOA");
                #endregion

                #region Delete Exchange Company
                Reports.TestStep = "Delete Exchange Company";
                ExchangeCompanyHelpers.DeleteExchangeCompany(File.FileID ?? 0);
                #endregion

                #region Verify Exchange Company is deleted
                Reports.TestStep = "Verify Exchange Company is deleted";
                ExchangeCompanyHelpers.VerifyExchangeCompany(BuyerSellerPrincipalTypeOCD.Seller, 1, "");
                #endregion
            }
            catch (Exception ex)
            {
                FailTest(GetExceptionInfo(ex));
            }
        }
        #endregion
    }
}
