﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using FASTSelenium.PageObjects.IIS;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Data;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using WebServices.Helpers.File;


namespace WebServices.File
{
    [CodedUITest]
    public class SignatureSigningWS : FASTHelpers
    {
        public static int fileId = 0;
        public static int signingId = 0;
        public static int signingPartyID = 0;



        /// <summary>
        /// Author: Yusuf
        /// Date : 29 Dec 2015
        /// Order 2
        /// </summary>
        [TestMethod]
        public void REG_GetSignatureSigning()
        {
            //Reports.TestStep = "Login to FAST";
            try
            {
                //if (fileId == 0)
                //{
                //  CreateFileViaService(FileServicePath, "SetSignatureSigning", 2);
                //                    fileId = System.Convert.ToInt32(ContextObjects["FileId"]);
                //              }

                //Reports.TestStep = "Login to FAST and create a file";
                //FAST_Init_File();
                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS.";
                FAST_Login_IIS();
                #endregion

                Reports.TestStep = "Create a file using WCF and get the fileId.";
                int fileId = CreateFile();
                //fileId = (int)File.FileID;

                var signatureSigningRequest = CreateOrderSigningRequest(fileId);

                var signatureSigningResponse = ServiceFactory.GetFileService().SetSignatureSigning(signatureSigningRequest);

                //dynamic setSigReq = GetRequest(objectType, FileServicePath + "SetSignatureSigning.xml", "SetSignatureSigning", 2);
                //setSigReq.SigningDetails.FileID = fileId;
                //setSigReq.SigningDetails.ProposedDate = DateTime.Today.AddDays(2).ToDateString();
                //setSigReq.SigningDetails.ProposedTime = "07:56:03 AM";
                //dynamic setSigResponse = InvokeServiceMethodByInstanceAndRequest(serviceInstance, "SetSignatureSigning", setSigReq);


                Reports.TestStep = "As a pre-requisite, verify the SetSignatureSigning operation response.";
                //Support.IsTrue(ServiceHelper.GetStatusOnReport(Convert.ToInt16(setSigResponse.Status).Equals(1), "The status is 1 in the response"));
                //Assert.IsTrue(Helper.GetStatusOnReport(setSigResponse.StatusDescription.ToLower().ToString().Contains("signing [s.no. 01] created successfully in pending status"), "The status description is as expected in the response"));

                Reports.StatusUpdate("Is status == 1 in the response ?", Convert.ToInt16(signatureSigningResponse.Status).Equals(1));
                Reports.StatusUpdate("Is the status description as expected in the response ?", signatureSigningResponse.StatusDescription.ToLower().ToString().Contains("signing [s.no. 01] created successfully in pending status"));

                var getSignatureSigningResponse = ServiceFactory.GetFileService().GetSignatureSigning(fileId);
                signingId = (int)getSignatureSigningResponse.OrderSigningInfo[0].SigningDetails.SigningID;
                signingPartyID = (int)getSignatureSigningResponse.OrderSigningInfo[0].BuyerDetails[0].SigningPartyID;

                //dynamic setSigResponse = InvokeServiceMethod("FASTFileService", "GetSignatureSigning", null, null, null, null, fileId);
                Reports.TestStep = "Verify the GetSignatureSigning operation response.";

                //dynamic priAddre = setSigResponse.OrderSigningInfo[0].PrimaryAddress;
                //dynamic delAddr = setSigResponse.OrderSigningInfo[0].DeliverAddress;
                //var sigAddre = setSigResponse.OrderSigningInfo[0].SigningAddress;
                //signingId = setSigResponse.OrderSigningInfo[0].SigningDetails.SigningID;
                //signingPartyID = setSigResponse.OrderSigningInfo[0].BuyerDetails[0].SigningPartyID;

                FastDriver.LeftNavigation.Navigate<SignatureSigning>(@"Home>Order Entry>Escrow Closing>Signature Signing").WaitForScreenToLoad();

                //Playback.Wait(2000);

                //HtmlSupport page = new HtmlSupport();
                //page.SetParent("IIS.SignatureSigning", "SignatureSigning");
                //Playback.Wait(2000);

                ServiceHelper.CompareUIDate(FastDriver.SignatureSigning.ProposedDate, "value", getSignatureSigningResponse.OrderSigningInfo[0].SigningDetails.ProposedDate.ToString());
                ServiceHelper.ContainsUIVal(FastDriver.SignatureSigning.ProposedTime, "value", getSignatureSigningResponse.OrderSigningInfo[0].SigningDetails.ProposedTime.ToString());
                ServiceHelper.ContainsUIVal(FastDriver.SignatureSigning.SpecialInstructions, "text", getSignatureSigningResponse.OrderSigningInfo[0].SigningDetails.SpecialInstructions.ToString());

                ServiceHelper.ContainsUIVal(FastDriver.SignatureSigning.SigningAddressLine1, "text", getSignatureSigningResponse.OrderSigningInfo[0].SigningAddress.PhysicalAddress.AddrLine1.ToString());
                ServiceHelper.ContainsUIVal(FastDriver.SignatureSigning.SigningAddressLine2, "text", getSignatureSigningResponse.OrderSigningInfo[0].SigningAddress.PhysicalAddress.AddrLine2.ToString());
                ServiceHelper.ContainsUIVal(FastDriver.SignatureSigning.SigningAddressCity, "text", getSignatureSigningResponse.OrderSigningInfo[0].SigningAddress.PhysicalAddress.City.ToString());
                ServiceHelper.ContainsUIVal(FastDriver.SignatureSigning.SigningAddressstate, "selecteditem", getSignatureSigningResponse.OrderSigningInfo[0].SigningAddress.PhysicalAddress.State.ToString());
                ServiceHelper.ContainsUIVal(FastDriver.SignatureSigning.SigningAddressZip, "text", getSignatureSigningResponse.OrderSigningInfo[0].SigningAddress.PhysicalAddress.Zip.ToString());


                ServiceHelper.ContainsUIVal(FastDriver.SignatureSigning.DeliveryAddressLine1, "text", getSignatureSigningResponse.OrderSigningInfo[0].DeliverAddress.PhysicalAddress.AddrLine1.ToString());
                ServiceHelper.ContainsUIVal(FastDriver.SignatureSigning.DeliveryAddressLine2, "text", getSignatureSigningResponse.OrderSigningInfo[0].DeliverAddress.PhysicalAddress.AddrLine2.ToString());
                ServiceHelper.ContainsUIVal(FastDriver.SignatureSigning.DeliveryAddressCity, "text", getSignatureSigningResponse.OrderSigningInfo[0].DeliverAddress.PhysicalAddress.City.ToString());
                ServiceHelper.ContainsUIVal(FastDriver.SignatureSigning.DeliveryAddressState, "selecteditem", getSignatureSigningResponse.OrderSigningInfo[0].DeliverAddress.PhysicalAddress.State.ToString());
                ServiceHelper.ContainsUIVal(FastDriver.SignatureSigning.DeliveryAddressZip, "text", getSignatureSigningResponse.OrderSigningInfo[0].DeliverAddress.PhysicalAddress.Zip.ToString());


                ServiceHelper.ContainsUIVal(FastDriver.SignatureSigning.PrimaryAddressLine1, "text", getSignatureSigningResponse.OrderSigningInfo[0].PrimaryAddress.PhysicalAddress.AddrLine1.ToString());
                ServiceHelper.ContainsUIVal(FastDriver.SignatureSigning.PrimaryAddressLine2, "text", getSignatureSigningResponse.OrderSigningInfo[0].PrimaryAddress.PhysicalAddress.AddrLine2.ToString());
                ServiceHelper.ContainsUIVal(FastDriver.SignatureSigning.PrimaryAddressCity, "text", getSignatureSigningResponse.OrderSigningInfo[0].PrimaryAddress.PhysicalAddress.City.ToString());
                ServiceHelper.ContainsUIVal(FastDriver.SignatureSigning.PrimaryAddressState, "selecteditem", getSignatureSigningResponse.OrderSigningInfo[0].PrimaryAddress.PhysicalAddress.State.ToString());
                ServiceHelper.ContainsUIVal(FastDriver.SignatureSigning.PrimaryAddressZip, "text", getSignatureSigningResponse.OrderSigningInfo[0].PrimaryAddress.PhysicalAddress.Zip.ToString());


                if ((FastDriver.SignatureSigning.BuyerSummaryTable.GetRowCount()) == getSignatureSigningResponse.OrderSigningInfo[0].BuyerDetails.Length)
                {
                    dynamic buyerDetail = getSignatureSigningResponse.OrderSigningInfo[0].BuyerDetails[0];
                    ServiceHelper.ContainsUIVal(FastDriver.SignatureSigning.BuyerDetailsFirstName, "text", getSignatureSigningResponse.OrderSigningInfo[0].BuyerDetails[0].FirstName.ToString());
                    ServiceHelper.ContainsUIVal(FastDriver.SignatureSigning.BuyerDetailsLastName, "text", getSignatureSigningResponse.OrderSigningInfo[0].BuyerDetails[0].LastName.ToString());
                    ServiceHelper.ContainsUIVal(FastDriver.SignatureSigning.BuyerPhonesHomeNumber, "text", getSignatureSigningResponse.OrderSigningInfo[0].BuyerDetails[0].PhoneDetails[0].Number.ToString(), true);
                    ServiceHelper.ContainsUIVal(FastDriver.SignatureSigning.BuyerPhonesHomeExtension, "text", getSignatureSigningResponse.OrderSigningInfo[0].BuyerDetails[0].PhoneDetails[0].Ext.ToString(), true);

                }
                /*
                 * FirstName LastName  PhoneDetails[0].Number  Ext*/
                if ((FastDriver.SignatureSigning.LoanSummaryTable.GetRowCount()) != getSignatureSigningResponse.OrderSigningInfo[0].LoanDetails.Length)
                {
                    //ServiceHelper.GetStatusOnReport(false, "Loan details not matching the request");
                    Reports.StatusUpdate("Loan details not matching the request", false);
                }
                //SetOrderSigningRequest.LoanDetails.LoanDetailArray0.LoanAmount
                dynamic LoanDetail = getSignatureSigningResponse.OrderSigningInfo[0].LoanDetails[0];
                ServiceHelper.ContainsUIVal(FastDriver.SignatureSigning.LoanAmount, "text", getSignatureSigningResponse.OrderSigningInfo[0].LoanDetails[0].LoanAmount.ToString(), true, true);
                ServiceHelper.ContainsUIVal(FastDriver.SignatureSigning.LoanNumber, "text", getSignatureSigningResponse.OrderSigningInfo[0].LoanDetails[0].LoanNum.ToString(), true, true);

            }
            catch (Exception ex)
            {
                Reports.StatusUpdate(ex.Message, false);
            }
        }



        /// <summary>
        /// Author : Yusuf
        /// Date : 29 Dec 2015
        /// Order 1
        /// </summary>
        [TestMethod]
        public void REG_SetSignatureSigning()
        {
            Reports.TestStep = "Login to FAST";
            try
            {
                Reports.TestStep = "Login to FAST and create a file";
                #region FAST Login IIS side
                Reports.TestStep = "Login to IIS";
                FAST_Login_IIS();
                #endregion

                Reports.TestStep = "Create a file using WCF and get the fileId.";
                int fileId = CreateFile();

                var setSignatureSigningRequest = CreateOrderSigningRequest(fileId);

                var setSignatureSigningResponse = ServiceFactory.GetFileService().SetSignatureSigning(setSignatureSigningRequest);

                Reports.TestStep = "Verifying the Service Response";

                Reports.StatusUpdate("Is status == 1 in the response ?", Convert.ToInt16(setSignatureSigningResponse.Status).Equals(1));
                Reports.StatusUpdate("Is the status description as expected in the response ?", setSignatureSigningResponse.StatusDescription.ToLower().ToString().Contains("signing [s.no. 01] created successfully in pending status"));

                FastDriver.LeftNavigation.Navigate<SignatureSigning>(@"Home>Order Entry>Escrow Closing>Signature Signing").WaitForScreenToLoad();
                ServiceHelper.CompareUIDate(FastDriver.SignatureSigning.ProposedDate, "value", setSignatureSigningRequest.SigningDetails.ProposedDate.ToString());
                ServiceHelper.ContainsUIVal(FastDriver.SignatureSigning.ProposedTime, "value", setSignatureSigningRequest.SigningDetails.ProposedTime.ToString());
                ServiceHelper.ContainsUIVal(FastDriver.SignatureSigning.SpecialInstructions, "text", setSignatureSigningRequest.SigningDetails.SpecialInstructions.ToString());

                ServiceHelper.ContainsUIVal(FastDriver.SignatureSigning.SigningAddressLine1, "text", setSignatureSigningRequest.SigningAddress.PhysicalAddress.AddrLine1.ToString());
                ServiceHelper.ContainsUIVal(FastDriver.SignatureSigning.SigningAddressLine2, "text", setSignatureSigningRequest.SigningAddress.PhysicalAddress.AddrLine2.ToString());
                ServiceHelper.ContainsUIVal(FastDriver.SignatureSigning.SigningAddressCity, "text", setSignatureSigningRequest.SigningAddress.PhysicalAddress.City.ToString());
                ServiceHelper.ContainsUIVal(FastDriver.SignatureSigning.SigningAddressstate, "selecteditem", setSignatureSigningRequest.SigningAddress.PhysicalAddress.State.ToString());
                ServiceHelper.ContainsUIVal(FastDriver.SignatureSigning.SigningAddressZip, "text", setSignatureSigningRequest.SigningAddress.PhysicalAddress.Zip.ToString());


                ServiceHelper.ContainsUIVal(FastDriver.SignatureSigning.DeliveryAddressLine1, "text", setSignatureSigningRequest.DeliverAddress.PhysicalAddress.AddrLine1.ToString());
                ServiceHelper.ContainsUIVal(FastDriver.SignatureSigning.DeliveryAddressLine2, "text", setSignatureSigningRequest.DeliverAddress.PhysicalAddress.AddrLine2.ToString());
                ServiceHelper.ContainsUIVal(FastDriver.SignatureSigning.DeliveryAddressCity, "text", setSignatureSigningRequest.DeliverAddress.PhysicalAddress.City.ToString());
                ServiceHelper.ContainsUIVal(FastDriver.SignatureSigning.DeliveryAddressState, "selecteditem", setSignatureSigningRequest.DeliverAddress.PhysicalAddress.State.ToString());
                ServiceHelper.ContainsUIVal(FastDriver.SignatureSigning.DeliveryAddressZip, "text", setSignatureSigningRequest.DeliverAddress.PhysicalAddress.Zip.ToString());


                //The below validations for PrimaryAddress have failures. myFAMS is the sole interface partner as per iGuide using this operation. Since no confirmation from them so far on these failures, commenting the below validations. - 17-Jul-2016
                /*ServiceHelper.ContainsUIVal(FastDriver.SignatureSigning.PrimaryAddressLine1, "text", setSignatureSigningRequest.PrimaryAddress.PhysicalAddress.AddrLine1.ToString());
                ServiceHelper.ContainsUIVal(FastDriver.SignatureSigning.PrimaryAddressLine2, "text", setSignatureSigningRequest.PrimaryAddress.PhysicalAddress.AddrLine2.ToString());
                ServiceHelper.ContainsUIVal(FastDriver.SignatureSigning.PrimaryAddressCity, "text", setSignatureSigningRequest.PrimaryAddress.PhysicalAddress.City.ToString());
                ServiceHelper.ContainsUIVal(FastDriver.SignatureSigning.PrimaryAddressState, "selecteditem", setSignatureSigningRequest.PrimaryAddress.PhysicalAddress.State.ToString());
                ServiceHelper.ContainsUIVal(FastDriver.SignatureSigning.PrimaryAddressZip, "text", setSignatureSigningRequest.PrimaryAddress.PhysicalAddress.Zip.ToString());*/


                if ((FastDriver.SignatureSigning.BuyerSummaryTable.GetRowCount()) == setSignatureSigningRequest.BuyerDetails.Length)
                {
                    //dynamic buyerDetail = setSignatureSigningRequest.BuyerDetails[0];
                    ServiceHelper.ContainsUIVal(FastDriver.SignatureSigning.BuyerDetailsFirstName, "text", setSignatureSigningRequest.BuyerDetails[0].FirstName.ToString());
                    ServiceHelper.ContainsUIVal(FastDriver.SignatureSigning.BuyerDetailsLastName, "text", setSignatureSigningRequest.BuyerDetails[0].LastName.ToString());
                    ServiceHelper.ContainsUIVal(FastDriver.SignatureSigning.BuyerPhonesHomeNumber, "text", setSignatureSigningRequest.BuyerDetails[0].PhoneDetails[0].Number.ToString(), true);
                    ServiceHelper.ContainsUIVal(FastDriver.SignatureSigning.BuyerPhonesHomeExtension, "text", setSignatureSigningRequest.BuyerDetails[0].PhoneDetails[0].Ext.ToString(), true);

                }
                /*
                 * Loan Details*/

                if ((FastDriver.SignatureSigning.LoanSummaryTable.GetRowCount() - 1) != setSignatureSigningRequest.LoanDetails.Length)
                {
                    Reports.StatusUpdate("Loan details not matching the request", false);
                }
                dynamic LoanDetail = setSignatureSigningRequest.LoanDetails[0];
                ServiceHelper.ContainsUIVal(FastDriver.SignatureSigning.LoanAmount, "text", setSignatureSigningRequest.LoanDetails[0].LoanAmount.ToString(), true, true);
                ServiceHelper.ContainsUIVal(FastDriver.SignatureSigning.LoanNumber, "text", setSignatureSigningRequest.LoanDetails[0].LoanNum.ToString(), true, true);
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate(ex.Message, false);
            }
        }

        [TestMethod]
        public void REG0001_SetDeliverSigningPackage()
        {
            try
            {
                Reports.TestDescription = "Verify SetDeliverSigningPackage service";

                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };
                //Create file in QA Sandpointe Office
                var fileRequest = RequestFactory.GetDetailedCreateFileDefaultRequest(189, 191);
                fileRequest.File.BusinessParties[0].AddrBookEntryID = AdminService.GetGABAddressBookEntryId("BOA", 189);
                fileRequest.File.NewLoan.FileBusinessParty.AddrBookEntryID = AdminService.GetGABAddressBookEntryId("BOA", 189);
                #endregion

                Reports.TestStep = "Log into FAST application, navigate to QA Sandpointe Office";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);
                FastDriver.SecuritySelectRegionOffice.Open();
                FastDriver.SecuritySelectRegionOffice.EnterBUID("191");

                Reports.TestStep = "Create a file using web service";
                int fileId = FastDriver.FACreateFileGetFileId(fileRequest);
                string fileNum = FileService.GetOrderDetails(fileId).FileNumber;
                FastDriver.TopFrame.SearchFileByFileNumber(fileNum);

                Reports.TestStep = "Create a signing order using web service (WS)";
                var signatureSigningRequest = CreateOrderSigningRequest(fileId);
                signatureSigningRequest.LoanDetails[0].LenderAddressBookEntryID = AdminService.GetGABAddressBookEntryId("BOA", 189);
                ServiceFactory.GetFileService().SetSignatureSigning(signatureSigningRequest);

                Reports.TestStep = "Create a signing order using web service (WS)";
                var getSigningResponse = SignatureSigningHelpers.GetSignatureSigning(fileId);
                int signingID = (int)getSigningResponse.OrderSigningInfo[0].SigningDetails.SigningID;

                Reports.TestStep = "Submit the signing order using web service (WS)";
                SignatureSigningHelpers.SetOrderSigning(fileId, signingID);

                Reports.TestStep = "Navigate to Signature Signing screen, validate sigining Ordered status";
                FastDriver.SignatureSigning.Open();

                string currentStatus = "";

                for (int i = 0; i <= 6; i++)
                {
                    currentStatus = FastDriver.SignatureSigning.SigningSummary.PerformTableAction(1, 4, TableAction.GetText).Message.Clean();

                    if (currentStatus == "Ordered")
                        break;
                    else
                    {
                        Thread.Sleep(10000);
                        FastDriver.SignatureSigning.Open();
                    }
                }

                if (currentStatus != "Ordered")
                    throw new Exception("Signing is not in Ordered status! Make sure the environment is connected to FASSNotary interface.");

                Reports.TestStep = "Invoke SetDeliverSigningPackage method, and validate response (WS)";
                var request = FileRequestFactory.GetDeliverSigningPackageRequest(fileId, signingID);
                var response = SignatureSigningHelpers.SetDeliverSigningPackage(request);
                Support.AreEqual("1", response.Status.ToString(), "Operation Status");
                Support.AreEqual("Operation Deliver Signing Package successful, Signing package delivery requested successfully", response.StatusDescription, "Status Description");
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
            finally { FastDriver.WebDriver.Quit(); }
        }
        
        [TestMethod]
        public void REG_SetOrderSigning()
        {
            int signingId = 0;
            int signingPartyId = 0;

            try
            {

                Reports.TestDescription = "Verify GetAdditionalInfoDetails operation.";
                #region FAST Login IIS side
                FAST_Login_IIS();
                #endregion

                var fileID = CreateFile();

                SetupPreRequisiteForOrderSigning(fileID, out signingId, out signingPartyId);

                var request = new OrderSigningRequest();

                request.EmployeeID = 1;
                request.FileID = fileID;
                request.SigningID = signingId;
                request.LoginName = "fastts\\fastqa07";
                request.Source = "FAMOS";

                Reports.TestStep = "Invoke SetOrderSigning operation.";
                var response = ServiceFactory.GetFileService().SetOrderSigning(request);
                Reports.StatusUpdate("SetOrderSigning operation invoked !", true);

                Reports.TestStep = "Verify the operation response.";
                
                Reports.StatusUpdate("Status field in the response is as expected ?", response.Status.ToString().Equals("1"));

                Reports.TestStep = "Verify the outcome on UI. Navigate to Signature Signing screen.";
                FastDriver.LeftNavigation.Navigate<SignatureSigning>(@"Home>Order Entry>Escrow Closing>Signature Signing").WaitForScreenToLoad();

                Support.AreEqual("Submitted",FastDriver.SignatureSigning.SigningSummary.PerformTableAction(1,4,TableAction.GetText).Message.Clean());
               // Support.AreEqual("Submitted", FastDriver.SignatureSigning.Status.FAGetValue());
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("Exception in Test Method - REG_SetOrderSigning : " + ex.Message, false);
            }
        }



        [TestMethod]
        public void REG_UpdateSignatureSigning()
        {
            try
            {
                int signingId = 0;
                int signingPartyId = 0;

                Reports.TestDescription = "Verify UpdateSignatureSigning operation.";

                #region FAST Login IIS side
                FAST_Login_IIS();
                #endregion

                var fileID = CreateFile();

                SetupPreRequisiteForOrderSigning(fileID, out signingId, out signingPartyId);

                var request = CreateRequestForUpdateSignatureSigning(fileID, signingId, signingPartyId);

                request.SignatureSigningDetail.FileID = fileID;
                request.SignatureSigningDetail.SigningID = signingId;

                request.oBuyerDetails[0].SigningID = signingId;
                request.oBuyerDetails[0].SigningPartyID = signingPartyId;


                request.SignatureSigningDetail.ProposedDate = DateTime.Today.AddDays(2).ToDateString();
                request.SignatureSigningDetail.ProposedTime = "07:56:03 AM";

                
                var response = ServiceFactory.GetFileService().UpdateSignatureSigning(request);

                Reports.TestStep = "Verify the operation response.";
                Reports.StatusUpdate("Is status == 1 in the response ?", Convert.ToInt16(response.Status).Equals(1));
                Reports.StatusUpdate("Is the status description as expected in the response ?", response.StatusDescription.ToLower().ToString().Contains("signaturesigning updated sucessfully"));


                Reports.TestStep = "Verify the outcome on UI. Navigate to Signature Signing screen.";
                FastDriver.LeftNavigation.Navigate<SignatureSigning>(@"Home>Order Entry>Escrow Closing>Signature Signing").WaitForScreenToLoad();

                Support.AreEqual(FastDriver.SignatureSigning.ProposedDate.FAGetValue(), request.SignatureSigningDetail.ProposedDate);
                Support.AreEqual(FastDriver.SignatureSigning.ProposedTime.FAGetValue(), request.SignatureSigningDetail.ProposedTime);
                Support.AreEqual(FastDriver.SignatureSigning.SpecialInstructions.FAGetValue(), request.SignatureSigningDetail.SpecialInstructions);

                Support.AreEqual(FastDriver.SignatureSigning.BuyerDetailsFirstName.FAGetValue(), RemoveSpecialCharacters(request.oBuyerDetails[0].FirstName));
                Support.AreEqual(FastDriver.SignatureSigning.BuyerDetailsLastName.FAGetValue(), RemoveSpecialCharacters(request.oBuyerDetails[0].LastName));
                Support.AreEqual(FastDriver.SignatureSigning.BuyerPhonesHomeNumber.FAGetValue(), RemoveSpecialCharacters(request.oBuyerDetails[0].PhoneDetails[0].Number));
                Support.AreEqual(FastDriver.SignatureSigning.BuyerPhonesHomeExtension.FAGetValue(), RemoveSpecialCharacters(request.oBuyerDetails[0].PhoneDetails[0].Ext));
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("Exception in Test Method - REG_UpdateSignatureSigning : " + ex.Message, false);
            }
        }
        
        #region Private Functions
        private bool WaitForEnabled(IWebElement element = null)
        {
            //element = Principals;
            try
            {
                FastDriver.TermsDatesStatus.SwitchToContentFrame();
                //                element = element ?? FindNow;
                FastDriver.TermsDatesStatus.WaitCreation(element);
                FastDriver.TermsDatesStatus.Wait.Until(dr =>
                {
                    return element.IsEnabled();
                });
            }
            catch (Exception e)
            {
                return false;
            }
            return true;
        }


        public static string RemoveSpecialCharacters(string str, bool removeComma = false)
        {
            StringBuilder sb = new StringBuilder();
            if (removeComma)
            {
                return str.Replace(",", "");
            }

            else
            {
                str = Regex.Replace(str, @"[^0-9a-zA-Z]+", "");
                return str.ToString();
            }
        }


        private bool SetupPreRequisiteForOrderSigning(int fileID, out int signingId, out int signingPartyId)
        {
            try
            {
                Reports.TestStep = "As a pre-requisite for GetSignatureSigning, invoke SetSignatureSigning operation.";
                var signatureSigningRequest = CreateOrderSigningRequest(fileID);
                var signatureSigningResponse = ServiceFactory.GetFileService().SetSignatureSigning(signatureSigningRequest);
                Reports.StatusUpdate("SetSignatureSigning operation invoked !", true);
                Reports.StatusUpdate("Status Description in the response is as expected ?", signatureSigningResponse.StatusDescription.ToLower().ToString().Contains("signing [s.no. 01] created successfully in pending status"));
                Reports.StatusUpdate("Status field in the response is as expected ?", Convert.ToInt32(signatureSigningResponse.Status).Equals(1));


                Reports.TestStep = "As a pre-requisite, invoke GetSignatureSigning operation.";
                var getSignatureSigningResponse = ServiceFactory.GetFileService().GetSignatureSigning(fileID);
                signingId = (int)getSignatureSigningResponse.OrderSigningInfo[0].SigningDetails.SigningID;
                signingPartyId = (int)getSignatureSigningResponse.OrderSigningInfo[0].BuyerDetails[0].SigningPartyID;
                if (signingId != 0)
                {
                    Reports.StatusUpdate("GetSignatureSigning operation invoked successfully!", true);
                }
                else
                {
                    Reports.StatusUpdate("Exception occurred while invoking GetSignatureSigning operation!", false);
                }
                return true;
            }
            catch
            {
                signingId = 0;
                signingPartyId = 0;
                return false;
            }
        }

        private int CreateFile()
        {
            int fileID;
            #region Create a file through WCF
            Reports.TestStep = "Create a file with required values through WCF.";
            var fileRequest = CreateFileRequest();

            var fileResponse = FASTWCFHelpers.FileService.CreateFile(fileRequest);
            fileID = (int)fileResponse.FileID;
            Support.IsTrue((int)(fileResponse.FileID ?? 0) > 0, "Is this FileId valid ? " + fileID);

            var fileDetails = FASTWCFHelpers.FileService.GetOrderDetails(fileID);
            Reports.TestStep = "Search File in MRU.";
            FastDriver.TopFrame.SearchFileByFileNumber(fileDetails.FileNumber);
            #endregion

            return fileID;
        }


        private CreateFileRequest CreateFileRequest()
        {
            return new CreateFileRequest
            {
                EmployeeObjectCD = "1",
                Source = "FAMOS",
                formType = ClosingDisclosureSupport.FormType,

                File = new FASTWCFHelpers.FastFileService.File()
                {
                    TransactionTypeObjectCD = "SALE",
                    BusinessSegmentObjectCD = "Commercial",
                    ExternalFileNumber = "12345678905",
                    AutoNumberIndicator = true,

                    Buyers = new BuyerSeller[]
                    {

                        new BuyerSeller()
                        {
                            BuyerSellerTypeID = 48,
                            FirstName = "Bart",
                            LastName = "Simpson",
                            Type = "Individual",
                        },
                        new BuyerSeller()
                        {
                            BuyerSellerTypeID = 49,
                            FirstName = "Homer",
                            LastName = "Simpson",
                            SpouseFirstName = "Margarette",
                            SpouseLastName = "Simpson",
                            Type = "Husband and Wife",
                        },
                        new BuyerSeller()
                        {
                            ShortName = "TrusteeName",
                            BuyerSellerTypeID = 50,
                            Type = "Trust/Estate",
                        },
                         new BuyerSeller()
                        {
                            ShortName = "CompanyName",
                            BuyerSellerTypeID = 51,
                            Type = "Business Entity",
                        },
                    },

                    BusinessParties = new FileBusinessParty[] 
                    {
                        new FileBusinessParty()
                        {
                            //AddrBookEntryID = AdminService.GetGABAddressBookEntryId("8835227"),
                            AddrBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                            RoleTypeObjectCD = "BUSSOURCE",
                        } 
                    },

                    Services = new Service[] 
                    { 
                        new Service() 
                        { 
                            OfficeInfo = new OfficeInfo() 
                            { 
                                RegionID = int.Parse(ClosingDisclosureSupport.IMDRegionBUID), 
                                BUID = 1487,
                            },
                        ServiceTypeObjectCD = "TO" 
                        },
                        new Service() 
                        {
                            OfficeInfo = new OfficeInfo() 
                            { 
                                RegionID = int.Parse(ClosingDisclosureSupport.IMDRegionBUID), 
                                BUID = 1487, 
                            },
                            ServiceTypeObjectCD = "EO"
                        }
                    },

                    Properties = new Property[] 
                    { 
                        new Property() 
                        {
                            Name = "my-test-property",
                            PropertyAddress = new FASTWCFHelpers.FastFileService.PhysicalAddress[] 
                            {
                                
                                new FASTWCFHelpers.FastFileService.PhysicalAddress() 
                                { 
                                    AddrLine1 = "Address1",
                                    AddrLine2 = "Address2",
                                    State = "CA", 
                                    City = "Santa Ana", 
                                    County = "Orange", 
                                    Country = "USA" ,
                                    Zip = "12345"
                                } 
                            } 
                        } 
                    },


                }
            };
        }

        private SetOrderSigningRequest CreateOrderSigningRequest(int fileId)
        {
            return new SetOrderSigningRequest()
            {
                BuyerDetails = new BuyerDetail[]
                {
                    new BuyerDetail()
                    {
                        FirstName = "BuyerFirst",
                        LangPrefTypeCdID = 2545,
                        LastName = "BuyerLast",
                        NameEditable = true,
                        PhoneDetails = new PhoneDetail[]
                        {
                            new PhoneDetail()
                            {
                                ElectronicAddrCdID = 1398,
                                Ext = "11",
                                Number = "1231231234",
                            }
                        }
                    }
                },

                DeliverAddress = new SigningAddress()
                {
                    PhysicalAddrTypeCdID = 1375,
                    PhysicalAddress = new PhysicalAddress()
                    {
                        AddrLine1 = "DelAddress",
                        AddrLine2 = "Del Street",
                        City = "Del City",
                        Country = "Del Country",
                        Enddated = false,
                        State = "CA",
                        Zip = "12312"
                    }
                },

                LoanDetails = new LoanDetail[]
                {
                    new LoanDetail()
                    {
                        AddButtonEditable = true,
                        LenderAddressBookEntryID = AdminService.GetGABAddressBookEntryId("247"),
                        LoanAmount = "100.02",
                        LoanNum = "1212333",
                        SearchButtonEditable = true
                    }
                },

                PrimaryAddress = new SigningAddress()
                {
                    PhysicalAddrTypeCdID = 1376,
                    PhysicalAddress = new PhysicalAddress()
                    {
                        AddrLine1 = "Pri Addr",
                        AddrLine2 = "Pri street",
                        City = "Pri City",
                        Enddated = false,
                        State = "CA",
                        Zip = "12312"
                    },
                },
                SigningAddress = new SigningAddress()
                {
                    PhysicalAddress = new PhysicalAddress()
                    {
                        AddrLine1 = "Sig addr",
                        AddrLine2 = "Sig Street",
                        City = "Sig City",
                        Enddated = false,
                        State = "CA",
                        Zip = "11223",
                    }
                },

                SigningDetails = new SigningDetail()
                {
                    FileID = (int?)fileId,
                    OrderSource = "FAST",
                    SigningLocTypeCdID = 2543,
                    SigningMethodTypeCdID = 2534,
                    SpecialInstructions = "Validate set",
                    ProposedDate = DateTime.Today.AddDays(2).ToDateString(),
                    ProposedTime = "07:56:03 AM"
                },
            };
        }



        private UpdateSignatureSigningRequest CreateRequestForUpdateSignatureSigning(int fileID, int signingID, int signingPartyID)
        {
            return new UpdateSignatureSigningRequest()
            {
                
                SignatureSigningDetail = new SigningDetail
                {
                    CreationEmployeeID = 1,
                    FileID = fileID,
                    OrderID = 0,
                    OrderSource = "FAST",
                    SigningCancellationReasonID = 0,
                    SigningID = signingID,
                    SigningLocTypeCdID = 2543,
                    SigningMethodTypeCdID = 2534,
                    SigningQualityID = 0,
                    SpecialInstructions = "Update Validate Set",
                    StatusCD = 0,
                },
                
                oBuyerDetails = new BuyerDetail[]
                {
                    new BuyerDetail()
                    {
                        FirstName = "UpdateBuyer",
                        LastName = "Updated LastName",
                        NameEditable = true,
                        PhoneDetails = new PhoneDetail[]
                        {
                            new PhoneDetail()
                            {
                                ElectronicAddrCdID = 0,
                                Ext = "1122",
                                Number = "1245321522"
                            }
                        },
                        RemoveButtonEditable = true,
                        SigningID = signingId,
                        SigningPartyID = signingPartyID,
                        StaticSeqNum = 1
                    }
                },
                LoginName = "fastts\\fastqa07",
                Source = "FAST"
            };
        
        }


        #endregion

    }
}
