﻿using FASTSelenium.Common;
using FASTSelenium.DataObjects;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using Microsoft.VisualStudio.TestTools.UITesting;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumInternalHelpersSupportLibrary;
using System;


namespace WebServices.File
{
    [CodedUITest]
    public class EventLogWS : MasterTestClass
    {
        [TestMethod]
        public void REG0001_GetEventLogs()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan();
                #endregion

                Reports.TestDescription = "Verify GetEventLogs() service.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                var file = FileService.GetOrderDetails(FastDriver.FACreateFileGetFileId(fileRequest));
                FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

                Reports.TestStep = "Invoke the GetEventLogs method";
                var eventLogsResponse = FileService.GetEventLogs(file.FileID.Value, eventCategoryID: 1);

                Reports.TestStep = "Validate Event Logs in FAST UI";
                FastDriver.EventTrackingLog.Open();
                FastDriver.EventTrackingLog.EventTable.PerformTableAction("Event", eventLogsResponse.EventLogs[0].EventName, "Event", TableAction.Click);
                FastDriver.EventTrackingLog.EventTable.PerformTableAction("Source", eventLogsResponse.EventLogs[0].Source, "Source", TableAction.Click);
                FastDriver.EventTrackingLog.EventTable.PerformTableAction("User", eventLogsResponse.EventLogs[0].User, "User", TableAction.Click);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [TestMethod]
        public void REG0002_AddEventLogEntry()
        {
            try
            {
                #region data setup
                var credentials = new Credentials() { UserName = AutoConfig.UserName, Password = AutoConfig.UserPassword };

                var fileRequest = FileRequestFactory.GetCreateFileDefaultRequest();
                fileRequest.File.NewLoan = new FASTWCFHelpers.FastFileService.NewLoan();
                #endregion

                Reports.TestDescription = "Verify AddEventLogEntry() service.";

                Reports.TestStep = "Log into FAST application.";
                FASTLogin.Login(AutoConfig.FASTHomeURL, credentials, true);

                Reports.TestStep = "Create File using web service.";
                var file = FileService.GetOrderDetails(FastDriver.FACreateFileGetFileId(fileRequest));
                FastDriver.TopFrame.SearchFileByFileNumber(file.FileNumber);

                Reports.TestStep = "Invoke the GetEventLogs method";
                var eventLogsResponse = FileService.GetEventLogs(file.FileID.Value, eventCategoryID: 1);

                Reports.TestStep = "Invoke AddEventLogEntry method";
                var eventLogEntryRequest = FileRequestFactory.GetAddEventLogDefaultRequest(file.FileID.Value, eventId: eventLogsResponse.EventLogs[0].EventID.Value);
                var response = FileService.AddEventLogEntry(eventLogEntryRequest);
                Support.AreEqual("0", response.Status.ToString(), response.StatusDescription);

                Reports.TestStep = "Navigate to Event / Tracking Log page";
                FastDriver.EventTrackingLog.Open();

                Reports.TestStep = "Validate Event Logs in FAST UI";
                FastDriver.EventTrackingLog.EventTable.PerformTableAction("Comments", eventLogEntryRequest.Comments, "Comments", TableAction.Click);
            }
            catch (Exception ex)
            {
                FailTest(ex.Message);
            }
        }

        [ClassCleanup]
        public static void ClassCleanup() { MasterTestClass.CleanupClass(); }
    }
}
