﻿using FASTWCFHelpers.FastEscrowService;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FASTWCFHelpers.Factories;
using SeleniumInternalHelpersSupportLibrary;

namespace WebServices.Helpers.Escrow
{
    class FeeCalculationHelper
    {
        public static FeesCalculationSummaryResponse GetFeeCalculationSummaryDetail(int ?fileID)
        {
            var response = new FeesCalculationSummaryResponse();
            bool result = false;
            try
            {
                response = FASTWCFHelpers.EscrowService.GetCalculationFees(EscrowRequestFactory.GetCalculationFeesRequest(fileID));
                result = (response.Status == 1) ? true : false;
                Reports.StatusUpdate(response.StatusDescription, result);
            }
            catch
            {
                Reports.StatusUpdate(response.StatusDescription, result);
            }
            return response;
        }

        public static FastFeeDescriptionResponse GetFastFeeDescription(FastFeeDescriptionRequest request)
        {
            var response = new FastFeeDescriptionResponse();
            bool result = false;
            try
            {
                response = FASTWCFHelpers.EscrowService.GetFastFeeDescription(request);
                result = (response.Status == 1) ? true : false;
                Reports.StatusUpdate(response.StatusDescription, result);
            }
            catch
            {
                Reports.StatusUpdate(response.StatusDescription, result);
            }
            return response;
        }
    }
}
