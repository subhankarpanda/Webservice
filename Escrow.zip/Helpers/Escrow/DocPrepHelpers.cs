﻿using FASTWCFHelpers.FastEscrowService;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FASTWCFHelpers.Factories;
using SeleniumInternalHelpersSupportLibrary;

namespace WebServices.Helpers.Escrow
{
    class DocPrepHelpers
    {
        public static ALTASettlementStatementResponse GetALTASettlementStatementDetails(int fileID)
        {
            var response = new ALTASettlementStatementResponse();
            bool result = false;
            try
            {
                var request = EscrowRequestFactory.GetALTASettlementStatementRequest(fileID);
                response = FASTWCFHelpers.EscrowService.GetALTASettlementStatement(request);
                result = (response.Status == 1) ? true : false;
                Reports.StatusUpdate(response.StatusDescription, result);
            }
            catch
            {
                Reports.StatusUpdate(response.StatusDescription, result);
            }
            return response;
        }
    }
}
