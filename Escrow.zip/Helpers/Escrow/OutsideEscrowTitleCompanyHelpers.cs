﻿using FASTWCFHelpers.FastEscrowService;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebServices.Helpers.Escrow
{
    class OutsideEscrowTitleCompanyHelpers
    {
        
        public static OperationResponse CreateOutsideEscrowCompany(OECRequest request)
        {
            OperationResponse response = null;

            try
            {
                response = FASTWCFHelpers.EscrowService.CreateOutsideEscrowCompany(request);

                Reports.StatusUpdate("CreateOutsideEscrowCompany", true);

            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("CreateOutsideEscrowCompany", false, ex.Message);
            }

            return response;

        }

        public static OECResponse GetOutsideEscrowCompanyDetails(ServiceFileRequest request)
        {
            OECResponse response = null;

            try
            {
                response = FASTWCFHelpers.EscrowService.GetOutsideEscrowCompanyDetails(request);

                Reports.StatusUpdate("GetOutsideEscrowCompanyDetails", true);

            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("GetOutsideEscrowCompanyDetails", false, ex.Message);
            }

            return response;

        }

        public static OTCResponse GetOutsideTitleCompanyDetails(ServiceFileRequest request)
        {
            OTCResponse response = null;

            try
            {
                response = FASTWCFHelpers.EscrowService.GetOutsideTitleCompanyDetails(request);

                Reports.StatusUpdate("GetOutsideTitleCompanyDetails", true);

            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("GetOutsideTitleCompanyDetails", false, ex.Message);
            }

            return response;

        }

        public static CreateOutsideTitleCompanyResponse CreateOutsideTitleCompany(OutsideTitleCompanyRequest request)
        {
            CreateOutsideTitleCompanyResponse response = null;

            try
            {
                response = FASTWCFHelpers.EscrowService.CreateOutsideTitleCompany(request);

                Reports.StatusUpdate("CreateOutsideTitleCompany", true);

            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("CreateOutsideTitleCompany", false, ex.Message);
            }

            return response;

        }

        public static OperationResponse UpdateOutsideTitleCompanyDetails(OTCRequest request)
        {
            OperationResponse response = null;

            try
            {
                response = FASTWCFHelpers.EscrowService.UpdateOutsideTitleCompanyDetails(request);

                Reports.StatusUpdate("UpdateOutsideTitleCompanyDetails", true);

            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("UpdateOutsideTitleCompanyDetails", false, ex.Message);
            }

            return response;

        }

        public static OperationResponse UpdateOutsideEscrowCompanyDetails(OECRequest request)
        {
            OperationResponse response = null;

            try
            {
                response = FASTWCFHelpers.EscrowService.UpdateOutsideEscrowCompanyDetails(request);

                Reports.StatusUpdate("UpdateOutsideEscrowCompanyDetails", true);

            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("UpdateOutsideEscrowCompanyDetails", false, ex.Message);
            }

            return response;

        }

    }
}
