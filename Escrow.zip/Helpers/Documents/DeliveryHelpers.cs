﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastDocumentService;
using SeleniumInternalHelpersSupportLibrary;

namespace WebServices.Helpers.Documents
{
    class DeliveryHelpers
    {
        public static DeliveryResponse EmailDelivery(int fileID, int docID)
        {
            DeliveryResponse response = null;

            try
            {
                var request = DocumentRequestFactory.GetEmailDeliveryRequest(fileID, docID);
                response = FASTWCFHelpers.DocumentService.EmailDelivery(request);

                Reports.StatusUpdate("EmailDelivery", true, response.StatusDescription);
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("EmailDelivery", false, ex.Message);
            }

            return response;
        }


        public static DeliveryResponse FaxDelivery(int fileID, int docID)
        {
            DeliveryResponse response = null;

            try
            {
                var request = DocumentRequestFactory.GetFaxDeliveryRequest(fileID, docID);
                response = FASTWCFHelpers.DocumentService.FaxDelivery(request);

                Reports.StatusUpdate("FaxDelivery", true, response.StatusDescription);
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("FaxDelivery", false, ex.Message);
            }

            return response;
        }


        public static DeliveryResponse FeeEntryDelivery(int fileID)
        {
            DeliveryResponse response = null;

            try
            {
                var request = DocumentRequestFactory.GetEmailFeeEntryDeliveryRequest(fileID);
                response = FASTWCFHelpers.DocumentService.FeeEntryDelivery(request);

                Reports.StatusUpdate("FeeEntryDelivery", true, response.StatusDescription);
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("FeeEntryDelivery", false, ex.Message);
            }

            return response;
        }


        public static DeliveryResponse WintrackDelivery(WintrackDeliveryRequest request)
        {
            DeliveryResponse response = null;
            try
            {
                response = FASTWCFHelpers.DocumentService.WintrackDelivery(request);

                Reports.StatusUpdate("WintrackDelivery", true, response.StatusDescription);
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("WintrackDelivery", false, ex.Message);
            }
            return response;
        }


        public static DeliveryResponse LACOMDelivery(LACOMDeliveryRequest request)
        {
            DeliveryResponse response = null;

            try
            {
                response = FASTWCFHelpers.DocumentService.LACOMDelivery(request);

                Reports.StatusUpdate("LACOMDelivery", true);

            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("LACOMDelivery", false, ex.Message);
            }

            return response;

        }

    }
}
