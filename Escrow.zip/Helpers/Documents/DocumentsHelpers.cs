﻿using FASTWCFHelpers;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastDocumentService;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebServices.Helpers.Documents
{
    class DocumentsHelpers
    {
        public static OperationResponse AddDocumentsToAssociateDocPackage(int fileID, Document[] docs, long packageID)
        {
            OperationResponse response = null;

            try
            {
                var request = DocumentRequestFactory.GetAddDocumentToAssociateDocPackageDefaultRequest(fileID, docs);
                request.PackageID = (int)packageID;
                response = FASTWCFHelpers.DocumentService.AddDocumentsToAssociateDocPackage(request);

                Reports.StatusUpdate("AddDocumentsToAssociateDocPackage", true, response.StatusDescription);
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("AddDocumentsToAssociateDocPackage", false, ex.Message);
            }

            return response;
        }

        public static DocTemplateResponse GetDefaultDocTemplates()
        {
            DocTemplateResponse response = null;

            try
            {
                DocTemplateRequest GetDocTempReq =DocumentRequestFactory.GetDocTemplatesDefaultRequest();
                response = FASTWCFHelpers.DocumentService.GetDocTemplates(GetDocTempReq);
                Reports.StatusUpdate("GetDefaultDocTemplates", true, "Count: " + response.Templates.Count().ToString());

            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("GetDefaultDocTemplates", false, ex.Message);
            }

            return response;

        }

        public static DocumentResponse CreateDocument(int fileID, int templateID)
        {
            DocumentResponse response = null;

            try
            {
                var CreateDocReq = DocumentRequestFactory.GetCreateDocumentDefaultRequest(fileID, templateID);
                response = FASTWCFHelpers.DocumentService.CreateDocument(CreateDocReq);
                Reports.StatusUpdate("CreateDocument", true, "DocID: " + response.DocumentID.ToString());
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("CreateDocument", false, ex.Message);
            }

            return response;
        }

        public static OperationResponse AddPhrasesToDocument(int fileID, int docID, string phraseCode = @"XRL/15", int region = 1486, int position = 1)
        {
            OperationResponse response = null;

            try
            {
                var request = DocumentRequestFactory.GetAddPhraseDefaultRequest(fileID,docID);
                request.DocumentID = docID;
                request.FileID = fileID;
                request.Phrases[0].PhraseCode = phraseCode;
                request.Phrases[0].PhraseRegionID = region;
                request.PositionToInsert = position;
                request.LoginName = @"fastts\fastqa07";
                request.Source = @"FAMOS";
                response = FASTWCFHelpers.DocumentService.AddPhrasesToDocument(request);

                Reports.StatusUpdate("AddPhrasesToDocument", true, response.StatusDescription);
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("AddPhrasesToDocument", false, ex.Message);
            }

            return response;
        }

        public static DocumentResponse CreateAssociateDocPackage(int fileID, Document[] docs, string packageName)
        {
            DocumentResponse response = null;

            try
            {
                var request = DocumentRequestFactory.GetCreateAssociateDocPackageDefaultRequest(fileID, docs, packageName);
                response = FASTWCFHelpers.DocumentService.CreateAssociateDocPackage(request);

                Reports.StatusUpdate("CreateAssociateDocPackage", true, response.StatusDescription);
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("CreateAssociateDocPackage", false, ex.Message);
            }

            return response;
        }

        public static OperationResponse EditDocument(int fileID, int docID, string editDocName)
        {
            OperationResponse response = null;

            try
            {
                var request = DocumentRequestFactory.GetEditDocumentDefaultRequest(fileID, docID, editDocName);
                response = FASTWCFHelpers.DocumentService.EditDocument(request);

                Reports.StatusUpdate("EditDocument", true, response.StatusDescription);
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("EditDocument", false, ex.Message);
            }

            return response;
        }

        public static OperationResponse FinalizeDocument(int fileID, int docID)
        {
            OperationResponse response = null;

            try
            {
                var request = DocumentRequestFactory.GetFinalizeDocumentRequest(fileID, docID);
                response = FASTWCFHelpers.DocumentService.FinalizeDocument(request);

                Reports.StatusUpdate("FinalizeDocument", true, response.StatusDescription);
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("FinalizeDocument", false, ex.Message);
            }

            return response;
        }

        public static AssociateDocPackageResponse GetAssociateDocPackages(ServiceFileRequest request)
        {
            AssociateDocPackageResponse response = null;

            try
            {
                response = FASTWCFHelpers.DocumentService.GetAssociateDocPackages(request);

                Reports.StatusUpdate("GetAssociateDocPackages", true, response.StatusDescription);
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("GetAssociateDocPackages", false, ex.Message);
            }

            return response;
        }

        public static DocumentDetailsResponse GetDocumentDetails(int fileID, int docID)
        {
            FASTWCFHelpers.FastDocumentService.DocumentDetailsResponse response = null;

            try
            {
                DocumentRequest request = DocumentRequestFactory.GetDocumentRequest(fileID, docID);
                response = FASTWCFHelpers.DocumentService.GetDocumentDetails(request);
                Reports.StatusUpdate("GetDocumentDetails", true, response.StatusMessage);
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("GetDocumentDetails", false, ex.Message);
            }

            return response;
        }

        public static OperationResponse AddPhraseMarker(int fileID, int docID)
        {
            var respnc = new OperationResponse();
            try
            {
                respnc = FASTWCFHelpers.DocumentService.AddPhraseMarker(DocumentRequestFactory.GetAddPhraseMarkerDefaultRequest(fileID, docID));
                if (respnc.Status == 1)
                {
                    Reports.StatusUpdate("AddPhraseMarker service has been invoked successfully.", true);
                }
                else
                {
                    Reports.StatusUpdate("AddPhraseMarker service is not invoked successfully.", false);
                }
            }
            catch
            {
                Reports.StatusUpdate("AddPhraseMarker service is not invoked successfully.", false);
            }
            return respnc;
        }

        public static OperationResponse CreateImageDocument(int fileID, int docID)
        {
            OperationResponse response = null;
            bool result = false;
            try
            {
                var request = DocumentRequestFactory.GetCreateImageDocumentDefaultRequest();
                request.DocumentID = docID;
                request.FileID = fileID;
                response = FASTWCFHelpers.DocumentService.CreateImageDocument(request);
                result = (response.Status == 1) ? true : false;
                Reports.StatusUpdate(response.StatusDescription,result);
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("CreateImageDocument", false, ex.Message);
            }

            return response;
        }

        public static OperationResponse DeletePhraseFromDocument(int fileID, int docID, long phraseID)
        {
            OperationResponse response = null;

            try
            {
                response = FASTWCFHelpers.DocumentService.DeletePhrases(DocumentRequestFactory.GetDeletePhraseRequest(fileID, docID, phraseID));
                Reports.StatusUpdate("DeletePhrasesFromDocument", true, "PhraseID: " + phraseID.ToString() + "is Deleted.");
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("DeletePhrasesFromDocument", false, ex.Message);
            }

            return response;
        }

        public static OperationResponse MovePhraseOfDocument(DocumentDetailsResponse docresponse)
        {
            OperationResponse response = null;

            try
            {
                response = FASTWCFHelpers.DocumentService.MovePhrase(DocumentRequestFactory.GetMovePhraseRequest(docresponse));
                if (response.Status == 1)
                {
                    Reports.StatusUpdate("Phrase has been moved successfuly:", true);
                }
                else
                {
                    Reports.StatusUpdate("Phrase has not been moved successfuly", false);
                }
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("MovePhraseOfDocument", false, ex.Message);
            }

            return response;
        }

        public static OperationResponse UpdatePhraseOfDocument(int fileID, int docID, long phraseID)
        {
            OperationResponse response = null;

            try
            {
                response = FASTWCFHelpers.DocumentService.UpdatePhrase(DocumentRequestFactory.GetDefaultUpdatePhraseRequest(fileID, docID, phraseID));
                if (response.Status == 1)
                {
                    Reports.StatusUpdate("UpdatePhraseOfDocument", true, "Document ID: " + docID.ToString() + "is updated.");
                }
                else
                {
                    Reports.StatusUpdate("UpdatePhraseOfDocument", false, "Document is not updated.");
                }
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("UpdatePhraseOfDocument", false, ex.Message);
            }

            return response;
        }

        public static DocPhraseResponse WaiveorUnWaivePhrase(int fileID, int docID, long docPhraseID, bool beWaiveFlag = false)
        {
            DocPhraseResponse respnc = null;
            try
            {
                respnc = FASTWCFHelpers.DocumentService.GetPhraseWaivedorUnwaived(DocumentRequestFactory.GetWaiveOrUnWaivePhraseRequest(fileID, docID, docPhraseID, beWaiveFlag));
                Reports.StatusUpdate(respnc.StatusDescription, (respnc.Status == 1) ? true : false);
            }
            catch
            {
                Reports.StatusUpdate("WaiveorUnwaivephrase webservice is not invoked successfully.", false);
            }
            return respnc;
        }

        public static OperationResponse DocumentRefresh(FASTWCFHelpers.FastDocumentService.DocumentDetailsResponse docDetails,int phraseSequence)
        {
            OperationResponse response = null;
            bool result = false;
            try
            {
                DocumentRefreshRequest request = DocumentRequestFactory.GetDocumentRefreshRequest(docDetails.FileID,docDetails.DocumentID);
                request.Phrases[0].DocPhraseId = docDetails.Phrases[phraseSequence - 1].DocPhraseID;
                request.Phrases[0].PhraseElements[0].DocPraseElementId = docDetails.Phrases[phraseSequence - 1].PhraseElements[0].DocPhraseElementID;
                response = FASTWCFHelpers.DocumentService.GetDocumentRefreshed(request);
                result = (response.Status == 1) ? true : false;
                Reports.StatusUpdate("DocumentRefresh webservice is invoked :"+response.StatusDescription, result);
            }
            catch
            {
                Reports.StatusUpdate("DocumentRefresh webservice is not invoked successfully.", false);
            }
            return response;
        }

        public static OperationResponse RemoveDocument(int fileID, int docID)
        {
            OperationResponse response = null;

            try
            {
                var request = DocumentRequestFactory.GetRemoveDocumentDefaultRequest(fileID);
                request.DocumentID = docID;
                 response = FASTWCFHelpers.DocumentService.RemoveDocument(request);

                Reports.StatusUpdate("RemoveDocument", true, response.StatusDescription);
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("RemoveDocument", false, ex.Message);
            }

            return response;
        }

        public static OperationResponse ModifyAssociateDocPackage(int fileID, Document[] docs, long packageID, string packageName = null, bool changeSequence = false)
        {
            OperationResponse response = null;

            try
            {
                var request = DocumentRequestFactory.GetModifyAssociateDocPackageDefaultRequest(fileID, docs);
                request.PackageID = (int)packageID;
                request.PackageName = packageName;
                if (changeSequence)
                {
                    request.DocumentList[0].SeqNum = 3;
                    request.DocumentList[1].SeqNum = 1;
                    request.DocumentList[2].SeqNum = 2;
                }
                response = FASTWCFHelpers.DocumentService.ModifyAssociateDocPackage(request);

                Reports.StatusUpdate("ModifyAssociateDocPackage", true, response.StatusDescription);
            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("ModifyAssociateDocPackage", false, ex.Message);
            }

            return response;
        }

        public static ImageDocumentResponse GetImageDocument(int fileId,int docID,int?imgDocID)
        {
            ImageDocumentResponse response = null;
            bool result = false;
            try
            {
                DocumentRequest request = DocumentRequestFactory.GetDocumentRequest(fileId, docID);
                request.ImageDocumentID = imgDocID;
                response = FASTWCFHelpers.DocumentService.GetImageDocument(request);
                result = (response.Status == 1) ? true : false;
                Reports.StatusUpdate("Invokation of GetImageDocument Webservice: "+response.StatusDescription, result);
            }
            catch
            {
                Reports.StatusUpdate("GetImageDocument service was not invoked successfully.", false);
            }
            return response;
        }

        public static ImageDocumentDetailsResponse GetImageDocumentDetails(int fileID,int docID, int? imgDocID)
        {
            ImageDocumentDetailsResponse response = null;
            bool status = false;
            try
            {
                DocumentRequest request = DocumentRequestFactory.GetDocumentRequest(fileID, docID);
                request.ImageDocumentID = imgDocID;
                response = FASTWCFHelpers.DocumentService.GetImageDocumentDetails(request);
            }
            catch
            {
                Reports.StatusUpdate("GetImageDocument service was not invoked successfully.", false);
            }
            return response;
        }

        public static OperationResponse PublishDocument(int?fileID, long?imageDocid, FileRoleType roleType)
        {
            OperationResponse response = null;
            bool result = false;
            try
            {
                PublishDocumentRequest request = DocumentRequestFactory.GetPublishDocumentRequest(fileID);
                request.ImageDocIds[0].ImageDocId = imageDocid;
                request.FileRolesToPublish[0].eFileRoleType = roleType;
                response = FASTWCFHelpers.DocumentService.PublishDocument(request);
                result = (response.Status == 1) ? true : false;
                Reports.StatusUpdate("PublissDocument service was invoked :"+response.StatusDescription, result);
            }
            catch
            {
                Reports.StatusUpdate("PublissDocument service was not invoked successfully.", false);
            }
            return response;
        }
    }
}
