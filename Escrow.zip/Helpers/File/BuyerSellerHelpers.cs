﻿using FASTSelenium.Common;
using FASTWCFHelpers;
using FASTWCFHelpers.DataObjects;
using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Web_Services_Regression.Regression.FileService;

namespace WebServices.Helpers.File
{
    public class BuyerSellerHelpers
    {
        public static void ExtentionTest()
        {
            //this is a helper method
        }

        public static AddBuyerSellerRequest GetBuyerSellerRequest()
        {
            var request = RequestFactory.GetAddBuyerSellerRequest(BuyerSellerTypeOCD.Individual);
            request.BuyerSeller.CurrentAddress = new FASTWCFHelpers.FastFileService.BuyerSellerAddress()
            {
                AddrLine1 = "CurrentAddress",
                AddrLine2 = "street line 2",
                AddrLine3 = "street line 3",
                AddrLine4 = "street line 4",
                BuyerSellerAddressTypeCdID = 80,
                City = "CurrentCity",
                Country = "USA",
                County = "Orange",
                State = "CA",
                Zip = "92130"
            };
            request.BuyerSeller.ForwardingAddress = new FASTWCFHelpers.FastFileService.BuyerSellerAddress()
            {
                AddrLine1 = "CurrentAddress",
                AddrLine2 = "street line 2",
                AddrLine3 = "street line 3",
                AddrLine4 = "street line 4",
                BuyerSellerAddressTypeCdID = 80,
                City = "CurrentCity",
                Country = "USA",
                County = "Orange",
                State = "CA",
                Zip = "92130"
            };
            request.BuyerSeller.ContactAddresses = new FASTWCFHelpers.FastFileService.ContactAddress[]
            {
                new FASTWCFHelpers.FastFileService.ContactAddress()
                {
                    ContextTypeCdID = ContextTypeCdID.Current,
                    Value = "(991)889-8383",
                    TypeCdID = ContactAddressTypeCdID.HomePhone,
                },
                new FASTWCFHelpers.FastFileService.ContactAddress()
                {
                    ContextTypeCdID = ContextTypeCdID.Forwarding,
                    Value = "(991)889-8383",
                    TypeCdID = ContactAddressTypeCdID.HomePhone,
                }
            };

            return request;
        }

        public static AddBuyerSellerRequest GetIndividualBuyerSellerRequest()
        {
            var request = GetBuyerSellerRequest();
            request.BuyerSeller.LoanApplicant = true;
            request.BuyerSeller.FirstName = "John";
            request.BuyerSeller.MiddleName = "Peter";
            request.BuyerSeller.LastName = "Colwyn";
            request.BuyerSeller.Suffix = "Jr.";
            request.BuyerSeller.SSN = "123456789";
            request.BuyerSeller.MaritalStatusCdID = BuyerSellerMaritalStatusCdID.SingleMan;
            request.BuyerSeller.VestingTypeCdID = BuyerSellerVestingCdID.ToBeDetermined;
            request.BuyerSeller.Salutation = "Dear Maestro";

            return request;
        }

        public static AddBuyerSellerRequest GetHusbandWifeBuyerSellerRequest()
        {
            var request = GetBuyerSellerRequest();
            request.BuyerSeller.LoanApplicant = true;
            request.BuyerSeller.SpouseLoanApplicant = false;
            request.BuyerSeller.FirstName = "John";
            request.BuyerSeller.MiddleName = "Peter";
            request.BuyerSeller.LastName = "Colwyn";
            request.BuyerSeller.Suffix = "Jr.";
            request.BuyerSeller.SSN = "123456789";
            request.BuyerSeller.MaritalStatusCdID = BuyerSellerMaritalStatusCdID.MarriedMan;
            request.BuyerSeller.VestingTypeCdID = BuyerSellerVestingCdID.ToBeDetermined;
            request.BuyerSeller.Salutation = "Dear Mr. & Mrs. Colwyn";
            request.BuyerSeller.SpouseFirstName = "Linda";
            request.BuyerSeller.SpouseMiddleName = "Elizabeth";
            request.BuyerSeller.SpouseLastName = "Colwyn";
            request.BuyerSeller.SpouseSuffix = "1st";
            request.BuyerSeller.SpouseSSN = "123456781";

            return request;
        }

        public static AddBuyerSellerRequest GetTrustEstateBuyerSellerRequest()
        {
            var request = GetBuyerSellerRequest();
            request.BuyerSeller.LoanApplicant = true;
            request.BuyerSeller.ShortName = "FAST Trust";
            request.BuyerSeller.Dated = DateTime.Today.AddYears(-1);
            request.BuyerSeller.TrustNumber = "12345678";
            request.BuyerSeller.SSN = "123456789";
            request.BuyerSeller.Salutation = "FAST Trust and Associates";

            return request;
        }

        public static AddBuyerSellerRequest GetBusinessTrustBuyerSellerRequest()
        {
            var request = GetBuyerSellerRequest();
            request.BuyerSeller.LoanApplicant = false;
            request.BuyerSeller.ShortName = "FAST Business Trust";
            request.BuyerSeller.SSN = "123456789";
            request.BuyerSeller.Salutation = "FAST Trust and Associates";
            request.BuyerSeller.StateOfIncorporationID = BuyerSellerStateOfIncorporationCdID.California;
            request.BuyerSeller.EntityTypeID = BuyerSellerEntityTypeCdID.BusinessTrust;

            return request;
        }

        public static void ValidateIndividualBuyerSeller(AddBuyerSellerRequest request)
        {
            var IndvidByrDictry = FastDriver.BuyerSellerSetup.GetIndivByrDtls;
            Support.AreEqual(request.BuyerSeller.FirstName, IndvidByrDictry["Indi First Name"], "Indi First Name");
            Support.AreEqual(request.BuyerSeller.MiddleName, IndvidByrDictry["Indi Middle Name"], "Indi Middle Name");
            Support.AreEqual(request.BuyerSeller.LastName, IndvidByrDictry["Indi Last Name"], "Indi Last Name");
            Support.AreEqual(request.BuyerSeller.Suffix, IndvidByrDictry["Indi Sufix"], "Indi Sufix");
            Support.AreEqual(request.BuyerSeller.SSN, IndvidByrDictry["Indi Ssn"].Replace("-", ""), "Indi Ssn");
            if (request.PrincipalType == BuyerSellerPrincipalTypeOCD.Buyer)
            {
                Support.AreEqual(request.BuyerSeller.LoanApplicant.ToString().ToLowerInvariant(), IndvidByrDictry["LoanApplicant"], "Loan Applicant");
            }
            //
            var VestiNSalutDictry = FastDriver.BuyerSellerSetup.GetIndiviVestgNdSalutio;
            Support.AreEqual("a single man", VestiNSalutDictry["Marital Status"], "Marital Status");
            Support.AreEqual(string.IsNullOrEmpty(VestiNSalutDictry["Vesting"]) ? "" : "(vesting to be determined)", VestiNSalutDictry["Vesting"], "Vesting");
            Support.AreEqual(string.IsNullOrEmpty(VestiNSalutDictry["Addl Vesting"]) ? "" : "Full Vesting", VestiNSalutDictry["Addl Vesting"], "Addl Vesting");
            Support.AreEqual("", VestiNSalutDictry["Misc Ref 1"], "Misc Ref 1");
            Support.AreEqual("", VestiNSalutDictry["Misc Ref 2"], "Misc Ref 2");
            //
            ValidateAddressAndContactDetails(request);
        }

        public static void ValidateHusbandWifeBuyerSeller(AddBuyerSellerRequest request)
        {
            var HuWfAndVestDictry = FastDriver.BuyerSellerSetup.GetHusWfDtlsAuthSign(false);
            Support.AreEqual(request.BuyerSeller.FirstName, HuWfAndVestDictry["Husband1FirstName"], "Husband1FirstName");
            Support.AreEqual(request.BuyerSeller.LastName, HuWfAndVestDictry["Husband2LastName"], "Husband 2 LastName");
            Support.AreEqual(request.BuyerSeller.SpouseFirstName, HuWfAndVestDictry["HusbandSpouseFirstName"], "HusbandSpouse FirstName");
            Support.AreEqual(request.BuyerSeller.SpouseMiddleName, HuWfAndVestDictry["HusbandSpouseMiddleName"], "HusbandSpouse MiddleName");
            Support.AreEqual(request.BuyerSeller.SpouseLastName, HuWfAndVestDictry["HusbandSpouseLastName"], "HusbandSpouse LastName");
            Support.AreEqual(request.BuyerSeller.SpouseSuffix, HuWfAndVestDictry["HusbandSpouseSuffix"], "HusbandSpouse Suffix");
            if (request.PrincipalType == BuyerSellerPrincipalTypeOCD.Buyer)
            {
                Support.AreEqual(request.BuyerSeller.LoanApplicant.ToString().ToLowerInvariant(), HuWfAndVestDictry["HusbandLoanApplicant"], " Husband Loan Applicant");
                Support.AreEqual(request.BuyerSeller.SpouseLoanApplicant.ToString().ToLowerInvariant(), HuWfAndVestDictry["SpouseLoanApplicant"], "Spouse Loan Applicant");
            }
            //
            var VestiNSalutDictry = FastDriver.BuyerSellerSetup.GetIndiviVestgNdSalutio;
            Support.AreEqual("a married man", VestiNSalutDictry["Marital Status"], "Marital Status");
            Support.AreEqual(string.IsNullOrEmpty(VestiNSalutDictry["Vesting"]) ? "" : "(vesting to be determined)", VestiNSalutDictry["Vesting"], "Vesting");
            Support.AreEqual(string.IsNullOrEmpty(VestiNSalutDictry["Addl Vesting"]) ? "" : "Full Vesting", VestiNSalutDictry["Addl Vesting"], "Addl Vesting");
            Support.AreEqual("", VestiNSalutDictry["Misc Ref 1"], "Misc Ref 1");
            Support.AreEqual("", VestiNSalutDictry["Misc Ref 2"], "Misc Ref 2");
            //
            ValidateAddressAndContactDetails(request);
        }

        public static void ValidateTrustEstateBuyerSeller(AddBuyerSellerRequest request)
        {
            var TrstEstByrDictry = FastDriver.BuyerSellerSetup.GetTrstestByrDtls(false);
            Support.AreEqual(request.BuyerSeller.ShortName, TrstEstByrDictry["TrusteeShortName"], "Trustee Short Name");
            Support.AreEqual(DateTime.Today.AddYears(-1).ToDateString(), TrstEstByrDictry["TrustDated"], "Trust Dated");
            Support.AreEqual(request.BuyerSeller.TrustNumber, TrstEstByrDictry["TrustNumber"], "Trust Number");
            Support.AreEqual("123-45-6789", TrstEstByrDictry["TrustSSNtext"], "Trust Ssn Text");
            if (request.PrincipalType == BuyerSellerPrincipalTypeOCD.Buyer)
            {
                Support.AreEqual(request.BuyerSeller.LoanApplicant.ToString().ToLowerInvariant(), TrstEstByrDictry["LoanApplicant"], "Loan Applicant");
            }
            ValidateAddressAndContactDetails(request);
        }

        public static void ValidateBusinessBuyerSeller(AddBuyerSellerRequest request)
        {
            var BusEntByrDictry = FastDriver.BuyerSellerSetup.GetBusEntByrDtls;
            Support.AreEqual(request.BuyerSeller.ShortName, BusEntByrDictry["BusinessEntityShortname"], "Bus Entity Shortname");
            Support.AreEqual("California", BusEntByrDictry["StateofIncorp"], "State of Incorp");
            Support.AreEqual("Business Trust", BusEntByrDictry["EntityType"], "Entity Type");
            Support.AreEqual("123-45-6789", BusEntByrDictry["BusinessEntitySSN"], "Business Entity Ssn");
            if (request.PrincipalType == BuyerSellerPrincipalTypeOCD.Buyer)
            {
                Support.AreEqual(request.BuyerSeller.LoanApplicant.ToString().ToLowerInvariant(), BusEntByrDictry["LoanApplicant"], "Loan Applicant");
            }
            ValidateAddressAndContactDetails(request);
        }

        public static void ValidateAddressAndContactDetails(AddBuyerSellerRequest request)
        {
            var CurAddrDictry = FastDriver.BuyerSellerSetup.GetCurrAddrDtls;
            Support.AreEqual(request.BuyerSeller.CurrentAddress.AddrLine1, CurAddrDictry["Curr Addr Street 1"], "Curr Addr Street 1");
            Support.AreEqual(request.BuyerSeller.CurrentAddress.AddrLine2, CurAddrDictry["Curr Addr Street 2"], "Curr Addr Street 2");
            Support.AreEqual(request.BuyerSeller.CurrentAddress.AddrLine3, CurAddrDictry["Curr Addr Street 3"], "Curr Addr Street 3");
            Support.AreEqual(request.BuyerSeller.CurrentAddress.AddrLine4, CurAddrDictry["Curr Addr Street 4"], "Curr Addr City");
            Support.AreEqual(request.BuyerSeller.CurrentAddress.City, CurAddrDictry["Curr Addr City"], "Curr Addr City");
            Support.AreEqual(request.BuyerSeller.CurrentAddress.State, CurAddrDictry["Curr Addr State"], "Curr Addr State");
            Support.AreEqual(request.BuyerSeller.CurrentAddress.County, CurAddrDictry["Curr Addr County"], "Curr Addr County");
            Support.AreEqual(request.BuyerSeller.CurrentAddress.Country, CurAddrDictry["Curr Addr Country"], "Curr Addr Country");
            //
            var ForwdAdrDictry = FastDriver.BuyerSellerSetup.GetForwdAdrDtls;
            Support.AreEqual(request.BuyerSeller.ForwardingAddress.AddrLine1, ForwdAdrDictry["Forward Addr Street 1"], "Forward Addr Street 1");
            Support.AreEqual(request.BuyerSeller.ForwardingAddress.AddrLine2, ForwdAdrDictry["Forward Addr Street 2"], "Forward Addr Street 2");
            Support.AreEqual(request.BuyerSeller.ForwardingAddress.AddrLine3, ForwdAdrDictry["Forward Addr Street 3"], "Forward Addr Street 3");
            Support.AreEqual(request.BuyerSeller.ForwardingAddress.AddrLine4, ForwdAdrDictry["Forward Addr Street 4"], "Forward Addr City");
            Support.AreEqual(request.BuyerSeller.ForwardingAddress.City, ForwdAdrDictry["Forward Addr City"], "Forward Addr City");
            Support.AreEqual(request.BuyerSeller.ForwardingAddress.State, ForwdAdrDictry["Forward Addr State"], "Forward Addr State");
            Support.AreEqual(request.BuyerSeller.ForwardingAddress.Country, ForwdAdrDictry["Forward Addr Country"], "Forward Addr Country");
            Support.AreEqual(request.BuyerSeller.ForwardingAddress.County, ForwdAdrDictry["Forward Addr County"], "Forward Addr County");
            //
            var CurrPhoDictry = FastDriver.BuyerSellerSetup.GetCurrentPhoneDetails();
            Support.AreEqual("(991)889-8383", CurrPhoDictry["Home Phone"].First(), "Current PhoneNum");
            var ForwdPhoDictry = FastDriver.BuyerSellerSetup.GetForwardingPhoneDetails();
            Support.AreEqual("(991)889-8383", ForwdPhoDictry["Home Fax"].First(), "Forwarding PhoneNum");
        }

        public static void ValidateFullVestingBuyerSeller(string vestingText)
        {
            FastDriver.BuyerSellerSetup.Full_Vesting();
            FastDriver.BuyerVesting.WaitForScreenToLoad();
            Support.AreEqual(vestingText, FastDriver.BuyerVesting.CompleteVesting.FAGetText(), "Complete Vesting");
        }

        public static UpdateBuyerSellerRequest GetBuyerSellerUpdateRequest()
        {
            var request = RequestFactory.GetUpdateBuyerSellerRequest(BuyerSellerTypeOCD.Individual);
            request.BuyerSeller.SeqNum = 1;
            request.BuyerSeller.CurrentAddress = new FASTWCFHelpers.FastFileService.BuyerSellerAddress()
            {
                AddrLine1 = "CurrentAddress",
                AddrLine2 = "street line 2",
                AddrLine3 = "street line 3",
                AddrLine4 = "street line 4",
                BuyerSellerAddressTypeCdID = 80,
                City = "CurrentCity",
                Country = "USA",
                County = "Orange",
                State = "CA",
                Zip = "92130"
            };
            request.BuyerSeller.ForwardingAddress = new FASTWCFHelpers.FastFileService.BuyerSellerAddress()
            {
                AddrLine1 = "CurrentAddress",
                AddrLine2 = "street line 2",
                AddrLine3 = "street line 3",
                AddrLine4 = "street line 4",
                BuyerSellerAddressTypeCdID = 80,
                City = "CurrentCity",
                Country = "USA",
                County = "Orange",
                State = "CA",
                Zip = "92130"
            };
            request.BuyerSeller.ContactAddresses = new FASTWCFHelpers.FastFileService.ContactAddress[]
            {
                new FASTWCFHelpers.FastFileService.ContactAddress()
                {
                    ContextTypeCdID = ContextTypeCdID.Current,
                    Value = "(991)889-8383",
                    TypeCdID = ContactAddressTypeCdID.HomePhone,
                },
                new FASTWCFHelpers.FastFileService.ContactAddress()
                {
                    ContextTypeCdID = ContextTypeCdID.Forwarding,
                    Value = "(991)889-8383",
                    TypeCdID = ContactAddressTypeCdID.HomePhone,
                }
            };

            return request;
        }

        public static UpdateBuyerSellerRequest GetIndividualBuyerSellerUpdateRequest()
        {
            var request = GetBuyerSellerUpdateRequest();
            request.BuyerSeller.LoanApplicant = true;
            request.BuyerSeller.FirstName = "John";
            request.BuyerSeller.MiddleName = "Peter";
            request.BuyerSeller.LastName = "Colwyn";
            request.BuyerSeller.Suffix = "Jr.";
            request.BuyerSeller.SSN = "123456789";
            request.BuyerSeller.MaritalStatusCdID = BuyerSellerMaritalStatusCdID.SingleMan;
            request.BuyerSeller.VestingTypeCdID = BuyerSellerVestingCdID.ToBeDetermined;
            request.BuyerSeller.Salutation = "Dear Maestro";

            return request;
        }

        public static UpdateBuyerSellerRequest GetHusbandWifeBuyerSellerUpdateRequest()
        {
            var request = GetBuyerSellerUpdateRequest();
            request.BuyerSeller.LoanApplicant = true;
            request.BuyerSeller.SpouseLoanApplicant = false;
            request.BuyerSeller.FirstName = "John";
            request.BuyerSeller.MiddleName = "Peter";
            request.BuyerSeller.LastName = "Colwyn";
            request.BuyerSeller.Suffix = "Jr.";
            request.BuyerSeller.SSN = "123456789";
            request.BuyerSeller.MaritalStatusCdID = BuyerSellerMaritalStatusCdID.MarriedMan;
            request.BuyerSeller.VestingTypeCdID = BuyerSellerVestingCdID.ToBeDetermined;
            request.BuyerSeller.Salutation = "Dear Mr. & Mrs. Colwyn";
            request.BuyerSeller.SpouseFirstName = "Linda";
            request.BuyerSeller.SpouseMiddleName = "Elizabeth";
            request.BuyerSeller.SpouseLastName = "Colwyn";
            request.BuyerSeller.SpouseSuffix = "1st";
            request.BuyerSeller.SpouseSSN = "123456781";

            return request;
        }

        public static UpdateBuyerSellerRequest GetTrustEstateBuyerSellerUpdateRequest()
        {
            var request = GetBuyerSellerUpdateRequest();
            request.BuyerSeller.LoanApplicant = true;
            request.BuyerSeller.ShortName = "FAST Trust";
            request.BuyerSeller.Dated = DateTime.Today.AddYears(-1);
            request.BuyerSeller.TrustNumber = "12345678";
            request.BuyerSeller.SSN = "123456789";
            request.BuyerSeller.Salutation = "FAST Trust and Associates";

            return request;
        }

        public static UpdateBuyerSellerRequest GetBusinessTrustBuyerSellerUpdateRequest()
        {
            var request = GetBuyerSellerUpdateRequest();
            request.BuyerSeller.LoanApplicant = false;
            request.BuyerSeller.ShortName = "FAST Business Trust";
            request.BuyerSeller.SSN = "123456789";
            request.BuyerSeller.Salutation = "FAST Trust and Associates";
            request.BuyerSeller.StateOfIncorporationID = BuyerSellerStateOfIncorporationCdID.California;
            request.BuyerSeller.EntityTypeID = BuyerSellerEntityTypeCdID.BusinessTrust;

            return request;
        }

        public static void ValidateIndividualBuyerSeller(UpdateBuyerSellerRequest request)
        {
            var IndvidByrDictry = FastDriver.BuyerSellerSetup.GetIndivByrDtls;
            Support.AreEqual(request.BuyerSeller.FirstName, IndvidByrDictry["Indi First Name"], "Indi First Name");
            Support.AreEqual(request.BuyerSeller.MiddleName, IndvidByrDictry["Indi Middle Name"], "Indi Middle Name");
            Support.AreEqual(request.BuyerSeller.LastName, IndvidByrDictry["Indi Last Name"], "Indi Last Name");
            Support.AreEqual(request.BuyerSeller.Suffix, IndvidByrDictry["Indi Sufix"], "Indi Sufix");
            Support.AreEqual(request.BuyerSeller.SSN, IndvidByrDictry["Indi Ssn"].Replace("-", ""), "Indi Ssn");
            if (request.PrincipalType == BuyerSellerPrincipalTypeOCD.Buyer)
            {
                Support.AreEqual(request.BuyerSeller.LoanApplicant.ToString().ToLowerInvariant(), IndvidByrDictry["LoanApplicant"], "Loan Applicant");
            }
            //
            var VestiNSalutDictry = FastDriver.BuyerSellerSetup.GetIndiviVestgNdSalutio;
            Support.AreEqual("a single man", VestiNSalutDictry["Marital Status"], "Marital Status");
            Support.AreEqual(string.IsNullOrEmpty(VestiNSalutDictry["Vesting"]) ? "" : "(vesting to be determined)", VestiNSalutDictry["Vesting"], "Vesting");
            Support.AreEqual(string.IsNullOrEmpty(VestiNSalutDictry["Addl Vesting"]) ? "" : "Full Vesting", VestiNSalutDictry["Addl Vesting"], "Addl Vesting");
            Support.AreEqual("", VestiNSalutDictry["Misc Ref 1"], "Misc Ref 1");
            Support.AreEqual("", VestiNSalutDictry["Misc Ref 2"], "Misc Ref 2");
            //
            ValidateAddressAndContactDetails(request);
        }

        public static void ValidateHusbandWifeBuyerSeller(UpdateBuyerSellerRequest request)
        {
            var HuWfAndVestDictry = FastDriver.BuyerSellerSetup.GetHusWfDtlsAuthSign(false);
            Support.AreEqual(request.BuyerSeller.FirstName, HuWfAndVestDictry["Husband1FirstName"], "Husband1FirstName");
            Support.AreEqual(request.BuyerSeller.LastName, HuWfAndVestDictry["Husband2LastName"], "Husband 2 LastName");
            Support.AreEqual(request.BuyerSeller.SpouseFirstName, HuWfAndVestDictry["HusbandSpouseFirstName"], "HusbandSpouse FirstName");
            Support.AreEqual(request.BuyerSeller.SpouseMiddleName, HuWfAndVestDictry["HusbandSpouseMiddleName"], "HusbandSpouse MiddleName");
            Support.AreEqual(request.BuyerSeller.SpouseLastName, HuWfAndVestDictry["HusbandSpouseLastName"], "HusbandSpouse LastName");
            Support.AreEqual(request.BuyerSeller.SpouseSuffix, HuWfAndVestDictry["HusbandSpouseSuffix"], "HusbandSpouse Suffix");
            if (request.PrincipalType == BuyerSellerPrincipalTypeOCD.Buyer)
            {
                Support.AreEqual(request.BuyerSeller.LoanApplicant.ToString().ToLowerInvariant(), HuWfAndVestDictry["HusbandLoanApplicant"], " Husband Loan Applicant");
                Support.AreEqual(request.BuyerSeller.SpouseLoanApplicant.ToString().ToLowerInvariant(), HuWfAndVestDictry["SpouseLoanApplicant"], "Spouse Loan Applicant");
            }
            //
            var VestiNSalutDictry = FastDriver.BuyerSellerSetup.GetIndiviVestgNdSalutio;
            Support.AreEqual("a married man", VestiNSalutDictry["Marital Status"], "Marital Status");
            Support.AreEqual("(vesting to be determined)", VestiNSalutDictry["Vesting"], "Vesting");
            Support.AreEqual("Full Vesting", VestiNSalutDictry["Addl Vesting"], "Addl Vesting");
            Support.AreEqual("", VestiNSalutDictry["Misc Ref 1"], "Misc Ref 1");
            Support.AreEqual("", VestiNSalutDictry["Misc Ref 2"], "Misc Ref 2");
            //
            ValidateAddressAndContactDetails(request);
        }

        public static void ValidateTrustEstateBuyerSeller(UpdateBuyerSellerRequest request)
        {
            var TrstEstByrDictry = FastDriver.BuyerSellerSetup.GetTrstestByrDtls(false);
            Support.AreEqual(request.BuyerSeller.ShortName, TrstEstByrDictry["TrusteeShortName"], "Trustee Short Name");
            Support.AreEqual(DateTime.Today.AddYears(-1).ToDateString(), TrstEstByrDictry["TrustDated"], "Trust Dated");
            Support.AreEqual(request.BuyerSeller.TrustNumber, TrstEstByrDictry["TrustNumber"], "Trust Number");
            Support.AreEqual("123-45-6789", TrstEstByrDictry["TrustSSNtext"], "Trust Ssn Text");
            if (request.PrincipalType == BuyerSellerPrincipalTypeOCD.Buyer)
            {
                Support.AreEqual(request.BuyerSeller.LoanApplicant.ToString().ToLowerInvariant(), TrstEstByrDictry["LoanApplicant"], "Loan Applicant");
            }
            ValidateAddressAndContactDetails(request);
        }

        public static void ValidateBusinessBuyerSeller(UpdateBuyerSellerRequest request)
        {
            var BusEntByrDictry = FastDriver.BuyerSellerSetup.GetBusEntByrDtls;
            Support.AreEqual(request.BuyerSeller.ShortName, BusEntByrDictry["BusinessEntityShortname"], "Bus Entity Shortname");
            Support.AreEqual("California", BusEntByrDictry["StateofIncorp"], "State of Incorp");
            Support.AreEqual("Business Trust", BusEntByrDictry["EntityType"], "Entity Type");
            Support.AreEqual("123-45-6789", BusEntByrDictry["BusinessEntitySSN"], "Business Entity Ssn");
            if (request.PrincipalType == BuyerSellerPrincipalTypeOCD.Buyer)
            {
                Support.AreEqual(request.BuyerSeller.LoanApplicant.ToString().ToLowerInvariant(), BusEntByrDictry["LoanApplicant"], "Loan Applicant");
            }
            ValidateAddressAndContactDetails(request);
        }

        public static void ValidateAddressAndContactDetails(UpdateBuyerSellerRequest request)
        {
            var CurAddrDictry = FastDriver.BuyerSellerSetup.GetCurrAddrDtls;
            Support.AreEqual(request.BuyerSeller.CurrentAddress.AddrLine1, CurAddrDictry["Curr Addr Street 1"], "Curr Addr Street 1");
            Support.AreEqual(request.BuyerSeller.CurrentAddress.AddrLine2, CurAddrDictry["Curr Addr Street 2"], "Curr Addr Street 2");
            Support.AreEqual(request.BuyerSeller.CurrentAddress.AddrLine3, CurAddrDictry["Curr Addr Street 3"], "Curr Addr Street 3");
            Support.AreEqual(request.BuyerSeller.CurrentAddress.AddrLine4, CurAddrDictry["Curr Addr Street 4"], "Curr Addr City");
            Support.AreEqual(request.BuyerSeller.CurrentAddress.City, CurAddrDictry["Curr Addr City"], "Curr Addr City");
            Support.AreEqual(request.BuyerSeller.CurrentAddress.State, CurAddrDictry["Curr Addr State"], "Curr Addr State");
            Support.AreEqual(request.BuyerSeller.CurrentAddress.County, CurAddrDictry["Curr Addr County"], "Curr Addr County");
            Support.AreEqual(request.BuyerSeller.CurrentAddress.Country, CurAddrDictry["Curr Addr Country"], "Curr Addr Country");
            //
            var ForwdAdrDictry = FastDriver.BuyerSellerSetup.GetForwdAdrDtls;
            Support.AreEqual(request.BuyerSeller.ForwardingAddress.AddrLine1, ForwdAdrDictry["Forward Addr Street 1"], "Forward Addr Street 1");
            Support.AreEqual(request.BuyerSeller.ForwardingAddress.AddrLine2, ForwdAdrDictry["Forward Addr Street 2"], "Forward Addr Street 2");
            Support.AreEqual(request.BuyerSeller.ForwardingAddress.AddrLine3, ForwdAdrDictry["Forward Addr Street 3"], "Forward Addr Street 3");
            Support.AreEqual(request.BuyerSeller.ForwardingAddress.AddrLine4, ForwdAdrDictry["Forward Addr Street 4"], "Forward Addr City");
            Support.AreEqual(request.BuyerSeller.ForwardingAddress.City, ForwdAdrDictry["Forward Addr City"], "Forward Addr City");
            Support.AreEqual(request.BuyerSeller.ForwardingAddress.State, ForwdAdrDictry["Forward Addr State"], "Forward Addr State");
            Support.AreEqual(request.BuyerSeller.ForwardingAddress.Country, ForwdAdrDictry["Forward Addr Country"], "Forward Addr Country");
            Support.AreEqual(request.BuyerSeller.ForwardingAddress.County, ForwdAdrDictry["Forward Addr County"], "Forward Addr County");
            //
            var CurrPhoDictry = FastDriver.BuyerSellerSetup.GetCurrentPhoneDetails();
            Support.AreEqual("(991)889-8383", CurrPhoDictry["Home Phone"].First(), "Current PhoneNum");
            var ForwdPhoDictry = FastDriver.BuyerSellerSetup.GetForwardingPhoneDetails();
            Support.AreEqual("(991)889-8383", ForwdPhoDictry["Home Fax"].First(), "Forwarding PhoneNum");
        }

        public static void AddBuyerSeller(int fileID, int typeID, string principalType)
        {
            AddBuyerSellerRequest request;
            switch (typeID)
            {
                case BuyerSellerTypeCdID.Individual:
                    request = BuyerSellerHelpers.GetIndividualBuyerSellerRequest();
                    break;
                case BuyerSellerTypeCdID.HusbandAndWife:
                    request = BuyerSellerHelpers.GetHusbandWifeBuyerSellerRequest();
                    break;
                case BuyerSellerTypeCdID.TrustEstate:
                    request = BuyerSellerHelpers.GetTrustEstateBuyerSellerRequest();
                    break;
                case BuyerSellerTypeCdID.BusinessEntity:
                    request = BuyerSellerHelpers.GetBusinessTrustBuyerSellerRequest();
                    break;
                default:
                    throw new Exception("BuyerSellerTypeCdID is not valid: " + typeID);
            }
            request.FileID = fileID;
            request.BuyerSeller.BuyerSellerTypeID = typeID;
            if (typeID == BuyerSellerTypeCdID.TrustEstate)
            {
                request.BuyerSeller.Name = "FAST Trust";
            }
            request.PrincipalType = principalType;
            var response = FileService.AddBuyerSeller(request);
            Support.AreEqual("1", response.Status.ToString(), response.StatusDescription);
        }

    }
}
