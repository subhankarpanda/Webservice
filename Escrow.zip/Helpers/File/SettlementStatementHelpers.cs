﻿using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebServices.Helpers.File
{
    class SettlementStatementHelpers
    {
        public static SettlementStatementResponse GetSettlementStatementDetails(int fileID)
        {
            SettlementStatementResponse response = null;

            try
            {
                response = FASTWCFHelpers.FileService.GetSettlementStatementDetails(fileID);

                Reports.StatusUpdate("GetSettlementStatementDetails", true);

            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("GetSettlementStatementDetails", false, ex.Message);
            }

            return response;

        }

        public static GetSettlementStatementResponse GetSettlementStatementScreenDetails(int fileID)
        {
            GetSettlementStatementResponse response = null;

            try
            {
                var request = RequestFactory.GetSettlementStatementRequest(fileID);
                response = FASTWCFHelpers.FileService.GetSettlementStatementScreenDetails(request);

                Reports.StatusUpdate("GetSettlementStatementScreenDetails", true);

            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("GetSettlementStatementScreenDetails", false, ex.Message);
            }

            return response;

        }

        public static UpdateSettelementStatementResponse UpdateSettlementStatementDetails(int fileID, UpdateSettelementStatementRequestInfo info)
        {
            UpdateSettelementStatementResponse response = null;

            try
            {
                var request = RequestFactory.GetUpdateSettelementStatementRequest(fileID, info);
                response = FASTWCFHelpers.FileService.UpdateSettlementStatementDetails(request);

                Reports.StatusUpdate("UpdateSettlementStatementDetails", true);

            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("UpdateSettlementStatementDetails", false, ex.Message);
            }

            return response;

        }
    }
}
