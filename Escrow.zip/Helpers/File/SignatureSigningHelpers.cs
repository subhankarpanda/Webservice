﻿using FASTWCFHelpers.Factories;
using FASTWCFHelpers.FastFileService;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebServices.Helpers.File
{
    class SignatureSigningHelpers
    {
        public static OperationResponse SetDeliverSigningPackage(DeliverSigningPackageRequest request)
        {
            OperationResponse response = null;

            try
            {
                response = FASTWCFHelpers.FileService.SetDeliverSigningPackage(request);

                Reports.StatusUpdate("SetDeliverSigningPackage", true);

            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("SetDeliverSigningPackage", false, ex.Message);
            }

            return response;

        }

        public static OrderSigningResponse GetSignatureSigning(int fileId)
        {
            OrderSigningResponse response = null;

            try
            {
                response = FASTWCFHelpers.FileService.GetSignatureSigning(fileId);

                Reports.StatusUpdate("GetSignatureSigning", true);

            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("GetSignatureSigning", false, ex.Message);
            }

            return response;

        }

        public static OperationResponse SetOrderSigning(int fileId, int signingId)
        {
            OperationResponse response = null;

            try
            {
                var request = FileRequestFactory.GetOrderSigningRequest(fileId, signingId);
                response = FASTWCFHelpers.FileService.SetOrderSigning(request);

                Reports.StatusUpdate("SetOrderSigning", true);

            }
            catch (Exception ex)
            {
                Reports.StatusUpdate("SetOrderSigning", false, ex.Message);
            }

            return response;

        }
    }
}
