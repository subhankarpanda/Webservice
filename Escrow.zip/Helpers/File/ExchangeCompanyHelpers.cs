﻿using FASTSelenium.Common;
using FASTWCFHelpers;
using FASTWCFHelpers.DataObjects;
using FASTWCFHelpers.FastFileService;
using SeleniumInternalHelpersSupportLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebServices.Helpers.File
{
    public class ExchangeCompanyHelpers
    {
        public static void AddExchangeCompany(string principalType, int summaryID, string gabCode)
        {
            bool isBuyer = principalType == BuyerSellerPrincipalTypeOCD.Buyer;
            FastDriver.BuyerSellerSummary.Open(isBuyer, summaryID);
            FastDriver.BuyerSellerSetup.btnExchangeCompany.FAClick();
            FastDriver.ExchangeCompany.WaitForScrenToLoad();
            FastDriver.ExchangeCompany.FindGAB(gabCode);
            FastDriver.BottomFrame.Done();
        }

        public static void VerifyExchangeCompany(string principalType, int summaryID, string gabCode)
        {
            bool isBuyer = principalType == BuyerSellerPrincipalTypeOCD.Buyer;
            FastDriver.BuyerSellerSummary.Open(isBuyer, summaryID);
            FastDriver.BuyerSellerSetup.btnExchangeCompany.FAClick();
            FastDriver.ExchangeCompany.WaitForScrenToLoad();
            Support.AreEqual(gabCode, FastDriver.ExchangeCompany.GABIdCodeLabel.FAGetText(), "Exchange Company IDCode label"); 
        }

        public static void VerifyExchangeCompany(int fileID, string gabCode)
        {
            var details = ExchangeCompanyHelpers.GetExchangeCompany(fileID);
            Support.IsTrue(details.ExchangeCompanies.Count() > 0, "ExchangeCompanies is not an empty set");
            Support.AreEqual(gabCode, details.ExchangeCompanies[0].FileBusinessParty.IDCode);
        }

        public static ExchangeCompanyResponse GetExchangeCompany(int fileID)
        {
            var details = FileService.GetExchangeCompany(fileID);
            Support.IsTrue(details.ExchangeCompanies.Count() > 0, "ExchangeCompanies is not an empty set");

            return details;
        }

        public static OperationResponse DeleteExchangeCompany(int fileID)
        {
            var details = ExchangeCompanyHelpers.GetExchangeCompany(fileID);
            var deleteResponse = FileService.DeleteExchangeCompany(details.ExchangeCompanies[0].FileBusinessParty.FileBusinessPartyID ?? 0);
            Support.AreEqual("1", deleteResponse.Status.ToString(), deleteResponse.StatusDescription);

            return deleteResponse;
        }
    }
}
